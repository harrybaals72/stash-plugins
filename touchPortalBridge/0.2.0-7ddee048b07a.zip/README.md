# touchPortalBridge

Touch Portal Bridge connects each open Stash tab to the **Stash Bridge** controller plugins: Touch Portal ([`touchportal/StashBridge`](../../touchportal/StashBridge/README.md)) and Stream Deck ([`streamdeck/com.hb72.stashbridge.sdPlugin`](../../streamdeck/com.hb72.stashbridge.sdPlugin/README.md)). Each controller shows what its controlled tab is doing (page kind, scene title, performers, playback time, speed, cover) and its buttons act on that tab: play/pause, skips, speed, markers, seeking, navigation, and Quick Tagger tags and markers. Nothing depends on keyboard focus or typed text, so several Stash tabs, and both controllers, can be used at once.

Quick tag and quick marker commands run Quick Tagger's own task (`runPluginOperation` on `quickTagger`) with the same arguments its dialogs send, so Quick Tagger must be installed. Its *Create missing tags* and *Marker preroll seconds* settings apply.

## Settings

- `bridgeUrl` (STRING, default `ws://127.0.0.1:47821, ws://127.0.0.1:47822`): the controllers' WebSocket addresses, comma-separated (Touch Portal, then Stream Deck). Each port must match that plugin's *WebSocket port* setting. A controller that is not running costs one failed connection every 30 seconds.
- `bridgeToken` (STRING): only needed when this Stash address is not in a bridge's allowed origins; use the same value as that bridge's access token.
- `hideIndicator` (BOOLEAN, default `false`): hide the badge (**Touch Portal**, **Stream Deck**) that marks the controlled tab when several tabs are open or it is pinned.
- `paletteTagPrefix` (STRING, default `Deck:`): tags whose name starts with this become controller tag palettes, and their child tags become palette keys. *Deck: Positions* makes a *Positions* palette. Clear it to turn palettes off.
- `quietTab` (BOOLEAN, default `false`): don't show the message at the top of the tab after a quick tag, marker, rating, undo, or confirmation request; the controllers still show results.

## Behavior

- Every tab connects to each bridge URL and reconnects on its own (after 1, 2, 5, 10, and 10 seconds, then every 30 seconds), so restarting Touch Portal, Stream Deck, or a bridge needs no reload.
- A tab reports its page kind (`scene`, `performer`, `list`, `other`), the scene or performer it shows, and the scene player's state. Playback time is sent at most once a second; play, pause, seek, speed, focus, and visibility changes are sent at once.
- Each bridge picks its controlled tab: a pinned tab, else the focused tab, else the most recently focused tab. With several tabs, that tab shows a badge naming the controllers whose target it is, for example **Stream Deck and Touch Portal** or **Stream Deck (pinned)**.
- On a scene page, the tab also sends each bridge a 144-pixel square of the scene's cover once, for Stream Deck's cover key. The tab fetches it because only the tab is signed in to Stash.
- Quick tags apply to the open scene, or to the open performer on a performer page. Quick markers need a scene page with a player and use the current playback time minus Quick Tagger's preroll. Missing tags are created only when the Touch Portal action says *Yes* and Quick Tagger allows it.
- After a quick tag or marker, the tab refreshes Stash's scene, marker, and performer queries and shows a short green (or red, on error) message at the top of the page. The result also appears in Touch Portal's *last command result* state.
- *Go to Stash page* uses Stash's router, so navigation keeps the single-page app state.
- The tab reports, for the scene (or the performer on a performer page): each tag's status by name (yours, from a marker, from a performer, plain), the rating, organized, and the queue position read from Stash's queue panel. Quick Tagger's sub-tags are matched to their tag by custom field, so renamed sub-tags still count.
- Queue commands trigger Stash's own `p n`, `p p`, and `p r` shortcuts, so Stash keeps its queue, autoplay, and *continue* settings. "Afterwards: Next scene" runs the next-scene shortcut once a tag, marker, rating, or organized change is saved.
- **Undo**: the tab keeps the last 20 changes made from any controller: quick tags (only what that press added, using Quick Tagger's `removeTag` with the scenes it changed), removed tags (re-applied), quick markers (deleted), ratings, organized, and added suggestions (removed again). The newest is reported with a label such as *tag Curly* or *rating 3★ → 4★*, and an undo names the change it expects, so a list that changed in between is refused. Reloading the tab clears the list.
- **Removing** a tag goes through Quick Tagger's `removeTag`; the controllers ask for a second press first and send a *notify* command, shown at the top of the tab, naming what will happen.
- **Palettes** are read when the tab connects and whenever it changes page. **Recent tags** (the last 24 applied from any controller) and **session counts** (scenes moved on from, tags, and markers since the last reset) are kept in the browser's local storage, so every tab shares them.
- **Suggestions** come from the Tag & Performer Suggestions plugin (`window.TagPerformerSuggestions`). A tab works them out once per scene, only while a controller asks for them (a Stream Deck suggestion key is showing, or a Touch Portal device shows a Stash Bridge page). Adding one adds exactly that tag or performer; dismissing hides it until the tab leaves the scene.
- **Hold to seek** plays at 16x, or rewinds at 16x by seeking back every 50 ms. Release restores the speed and play state and returns to where the video was 400 ms earlier, never past where the hold began. A hold also ends when its controller disconnects.
- **List filters**: on a list page (scenes, performers, markers, images, galleries, …) the tab reports the list's sort, direction, page, the tags it requires or hides, and the organized filter, read from the URL. The *listFilter* command changes that URL the way Stash's own filter controls do (Stash rereads its filter whenever the URL changes): sort by a field (again flips the direction), flip the direction, shuffle (random order), cycle the organized filter (any, not organized, organized), clear all filters, change page, or toggle a tag in the tag filter as required or hidden. Tags are found by name; a new tag filter includes sub-tags, so Quick Tagger's *A (user)* and *A (marker)* count as *A*. Filter changes return to page 1.
- **Performer image** uses the Scene Frame Performer Image plugin (`window.SceneFramePerformerImage`): open its picker, or save the current frame for the scene's only performer. An existing image is never replaced without a confirming second press.
- Stash's default content security policy already allows WebSocket connections, so the plugin needs no CSP entries.

## Tests

```text
npm run stash -- test --plugin touchPortalBridge --suite unit
npm run stash -- test --plugin touchPortalBridge --suite ui
```

The UI suite starts a disposable Stash with Quick Tagger and this plugin and runs three tests:

- `touch-portal-bridge.e2e.test.js` runs the real Touch Portal bridge (`touchportal/StashBridge/src/bridge.js`) against a fake Touch Portal socket and drives two Playwright tabs. It covers states, playback, skips, the seek slider, markers, hold-for-speed, quick tags (including a refused missing tag), quick markers, focus following, pinning, navigation, closing a tab, and reconnecting after the bridge restarts.
- `triage.e2e.test.js` installs Quick Tagger, Tag & Performer Suggestions, and Scene Frame Performer Image too, and drives the real Stream Deck plugin through a queue of 14 scenes. It covers the queue position, tag status, a confirmed removal, undo of that removal, rating, organized, palettes and recent tags, a real suggestion, holding to 16x and jumping back, saving and confirming a replacement performer image, session counts, "then next scene", and, on the scene list, sorting, flipping, filtering by a palette tag, hiding it, clearing, and the organized filter.
- `stream-deck-bridge.e2e.test.js` runs the real Stream Deck plugin (`streamdeck/com.hb72.stashbridge.sdPlugin/src/plugin.js`) against a fake Stream Deck app, with the Touch Portal bridge also running and one tab connected to both. It covers key images (title, time, cover, speed), play, skip, markers, tapped and held speed, quick tags and markers, pinning and the badge, navigation, alerts on failed presses, and turning between the Stash profile's Player and Browse pages.

Playwright reports every page as focused, so the test replaces each tab's `document.hasFocus()` with a switch. Check real focus by hand: open two Stash tabs in two browser windows, focus each in turn, and confirm the **Stash: controlled tab** state and the badge follow.

Leaving a scene right after it loads can hit races in Stash's own player, which Stash's own links and queue shortcuts trigger too: `Cannot read properties of null (reading 'querySelector')` (`ScenePlayer/markers.ts` draws marker dots in an animation frame after the player is disposed), `Cannot read properties of null (reading '$')` (`ScenePlayer/vtt-thumbnails.ts` sets up thumbnail sprites when their fetch resolves on a disposed player), and the browser's *The play() request was interrupted by a new load request* when the queue loads the next scene while the old one starts playing. The tests ignore only those three (`isKnownStashRace` in `tests/ui/controller-harness.js`).
