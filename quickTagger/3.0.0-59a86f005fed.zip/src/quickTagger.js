(function () {
  var api = window.PluginApi;
  if (!api) return;

  var React = api.React;
  var ReactDOM = api.ReactDOM;
  var patch = api.patch;
  var Mousetrap = api.libraries && api.libraries.Mousetrap;

  var PLUGIN_ID = "quickTagger";
  var TASK_APPLY = "Apply quick tag";
  var TASK_MARKER = "Create quick marker";

  var DEFAULTS = {
    createMissingTags: true,
    skipCreateConfirmation: false,
    applyToPerformerScenes: true,
    scanAfterUpdate: false,
    waitForScan: true,
    markerPrerollSeconds: 5,
    quickTagShortcut: "alt+q",
    quickMarkerShortcut: "alt+m",
    showToasts: true,
  };

  // runPluginOperation returns the task's output, or its error as a GraphQL error.
  // runPluginTask jobs finish as FINISHED even when the task returns an error.
  var RUN_PLUGIN_OPERATION = "mutation QuickTaggerRunPluginOperation($plugin_id: ID!, $args: Map){ runPluginOperation(plugin_id:$plugin_id, args:$args) }";
  var CONFIG = "query QuickTaggerConfig { configuration { plugins } }";
  var FIND_TAGS = "query QuickTaggerFindTags($tag_filter: TagFilterType, $filter: FindFilterType){ findTags(tag_filter:$tag_filter, filter:$filter){ tags{ id name aliases } } }";
  // Quick Tagger's own sub-tags ("A (user)" etc.) carry this custom field.
  var ROLE_FIELD = "quickTagger_role";
  var SUGGESTION_LIMIT = 10;
  var SUGGESTION_DELAY_MS = 200;
  // Stash's own queries that show what a quick tag or marker changes.
  var REFRESH_QUERIES = ["FindScene", "FindSceneMarkerTags", "FindPerformer"];

  function trim(v) { return String(v || "").replace(/^\s+|\s+$/g, ""); }
  function escapeRegex(v) { return String(v).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&"); }

  function gql(query, variables) {
    return fetch("/graphql", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: query, variables: variables || {} }),
    })
      .then(function (r) { return r.json(); })
      .then(function (json) {
        if (json.errors && json.errors.length) throw new Error(json.errors[0].message || "GraphQL error");
        return json.data;
      });
  }

  async function loadSettings() {
    try {
      var data = await gql(CONFIG, {});
      var pluginCfg = data && data.configuration && data.configuration.plugins ? data.configuration.plugins[PLUGIN_ID] : null;
      return Object.assign({}, DEFAULTS, pluginCfg || {});
    } catch (_err) {
      return Object.assign({}, DEFAULTS);
    }
  }

  async function runTask(args) {
    var data = await gql(RUN_PLUGIN_OPERATION, { plugin_id: PLUGIN_ID, args: args });
    return data ? data.runPluginOperation : null;
  }

  // Suggests plain tags only; the "A (user)" style sub-tags are created and chosen
  // by the task.
  async function suggestTags(text) {
    var data = await gql(FIND_TAGS, {
      tag_filter: {
        name: { value: "(?i)" + escapeRegex(text), modifier: "MATCHES_REGEX" },
        custom_fields: [{ field: ROLE_FIELD, modifier: "IS_NULL" }],
      },
      filter: { per_page: 25, sort: "name", direction: "ASC" },
    });
    var needle = text.toLowerCase();
    var rows = (data && data.findTags && data.findTags.tags) || [];
    var items = [];
    for (var i = 0; i < rows.length; i += 1) {
      var name = String(rows[i].name || "");
      var at = name.toLowerCase().indexOf(needle);
      if (at < 0) continue;
      items.push({ id: String(rows[i].id), label: name, prefix: at === 0 });
    }
    items.sort(function (a, b) { return a.prefix === b.prefix ? 0 : a.prefix ? -1 : 1; });
    return items.slice(0, SUGGESTION_LIMIT);
  }

  function sameText(a, b) { return String(a || "").toLowerCase() === String(b || "").toLowerCase(); }

  // Mirrors the task: the text names an existing tag by name (including a Quick
  // Tagger sub-tag's name) or by alias. Stash runs EQUALS as a case-insensitive LIKE.
  async function tagExists(text) {
    var byName = await gql(FIND_TAGS, { tag_filter: { name: { value: text, modifier: "EQUALS" } }, filter: { per_page: -1 } });
    var names = (byName && byName.findTags && byName.findTags.tags) || [];
    if (names.some(function (t) { return sameText(t.name, text); })) return true;
    var byAlias = await gql(FIND_TAGS, { tag_filter: { aliases: { value: text, modifier: "EQUALS" } }, filter: { per_page: -1 } });
    var aliased = (byAlias && byAlias.findTags && byAlias.findTags.tags) || [];
    return aliased.some(function (t) { return (t.aliases || []).some(function (a) { return sameText(a, text); }); });
  }

  // The task writes through its own GraphQL connection, so Stash's Apollo cache
  // does not see the change until these queries run again.
  function refreshStashQueries() {
    var service = api.utils && api.utils.StashService;
    var client = service && service.getClient ? service.getClient() : null;
    if (!client || !client.refetchQueries) return Promise.resolve();
    return Promise.resolve(client.refetchQueries({ include: REFRESH_QUERIES })).catch(function () {});
  }

  // focus() alone scrolls the page to the element.
  function focusWithoutScroll(el) {
    if (el && el.focus) el.focus({ preventScroll: true });
  }

  // Scrolls the suggestion list, not the page, to a highlighted row.
  function keepInList(el) {
    var list = el && el.parentNode;
    if (!list) return;
    if (el.offsetTop < list.scrollTop) list.scrollTop = el.offsetTop;
    else if (el.offsetTop + el.offsetHeight > list.scrollTop + list.clientHeight) list.scrollTop = el.offsetTop + el.offsetHeight - list.clientHeight;
  }

  function emptySuggestions() { return { items: [], active: -1, open: false }; }

  // The scene player's own video. Marker previews in the sidebar are videos too
  // and come before the player on the page.
  function getSceneSeconds() {
    var video = document.querySelector(".scene-player-container video");
    if (!video) return 0;
    return Number(video.currentTime || 0);
  }

  var shortcutRegistry = {};

  function bindShortcut(key, handler) {
    if (!Mousetrap || !key) return;
    if (shortcutRegistry[key]) Mousetrap.unbind(key);
    Mousetrap.bind(key, handler);
    shortcutRegistry[key] = true;
  }

  function unbindShortcut(key) {
    if (!Mousetrap || !key) return;
    Mousetrap.unbind(key);
    delete shortcutRegistry[key];
  }

  function QuickTaggerControls(props) {
    var targetType = props.targetType;
    var targetId = props.targetId;
    var sceneId = props.sceneId || "";
    var showMarker = !!props.showMarker;

    var useState = React.useState;
    var useEffect = React.useEffect;
    var useMemo = React.useMemo;
    var useRef = React.useRef;

    var _state = useState(false), tagOpen = _state[0], setTagOpen = _state[1];
    var _state2 = useState(false), markerOpen = _state2[0], setMarkerOpen = _state2[1];
    var _state3 = useState(""), tagText = _state3[0], setTagText = _state3[1];
    var _state4 = useState(""), markerText = _state4[0], setMarkerText = _state4[1];
    var _state5 = useState(false), busy = _state5[0], setBusy = _state5[1];
    var _state6 = useState(DEFAULTS), settings = _state6[0], setSettings = _state6[1];
    var _state7 = useState(emptySuggestions()), tagSuggest = _state7[0], setTagSuggest = _state7[1];
    var _state8 = useState(emptySuggestions()), markerSuggest = _state8[0], setMarkerSuggest = _state8[1];
    // { kind, tagName, args } while asking whether a missing tag should be created.
    var _state9 = useState(null), pending = _state9[0], setPending = _state9[1];
    var toast = api.hooks.useToast();

    var containerID = useMemo(function () {
      return "quickTagger-controls-" + targetType + "-" + targetId;
    }, [targetType, targetId]);

    var activeRef = useRef({ targetType: targetType, targetId: targetId });
    var tagInputRef = useRef(null);
    var markerInputRef = useRef(null);
    var confirmRef = useRef(null);
    // Text set by choosing a suggestion, so choosing does not reopen the list.
    var chosenRef = useRef({ tag: null, marker: null });
    // Set before the first await, so a repeated Enter or click cannot start a
    // second task (and a second marker) before the busy state re-renders.
    var runningRef = useRef(false);
    activeRef.current = { targetType: targetType, targetId: targetId };

    var fields = {
      tag: {
        task: TASK_APPLY, label: "Quick tag", success: "Quick tag applied",
        text: tagText, setText: setTagText, setOpen: setTagOpen,
        suggest: tagSuggest, setSuggest: setTagSuggest, inputRef: tagInputRef,
        listID: containerID + "-tag-suggestions",
      },
      marker: {
        task: TASK_MARKER, label: "Quick marker", success: "Quick marker created",
        text: markerText, setText: setMarkerText, setOpen: setMarkerOpen,
        suggest: markerSuggest, setSuggest: setMarkerSuggest, inputRef: markerInputRef,
        listID: containerID + "-marker-suggestions",
      },
    };

    useEffect(function () {
      var alive = true;
      loadSettings().then(function (s) { if (alive) setSettings(s); });
      return function () { alive = false; };
    }, []);

    useEffect(function () {
      if (!Mousetrap) return;
      function onQuickTag() { setTagOpen(true); return false; }
      function onQuickMarker() { if (showMarker) setMarkerOpen(true); return false; }

      var quickTagKey = settings.quickTagShortcut || DEFAULTS.quickTagShortcut;
      var quickMarkerKey = settings.quickMarkerShortcut || DEFAULTS.quickMarkerShortcut;
      bindShortcut(quickTagKey, onQuickTag);
      if (showMarker) bindShortcut(quickMarkerKey, onQuickMarker);

      return function () {
        unbindShortcut(quickTagKey);
        if (showMarker) unbindShortcut(quickMarkerKey);
      };
    }, [settings.quickTagShortcut, settings.quickMarkerShortcut, showMarker]);

    var pendingKind = pending ? pending.kind : null;
    useEffect(function () {
      if (tagOpen && pendingKind !== "tag") focusWithoutScroll(tagInputRef.current);
    }, [tagOpen, pendingKind]);

    useEffect(function () {
      if (markerOpen && pendingKind !== "marker") focusWithoutScroll(markerInputRef.current);
    }, [markerOpen, pendingKind]);

    useEffect(function () {
      if (pendingKind) focusWithoutScroll(confirmRef.current);
    }, [pendingKind]);

    useEffect(function () {
      return scheduleSuggestions("tag", tagOpen ? tagText : "");
    }, [tagOpen, tagText]);

    useEffect(function () {
      return scheduleSuggestions("marker", markerOpen ? markerText : "");
    }, [markerOpen, markerText]);

    function scheduleSuggestions(kind, value) {
      var text = trim(value);
      if (!text || chosenRef.current[kind] === text) return undefined;
      var setSuggest = fields[kind].setSuggest;
      var alive = true;
      var timer = setTimeout(function () {
        suggestTags(text)
          .then(function (items) {
            if (!alive) return;
            // Keep a tag highlighted (by Tab or the arrows) while results were loading.
            setSuggest(function (prev) {
              var kept = prev.active >= 0 ? prev.items[prev.active] : null;
              var active = -1;
              for (var i = 0; kept && i < items.length; i += 1) if (items[i].id === kept.id) active = i;
              return { items: items, active: active, open: items.length > 0 };
            });
          })
          .catch(function () { if (alive) setSuggest(emptySuggestions()); });
      }, SUGGESTION_DELAY_MS);
      return function () { alive = false; clearTimeout(timer); };
    }

    function changeText(kind, value) {
      var field = fields[kind];
      chosenRef.current[kind] = null;
      field.setText(value);
      // Drop the highlight and stale rows now; fresh results arrive after the debounce.
      var needle = trim(value).toLowerCase();
      field.setSuggest(function (prev) {
        var items = needle ? prev.items.filter(function (item) { return item.label.toLowerCase().indexOf(needle) >= 0; }) : [];
        return { items: items, active: -1, open: prev.open && items.length > 0 };
      });
    }

    function chooseSuggestion(kind, item) {
      var field = fields[kind];
      chosenRef.current[kind] = item.label;
      field.setText(item.label);
      field.setSuggest(emptySuggestions());
      focusWithoutScroll(field.inputRef.current);
    }

    function setSuggestionsOpen(kind, open) {
      fields[kind].setSuggest(function (prev) {
        return { items: prev.items, active: -1, open: open && prev.items.length > 0 };
      });
    }

    function closeField(kind) {
      var field = fields[kind];
      field.setOpen(false);
      // Unsubmitted text is dropped, so the dialog reopens empty.
      field.setText("");
      chosenRef.current[kind] = null;
      field.setSuggest(emptySuggestions());
      if (pending && pending.kind === kind) setPending(null);
    }

    function onFieldKeyDown(kind, e) {
      var field = fields[kind];
      var suggest = field.suggest;
      var count = suggest.items.length;
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        if (!count) return;
        e.preventDefault();
        var step = e.key === "ArrowDown" ? 1 : -1;
        var next = suggest.open && suggest.active >= 0 ? (suggest.active + step + count) % count : (step > 0 ? 0 : count - 1);
        field.setSuggest({ items: suggest.items, active: next, open: true });
      } else if (e.key === "Tab") {
        if (!suggest.open || !count) return;
        // Tab walks the suggestions, then back to the text box (-1). Focus stays in
        // the input throughout, so typing carries on and drops the highlight.
        e.preventDefault();
        var at = suggest.active + (e.shiftKey ? -1 : 1);
        if (at >= count) at = -1;
        else if (at < -1) at = count - 1;
        field.setSuggest({ items: suggest.items, active: at, open: true });
      } else if (e.key === "Enter") {
        // Enter fills a highlighted suggestion; it submits only from the text box.
        e.preventDefault();
        var item = suggest.open && suggest.active >= 0 ? suggest.items[suggest.active] : null;
        if (item) chooseSuggestion(kind, item);
        else submitField(kind);
      } else if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        if (suggest.open) setSuggestionsOpen(kind, false);
        else closeField(kind);
      }
    }

    function emitError(task, err) {
      if (settings.showToasts) toast.error(err);
      window.dispatchEvent(new CustomEvent("quickTagger:task-error", { detail: { task: task, error: String(err && err.message ? err.message : err) } }));
    }

    function taskArgs(kind, text) {
      if (kind === "marker") {
        return {
          mode: "createMarker",
          sceneId: sceneId,
          targetType: "scene",
          text: text,
          seconds: getSceneSeconds(),
          createMissingTags: settings.createMissingTags,
          markerPrerollSeconds: settings.markerPrerollSeconds,
        };
      }
      return {
        mode: "applyTag",
        targetType: activeRef.current.targetType,
        targetId: activeRef.current.targetId,
        text: text,
        createMissingTags: settings.createMissingTags,
        applyToPerformerScenes: settings.applyToPerformerScenes,
        scanAfterUpdate: settings.scanAfterUpdate,
        waitForScan: settings.waitForScan,
        markerPrerollSeconds: settings.markerPrerollSeconds,
      };
    }

    function exclusive(work) {
      if (runningRef.current) return;
      runningRef.current = true;
      work().finally(function () { runningRef.current = false; });
    }

    function submitField(kind) {
      exclusive(function () { return submitText(kind); });
    }

    async function submitText(kind) {
      var field = fields[kind];
      var text = trim(field.inputRef.current ? field.inputRef.current.value : field.text);
      if (!text) {
        emitError(field.task, field.label + " text is required");
        return;
      }

      // Marker seconds are captured now, before any confirmation prompt.
      var args = taskArgs(kind, text);
      var tagName = text;
      setBusy(true);
      var exists = null;
      try { exists = await tagExists(tagName); } catch (_err) { exists = null; }
      if (exists === false) {
        if (!settings.createMissingTags) {
          setBusy(false);
          emitError(field.task, "Tag " + tagName + " does not exist and creating missing tags is disabled");
          return;
        }
        if (!settings.skipCreateConfirmation) {
          setBusy(false);
          setPending({ kind: kind, tagName: tagName, args: args });
          return;
        }
      }
      // A failed lookup leaves the decision to the task and createMissingTags.
      await runField(kind, args);
    }

    async function runField(kind, args) {
      var field = fields[kind];
      setBusy(true);
      try {
        var result = await runTask(args);
        setPending(null);
        field.setOpen(false);
        field.setText("");
        field.setSuggest(emptySuggestions());
        if (settings.showToasts) toast.success(field.success);
        await refreshStashQueries();
        window.dispatchEvent(new CustomEvent("quickTagger:task-complete", { detail: { task: field.task, args: args, result: result } }));
      } catch (err) {
        setPending(null);
        emitError(field.task, err);
      } finally {
        setBusy(false);
      }
    }

    function confirmCreate() {
      if (!pending) return;
      exclusive(function () { return runField(pending.kind, Object.assign({}, pending.args, { createMissingTags: true })); });
    }

    function declineCreate() {
      setPending(null);
    }

    function renderConfirm(kind) {
      return React.createElement("div", {
        className: "quick-tagger-confirm",
        role: "group",
        "aria-label": "Create missing tag",
        onKeyDown: function (e) {
          if (e.key !== "Escape") return;
          e.preventDefault();
          e.stopPropagation();
          declineCreate();
        },
      },
        React.createElement("p", { style: { margin: "0 0 0.5rem" } },
          "Tag \"" + pending.tagName + "\" does not exist. " + (kind === "marker" ? "Create it for this marker?" : "Create it?")),
        React.createElement("button", { type: "button", ref: function (el) { confirmRef.current = el; }, className: "btn btn-primary", onClick: confirmCreate, disabled: busy }, "Create tag"),
        React.createElement("button", { type: "button", className: "btn btn-secondary", onClick: declineCreate, disabled: busy }, "Don't create"),
        React.createElement("button", { type: "button", className: "btn btn-secondary", onClick: function () { closeField(kind); } }, "Cancel")
      );
    }

    function renderInput(kind) {
      var field = fields[kind];
      var suggest = field.suggest;
      var showList = suggest.open && suggest.items.length > 0;
      var inputProps = {
        type: "text",
        ref: function (el) { field.inputRef.current = el; },
        value: field.text,
        onChange: function (e) { changeText(kind, e.target.value); },
        onKeyDown: function (e) { onFieldKeyDown(kind, e); },
        onFocus: function () { setSuggestionsOpen(kind, true); },
        onBlur: function () { setSuggestionsOpen(kind, false); },
        placeholder: field.label,
        autoComplete: "off",
        role: "combobox",
        "aria-autocomplete": "list",
        "aria-expanded": showList ? "true" : "false",
      };
      if (showList) inputProps["aria-controls"] = field.listID;
      if (showList && suggest.active >= 0) inputProps["aria-activedescendant"] = field.listID + "-" + suggest.active;

      return React.createElement("span", { style: { position: "relative", display: "inline-block" } },
        React.createElement("input", inputProps),
        showList ? React.createElement("ul", {
          id: field.listID,
          role: "listbox",
          className: "dropdown-menu show quick-tagger-suggestions",
          style: { position: "absolute", top: "100%", left: 0, minWidth: "100%", maxHeight: "16rem", overflowY: "auto", zIndex: 1060 },
        }, suggest.items.map(function (item, index) {
          var active = index === suggest.active;
          var itemProps = {
            key: item.id,
            id: field.listID + "-" + index,
            role: "option",
            "aria-selected": active ? "true" : "false",
            className: "dropdown-item" + (active ? " active" : ""),
            style: { cursor: "pointer" },
            // mousedown keeps focus in the input, so blur does not close the list first.
            onMouseDown: function (e) { e.preventDefault(); chooseSuggestion(kind, item); },
          };
          if (active) itemProps.ref = keepInList;
          return React.createElement("li", itemProps, item.label);
        })) : null
      );
    }

    function renderDialog(kind) {
      var confirming = !!pending && pending.kind === kind;
      // Fixed to the viewport so it shows wherever the page is scrolled. Dialogs
      // default to the user agent's dark text colour; inherit Stash's instead.
      var dialogProps = {
        open: true,
        className: "bg-dark quick-tagger-dialog",
        style: {
          position: "fixed", top: "5rem", left: 0, right: 0, margin: "0 auto", zIndex: 1050,
          border: "none", borderRadius: "0.25rem", boxShadow: "0 0.5rem 1rem rgba(0, 0, 0, 0.5)",
          overflow: "visible", color: "inherit",
        },
      };
      var dialog = confirming
        ? React.createElement("dialog", dialogProps, renderConfirm(kind))
        : React.createElement("dialog", dialogProps,
          renderInput(kind),
          React.createElement("button", { type: "button", className: "btn btn-primary", onClick: function () { submitField(kind); }, disabled: busy }, "Submit"),
          React.createElement("button", { type: "button", className: "btn btn-secondary", onClick: function () { closeField(kind); } }, "Cancel")
        );
      // A collapsed scene sidebar is hidden, so the dialog lives outside it.
      return ReactDOM && ReactDOM.createPortal ? ReactDOM.createPortal(dialog, document.body) : dialog;
    }

    return React.createElement(
      "div",
      { id: containerID, className: "quick-tagger-controls", style: { marginBottom: "0.75rem", display: "flex", gap: "0.5rem", alignItems: "center" } },
      React.createElement("button", { type: "button", className: "btn btn-secondary", onClick: function () { setTagOpen(true); }, disabled: busy }, "Quick Tagger"),
      showMarker ? React.createElement("button", { type: "button", className: "btn btn-secondary", onClick: function () { setMarkerOpen(true); }, disabled: busy }, "Quick Marker") : null,
      tagOpen ? renderDialog("tag") : null,
      markerOpen ? renderDialog("marker") : null
    );
  }

  // React passes components a second argument, which would arrive in an after
  // patch ahead of the rendered result; pass on the props alone.
  patch.before("ScenePage.TabContent", function (props) {
    return [props];
  });

  // Inside the sidebar's tab content: anything rendered beside ScenePage itself
  // becomes a column of the scene row and pushes the player below the sidebar.
  patch.after("ScenePage.TabContent", function (props, result) {
    var sceneID = props && props.scene && props.scene.id ? String(props.scene.id) : "";
    if (!sceneID) return result;
    return React.createElement(React.Fragment, null,
      React.createElement(QuickTaggerControls, { targetType: "scene", targetId: sceneID, sceneId: sceneID, showMarker: true }),
      result
    );
  });

  patch.before("PerformerPage", function (props) {
    return [props];
  });

  patch.after("PerformerPage", function (props, result) {
    var performerID = props && props.performer && props.performer.id ? String(props.performer.id) : "";
    if (!performerID) return result;
    return React.createElement(React.Fragment, null,
      React.createElement(QuickTaggerControls, { targetType: "performer", targetId: performerID, sceneId: "", showMarker: false }),
      result
    );
  });
})();
