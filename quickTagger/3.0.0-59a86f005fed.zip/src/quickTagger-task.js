(function (root) {
  var DEFAULTS = {
    createMissingTags: true,
    applyToPerformerScenes: true,
    scanAfterUpdate: false,
    waitForScan: true,
    markerPrerollSeconds: 5,
  };

  // Quick Tagger keeps one plain tag per concept ("A") and creates sub-tags of it
  // that record where a scene tag came from. Sub-tags are found by these custom
  // fields, never by name, so renaming either tag does not break the link.
  var ROLE_FIELD = "quickTagger_role";
  var CONCEPT_FIELD = "quickTagger_concept";
  var ROLES = {
    user: "Added by you with Quick Tagger.",
    performer: "Added by Quick Tagger to the scenes of a performer you tagged.",
    marker: "Kept by Quick Tagger on scenes that contain a marker of this tag.",
  };

  function own(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
  }

  function trim(value) {
    return String(value || "").replace(/^\s+|\s+$/g, "");
  }

  function toBool(value, fallback) {
    if (value === undefined || value === null || value === "") return fallback;
    if (value === true || value === false) return value;
    if (value === "true") return true;
    if (value === "false") return false;
    return fallback;
  }

  function toInt(value, fallback, min, max) {
    var parsed = parseInt(value, 10);
    if (isNaN(parsed)) parsed = fallback;
    if (parsed < min) parsed = min;
    if (parsed > max) parsed = max;
    return parsed;
  }

  function getGQL(options) {
    if (options && options.gql) return options.gql;
    if (typeof gql !== "undefined") return gql;
    throw new Error("gql API is not available");
  }

  function getLog(options) {
    if (options && options.log) return options.log;
    if (typeof log !== "undefined") return log;
    return { Info: function () {}, Warn: function () {}, Error: function () {}, Progress: function () {} };
  }

  function getUtil(options) {
    if (options && options.util) return options.util;
    if (typeof util !== "undefined") return util;
    return { Sleep: function () {} };
  }

  function gqlDo(gqlClient, query, variables) {
    if (variables === undefined) variables = {};
    return gqlClient.Do(query, variables);
  }

  function mergeSettings(args) {
    args = args || {};
    var settings = own(args, "settings") && args.settings ? args.settings : {};
    var merged = {
      mode: args.mode || "applyTag",
      targetType: args.targetType,
      targetId: args.targetId === undefined || args.targetId === null ? "" : String(args.targetId),
      text: own(args, "text") ? String(args.text) : own(args, "title") ? String(args.title) : "",
      sceneId: own(args, "sceneId") ? String(args.sceneId || "") : "",
      seconds: own(args, "seconds") ? Number(args.seconds) : null,
      createMissingTags: toBool(own(args, "createMissingTags") ? args.createMissingTags : settings.createMissingTags, DEFAULTS.createMissingTags),
      applyToPerformerScenes: toBool(own(args, "applyToPerformerScenes") ? args.applyToPerformerScenes : settings.applyToPerformerScenes, DEFAULTS.applyToPerformerScenes),
      scanAfterUpdate: toBool(own(args, "scanAfterUpdate") ? args.scanAfterUpdate : settings.scanAfterUpdate, DEFAULTS.scanAfterUpdate),
      waitForScan: toBool(own(args, "waitForScan") ? args.waitForScan : settings.waitForScan, DEFAULTS.waitForScan),
      markerPrerollSeconds: toInt(own(args, "markerPrerollSeconds") ? args.markerPrerollSeconds : settings.markerPrerollSeconds, DEFAULTS.markerPrerollSeconds, 0, 3600),
    };
    return merged;
  }

  var MODES = ["applyTag", "createMarker", "syncMarkerTags", "markerHook", "compatibilityCheck"];

  function validateArgs(args) {
    if (MODES.indexOf(args.mode) < 0) throw new Error("invalid mode: " + args.mode);
    if (args.mode !== "applyTag" && args.mode !== "createMarker") return;

    var text = trim(args.text);
    if (!text) throw new Error("text is required");

    if (args.mode === "applyTag") {
      if (args.targetType !== "scene" && args.targetType !== "performer") {
        throw new Error("targetType must be scene or performer");
      }
      if (!args.targetId) throw new Error("targetId is required");
    }

    if (args.mode === "createMarker") {
      if (!args.sceneId) throw new Error("sceneId is required for marker creation");
      if (args.targetType && args.targetType !== "scene") throw new Error("marker creation supports scene target only");
    }
  }

  var TAG_FIELDS = "id name aliases custom_fields";
  var FIND_TAGS = "query QuickTaggerFindTags($filter: TagFilterType){ findTags(tag_filter:$filter, filter:{ per_page: -1 }){ tags{ " + TAG_FIELDS + " } } }";
  var FIND_TAGS_BY_ID = "query QuickTaggerFindTagsByID($ids: [ID!]){ findTags(ids:$ids){ tags{ " + TAG_FIELDS + " } } }";
  var CREATE_TAG = "mutation QuickTaggerCreateTag($input: TagCreateInput!){ tagCreate(input:$input){ " + TAG_FIELDS + " } }";
  var FIND_SCENE = "query QuickTaggerFindScene($id: ID!){ findScene(id:$id){ id files{ path } tags{ id } } }";
  var UPDATE_SCENE = "mutation QuickTaggerUpdateScene($input: SceneUpdateInput!){ sceneUpdate(input:$input){ id tags{ id } } }";
  var FIND_PERFORMER = "query QuickTaggerFindPerformer($id: ID!){ findPerformer(id:$id){ id tags{ id } } }";
  var UPDATE_PERFORMER = "mutation QuickTaggerUpdatePerformer($input: PerformerUpdateInput!){ performerUpdate(input:$input){ id tags{ id } } }";
  var FIND_SCENES_BY_PERFORMER = "query QuickTaggerFindScenesByPerformer($scene_filter: SceneFilterType, $filter: FindFilterType){ findScenes(scene_filter:$scene_filter, filter:$filter){ scenes{ id tags{ id } files{ path } } } }";
  var FIND_MARKER_SCENES = "query QuickTaggerMarkerScenes($scene_filter: SceneFilterType, $ids: [ID!]){ findScenes(scene_filter:$scene_filter, ids:$ids, filter:{ per_page: -1 }){ scenes{ id tags{ id custom_fields } scene_markers{ id primary_tag{ " + TAG_FIELDS + " } } } } }";
  var FIND_MARKER = "query QuickTaggerFindMarker($ids: [ID!]){ findSceneMarkers(ids:$ids){ scene_markers{ id scene{ id } } } }";
  var CREATE_MARKER = "mutation QuickTaggerCreateMarker($input: SceneMarkerCreateInput!){ sceneMarkerCreate(input:$input){ id title seconds primary_tag{ id name } scene{ id } } }";
  var METADATA_SCAN = "mutation QuickTaggerScan($input: ScanMetadataInput!){ metadataScan(input:$input) }";
  var FIND_JOB = "query QuickTaggerFindJob($id: ID!){ findJob(input:{ id:$id }){ id status error } }";
  var INTROSPECTION = "query QuickTaggerCompatibility{ sceneUpdate: __type(name:\"SceneUpdateInput\"){ inputFields{name} } performerUpdate: __type(name:\"PerformerUpdateInput\"){ inputFields{name} } sceneMarkerCreate: __type(name:\"SceneMarkerCreateInput\"){ inputFields{name} } tagCreate: __type(name:\"TagCreateInput\"){ inputFields{name} } tagFilter: __type(name:\"TagFilterType\"){ inputFields{name} } sceneFilter: __type(name:\"SceneFilterType\"){ inputFields{name} } scanMetadata: __type(name:\"ScanMetadataInput\"){ inputFields{name} } schema: __schema{ queryType{ fields{name} } mutationType{ fields{name} } } }";

  function errorMessage(err) {
    return String(err && err.message ? err.message : err);
  }

  function tagRow(row) {
    var fields = row.custom_fields || {};
    return {
      id: String(row.id),
      name: row.name,
      aliases: row.aliases || [],
      role: fields[ROLE_FIELD] ? String(fields[ROLE_FIELD]) : null,
      concept: fields[CONCEPT_FIELD] ? String(fields[CONCEPT_FIELD]) : null,
    };
  }

  function findTags(gqlClient, filter) {
    var result = gqlDo(gqlClient, FIND_TAGS, { filter: filter });
    return ((result && result.findTags && result.findTags.tags) || []).map(tagRow);
  }

  function findTagByID(gqlClient, id) {
    var result = gqlDo(gqlClient, FIND_TAGS_BY_ID, { ids: [String(id)] });
    var rows = (result && result.findTags && result.findTags.tags) || [];
    return rows.length ? tagRow(rows[0]) : null;
  }

  // Stash runs EQUALS as a case-insensitive LIKE ("_" and "%" are wildcards), so
  // every name match is confirmed here.
  function sameText(a, b) {
    return String(a || "").toLowerCase() === String(b || "").toLowerCase();
  }

  // The concept is the plain tag "A". Typing an alias of A, or the name of one of
  // A's Quick Tagger sub-tags, resolves to A as well.
  function findConcept(gqlClient, text) {
    var byName = findTags(gqlClient, { name: { value: text, modifier: "EQUALS" } }).filter(function (t) { return sameText(t.name, text); });
    if (byName.length) {
      if (!byName[0].role) return byName[0];
      return byName[0].concept ? findTagByID(gqlClient, byName[0].concept) : null;
    }
    var byAlias = findTags(gqlClient, { aliases: { value: text, modifier: "EQUALS" } }).filter(function (t) {
      return !t.role && t.aliases.some(function (alias) { return sameText(alias, text); });
    });
    return byAlias.length ? byAlias[0] : null;
  }

  function resolveConcept(gqlClient, text, args) {
    var name = trim(text);
    var existing = findConcept(gqlClient, name);
    if (existing) return { id: existing.id, name: existing.name, created: false };
    if (!args.createMissingTags) throw new Error("tag not found and createMissingTags is disabled: " + name);
    var result = gqlDo(gqlClient, CREATE_TAG, { input: { name: name } });
    if (!result || !result.tagCreate) throw new Error("failed to create tag: " + name);
    return { id: String(result.tagCreate.id), name: result.tagCreate.name, created: true };
  }

  function findRoleTag(gqlClient, conceptID, role) {
    var rows = findTags(gqlClient, {
      custom_fields: [
        { field: ROLE_FIELD, value: [role], modifier: "EQUALS" },
        { field: CONCEPT_FIELD, value: [String(conceptID)], modifier: "EQUALS" },
      ],
    });
    return rows.length ? rows[0] : null;
  }

  // Sub-tags are named "A (role)", ignored by Auto Tag, and stamped with their role
  // and the concept's ID.
  function ensureRoleTag(gqlClient, concept, role, cache) {
    var key = role + ":" + concept.id;
    if (cache && cache[key]) return cache[key];
    var tag = findRoleTag(gqlClient, concept.id, role);
    if (!tag) {
      var name = concept.name + " (" + role + ")";
      var custom = {};
      custom[ROLE_FIELD] = role;
      custom[CONCEPT_FIELD] = String(concept.id);
      var result;
      try {
        result = gqlDo(gqlClient, CREATE_TAG, {
          input: { name: name, parent_ids: [String(concept.id)], ignore_auto_tag: true, description: ROLES[role], custom_fields: custom },
        });
      } catch (err) {
        throw new Error("could not create tag " + name + "; a tag with that name may already exist that Quick Tagger does not manage: " + errorMessage(err));
      }
      if (!result || !result.tagCreate) throw new Error("failed to create tag: " + name);
      tag = tagRow(result.tagCreate);
    }
    var ret = { id: tag.id, name: tag.name };
    if (cache) cache[key] = ret;
    return ret;
  }

  function uniqueIDs(existing, addID) {
    var seen = {};
    var ret = [];
    for (var i = 0; i < (existing || []).length; i += 1) {
      var id = String(existing[i]);
      if (!seen[id]) {
        seen[id] = true;
        ret.push(id);
      }
    }
    if (addID && !seen[String(addID)]) ret.push(String(addID));
    return ret;
  }

  function applySceneTag(gqlClient, args, resolvedTag) {
    var result = gqlDo(gqlClient, FIND_SCENE, { id: args.targetId });
    if (!result || !result.findScene) throw new Error("scene not found: " + args.targetId);
    var scene = result.findScene;
    var existing = (scene.tags || []).map(function (t) { return String(t.id); });
    var merged = uniqueIDs(existing, resolvedTag.id);
    var updated = false;
    if (merged.length !== existing.length) {
      gqlDo(gqlClient, UPDATE_SCENE, { input: { id: String(scene.id), tag_ids: merged } });
      updated = true;
    }
    return {
      updatedScenes: updated ? [String(scene.id)] : [],
      skipped: updated ? [] : [String(scene.id)],
      scanPaths: (scene.files || []).map(function (f) { return f.path; }),
    };
  }

  // The performer itself gets the user tag. Their scenes get the separate performer
  // tag, because a performer-wide tag is less certain than tagging one scene.
  function applyPerformerTag(gqlClient, args, resolvedTag, sceneTag) {
    var result = gqlDo(gqlClient, FIND_PERFORMER, { id: args.targetId });
    if (!result || !result.findPerformer) throw new Error("performer not found: " + args.targetId);
    var performer = result.findPerformer;
    var existing = (performer.tags || []).map(function (t) { return String(t.id); });
    var merged = uniqueIDs(existing, resolvedTag.id);
    gqlDo(gqlClient, UPDATE_PERFORMER, { input: { id: String(performer.id), tag_ids: merged } });

    var updatedScenes = [];
    var skipped = [];
    var scanPaths = [];
    if (sceneTag) {
      var scenes = gqlDo(gqlClient, FIND_SCENES_BY_PERFORMER, {
        filter: { per_page: -1 },
        scene_filter: { performers: { value: String(performer.id), modifier: "INCLUDES_ALL", excludes: [] } },
      });
      var rows = (scenes && scenes.findScenes && scenes.findScenes.scenes) || [];
      for (var i = 0; i < rows.length; i += 1) {
        var row = rows[i];
        var rowExisting = (row.tags || []).map(function (t) { return String(t.id); });
        var rowMerged = uniqueIDs(rowExisting, sceneTag.id);
        if (rowMerged.length !== rowExisting.length) {
          gqlDo(gqlClient, UPDATE_SCENE, { input: { id: String(row.id), tag_ids: rowMerged } });
          updatedScenes.push(String(row.id));
        } else {
          skipped.push(String(row.id));
        }
        var files = row.files || [];
        for (var fi = 0; fi < files.length; fi += 1) scanPaths.push(files[fi].path);
      }
    }

    return {
      performerId: String(performer.id),
      updatedScenes: updatedScenes,
      skipped: skipped,
      scanPaths: scanPaths,
    };
  }

  function clampMarkerSeconds(seconds, preroll) {
    var sec = Number(seconds);
    if (isNaN(sec)) sec = 1;
    sec = Math.floor(sec - preroll);
    if (sec < 1) sec = 1;
    return sec;
  }

  function createQuickMarker(gqlClient, args, resolvedTag) {
    var sceneId = String(args.sceneId);
    var markerSeconds = clampMarkerSeconds(args.seconds, args.markerPrerollSeconds);
    var result = gqlDo(gqlClient, CREATE_MARKER, {
      input: {
        scene_id: sceneId,
        primary_tag_id: String(resolvedTag.id),
        title: trim(args.text),
        seconds: markerSeconds,
      },
    });
    if (!result || !result.sceneMarkerCreate) throw new Error("marker creation failed");
    return {
      id: String(result.sceneMarkerCreate.id),
      title: result.sceneMarkerCreate.title,
      seconds: result.sceneMarkerCreate.seconds,
      scene_id: sceneId,
      primary_tag_id: String(resolvedTag.id),
    };
  }

  function loadMarkerScenes(gqlClient, variables) {
    var result = gqlDo(gqlClient, FIND_MARKER_SCENES, variables);
    return (result && result.findScenes && result.findScenes.scenes) || [];
  }

  // The marker sub-tag "A (marker)" is derived: a scene carries it exactly when one
  // of its markers has A, or one of A's Quick Tagger sub-tags, as primary tag.
  // Only marker sub-tags are added or removed; every other scene tag is untouched.
  // scope: { sceneIds } checks those scenes, { tagged } checks scenes carrying a
  // marker sub-tag (enough after a marker is deleted), { all } also checks every
  // scene with markers.
  function syncMarkerTags(gqlClient, scope) {
    var scenes = {};
    function collect(rows) {
      for (var i = 0; i < rows.length; i += 1) scenes[String(rows[i].id)] = rows[i];
    }
    if (scope.sceneIds) {
      collect(loadMarkerScenes(gqlClient, { ids: scope.sceneIds }));
    } else {
      var markerTagIDs = findTags(gqlClient, { custom_fields: [{ field: ROLE_FIELD, value: ["marker"], modifier: "EQUALS" }] })
        .map(function (t) { return t.id; });
      if (markerTagIDs.length) {
        collect(loadMarkerScenes(gqlClient, { scene_filter: { tags: { value: markerTagIDs, modifier: "INCLUDES", depth: 0 } } }));
      }
      if (scope.all) collect(loadMarkerScenes(gqlClient, { scene_filter: { has_markers: "true" } }));
    }

    var roleCache = {};
    var conceptCache = {};
    function markerTagFor(primary) {
      var tag = tagRow(primary);
      if (tag.role === "marker") return tag.id;
      var concept = tag;
      if (tag.role) {
        if (!tag.concept) return null;
        if (!own(conceptCache, tag.concept)) conceptCache[tag.concept] = findTagByID(gqlClient, tag.concept);
        concept = conceptCache[tag.concept];
        if (!concept) return null;
      }
      return ensureRoleTag(gqlClient, concept, "marker", roleCache).id;
    }

    var ids = Object.keys(scenes);
    var updated = [];
    for (var i = 0; i < ids.length; i += 1) {
      var scene = scenes[ids[i]];
      var desired = {};
      var markers = scene.scene_markers || [];
      for (var m = 0; m < markers.length; m += 1) {
        var markerTagID = markers[m].primary_tag ? markerTagFor(markers[m].primary_tag) : null;
        if (markerTagID) desired[markerTagID] = true;
      }
      var next = [];
      var removed = [];
      var present = {};
      var tags = scene.tags || [];
      for (var t = 0; t < tags.length; t += 1) {
        var row = tagRow(tags[t]);
        present[row.id] = true;
        if (row.role === "marker" && !desired[row.id]) removed.push(row.id);
        else next.push(row.id);
      }
      var added = Object.keys(desired).filter(function (id) { return !present[id]; });
      if (!added.length && !removed.length) continue;
      gqlDo(gqlClient, UPDATE_SCENE, { input: { id: String(scene.id), tag_ids: next.concat(added) } });
      updated.push({ sceneId: String(scene.id), added: added, removed: removed });
    }
    return { scenesChecked: ids.length, updated: updated };
  }

  // Stash reports the marker ID to hooks. A deleted marker no longer has a scene,
  // so deletions recheck every scene that carries a marker sub-tag.
  function runMarkerHook(gqlClient, hookContext) {
    var type = hookContext && hookContext.type ? String(hookContext.type) : "";
    var sceneID = null;
    if (type !== "SceneMarker.Destroy.Post" && hookContext && hookContext.id) {
      var result = gqlDo(gqlClient, FIND_MARKER, { ids: [String(hookContext.id)] });
      var markers = (result && result.findSceneMarkers && result.findSceneMarkers.scene_markers) || [];
      if (markers.length && markers[0].scene) sceneID = String(markers[0].scene.id);
    }
    var sync = syncMarkerTags(gqlClient, sceneID ? { sceneIds: [sceneID] } : { tagged: true });
    return { mode: "markerHook", hook: type, scenesChecked: sync.scenesChecked, updated: sync.updated };
  }

  function uniquePaths(paths) {
    var seen = {};
    var ret = [];
    for (var i = 0; i < (paths || []).length; i += 1) {
      var p = String(paths[i] || "");
      if (!p || seen[p]) continue;
      seen[p] = true;
      ret.push(p);
    }
    return ret;
  }

  function waitForJob(gqlClient, utilApi, jobID, label) {
    var deadline = Date.now() + 60000;
    while (Date.now() < deadline) {
      var data = gqlDo(gqlClient, FIND_JOB, { id: String(jobID) });
      var job = data ? data.findJob : null;
      if (!job) throw new Error(label + " " + jobID + " not found");
      if (job.status === "FINISHED") return "FINISHED";
      if (job.status === "FAILED" || job.status === "CANCELLED") {
        throw new Error(label + " " + jobID + " " + job.status + ": " + (job.error || "no error message"));
      }
      utilApi.Sleep(500);
    }
    throw new Error(label + " " + jobID + " timed out");
  }

  function isInStashPluginRuntime() {
    // When running inside Stash's Goja embedded-JS runtime, the global `input` object exists.
    // Inside a plugin task job, waiting for a nested scan job (metadataScan) deadlocks:
    // the scan job cannot finish while the plugin task job is still RUNNING.
    return typeof input !== "undefined";
  }

  function maybeScan(gqlClient, utilApi, args, scanPaths) {
    var paths = uniquePaths(scanPaths);
    if (!args.scanAfterUpdate || !paths.length) {
      return { requested: false, jobId: null, status: null, paths: paths };
    }

    var scan = gqlDo(gqlClient, METADATA_SCAN, {
      input: {
        paths: paths,
        rescan: true,
        scanGenerateCovers: false,
        scanGeneratePreviews: false,
        scanGenerateImagePreviews: false,
        scanGenerateSprites: false,
        scanGeneratePhashes: false,
        scanGenerateImagePhashes: false,
        scanGenerateThumbnails: false,
        scanGenerateClipPreviews: false,
      },
    });
    var jobId = scan ? scan.metadataScan : null;
    if (!jobId) throw new Error("metadataScan did not return job id");

    var status = null;
    // Only block-and-poll for scan completion when running outside Stash's plugin runtime.
    // Inside Stash (Goja + input.Args), the plugin task job must finish before the
    // nested scan job can complete — waiting here would deadlock.
    if (args.waitForScan && !isInStashPluginRuntime()) {
      status = waitForJob(gqlClient, utilApi, jobId, "scan");
    }

    return { requested: true, jobId: String(jobId), status: status, paths: paths };
  }

  function fieldNames(typeInfo) {
    var ret = {};
    var fields = typeInfo && typeInfo.inputFields ? typeInfo.inputFields : [];
    for (var i = 0; i < fields.length; i += 1) ret[fields[i].name] = true;
    return ret;
  }

  function operationNames(schemaType) {
    var ret = {};
    var fields = schemaType && schemaType.fields ? schemaType.fields : [];
    for (var i = 0; i < fields.length; i += 1) ret[fields[i].name] = true;
    return ret;
  }

  function requireFields(name, actual, required, missing) {
    for (var i = 0; i < required.length; i += 1) {
      if (!actual[required[i]]) missing.push(name + "." + required[i]);
    }
  }

  function compatibilityCheck(gqlClient) {
    var data = gqlDo(gqlClient, INTROSPECTION, {});
    var missing = [];
    requireFields("SceneUpdateInput", fieldNames(data.sceneUpdate), ["id", "tag_ids"], missing);
    requireFields("PerformerUpdateInput", fieldNames(data.performerUpdate), ["id", "tag_ids"], missing);
    requireFields("SceneMarkerCreateInput", fieldNames(data.sceneMarkerCreate), ["scene_id", "primary_tag_id", "seconds"], missing);
    requireFields("TagCreateInput", fieldNames(data.tagCreate), ["name", "parent_ids", "ignore_auto_tag", "custom_fields"], missing);
    requireFields("TagFilterType", fieldNames(data.tagFilter), ["name", "aliases", "custom_fields"], missing);
    requireFields("SceneFilterType", fieldNames(data.sceneFilter), ["tags", "has_markers"], missing);
    requireFields("ScanMetadataInput", fieldNames(data.scanMetadata), ["paths"], missing);
    requireFields("Query", operationNames(data.schema && data.schema.queryType), ["findScene", "findPerformer", "findScenes", "findSceneMarkers", "findTags", "findJob"], missing);
    requireFields("Mutation", operationNames(data.schema && data.schema.mutationType), ["sceneUpdate", "performerUpdate", "sceneMarkerCreate", "tagCreate", "metadataScan"], missing);
    if (missing.length) throw new Error("compatibility check failed: missing " + missing.join(", "));
    return { mode: "compatibilityCheck", ok: true, missing: [] };
  }

  function runQuickTagger(rawArgs, options) {
    var gqlClient = getGQL(options);
    var logger = getLog(options);
    var utilApi = getUtil(options);
    var args = mergeSettings(rawArgs || {});
    validateArgs(args);

    if (args.mode === "compatibilityCheck") return compatibilityCheck(gqlClient);
    if (args.mode === "syncMarkerTags") {
      var resync = syncMarkerTags(gqlClient, { all: true });
      logger.Info("quickTagger marker tag resync checked " + resync.scenesChecked + " scenes, updated " + resync.updated.length);
      return { mode: "syncMarkerTags", scenesChecked: resync.scenesChecked, updated: resync.updated };
    }
    if (args.mode === "markerHook") return runMarkerHook(gqlClient, rawArgs && rawArgs.hookContext);

    var concept = resolveConcept(gqlClient, args.text, args);
    var roleCache = {};

    if (args.mode === "applyTag") {
      var userTag = ensureRoleTag(gqlClient, concept, "user", roleCache);
      var applyResult;
      if (args.targetType === "scene") {
        applyResult = applySceneTag(gqlClient, args, userTag);
      } else {
        var performerTag = args.applyToPerformerScenes ? ensureRoleTag(gqlClient, concept, "performer", roleCache) : null;
        applyResult = applyPerformerTag(gqlClient, args, userTag, performerTag);
      }

      var scanResult = maybeScan(gqlClient, utilApi, args, applyResult.scanPaths);
      return {
        mode: "applyTag",
        targetType: args.targetType,
        targetId: args.targetId,
        text: trim(args.text),
        concept: concept,
        tag: userTag,
        updated: {
          scenes: applyResult.updatedScenes || [],
          performers: applyResult.performerId ? [applyResult.performerId] : [],
        },
        skipped: applyResult.skipped || [],
        scan: scanResult,
      };
    }

    logger.Info("quickTagger marker for scene " + args.sceneId);
    var markerTag = ensureRoleTag(gqlClient, concept, "marker", roleCache);
    var marker = createQuickMarker(gqlClient, args, markerTag);
    // Stash's marker hook normally does this already; syncing here keeps direct
    // task runs correct when hooks are not running.
    syncMarkerTags(gqlClient, { sceneIds: [String(args.sceneId)] });
    return {
      mode: "createMarker",
      sceneId: args.sceneId,
      text: trim(args.text),
      concept: concept,
      tag: markerTag,
      marker: marker,
    };
  }

  function main() {
    try {
      return { Output: runQuickTagger(input.Args || {}) };
    } catch (err) {
      return { Error: String(err && err.message ? err.message : err) };
    }
  }

  var api = {
    DEFAULTS: DEFAULTS,
    mergeSettings: mergeSettings,
    validateArgs: validateArgs,
    ROLE_FIELD: ROLE_FIELD,
    CONCEPT_FIELD: CONCEPT_FIELD,
    resolveConcept: resolveConcept,
    ensureRoleTag: ensureRoleTag,
    syncMarkerTags: syncMarkerTags,
    clampMarkerSeconds: clampMarkerSeconds,
    runQuickTagger: runQuickTagger,
    compatibilityCheck: compatibilityCheck,
  };

  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.QuickTaggerTask = api;

  if (typeof input !== "undefined") {
    return main();
  }
})(this);
