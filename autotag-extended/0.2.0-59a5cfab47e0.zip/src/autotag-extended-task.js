(function (root) {
  var PLUGIN_ID = "autotag-extended";

  var DEFAULTS = {
    includeAliases: true,
    matchScenes: true,
    matchImages: true,
    matchTitle: true,
    matchDetails: true,
    respectOrganized: true,
    respectIgnoreAutoTag: true,
    pageSize: 250,
    previewLimit: 25,
    matchPerformers: true,
    matchTags: true,
    allowSingleWordAliases: false,
    matchPath: true,
  };

  var TASK_NAME = "Apply title/details auto tag";

  var FIND_PERFORMER = "\
query FindPerformerForAutoTagExtended($id: ID!) {\
  findPerformer(id: $id) {\
    id\
    name\
    alias_list\
    ignore_auto_tag\
  }\
}";

  var FIND_TAG = "\
query FindTagForAutoTagExtended($id: ID!) {\
  findTag(id: $id) {\
    id\
    name\
    aliases\
    ignore_auto_tag\
  }\
}";

  var FIND_ALL_PERFORMERS = "\
query FindAllPerformersForAutoTagExtended {\
  findPerformers(filter: { per_page: -1 }) {\
    performers {\
      id\
      name\
      alias_list\
      ignore_auto_tag\
    }\
  }\
}";

  var FIND_ALL_TAGS = "\
query FindAllTagsForAutoTagExtended {\
  findTags(filter: { per_page: -1 }) {\
    tags {\
      id\
      name\
      aliases\
      ignore_auto_tag\
    }\
  }\
}";

  var FIND_PERFORMERS_NAMED = "\
query FindPerformersNamedForAutoTagExtended($performer_filter: PerformerFilterType) {\
  findPerformers(filter: { per_page: -1 }, performer_filter: $performer_filter) {\
    performers {\
      id\
      name\
      alias_list\
      ignore_auto_tag\
    }\
  }\
}";

  var FIND_TAGS_NAMED = "\
query FindTagsNamedForAutoTagExtended($tag_filter: TagFilterType) {\
  findTags(filter: { per_page: -1 }, tag_filter: $tag_filter) {\
    tags {\
      id\
      name\
      aliases\
      ignore_auto_tag\
    }\
  }\
}";

  var FIND_MEDIA_SCENES = "\
query FindMediaScenesForAutoTagExtended($filter: FindFilterType, $scene_filter: SceneFilterType, $ids: [ID!]) {\
  findScenes(filter: $filter, scene_filter: $scene_filter, ids: $ids) {\
    scenes {\
      id\
      title\
      details\
      organized\
      files { path }\
      performers { id }\
      tags { id }\
    }\
  }\
}";

  var FIND_MEDIA_IMAGES = "\
query FindMediaImagesForAutoTagExtended($filter: FindFilterType, $image_filter: ImageFilterType, $ids: [ID!]) {\
  findImages(filter: $filter, image_filter: $image_filter, ids: $ids) {\
    images {\
      id\
      title\
      details\
      organized\
      visual_files { ... on BaseFile { path } }\
      performers { id }\
      tags { id }\
    }\
  }\
}";

  var LIBRARY_PATHS = "\
query LibraryPathsForAutoTagExtended {\
  configuration { general { stashes { path } } }\
}";

  var COUNT_MEDIA_SCENES = "\
query CountMediaScenesForAutoTagExtended($scene_filter: SceneFilterType) {\
  findScenes(filter: { per_page: 1 }, scene_filter: $scene_filter) { count }\
}";

  var COUNT_MEDIA_IMAGES = "\
query CountMediaImagesForAutoTagExtended($image_filter: ImageFilterType) {\
  findImages(filter: { per_page: 1 }, image_filter: $image_filter) { count }\
}";

  // Bulk updates in ADD mode insert only the missing links inside one write
  // transaction, so edits made while a run is in progress are never undone.
  var ADD_TO_SCENES = "\
mutation AddToScenesForAutoTagExtended($input: BulkSceneUpdateInput!) {\
  bulkSceneUpdate(input: $input) { id }\
}";

  var ADD_TO_IMAGES = "\
mutation AddToImagesForAutoTagExtended($input: BulkImageUpdateInput!) {\
  bulkImageUpdate(input: $input) { id }\
}";

  var PLUGIN_SETTINGS = "\
query AutoTagExtendedSettings($include: [ID!]) {\
  configuration { plugins(include: $include) }\
}";

  var INTROSPECTION = "\
query AutoTagExtendedCompatibility {\
  sceneFilter: __type(name: \"SceneFilterType\") { inputFields { name } }\
  imageFilter: __type(name: \"ImageFilterType\") { inputFields { name } }\
  sceneUpdate: __type(name: \"BulkSceneUpdateInput\") { inputFields { name } }\
  imageUpdate: __type(name: \"BulkImageUpdateInput\") { inputFields { name } }\
  queryType: __schema { queryType { fields { name } } mutationType { fields { name } } }\
}";

  function own(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
  }

  function toBool(value, fallback) {
    if (value === undefined || value === null || value === "") return fallback;
    if (value === true || value === false) return value;
    if (value === 1 || value === 0) return value === 1;
    var text = String(value).toLowerCase();
    if (text === "true" || text === "1") return true;
    if (text === "false" || text === "0") return false;
    return fallback;
  }

  function toInt(value, fallback, min, max) {
    var parsed = parseInt(value, 10);
    if (isNaN(parsed)) parsed = fallback;
    if (parsed < min) parsed = min;
    if (parsed > max) parsed = max;
    return parsed;
  }

  function toIdList(value) {
    var source = [];
    var ret = [];
    var seen = {};
    var i;
    if (value === undefined || value === null || value === "") return ret;
    if (typeof value === "string" || typeof value === "number") {
      source = String(value).split(/[\s,]+/);
    } else if (typeof value.length === "number") {
      for (i = 0; i < value.length; i += 1) source.push(String(value[i]));
    }
    for (i = 0; i < source.length; i += 1) {
      var id = trim(source[i]);
      if (!id) continue;
      if (!/^\d+$/.test(id)) throw new Error("invalid media id: " + source[i]);
      if (!seen[id]) {
        seen[id] = true;
        ret.push(id);
      }
    }
    return ret;
  }

  function normalizeArgs(args) {
    args = args || {};
    var ret = {
      mode: args.mode || "preview",
      targetType: args.targetType,
      targetId: args.targetId === undefined || args.targetId === null ? "" : String(args.targetId),
      includeAliases: toBool(args.includeAliases, DEFAULTS.includeAliases),
      matchScenes: toBool(args.matchScenes, DEFAULTS.matchScenes),
      matchImages: toBool(args.matchImages, DEFAULTS.matchImages),
      matchTitle: toBool(args.matchTitle, DEFAULTS.matchTitle),
      matchDetails: toBool(args.matchDetails, DEFAULTS.matchDetails),
      respectOrganized: toBool(args.respectOrganized, DEFAULTS.respectOrganized),
      respectIgnoreAutoTag: toBool(args.respectIgnoreAutoTag, DEFAULTS.respectIgnoreAutoTag),
      pageSize: toInt(args.pageSize, DEFAULTS.pageSize, 1, 1000),
      previewLimit: toInt(args.previewLimit, DEFAULTS.previewLimit, 0, 250),
      matchPerformers: toBool(args.matchPerformers, DEFAULTS.matchPerformers),
      matchTags: toBool(args.matchTags, DEFAULTS.matchTags),
      allowSingleWordAliases: toBool(args.allowSingleWordAliases, DEFAULTS.allowSingleWordAliases),
      matchPath: toBool(args.matchPath, DEFAULTS.matchPath),
      mediaScope: args.mediaScope || "selected",
      sceneIds: toIdList(args.sceneIds),
      imageIds: toIdList(args.imageIds),
      // Only tasks may report progress: Stash gives plugin operations no
      // progress listener, so log.Progress blocks forever there.
      reportProgress: toBool(args.reportProgress, false),
    };
    var isMedia = ret.targetType === "media";

    if (ret.mode !== "preview" && ret.mode !== "apply" && ret.mode !== "compatibilityCheck") {
      throw new Error("invalid mode: " + ret.mode);
    }
    if (ret.mode !== "compatibilityCheck" && ret.targetType !== "performer" && ret.targetType !== "tag" && !isMedia) {
      throw new Error("targetType must be performer, tag, or media");
    }
    if (ret.mode !== "compatibilityCheck" && !isMedia && !ret.targetId) {
      throw new Error("targetId is required");
    }
    if (ret.mode !== "compatibilityCheck" && isMedia) {
      if (ret.mediaScope !== "selected" && ret.mediaScope !== "all") {
        throw new Error("mediaScope must be selected or all");
      }
      if (ret.mediaScope === "selected" && !ret.sceneIds.length && !ret.imageIds.length) {
        throw new Error("sceneIds or imageIds is required when mediaScope is selected");
      }
      if (!ret.matchPerformers && !ret.matchTags) {
        throw new Error("at least one of matchPerformers or matchTags must be enabled");
      }
    }
    if (!ret.matchScenes && !ret.matchImages) {
      throw new Error("at least one of matchScenes or matchImages must be enabled");
    }
    if (!ret.matchTitle && !ret.matchDetails && !ret.matchPath) {
      throw new Error("at least one of matchTitle, matchDetails or matchPath must be enabled");
    }

    return ret;
  }

  function trim(value) {
    return String(value || "").replace(/^\s+|\s+$/g, "");
  }

  function normalizeTerm(value) {
    return trim(value).replace(/\s+/g, " ");
  }

  function uniqueTerms(name, aliases, includeAliases) {
    var source = [name];
    var ret = [];
    var seen = Object.create(null);
    var i;
    if (includeAliases && aliases) {
      for (i = 0; i < aliases.length; i += 1) source.push(aliases[i]);
    }
    for (i = 0; i < source.length; i += 1) {
      var term = normalizeTerm(source[i]);
      var key = term.toLowerCase();
      if (term && !seen[key]) {
        seen[key] = true;
        ret.push(term);
      }
    }
    return ret;
  }

  function escapeRegex(value) {
    return String(value).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&");
  }

  function resultTemplate(mode) {
    return {
      mode: mode,
      target: null,
      matched: { scenes: 0, images: 0 },
      updated: { scenes: 0, images: 0 },
      skipped: { alreadyTagged: 0, organized: 0, ignoreAutoTag: 0 },
      samples: [],
      errors: [],
    };
  }

  function getGQL(options) {
    if (options && options.gql) return options.gql;
    if (typeof gql !== "undefined") return gql;
    throw new Error("gql API is not available");
  }

  function getLog(options) {
    if (options && options.log) return options.log;
    if (typeof log !== "undefined") return log;
    return {
      Info: function () {},
      Warn: function () {},
      Error: function () {},
      Progress: function () {},
    };
  }

  function gqlDo(gqlClient, query, variables) {
    if (variables === undefined) variables = {};
    return gqlClient.Do(query, variables);
  }

  function loadTarget(gqlClient, args) {
    if (args.targetType === "performer") {
      var performerResult = gqlDo(gqlClient, FIND_PERFORMER, { id: args.targetId });
      if (!performerResult.findPerformer) throw new Error("performer not found: " + args.targetId);
      return toEntity("performer", performerResult.findPerformer);
    }

    var tagResult = gqlDo(gqlClient, FIND_TAG, { id: args.targetId });
    if (!tagResult.findTag) throw new Error("tag not found: " + args.targetId);
    return toEntity("tag", tagResult.findTag);
  }

  function hasTarget(row, target) {
    var items = target.type === "performer" ? row.performers : row.tags;
    items = items || [];
    for (var i = 0; i < items.length; i += 1) {
      if (String(items[i].id) === String(target.id)) return true;
    }
    return false;
  }

  function makeFindFilter(args) {
    return {
      per_page: args.pageSize,
      sort: "id",
      direction: "ASC",
    };
  }

  // Matching engine shared by both modes. Names and aliases are indexed by
  // their word sequence and each scene/image text is looked up word by word,
  // so the cost per item depends on the length of its text, not on how many
  // names are indexed.

  var TERM_SEPARATOR = "[.\\-_\\t\\n\\f\\r ]+";

  // File paths follow stock Stash auto tag: words may also be run together,
  // so "Jane Doe" matches JaneDoe.mp4 as well as Jane.Doe.mp4.
  var PATH_SEPARATOR = "[.\\-_ ]*";

  // Non-ASCII letters without case that should still count as word characters.
  // goja's \p{L} support is unreliable, so word characters are classified here.
  var UNCASED_WORD_RANGES = [
    [0x05d0, 0x05ea], [0x05f0, 0x05f2],
    [0x0620, 0x064a], [0x0671, 0x06d3],
    [0x0900, 0x0dff],
    [0x0e01, 0x0e3a], [0x0e40, 0x0e4e],
    [0x1100, 0x11ff],
    [0x3041, 0x3096], [0x309d, 0x309f], [0x30a1, 0x30fa], [0x30fc, 0x30ff],
    [0x3400, 0x4dbf], [0x4e00, 0x9fff], [0xac00, 0xd7a3], [0xf900, 0xfaff], [0xff66, 0xff9f],
  ];

  // Symbols that have case mappings but are not letters.
  var CASED_SYMBOL_RANGES = [[0x2160, 0x2188], [0x24b6, 0x24e9]];

  function inRanges(code, ranges) {
    for (var i = 0; i < ranges.length; i += 1) {
      if (code >= ranges[i][0] && code <= ranges[i][1]) return true;
    }
    return false;
  }

  function isWordCode(code) {
    if (code < 0x80) return (code >= 0x30 && code <= 0x39) || (code >= 0x41 && code <= 0x5a) || (code >= 0x61 && code <= 0x7a);
    if (code >= 0xd800 && code <= 0xdfff) return false;
    if (code >= 0x0300 && code <= 0x036f) return true;
    if (inRanges(code, CASED_SYMBOL_RANGES)) return false;
    var ch = String.fromCharCode(code);
    if (ch.toLowerCase() !== ch.toUpperCase()) return true;
    return inRanges(code, UNCASED_WORD_RANGES);
  }

  // Full-width forms (Ｍｉｓａｋｉ, １２３, －) and the ideographic space read as
  // their ASCII equivalents. One character maps to one, so offsets hold.
  function foldWidth(text) {
    return text.replace(/[\uff01-\uff5e\u3000]/g, function (ch) {
      var code = ch.charCodeAt(0);
      return code === 0x3000 ? " " : String.fromCharCode(code - 0xfee0);
    });
  }

  function foldText(value) {
    var text = value === undefined || value === null ? "" : String(value);
    if (text.normalize) text = text.normalize("NFC");
    return foldWidth(text).toLowerCase();
  }

  function wordTokens(text) {
    var tokens = [];
    var start = -1;
    for (var i = 0; i <= text.length; i += 1) {
      var word = i < text.length && isWordCode(text.charCodeAt(i));
      if (word && start < 0) {
        start = i;
      } else if (!word && start >= 0) {
        tokens.push({ word: text.slice(start, i), start: start, end: i });
        start = -1;
      }
    }
    return tokens;
  }

  // Compiles a name/alias: its whitespace-separated parts must appear
  // literally, joined by one or more of . - _ or whitespace (or, in paths,
  // zero or more of . - _ and space), with a non-word character or the text
  // edge on both sides. Returns null for terms that cannot be indexed by word.
  function compileTerm(term) {
    var text = foldText(normalizeTerm(term));
    if (!text) return null;
    var parts = text.split(" ");
    // A punctuation-only part ("Rock & Roll") is matched literally, but not at
    // either end, where its distance from the first/last word is not fixed.
    if (!wordTokens(parts[0]).length || !wordTokens(parts[parts.length - 1]).length) return null;
    var escaped = [];
    for (var i = 0; i < parts.length; i += 1) escaped.push(escapeRegex(parts[i]));
    var tokens = wordTokens(text);
    var words = [];
    var wordCount = 0;
    for (var j = 0; j < tokens.length; j += 1) {
      words.push(tokens[j].word);
      // Initials like the J in "J.Lo" do not count toward the word count.
      if (tokens[j].word.length > 1) wordCount += 1;
    }
    return {
      text: text,
      key: words.join(" "),
      size: words.length,
      wordCount: wordCount,
      lead: tokens[0].start,
      trail: text.length - tokens[tokens.length - 1].end,
      pattern: "^" + escaped.join(TERM_SEPARATOR) + "$",
      pathKey: words.join(""),
      pathPattern: "^" + escaped.join(PATH_SEPARATOR) + "$",
    };
  }

  function newDictionary() {
    return { index: Object.create(null), pathIndex: Object.create(null), maxTokens: 0 };
  }

  // Titles and details are looked up by words joined with spaces. Paths are
  // looked up with the words run together, because a path may write a name
  // with or without separators.
  function addDictionaryTerm(dictionary, entry, compiled) {
    entry.key = compiled.key;
    entry.pathKey = compiled.pathKey;
    entry.lead = compiled.lead;
    entry.trail = compiled.trail;
    entry.pattern = compiled.pattern;
    entry.pathPattern = compiled.pathPattern;
    entry.core = null;
    entry.pathCore = null;
    (dictionary.index[compiled.key] = dictionary.index[compiled.key] || []).push(entry);
    (dictionary.pathIndex[compiled.pathKey] = dictionary.pathIndex[compiled.pathKey] || []).push(entry);
    if (compiled.size > dictionary.maxTokens) dictionary.maxTokens = compiled.size;
  }

  // Returns the matched span, or null.
  function termMatchesAt(text, firstToken, lastToken, entry, forPath) {
    var start = firstToken.start - entry.lead;
    var end = lastToken.end + entry.trail;
    if (start < 0 || end > text.length) return null;
    if (start > 0 && isWordCode(text.charCodeAt(start - 1))) return null;
    if (end < text.length && isWordCode(text.charCodeAt(end))) return null;
    // Compiled on first use: most indexed terms never occur in the media checked.
    var re;
    if (forPath) {
      if (!entry.pathCore) entry.pathCore = new RegExp(entry.pathPattern);
      re = entry.pathCore;
    } else {
      if (!entry.core) entry.core = new RegExp(entry.pattern);
      re = entry.core;
    }
    return re.test(text.slice(start, end)) ? { entry: entry, start: start, end: end } : null;
  }

  // A name inside a longer matched name is not a separate match: in
  // "Eva Elfie solo" only "Eva Elfie" counts, not also "Eva".
  function longestMatches(matches) {
    var ret = [];
    for (var i = 0; i < matches.length; i += 1) {
      var a = matches[i];
      var covered = false;
      for (var j = 0; j < matches.length && !covered; j += 1) {
        var b = matches[j];
        covered = b.start <= a.start && a.end <= b.end && b.end - b.start > a.end - a.start;
      }
      if (!covered) ret.push(a);
    }
    return ret;
  }

  function findTermMatches(value, dictionary, forPath) {
    var text = foldText(value);
    var tokens = wordTokens(text);
    var index = forPath ? dictionary.pathIndex : dictionary.index;
    var joiner = forPath ? "" : " ";
    var ret = [];
    for (var i = 0; i < tokens.length; i += 1) {
      var key = "";
      for (var n = 0; n < dictionary.maxTokens && i + n < tokens.length; n += 1) {
        key = n === 0 ? tokens[i].word : key + joiner + tokens[i + n].word;
        var entries = index[key];
        if (!entries) continue;
        for (var e = 0; e < entries.length; e += 1) {
          var match = termMatchesAt(text, tokens[i], tokens[i + n], entries[e], forPath);
          if (match) ret.push(match);
        }
      }
    }
    return longestMatches(ret);
  }

  function loadLibraryRoots(gqlClient) {
    var stashes = gqlDo(gqlClient, LIBRARY_PATHS).configuration.general.stashes || [];
    var roots = [];
    for (var i = 0; i < stashes.length; i += 1) {
      if (stashes[i].path) roots.push(String(stashes[i].path));
    }
    roots.sort(function (a, b) { return b.length - a.length; });
    return roots;
  }

  function isWindowsPath(value) {
    return /^[A-Za-z]:/.test(value) || value.indexOf("\\") >= 0;
  }

  // Windows paths are compared without regard to case or separator style.
  function comparablePath(value, windows) {
    return windows ? value.replace(/\\/g, "/").toLowerCase() : value;
  }

  // The part of a file path that is matched: relative to its library folder,
  // so the library location itself never matches, and without the extension.
  function pathMatchText(path, roots) {
    var text = String(path || "");
    for (var i = 0; i < roots.length; i += 1) {
      var windows = isWindowsPath(text) || isWindowsPath(roots[i]);
      var full = comparablePath(text, windows);
      // A root of "/" trims to "", which still strips the leading separator.
      var root = comparablePath(roots[i].replace(/[\/\\]+$/, ""), windows);
      if (full.indexOf(root) === 0 && full.charAt(root.length) === "/") {
        text = text.slice(root.length + 1);
        break;
      }
    }
    return text.replace(/\.[^.\/\\]*$/, "");
  }

  // The title shown in previews: the item's title, else its file name.
  function displayTitle(row) {
    if (row.title) return row.title;
    var paths = mediaPaths(row);
    return paths.length ? paths[0].replace(/^.*[\/\\]/, "") : "";
  }

  function mediaPaths(row) {
    var files = row.files || row.visual_files || [];
    var ret = [];
    for (var i = 0; i < files.length; i += 1) {
      if (files[i] && files[i].path) ret.push(files[i].path);
    }
    return ret;
  }

  function matchesTerm(value, term) {
    var compiled = compileTerm(term);
    if (!compiled) return false;
    var dictionary = newDictionary();
    addDictionaryTerm(dictionary, { term: term }, compiled);
    return findTermMatches(value, dictionary, false).length > 0;
  }

  // Scene/image mode: every performer and tag against the selected items or
  // the whole library.

  function toEntity(type, row) {
    return {
      type: type,
      id: String(row.id),
      name: row.name,
      aliases: (type === "performer" ? row.alias_list : row.aliases) || [],
      ignore_auto_tag: !!row.ignore_auto_tag,
    };
  }

  // All performers and tags. Kinds that are switched off are still loaded:
  // their names keep shorter names inside them from matching.
  function loadEntities(gqlClient) {
    var ret = [];
    var i;
    var performers = gqlDo(gqlClient, FIND_ALL_PERFORMERS).findPerformers.performers || [];
    for (i = 0; i < performers.length; i += 1) ret.push(toEntity("performer", performers[i]));
    var tags = gqlDo(gqlClient, FIND_ALL_TAGS).findTags.tags || [];
    for (i = 0; i < tags.length; i += 1) ret.push(toEntity("tag", tags[i]));
    return ret;
  }

  // Indexes every name/alias by its word sequence. Entries that may not be
  // applied (ignored, switched-off kind, or not the target in performer/tag
  // mode) are still indexed as block-only, so a longer name in the text wins
  // over a shorter name inside it. Terms that look the same to the matcher
  // but belong to different performers (or different tags) are ambiguous and
  // are never applied. Paths compare words run together, so "Jane Doe" and
  // "Janedoe" are ambiguous only in paths.
  //
  // With targetKey ("performer:7"), only that entity is applied; all of its
  // aliases are used and none of them count as ambiguous.
  function buildDictionary(entities, args, result, targetKey) {
    var stats = result.dictionary;
    var candidates = [];
    var owners = Object.create(null);
    var i;

    function claim(key, entity, term) {
      if (!owners[key]) owners[key] = { type: entity.type, term: term, ids: [] };
      if (owners[key].ids.indexOf(entity.id) < 0) owners[key].ids.push(entity.id);
    }

    for (i = 0; i < entities.length; i += 1) {
      var entity = entities[i];
      var applicable;
      if (targetKey) {
        applicable = entity.type + ":" + entity.id === targetKey;
      } else {
        if (entity.type === "performer") stats.performers += 1;
        if (entity.type === "tag") stats.tags += 1;
        var ignored = args.respectIgnoreAutoTag && entity.ignore_auto_tag;
        var enabled = entity.type === "performer" ? args.matchPerformers : args.matchTags;
        if (ignored && enabled) result.skipped.ignoreAutoTag += 1;
        applicable = enabled && !ignored;
      }
      var nameKey = foldText(normalizeTerm(entity.name));
      var terms = uniqueTerms(entity.name, entity.aliases, applicable ? args.includeAliases : true);
      for (var t = 0; t < terms.length; t += 1) {
        var compiled = compileTerm(terms[t]);
        if (!compiled) {
          if (applicable) stats.unsupportedTerms += 1;
          continue;
        }
        if (applicable && !targetKey && compiled.text !== nameKey && compiled.wordCount < 2 && !args.allowSingleWordAliases) {
          stats.singleWordAliases += 1;
          continue;
        }
        if (applicable && !targetKey) {
          claim(entity.type + " " + compiled.key, entity, terms[t]);
          claim(entity.type + "/" + compiled.pathKey, entity, terms[t]);
        }
        candidates.push({ entity: entity, term: terms[t], compiled: compiled, applicable: applicable });
      }
    }

    // Report path-key groups only: terms sharing a title/details key always
    // share a path key too, so this lists each conflict once.
    for (var key in owners) {
      if (key.indexOf("/") < 0 || owners[key].ids.length < 2) continue;
      stats.ambiguousTerms += 1;
      if (result.ambiguous.length < args.previewLimit) result.ambiguous.push(owners[key]);
    }

    var dictionary = newDictionary();
    for (i = 0; i < candidates.length; i += 1) {
      var c = candidates[i];
      var entry = { type: c.entity.type, id: c.entity.id, name: c.entity.name, term: c.term, blockOnly: !c.applicable };
      if (c.applicable && !targetKey) {
        entry.textAmbiguous = owners[c.entity.type + " " + c.compiled.key].ids.length > 1;
        entry.pathAmbiguous = owners[c.entity.type + "/" + c.compiled.pathKey].ids.length > 1;
      }
      addDictionaryTerm(dictionary, entry, c.compiled);
      if (c.applicable && !(entry.textAmbiguous && entry.pathAmbiguous)) stats.terms += 1;
    }
    return dictionary;
  }

  function matchMedia(row, dictionary, args, result, roots) {
    var additions = [];
    var seen = {};
    var sources = [];
    var i;
    if (args.matchTitle) sources.push({ field: "title", text: row.title });
    if (args.matchDetails) sources.push({ field: "details", text: row.details });
    if (args.matchPath) {
      var paths = mediaPaths(row);
      for (i = 0; i < paths.length; i += 1) sources.push({ field: "path", text: pathMatchText(paths[i], roots), forPath: true });
    }
    for (var f = 0; f < sources.length; f += 1) {
      var matches = findTermMatches(sources[f].text, dictionary, sources[f].forPath);
      for (var m = 0; m < matches.length; m += 1) {
        var entry = matches[m].entry;
        if (entry.blockOnly || (sources[f].forPath ? entry.pathAmbiguous : entry.textAmbiguous)) continue;
        var key = entry.type + ":" + entry.id;
        if (seen[key]) continue;
        seen[key] = true;
        if (hasTarget(row, entry)) {
          result.skipped.alreadyTagged += 1;
          continue;
        }
        additions.push({
          type: entry.type,
          id: entry.id,
          name: entry.name,
          field: sources[f].field,
          term: entry.term,
        });
      }
    }
    return additions;
  }

  function mediaFilter(args, lastID) {
    var filter = {};
    if (args.respectOrganized) filter.organized = false;
    if (lastID > 0) filter.id = { value: lastID, modifier: "GREATER_THAN" };
    return filter;
  }

  function queryMediaPage(gqlClient, mediaType, variables) {
    if (mediaType === "scene") return gqlDo(gqlClient, FIND_MEDIA_SCENES, variables).findScenes.scenes || [];
    return gqlDo(gqlClient, FIND_MEDIA_IMAGES, variables).findImages.images || [];
  }

  function countMedia(gqlClient, mediaType, args) {
    if (args.mediaScope === "selected") return mediaType === "scene" ? args.sceneIds.length : args.imageIds.length;
    if (mediaType === "scene") return gqlDo(gqlClient, COUNT_MEDIA_SCENES, { scene_filter: mediaFilter(args, 0) }).findScenes.count;
    return gqlDo(gqlClient, COUNT_MEDIA_IMAGES, { image_filter: mediaFilter(args, 0) }).findImages.count;
  }

  // Calls fn with each page of scenes/images: the selected IDs, or every item
  // in ID order. buildFilter, when given, narrows the pages to likely matches.
  // onMissing(id, error) receives selected IDs that could not be loaded.
  function forEachMediaPage(gqlClient, mediaType, args, fn, buildFilter, onMissing) {
    var filterKey = mediaType === "scene" ? "scene_filter" : "image_filter";
    if (!buildFilter && args.mediaScope === "selected") {
      var ids = mediaType === "scene" ? args.sceneIds : args.imageIds;
      for (var i = 0; i < ids.length; i += args.pageSize) {
        var chunk = ids.slice(i, i + args.pageSize);
        var rows;
        try {
          rows = queryMediaPage(gqlClient, mediaType, { ids: chunk });
        } catch (err) {
          // Stash fails the whole lookup when one ID is missing; retry one by one.
          rows = [];
          for (var c = 0; c < chunk.length; c += 1) {
            try {
              rows = rows.concat(queryMediaPage(gqlClient, mediaType, { ids: [chunk[c]] }));
            } catch (itemErr) {
              if (onMissing) onMissing(chunk[c], itemErr);
            }
          }
        }
        fn(rows);
      }
      return;
    }

    var lastID = 0;
    while (true) {
      var variables = { filter: makeFindFilter(args) };
      variables[filterKey] = buildFilter ? buildFilter(lastID) : mediaFilter(args, lastID);
      var rows = queryMediaPage(gqlClient, mediaType, variables);
      fn(rows);
      var previousID = lastID;
      for (var r = 0; r < rows.length; r += 1) {
        var idInt = parseInt(rows[r].id, 10);
        if (!isNaN(idInt) && idInt > lastID) lastID = idInt;
      }
      if (rows.length < args.pageSize) break;
      if (lastID <= previousID) throw new Error("paging " + mediaType + "s stopped advancing after id " + lastID);
    }
  }

  function updateMedia(gqlClient, mediaType, row, additions) {
    var input = { ids: [String(row.id)] };
    var performerIds = [];
    var tagIds = [];
    for (var i = 0; i < additions.length; i += 1) {
      if (additions[i].type === "performer") performerIds.push(additions[i].id);
      else tagIds.push(additions[i].id);
    }
    if (performerIds.length) input.performer_ids = { ids: performerIds, mode: "ADD" };
    if (tagIds.length) input.tag_ids = { ids: tagIds, mode: "ADD" };
    gqlDo(gqlClient, mediaType === "scene" ? ADD_TO_SCENES : ADD_TO_IMAGES, { input: input });
  }

  function describeAdditions(additions) {
    var ret = [];
    for (var i = 0; i < additions.length; i += 1) {
      ret.push(additions[i].type + " \"" + additions[i].name + "\" (" + additions[i].field + ": \"" + additions[i].term + "\")");
    }
    return ret.join(", ");
  }

  function mediaResultTemplate(args) {
    var result = resultTemplate(args.mode);
    result.target = {
      type: "media",
      scope: args.mediaScope,
      sceneIds: args.sceneIds,
      imageIds: args.imageIds,
    };
    result.dictionary = { performers: 0, tags: 0, terms: 0, singleWordAliases: 0, ambiguousTerms: 0, unsupportedTerms: 0 };
    result.checked = { scenes: 0, images: 0 };
    result.added = { performers: 0, tags: 0 };
    result.ambiguous = [];
    return result;
  }

  function runMediaAutoTag(gqlClient, logger, args) {
    var result = mediaResultTemplate(args);
    var dictionary = buildDictionary(loadEntities(gqlClient), args, result);
    var roots = args.matchPath ? loadLibraryRoots(gqlClient) : [];
    var mediaTypes = [];
    var total = 0;
    var processed = 0;
    var i;

    if (args.matchScenes && (args.mediaScope === "all" || args.sceneIds.length)) mediaTypes.push("scene");
    if (args.matchImages && (args.mediaScope === "all" || args.imageIds.length)) mediaTypes.push("image");
    for (i = 0; i < mediaTypes.length; i += 1) total += countMedia(gqlClient, mediaTypes[i], args);

    logger.Info("AutoTag Extended " + args.mode + ": indexed " + result.dictionary.terms + " names/aliases from " + result.dictionary.performers + " performers and " + result.dictionary.tags + " tags; checking " + total + " items");

    for (i = 0; i < mediaTypes.length; i += 1) {
      var mediaType = mediaTypes[i];
      var plural = mediaType === "scene" ? "scenes" : "images";
      forEachMediaPage(gqlClient, mediaType, args, function (rows) {
        for (var r = 0; r < rows.length; r += 1) {
          var row = rows[r];
          processed += 1;
          if (args.respectOrganized && row.organized) {
            result.skipped.organized += 1;
            continue;
          }
          result.checked[plural] += 1;
          var additions = matchMedia(row, dictionary, args, result, roots);
          if (!additions.length) continue;

          result.matched[plural] += 1;
          for (var a = 0; a < additions.length; a += 1) {
            if (additions[a].type === "performer") result.added.performers += 1;
            else result.added.tags += 1;
          }
          var sampled = result.samples.length < args.previewLimit;
          if (sampled) {
            result.samples.push({ mediaType: mediaType, id: String(row.id), title: displayTitle(row), additions: additions });
          }
          if (args.mode === "preview") {
            if (args.mediaScope === "all" && sampled) {
              logger.Info("AutoTag Extended preview " + mediaType + " " + row.id + " would add " + describeAdditions(additions));
            }
            continue;
          }
          try {
            updateMedia(gqlClient, mediaType, row, additions);
            result.updated[plural] += 1;
            logger.Info("AutoTag Extended " + mediaType + " " + row.id + " added " + describeAdditions(additions));
          } catch (err) {
            result.errors.push({ mediaType: mediaType, id: String(row.id), error: String(err && err.message ? err.message : err) });
            logger.Warn("AutoTag Extended failed to update " + mediaType + " " + row.id + ": " + result.errors[result.errors.length - 1].error);
          }
        }
        if (args.reportProgress && total > 0) logger.Progress(Math.min(1, processed / total));
      }, null, function (id, err) {
        processed += 1;
        result.errors.push({ mediaType: mediaType, id: String(id), error: String(err && err.message ? err.message : err) });
        logger.Warn("AutoTag Extended could not load " + mediaType + " " + id + ": " + result.errors[result.errors.length - 1].error);
      });
    }

    logger.Info("AutoTag Extended " + args.mode + " finished: " + (result.matched.scenes + result.matched.images) + " of " + (result.checked.scenes + result.checked.images) + " items matched; " + result.added.performers + " performer and " + result.added.tags + " tag additions" + (args.mode === "apply" ? "; " + (result.updated.scenes + result.updated.images) + " items updated" : ""));
    return result;
  }

  // Performer/tag mode: one target against every scene/image. Stash's
  // database regex finds candidate items quickly (one query per media type,
  // all names and fields at once), then the shared engine confirms each
  // candidate so both modes apply exactly the same rules.

  // The database compares raw code points, so its separators also accept the
  // full-width forms of . - _ and the ideographic space.
  var SERVER_TERM_SEPARATOR = "[.\\-_\\t\\n\\f\\r \\x{3000}\\x{FF0E}\\x{FF0D}\\x{FF3F}]+";
  var SERVER_PATH_SEPARATOR = "[.\\-_ \\x{3000}\\x{FF0E}\\x{FF0D}\\x{FF3F}]*";

  function hexCode(code) {
    return "\\x{" + code.toString(16).toUpperCase() + "}";
  }

  // Each ASCII character also accepts its full-width form: "M" -> [MＭ].
  function serverPart(part) {
    var ret = "";
    for (var i = 0; i < part.length; i += 1) {
      var code = part.charCodeAt(i);
      if (code >= 0x21 && code <= 0x7e) ret += "[" + hexCode(code) + hexCode(code + 0xfee0) + "]";
      else ret += escapeRegex(part.charAt(i));
    }
    return ret;
  }

  // The candidate regex must never reject what the local check accepts, so
  // it uses a looser boundary (any non-ASCII-alphanumeric character), accepts
  // full-width characters, and lists both composed and decomposed spellings
  // of accented names, since the database does no Unicode normalization.
  function serverRegex(terms, forPath) {
    var separator = forPath ? SERVER_PATH_SEPARATOR : SERVER_TERM_SEPARATOR;
    var alternatives = [];
    var seen = Object.create(null);
    for (var i = 0; i < terms.length; i += 1) {
      var term = foldWidth(normalizeTerm(terms[i]));
      var forms = term.normalize ? [term.normalize("NFC"), term.normalize("NFD")] : [term];
      for (var k = 0; k < forms.length; k += 1) {
        var parts = forms[k].split(" ");
        var escaped = [];
        for (var j = 0; j < parts.length; j += 1) {
          if (parts[j]) escaped.push(serverPart(parts[j]));
        }
        var alternative = escaped.join(separator);
        if (alternative && !seen[alternative]) {
          seen[alternative] = true;
          alternatives.push(alternative);
        }
      }
    }
    return "(?i)(^|[^0-9A-Za-z])(?:" + alternatives.join("|") + ")($|[^0-9A-Za-z])";
  }

  // (title) OR (details) OR (path), each branch carrying the paging and
  // organized criteria because Stash applies them per branch.
  function targetFilter(terms, args, lastID) {
    var branches = [];
    if (args.matchTitle) branches.push({ field: "title", value: serverRegex(terms, false) });
    if (args.matchDetails) branches.push({ field: "details", value: serverRegex(terms, false) });
    if (args.matchPath) branches.push({ field: "path", value: serverRegex(terms, true) });
    var filter = null;
    for (var i = branches.length - 1; i >= 0; i -= 1) {
      var branch = mediaFilter(args, lastID);
      branch[branches[i].field] = { value: branches[i].value, modifier: "MATCHES_REGEX" };
      if (filter) branch.OR = filter;
      filter = branch;
    }
    return filter;
  }

  // Other performers/tags whose name or alias contains one of the target's
  // names. Only these can hold a longer name that outranks the target.
  function loadContainingEntities(gqlClient, terms, target) {
    var re = serverRegex(terms, false);
    var ret = [];
    var i;
    var performers = gqlDo(gqlClient, FIND_PERFORMERS_NAMED, {
      performer_filter: { name: { value: re, modifier: "MATCHES_REGEX" }, OR: { aliases: { value: re, modifier: "MATCHES_REGEX" } } },
    }).findPerformers.performers || [];
    for (i = 0; i < performers.length; i += 1) ret.push(toEntity("performer", performers[i]));
    var tags = gqlDo(gqlClient, FIND_TAGS_NAMED, {
      tag_filter: { name: { value: re, modifier: "MATCHES_REGEX" }, OR: { aliases: { value: re, modifier: "MATCHES_REGEX" } } },
    }).findTags.tags || [];
    for (i = 0; i < tags.length; i += 1) ret.push(toEntity("tag", tags[i]));
    var key = target.type + ":" + target.id;
    return ret.filter(function (entity) { return entity.type + ":" + entity.id !== key; });
  }

  function runTargetAutoTag(gqlClient, logger, args) {
    var result = resultTemplate(args.mode);
    var target = loadTarget(gqlClient, args);
    result.target = { type: target.type, id: target.id, name: target.name };

    if (args.respectIgnoreAutoTag && target.ignore_auto_tag) {
      result.skipped.ignoreAutoTag = 1;
      return result;
    }

    var terms = [];
    var allTerms = uniqueTerms(target.name, target.aliases, args.includeAliases);
    for (var t = 0; t < allTerms.length; t += 1) {
      if (compileTerm(allTerms[t])) terms.push(allTerms[t]);
    }
    if (!terms.length) return result;

    var entities = loadContainingEntities(gqlClient, terms, target);
    entities.push(target);
    var scratch = { dictionary: { performers: 0, tags: 0, terms: 0, singleWordAliases: 0, ambiguousTerms: 0, unsupportedTerms: 0 }, skipped: { ignoreAutoTag: 0 }, ambiguous: [] };
    var dictionary = buildDictionary(entities, args, scratch, target.type + ":" + target.id);

    var roots = args.matchPath ? loadLibraryRoots(gqlClient) : [];
    var candidates = [];
    var mediaTypes = [];
    if (args.matchScenes) mediaTypes.push("scene");
    if (args.matchImages) mediaTypes.push("image");

    for (var m = 0; m < mediaTypes.length; m += 1) {
      var mediaType = mediaTypes[m];
      var plural = mediaType === "scene" ? "scenes" : "images";
      forEachMediaPage(gqlClient, mediaType, args, function (rows) {
        for (var r = 0; r < rows.length; r += 1) {
          if (args.respectOrganized && rows[r].organized) {
            result.skipped.organized += 1;
            continue;
          }
          var additions = matchMedia(rows[r], dictionary, args, result, roots);
          if (!additions.length) continue;
          result.matched[plural] += 1;
          candidates.push({ mediaType: mediaType, row: rows[r], additions: additions });
          if (result.samples.length < args.previewLimit) {
            result.samples.push({ mediaType: mediaType, id: String(rows[r].id), title: displayTitle(rows[r]), field: additions[0].field, term: additions[0].term });
          }
        }
      }, function (lastID) {
        return targetFilter(terms, args, lastID);
      });
    }

    if (args.mode === "preview") return result;

    logger.Info("AutoTag Extended applying " + candidates.length + " updates for " + target.type + " " + target.name);
    for (var i = 0; i < candidates.length; i += 1) {
      var candidate = candidates[i];
      try {
        updateMedia(gqlClient, candidate.mediaType, candidate.row, candidate.additions);
        result.updated[candidate.mediaType === "scene" ? "scenes" : "images"] += 1;
      } catch (err) {
        result.errors.push({ mediaType: candidate.mediaType, id: String(candidate.row.id), error: String(err && err.message ? err.message : err) });
        logger.Warn("AutoTag Extended failed to update " + candidate.mediaType + " " + candidate.row.id + ": " + result.errors[result.errors.length - 1].error);
      }
      if (args.reportProgress) logger.Progress((i + 1) / candidates.length);
    }
    return result;
  }

  function runAutoTag(args, options) {
    args = normalizeArgs(args);
    var gqlClient = getGQL(options);
    var logger = getLog(options);

    if (args.mode === "compatibilityCheck") {
      return compatibilityCheck(gqlClient);
    }

    if (args.targetType === "media") {
      return runMediaAutoTag(gqlClient, logger, args);
    }
    return runTargetAutoTag(gqlClient, logger, args);
  }

  function fieldNames(typeInfo) {
    var ret = {};
    var fields = typeInfo && typeInfo.inputFields ? typeInfo.inputFields : [];
    for (var i = 0; i < fields.length; i += 1) ret[fields[i].name] = true;
    return ret;
  }

  function operationNames(schemaType) {
    var ret = {};
    var fields = schemaType && schemaType.fields ? schemaType.fields : [];
    for (var i = 0; i < fields.length; i += 1) ret[fields[i].name] = true;
    return ret;
  }

  function requireFields(name, actual, required, missing) {
    for (var i = 0; i < required.length; i += 1) {
      if (!actual[required[i]]) missing.push(name + "." + required[i]);
    }
  }

  function compatibilityCheck(gqlClient) {
    var data = gqlDo(gqlClient, INTROSPECTION, {});
    var missing = [];
    requireFields("SceneFilterType", fieldNames(data.sceneFilter), ["id", "title", "details", "path", "organized", "OR"], missing);
    requireFields("ImageFilterType", fieldNames(data.imageFilter), ["id", "title", "details", "path", "organized", "OR"], missing);
    requireFields("BulkSceneUpdateInput", fieldNames(data.sceneUpdate), ["ids", "performer_ids", "tag_ids"], missing);
    requireFields("BulkImageUpdateInput", fieldNames(data.imageUpdate), ["ids", "performer_ids", "tag_ids"], missing);
    requireFields("Query", operationNames(data.queryType && data.queryType.queryType), ["findScenes", "findImages", "findPerformer", "findTag", "findPerformers", "findTags"], missing);
    requireFields("Mutation", operationNames(data.queryType && data.queryType.mutationType), ["bulkSceneUpdate", "bulkImageUpdate", "runPluginTask", "runPluginOperation"], missing);
    return {
      mode: "compatibilityCheck",
      ok: missing.length === 0,
      missing: missing,
      pluginID: PLUGIN_ID,
      taskName: TASK_NAME,
    };
  }

  function loadSettings(gqlClient) {
    try {
      var data = gqlDo(gqlClient, PLUGIN_SETTINGS, { include: [PLUGIN_ID] });
      var plugins = data && data.configuration && data.configuration.plugins;
      return (plugins && plugins[PLUGIN_ID]) || {};
    } catch (err) {
      return {};
    }
  }

  // Saved plugin settings fill in options the caller did not pass, so tasks
  // started from the Tasks page follow the settings page.
  function applySettings(args, settings) {
    var ret = {};
    var key;
    for (key in args) ret[key] = args[key];
    settings = settings || {};
    for (key in DEFAULTS) {
      if (!own(DEFAULTS, key)) continue;
      var missing = ret[key] === undefined || ret[key] === null || ret[key] === "";
      if (missing && settings[key] !== undefined && settings[key] !== null) ret[key] = settings[key];
    }
    return ret;
  }

  function main() {
    try {
      return {
        Output: runAutoTag(applySettings(input.Args || {}, loadSettings(gql))),
      };
    } catch (err) {
      return {
        Error: String(err && err.message ? err.message : err),
      };
    }
  }

  var api = {
    DEFAULTS: DEFAULTS,
    PLUGIN_ID: PLUGIN_ID,
    TASK_NAME: TASK_NAME,
    normalizeArgs: normalizeArgs,
    normalizeTerm: normalizeTerm,
    uniqueTerms: uniqueTerms,
    escapeRegex: escapeRegex,
    serverRegex: serverRegex,
    matchesTerm: matchesTerm,
    toIdList: toIdList,
    isWordCode: isWordCode,
    compileTerm: compileTerm,
    newDictionary: newDictionary,
    addDictionaryTerm: addDictionaryTerm,
    findTermMatches: findTermMatches,
    pathMatchText: pathMatchText,
    runAutoTag: runAutoTag,
    applySettings: applySettings,
    compatibilityCheck: compatibilityCheck,
    _queries: {
      FIND_PERFORMER: FIND_PERFORMER,
      FIND_TAG: FIND_TAG,
      FIND_ALL_PERFORMERS: FIND_ALL_PERFORMERS,
      FIND_ALL_TAGS: FIND_ALL_TAGS,
      FIND_PERFORMERS_NAMED: FIND_PERFORMERS_NAMED,
      FIND_TAGS_NAMED: FIND_TAGS_NAMED,
      FIND_MEDIA_SCENES: FIND_MEDIA_SCENES,
      FIND_MEDIA_IMAGES: FIND_MEDIA_IMAGES,
      LIBRARY_PATHS: LIBRARY_PATHS,
      COUNT_MEDIA_SCENES: COUNT_MEDIA_SCENES,
      COUNT_MEDIA_IMAGES: COUNT_MEDIA_IMAGES,
      ADD_TO_SCENES: ADD_TO_SCENES,
      ADD_TO_IMAGES: ADD_TO_IMAGES,
      INTROSPECTION: INTROSPECTION,
    },
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }

  root.AutoTagExtendedTask = api;

  if (typeof input !== "undefined") {
    return main();
  }
})(this);
