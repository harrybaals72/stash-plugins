(function () {
  var PluginApi = window.PluginApi;
  if (!PluginApi || !PluginApi.React || !PluginApi.ReactDOM || !PluginApi.libraries) return;

  var React = PluginApi.React;
  var ReactDOM = PluginApi.ReactDOM;
  var h = React.createElement;

  function createFallbackBootstrap() {
    function noop() {}
    function wrap(tag, extraProps) {
      return function (props) {
        return h(tag, Object.assign({}, extraProps, props), props && props.children);
      };
    }

    function Checkbox(props) {
      return h("label", { className: "form-check" },
        h("input", {
          type: "checkbox",
          checked: !!props.checked,
          disabled: !!props.disabled,
          onChange: function (event) {
            props.onChange && props.onChange(event);
          },
        }),
        " ",
        props.label
      );
    }

    function Control(props) {
      return h("input", {
        type: props.type || "text",
        min: props.min,
        max: props.max,
        value: props.value,
        disabled: !!props.disabled,
        onChange: props.onChange,
      });
    }

    function Modal(props) {
      if (!props.show) return null;
      return h("div", { role: "dialog", className: "autotag-extended-modal" },
        h("div", { className: "autotag-extended-modal-card" }, props.children)
      );
    }

    Modal.Header = wrap("div", { className: "autotag-extended-modal-header" });
    Modal.Title = wrap("div", { className: "autotag-extended-modal-title" });
    Modal.Body = wrap("div", { className: "autotag-extended-modal-body" });
    Modal.Footer = wrap("div", { className: "autotag-extended-modal-footer" });

    return {
      Button: function (props) { return h("button", { type: props.type || "button", disabled: !!props.disabled, onClick: props.onClick }, props.children); },
      Form: { Check: Checkbox, Group: wrap("div"), Label: wrap("label"), Control: Control },
      Modal: Modal,
      Alert: function (props) { return h("div", { role: props.role || "alert", className: "alert" }, props.children); },
      noop: noop,
    };
  }

  var Bootstrap = (PluginApi.libraries && PluginApi.libraries.Bootstrap) || createFallbackBootstrap();

  var PLUGIN_ID = "autotag-extended";
  var TASK_NAME = "Apply title/details auto tag";

  var FIND_PERFORMER = "query AutoTagExtendedUiPerformer($id: ID!) { findPerformer(id: $id) { id name alias_list ignore_auto_tag } }";
  var FIND_TAG = "query AutoTagExtendedUiTag($id: ID!) { findTag(id: $id) { id name aliases ignore_auto_tag } }";
  var RUN_OPERATION = "mutation AutoTagExtendedRunOperation($plugin_id: ID!, $args: Map) { runPluginOperation(plugin_id: $plugin_id, args: $args) }";
  var RUN_TASK = "mutation AutoTagExtendedRunTask($plugin_id: ID!, $task_name: String!, $args_map: Map) { runPluginTask(plugin_id: $plugin_id, task_name: $task_name, args_map: $args_map) }";

  var defaults = {
    includeAliases: true,
    matchScenes: true,
    matchImages: true,
    matchTitle: true,
    matchDetails: true,
    matchPath: true,
    respectOrganized: true,
    respectIgnoreAutoTag: true,
    pageSize: 250,
    previewLimit: 25,
  };

  var mediaDefaults = {
    matchPerformers: true,
    matchTags: true,
    includeAliases: true,
    allowSingleWordAliases: false,
    matchTitle: true,
    matchDetails: true,
    matchPath: true,
    respectOrganized: true,
    respectIgnoreAutoTag: true,
  };

  function graphql(query, variables) {
    return fetch("/graphql", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: query, variables: variables || {} }),
    }).then(function (response) {
      return response.text().then(function (body) {
        var json;
        try {
          json = JSON.parse(body);
        } catch (err) {
          throw new Error("Stash returned non-JSON HTTP " + response.status + ": " + body.slice(0, 500));
        }

        if (!response.ok || json.errors) {
          throw new Error(JSON.stringify(json.errors || json, null, 2));
        }

        return json.data;
      });
    });
  }

  function parsePluginResult(value) {
    if (typeof value !== "string") return value;
    try {
      return JSON.parse(value);
    } catch (err) {
      return value;
    }
  }

  function findTarget(targetType, targetId) {
    return graphql(targetType === "performer" ? FIND_PERFORMER : FIND_TAG, { id: targetId }).then(function (data) {
      if (targetType === "performer" && data && data.findPerformer) {
        return {
          type: "performer",
          id: String(data.findPerformer.id),
          name: data.findPerformer.name,
          aliases: data.findPerformer.alias_list || [],
          ignoreAutoTag: !!data.findPerformer.ignore_auto_tag,
        };
      }

      if (targetType === "tag" && data && data.findTag) {
        return {
          type: "tag",
          id: String(data.findTag.id),
          name: data.findTag.name,
          aliases: data.findTag.aliases || [],
          ignoreAutoTag: !!data.findTag.ignore_auto_tag,
        };
      }

      throw new Error("Unable to load " + targetType + " #" + targetId);
    });
  }

  function titleCase(value) {
    return value.charAt(0).toUpperCase() + value.slice(1);
  }

  function checkbox(label, checked, onChange, disabled) {
    return h(Bootstrap.Form.Check, {
      type: "checkbox",
      label: label,
      checked: checked,
      disabled: !!disabled,
      onChange: function (event) {
        onChange(event.currentTarget.checked);
      },
    });
  }

  function numberInput(label, value, min, max, onChange) {
    return h(Bootstrap.Form.Group, null,
      h(Bootstrap.Form.Label, null, label),
      h(Bootstrap.Form.Control, {
        type: "number",
        min: min,
        max: max,
        value: value,
        onChange: function (event) {
          onChange(event.currentTarget.value);
        },
      })
    );
  }

  function ResultSummary(props) {
    var result = props.result;
    if (!result || typeof result !== "object") return null;

    var samples = result.samples || [];
    return h("div", { className: "autotag-extended-summary" },
      h("div", null,
        "Matches: ",
        h("strong", null, String(result.matched && result.matched.scenes || 0)),
        " scenes, ",
        h("strong", null, String(result.matched && result.matched.images || 0)),
        " images"
      ),
      h("div", null,
        "Skipped: ",
        String(result.skipped && result.skipped.alreadyTagged || 0),
        " already tagged, ",
        String(result.skipped && result.skipped.organized || 0),
        " organized, ",
        String(result.skipped && result.skipped.ignoreAutoTag || 0),
        " ignore-auto-tag target"
      ),
      result.mode === "apply" ? h("div", null,
        "Updated: ",
        String(result.updated && result.updated.scenes || 0),
        " scenes, ",
        String(result.updated && result.updated.images || 0),
        " images"
      ) : null,
      samples.length ? h("ol", { className: "autotag-extended-samples" }, samples.map(function (sample) {
        return h("li", { key: sample.mediaType + ":" + sample.id + ":" + sample.field },
          sample.title || "(untitled)",
          h("span", { className: "autotag-extended-sample-meta" },
            titleCase(sample.mediaType),
            " #",
            sample.id,
            " matched ",
            sample.field,
            " using \"",
            sample.term,
            "\""
          )
        );
      })) : null
    );
  }

  function AutoTagExtendedModal(props) {
    var target = props.target;
    var onHide = props.onHide;
    var statePair = React.useState(defaults);
    var settings = statePair[0];
    var setSettings = statePair[1];
    var previewPair = React.useState(null);
    var preview = previewPair[0];
    var setPreview = previewPair[1];
    var errorPair = React.useState("");
    var error = errorPair[0];
    var setError = errorPair[1];
    var jobPair = React.useState("");
    var jobID = jobPair[0];
    var setJobID = jobPair[1];
    var previewingPair = React.useState(false);
    var previewing = previewingPair[0];
    var setPreviewing = previewingPair[1];
    var applyingPair = React.useState(false);
    var applying = applyingPair[0];
    var setApplying = applyingPair[1];

    function setOption(key, value) {
      setSettings(function (current) {
        var next = {};
        Object.keys(current).forEach(function (name) {
          next[name] = current[name];
        });
        next[key] = value;
        return next;
      });
      setPreview(null);
    }

    function args(mode) {
      var pageSize = parseInt(settings.pageSize, 10);
      var previewLimit = parseInt(settings.previewLimit, 10);
      return {
        mode: mode,
        targetType: target.type,
        targetId: target.id,
        includeAliases: !!settings.includeAliases,
        matchScenes: !!settings.matchScenes,
        matchImages: !!settings.matchImages,
        matchTitle: !!settings.matchTitle,
        matchDetails: !!settings.matchDetails,
        matchPath: !!settings.matchPath,
        respectOrganized: !!settings.respectOrganized,
        respectIgnoreAutoTag: !!settings.respectIgnoreAutoTag,
        pageSize: isNaN(pageSize) ? defaults.pageSize : pageSize,
        previewLimit: isNaN(previewLimit) ? defaults.previewLimit : previewLimit,
      };
    }

    function handlePreview() {
      setError("");
      setJobID("");
      setPreviewing(true);
      graphql(RUN_OPERATION, {
        plugin_id: PLUGIN_ID,
        args: args("preview"),
      }).then(function (data) {
        setPreview(parsePluginResult(data && data.runPluginOperation) || null);
      }).catch(function (err) {
        setError(err && err.message ? err.message : String(err));
      }).finally(function () {
        setPreviewing(false);
      });
    }

    function handleApply() {
      setError("");
      setJobID("");
      setApplying(true);
      graphql(RUN_TASK, {
        plugin_id: PLUGIN_ID,
        task_name: TASK_NAME,
        args_map: args("apply"),
      }).then(function (data) {
        setJobID(String(data && data.runPluginTask || ""));
      }).catch(function (err) {
        setError(err && err.message ? err.message : String(err));
      }).finally(function () {
        setApplying(false);
      });
    }

    return h(Bootstrap.Modal, {
      show: true,
      onHide: onHide,
      className: "autotag-extended-modal",
      size: "lg",
    },
      h(Bootstrap.Modal.Header, { closeButton: true },
        h(Bootstrap.Modal.Title, null, "Auto Tag Title/Details")
      ),
      h(Bootstrap.Modal.Body, null,
        h("div", { className: "autotag-extended-target" },
          h("span", { className: "autotag-extended-target-name" }, target.name),
          h("span", { className: "autotag-extended-muted" },
            titleCase(target.type),
            target.aliases && target.aliases.length ? " aliases: " + target.aliases.join(", ") : ""
          )
        ),
        target.ignoreAutoTag && settings.respectIgnoreAutoTag ? h(Bootstrap.Alert, { variant: "warning" },
          "This ",
          target.type,
          " has ignore auto tag enabled. Disable the respect option below to run anyway."
        ) : null,
        h("div", { className: "autotag-extended-grid" },
          h("div", null,
            checkbox("Include aliases", settings.includeAliases, function (value) { setOption("includeAliases", value); }),
            checkbox("Scenes", settings.matchScenes, function (value) { setOption("matchScenes", value); }),
            checkbox("Images", settings.matchImages, function (value) { setOption("matchImages", value); })
          ),
          h("div", null,
            checkbox("Title", settings.matchTitle, function (value) { setOption("matchTitle", value); }),
            checkbox("Details", settings.matchDetails, function (value) { setOption("matchDetails", value); }),
            checkbox("File path", settings.matchPath, function (value) { setOption("matchPath", value); }),
            checkbox("Skip organized media", settings.respectOrganized, function (value) { setOption("respectOrganized", value); }),
            checkbox("Respect ignore auto tag", settings.respectIgnoreAutoTag, function (value) { setOption("respectIgnoreAutoTag", value); })
          ),
          h("div", null,
            numberInput("Query page size", settings.pageSize, 1, 1000, function (value) { setOption("pageSize", value); }),
            numberInput("Preview limit", settings.previewLimit, 0, 250, function (value) { setOption("previewLimit", value); })
          )
        ),
        error ? h(Bootstrap.Alert, { variant: "danger" }, error) : null,
        jobID ? h(Bootstrap.Alert, { variant: "success" }, "Task queued as job ", jobID, ". Follow its progress under Settings > Tasks, then reload this page to see the changes.") : null,
        h(ResultSummary, { result: preview })
      ),
      h(Bootstrap.Modal.Footer, null,
        h(Bootstrap.Button, { variant: "secondary", onClick: onHide }, "Close"),
        h(Bootstrap.Button, { variant: "outline-primary", onClick: handlePreview, disabled: previewing || applying }, previewing ? "Previewing..." : "Preview"),
        h(Bootstrap.Button, { variant: "primary", onClick: handleApply, disabled: previewing || applying }, applying ? "Applying..." : "Apply")
      )
    );
  }

  function MediaResultSummary(props) {
    var result = props.result;
    if (!result || typeof result !== "object") return null;

    var additions = [];
    (result.samples || []).forEach(function (sample) {
      (sample.additions || []).forEach(function (addition) {
        additions.push(addition);
      });
    });
    var dictionary = result.dictionary || {};
    var skipped = result.skipped || {};
    var applied = result.mode === "apply";

    return h("div", { className: "autotag-extended-summary" },
      h("div", null,
        applied ? "Added: " : "Would add: ",
        h("strong", null, String(result.added && result.added.performers || 0)),
        " performers, ",
        h("strong", null, String(result.added && result.added.tags || 0)),
        " tags"
      ),
      h("div", { className: "autotag-extended-muted" },
        "Checked ",
        String(dictionary.terms || 0),
        " names/aliases. Skipped: ",
        String(skipped.alreadyTagged || 0),
        " already present, ",
        String(dictionary.singleWordAliases || 0),
        " single-word aliases, ",
        String(dictionary.ambiguousTerms || 0),
        " ambiguous, ",
        String(skipped.ignoreAutoTag || 0),
        " ignore-auto-tag",
        skipped.organized ? ", item is organized" : ""
      ),
      additions.length ? h("ul", { className: "autotag-extended-samples" }, additions.map(function (addition) {
        return h("li", { key: addition.type + ":" + addition.id },
          titleCase(addition.type),
          ": ",
          h("strong", null, addition.name),
          h("span", { className: "autotag-extended-sample-meta" },
            "matched ",
            addition.field,
            " using \"",
            addition.term,
            "\""
          )
        );
      })) : h("div", null, applied ? "Nothing was added." : "No new performers or tags found."),
      result.errors && result.errors.length ? h(Bootstrap.Alert, { variant: "danger" }, result.errors.map(function (err) { return err.error; }).join("; ")) : null,
      applied && additions.length ? h("div", null,
        h(Bootstrap.Button, { variant: "link", onClick: function () { window.location.reload(); } }, "Reload page to see changes")
      ) : null
    );
  }

  function MediaAutoTagModal(props) {
    var target = props.target;
    var onHide = props.onHide;
    var statePair = React.useState(mediaDefaults);
    var settings = statePair[0];
    var setSettings = statePair[1];
    var resultPair = React.useState(null);
    var result = resultPair[0];
    var setResult = resultPair[1];
    var errorPair = React.useState("");
    var error = errorPair[0];
    var setError = errorPair[1];
    var runningPair = React.useState("");
    var running = runningPair[0];
    var setRunning = runningPair[1];

    function setOption(key, value) {
      setSettings(function (current) {
        var next = {};
        Object.keys(current).forEach(function (name) {
          next[name] = current[name];
        });
        next[key] = value;
        return next;
      });
      setResult(null);
    }

    function run(mode) {
      var args = {
        mode: mode,
        targetType: "media",
        mediaScope: "selected",
        matchScenes: target.type === "scene",
        matchImages: target.type === "image",
        previewLimit: 250,
      };
      Object.keys(settings).forEach(function (name) {
        args[name] = !!settings[name];
      });
      if (target.type === "scene") args.sceneIds = [target.id];
      else args.imageIds = [target.id];

      setError("");
      setRunning(mode);
      graphql(RUN_OPERATION, { plugin_id: PLUGIN_ID, args: args }).then(function (data) {
        setResult(parsePluginResult(data && data.runPluginOperation) || null);
      }).catch(function (err) {
        setError(err && err.message ? err.message : String(err));
      }).finally(function () {
        setRunning("");
      });
    }

    var noScope = !settings.matchPerformers && !settings.matchTags;
    var noFields = !settings.matchTitle && !settings.matchDetails && !settings.matchPath;

    return h(Bootstrap.Modal, {
      show: true,
      onHide: onHide,
      className: "autotag-extended-modal",
      size: "lg",
    },
      h(Bootstrap.Modal.Header, { closeButton: true },
        h(Bootstrap.Modal.Title, null, "Auto Tag Title/Details")
      ),
      h(Bootstrap.Modal.Body, null,
        h("div", { className: "autotag-extended-target" },
          h("span", { className: "autotag-extended-target-name" }, titleCase(target.type), " #", target.id),
          h("span", { className: "autotag-extended-muted" }, "Finds every performer and tag whose name or alias appears in this ", target.type, "'s title, details, or file path.")
        ),
        h("div", { className: "autotag-extended-grid" },
          h("div", null,
            checkbox("Performers", settings.matchPerformers, function (value) { setOption("matchPerformers", value); }),
            checkbox("Tags", settings.matchTags, function (value) { setOption("matchTags", value); }),
            checkbox("Include aliases", settings.includeAliases, function (value) { setOption("includeAliases", value); }),
            checkbox("Single-word aliases", settings.allowSingleWordAliases, function (value) { setOption("allowSingleWordAliases", value); }, !settings.includeAliases)
          ),
          h("div", null,
            checkbox("Title", settings.matchTitle, function (value) { setOption("matchTitle", value); }),
            checkbox("Details", settings.matchDetails, function (value) { setOption("matchDetails", value); }),
            checkbox("File path", settings.matchPath, function (value) { setOption("matchPath", value); }),
            checkbox("Skip if organized", settings.respectOrganized, function (value) { setOption("respectOrganized", value); }),
            checkbox("Respect ignore auto tag", settings.respectIgnoreAutoTag, function (value) { setOption("respectIgnoreAutoTag", value); })
          )
        ),
        error ? h(Bootstrap.Alert, { variant: "danger" }, error) : null,
        h(MediaResultSummary, { result: result })
      ),
      h(Bootstrap.Modal.Footer, null,
        h(Bootstrap.Button, { variant: "secondary", onClick: onHide }, "Close"),
        h(Bootstrap.Button, { variant: "outline-primary", onClick: function () { run("preview"); }, disabled: !!running || noScope || noFields }, running === "preview" ? "Previewing..." : "Preview"),
        h(Bootstrap.Button, { variant: "primary", onClick: function () { run("apply"); }, disabled: !!running || noScope || noFields }, running === "apply" ? "Applying..." : "Apply")
      )
    );
  }

  function isMediaType(type) {
    return type === "scene" || type === "image";
  }

  function AutoTagExtendedButton(props) {
    var targetType = props.targetType;
    var targetId = props.targetId;
    var modalPair = React.useState(false);
    var showModal = modalPair[0];
    var setShowModal = modalPair[1];
    var targetPair = React.useState(null);
    var target = targetPair[0];
    var setTarget = targetPair[1];
    var loadingPair = React.useState(false);
    var loading = loadingPair[0];
    var setLoading = loadingPair[1];
    var errorPair = React.useState("");
    var error = errorPair[0];
    var setError = errorPair[1];
    var currentKey = React.useRef("");
    currentKey.current = targetType + ":" + targetId;

    React.useEffect(function () {
      setShowModal(false);
      setTarget(null);
      setLoading(false);
      setError("");
    }, [targetType, targetId]);

    function openModal() {
      if (target) {
        setShowModal(true);
        return;
      }
      if (isMediaType(targetType)) {
        setTarget({ type: targetType, id: String(targetId) });
        setShowModal(true);
        return;
      }

      var requestKey = targetType + ":" + targetId;
      setLoading(true);
      setError("");
      findTarget(targetType, targetId).then(function (loadedTarget) {
        if (currentKey.current !== requestKey) return;
        setTarget(loadedTarget);
        setShowModal(true);
      }).catch(function (err) {
        if (currentKey.current !== requestKey) return;
        setError(err && err.message ? err.message : String(err));
      }).finally(function () {
        if (currentKey.current === requestKey) setLoading(false);
      });
    }

    return h("span", { className: "autotag-extended-action" },
      h(Bootstrap.Button, {
        variant: "secondary",
        size: "sm",
        disabled: loading || !targetId,
        onClick: openModal,
      }, loading ? "Loading..." : "Auto tag title/details"),
      error ? h("span", { className: "autotag-extended-error text-danger ml-2" }, error) : null,
      showModal && target ? h(isMediaType(target.type) ? MediaAutoTagModal : AutoTagExtendedModal, {
        target: target,
        onHide: function () { setShowModal(false); },
      }) : null
    );
  }

  function pageTarget() {
    var path = window.location.pathname;
    var performerMatch = path.match(/^\/performers\/(\d+)/);
    if (performerMatch) {
      return { type: "performer", id: performerMatch[1], selectors: ["#performer-page .performer-head", "#performer-page .detail-container", "#performer-page .detail-header", "#performer-page"] };
    }
    var tagMatch = path.match(/^\/tags\/(\d+)/);
    if (tagMatch) {
      return { type: "tag", id: tagMatch[1], selectors: ["#tag-page .tag-head", "#tag-page .detail-container", "#tag-page .detail-header", "#tag-page"] };
    }
    var sceneMatch = path.match(/^\/scenes\/(\d+)/);
    if (sceneMatch) {
      return { type: "scene", id: sceneMatch[1], selectors: [".scene-tabs > div:first-child", ".scene-tabs"] };
    }
    var imageMatch = path.match(/^\/images\/(\d+)/);
    if (imageMatch) {
      return { type: "image", id: imageMatch[1], selectors: [".image-tabs > div:first-child", ".image-tabs"] };
    }
    return null;
  }

  function renderInto(root, props) {
    if (ReactDOM.createRoot) {
      if (!root.__autotagExtendedRoot) root.__autotagExtendedRoot = ReactDOM.createRoot(root);
      root.__autotagExtendedRoot.render(h(AutoTagExtendedButton, props));
    } else {
      ReactDOM.render(h(AutoTagExtendedButton, props), root);
    }
  }

  function TestRoute() {
    var params = new URLSearchParams(window.location.search);
    return h("div", { className: "autotag-extended-test-route", style: { padding: "1rem" } },
      h(AutoTagExtendedButton, {
        targetType: params.get("targetType") || "performer",
        targetId: params.get("targetId") || "",
      })
    );
  }

  if (PluginApi.register && PluginApi.register.route) {
    PluginApi.register.route("/plugin/autotag-extended/test-ui", TestRoute);
  }

  function mount() {
    var target = pageTarget();
    var existing = document.querySelector("[data-autotag-extended-root]");
    if (!target) {
      if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
      return;
    }

    var host = null;
    for (var i = 0; i < target.selectors.length; i += 1) {
      host = document.querySelector(target.selectors[i]);
      if (host) break;
    }
    if (!host) return;

    if (existing && !host.contains(existing) && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }

    var root = host.querySelector("[data-autotag-extended-root]");
    if (!root) {
      root = document.createElement("div");
      root.setAttribute("data-autotag-extended-root", "true");
      root.className = "autotag-extended-root";
      host.appendChild(root);
    } else if (!root.classList.contains("autotag-extended-root")) {
      root.classList.add("autotag-extended-root");
    }

    renderInto(root, { targetType: target.type, targetId: target.id });
  }

  var mountTimer = null;
  function scheduleMount() {
    if (mountTimer) window.clearTimeout(mountTimer);
    mountTimer = window.setTimeout(mount, 75);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scheduleMount);
  } else {
    scheduleMount();
  }

  if (PluginApi.Event && PluginApi.Event.addEventListener) {
    PluginApi.Event.addEventListener("stash:location", scheduleMount);
  }

  function startObserver() {
    if (!document.body || !window.MutationObserver) return;
    var observer = new MutationObserver(scheduleMount);
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.body) {
    startObserver();
  } else {
    document.addEventListener("DOMContentLoaded", startObserver);
  }
})();
