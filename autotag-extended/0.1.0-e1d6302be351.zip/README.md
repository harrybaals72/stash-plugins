# AutoTag Extended

AutoTag Extended is a Stash plugin that adds a separate title/details based auto-tag action to performer and tag detail pages.

It does not change stock auto tag behavior. Stock auto tag remains path/filename based; this plugin only searches scene/image `title` and `details`.

## Install

Copy the `autotag-extended` folder into your Stash plugin directory, then click `Reload Plugins` in Stash.

The YAML filename is `autotag-extended.yml`, so the plugin id is `autotag-extended`.

## Use

Open a performer or tag page and click `Auto tag title/details`.

The modal supports:

- preview without writes
- applying to scenes
- applying to images
- matching title
- matching details
- matching aliases
- skipping organized media
- respecting `ignore_auto_tag`

## Test

Run pure-function tests:

```text
npm run stash -- test --plugin autotag-extended --suite unit
```

These tests do not require Stash.

Run GraphQL integration and browser tests against isolated Stash instances:

```text
npm run stash -- test --plugin autotag-extended --suite integration
npm run stash -- test --plugin autotag-extended --suite ui
```

Build and validate the deployable package:

```text
npm run stash -- validate --plugin autotag-extended
npm run stash -- build --plugin autotag-extended
```

The shared test runner builds and installs the plugin artifact, reloads Stash, creates isolated fixtures, waits for jobs, verifies GraphQL state, and cleans up. The UI suite includes a mocked `PluginApi` contract test and a live browser interaction against managed Stash. See the repository [testing guide](../../docs/testing/README.md) and [deployment guide](../../docs/deployment/README.md) for harness settings and target rollout.

## Validation checklist

Use a disposable Stash database for release checks:

- create one performer with a name and alias and one tag with a name and alias
- create unorganized scene and image records with matching title text
- create unorganized scene and image records with matching details text
- create records that already contain the performer/tag
- create organized records that match
- run preview first and confirm counts and samples
- run apply and confirm only the expected performer/tag relationships were added
- repeat with `Respect ignore auto tag` enabled and disabled
- repeat after upgrading Stash by running the unit tests and the `Compatibility check` plugin task
