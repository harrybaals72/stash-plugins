(function (root) {
  var PLUGIN_ID = "autotag-extended";

  var DEFAULTS = {
    includeAliases: true,
    matchScenes: true,
    matchImages: true,
    matchTitle: true,
    matchDetails: true,
    respectOrganized: true,
    respectIgnoreAutoTag: true,
    pageSize: 250,
    previewLimit: 25,
  };

  var TASK_NAME = "Apply title/details auto tag";

  var FIND_PERFORMER = "\
query FindPerformerForAutoTagExtended($id: ID!) {\
  findPerformer(id: $id) {\
    id\
    name\
    alias_list\
    ignore_auto_tag\
  }\
}";

  var FIND_TAG = "\
query FindTagForAutoTagExtended($id: ID!) {\
  findTag(id: $id) {\
    id\
    name\
    aliases\
    ignore_auto_tag\
  }\
}";

  var FIND_SCENES = "\
query FindScenesForAutoTagExtended($filter: FindFilterType, $scene_filter: SceneFilterType) {\
  findScenes(filter: $filter, scene_filter: $scene_filter) {\
    count\
    scenes {\
      id\
      title\
      details\
      organized\
      performers { id name }\
      tags { id name }\
    }\
  }\
}";

  var FIND_IMAGES = "\
query FindImagesForAutoTagExtended($filter: FindFilterType, $image_filter: ImageFilterType) {\
  findImages(filter: $filter, image_filter: $image_filter) {\
    count\
    images {\
      id\
      title\
      details\
      organized\
      performers { id name }\
      tags { id name }\
    }\
  }\
}";

  var UPDATE_SCENE = "\
mutation UpdateSceneForAutoTagExtended($input: SceneUpdateInput!) {\
  sceneUpdate(input: $input) {\
    id\
    performers { id }\
    tags { id }\
  }\
}";

  var UPDATE_IMAGE = "\
mutation UpdateImageForAutoTagExtended($input: ImageUpdateInput!) {\
  imageUpdate(input: $input) {\
    id\
    performers { id }\
    tags { id }\
  }\
}";

  var INTROSPECTION = "\
query AutoTagExtendedCompatibility {\
  sceneFilter: __type(name: \"SceneFilterType\") { inputFields { name } }\
  imageFilter: __type(name: \"ImageFilterType\") { inputFields { name } }\
  sceneUpdate: __type(name: \"SceneUpdateInput\") { inputFields { name } }\
  imageUpdate: __type(name: \"ImageUpdateInput\") { inputFields { name } }\
  queryType: __schema { queryType { fields { name } } mutationType { fields { name } } }\
}";

  function own(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
  }

  function toBool(value, fallback) {
    if (value === undefined || value === null || value === "") return fallback;
    if (value === true || value === false) return value;
    if (value === "true") return true;
    if (value === "false") return false;
    return fallback;
  }

  function toInt(value, fallback, min, max) {
    var parsed = parseInt(value, 10);
    if (isNaN(parsed)) parsed = fallback;
    if (parsed < min) parsed = min;
    if (parsed > max) parsed = max;
    return parsed;
  }

  function normalizeArgs(args) {
    args = args || {};
    var ret = {
      mode: args.mode || "apply",
      targetType: args.targetType,
      targetId: args.targetId === undefined || args.targetId === null ? "" : String(args.targetId),
      includeAliases: toBool(args.includeAliases, DEFAULTS.includeAliases),
      matchScenes: toBool(args.matchScenes, DEFAULTS.matchScenes),
      matchImages: toBool(args.matchImages, DEFAULTS.matchImages),
      matchTitle: toBool(args.matchTitle, DEFAULTS.matchTitle),
      matchDetails: toBool(args.matchDetails, DEFAULTS.matchDetails),
      respectOrganized: toBool(args.respectOrganized, DEFAULTS.respectOrganized),
      respectIgnoreAutoTag: toBool(args.respectIgnoreAutoTag, DEFAULTS.respectIgnoreAutoTag),
      pageSize: toInt(args.pageSize, DEFAULTS.pageSize, 1, 1000),
      previewLimit: toInt(args.previewLimit, DEFAULTS.previewLimit, 0, 250),
    };

    if (ret.mode !== "preview" && ret.mode !== "apply" && ret.mode !== "compatibilityCheck") {
      throw new Error("invalid mode: " + ret.mode);
    }
    if (ret.mode !== "compatibilityCheck" && ret.targetType !== "performer" && ret.targetType !== "tag") {
      throw new Error("targetType must be performer or tag");
    }
    if (ret.mode !== "compatibilityCheck" && !ret.targetId) {
      throw new Error("targetId is required");
    }
    if (!ret.matchScenes && !ret.matchImages) {
      throw new Error("at least one of matchScenes or matchImages must be enabled");
    }
    if (!ret.matchTitle && !ret.matchDetails) {
      throw new Error("at least one of matchTitle or matchDetails must be enabled");
    }

    return ret;
  }

  function trim(value) {
    return String(value || "").replace(/^\s+|\s+$/g, "");
  }

  function normalizeTerm(value) {
    return trim(value).replace(/\s+/g, " ");
  }

  function uniqueTerms(name, aliases, includeAliases) {
    var source = [name];
    var ret = [];
    var seen = {};
    var i;
    if (includeAliases && aliases) {
      for (i = 0; i < aliases.length; i += 1) source.push(aliases[i]);
    }
    for (i = 0; i < source.length; i += 1) {
      var term = normalizeTerm(source[i]);
      var key = term.toLowerCase();
      if (term && !seen[key]) {
        seen[key] = true;
        ret.push(term);
      }
    }
    return ret;
  }

  function escapeRegex(value) {
    return String(value).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&");
  }

  function buildGraphQLRegex(term) {
    var parts = normalizeTerm(term).split(" ");
    var escaped = [];
    for (var i = 0; i < parts.length; i += 1) {
      if (parts[i]) escaped.push(escapeRegex(parts[i]));
    }
    if (!escaped.length) return "";
    return "(?i)(^|_|[^\\p{L}\\d])" + escaped.join("[.\\-_\\s]+") + "($|_|[^\\p{L}\\d])";
  }

  function buildJavaScriptRegex(term) {
    var parts = normalizeTerm(term).split(" ");
    var escaped = [];
    for (var i = 0; i < parts.length; i += 1) {
      if (parts[i]) escaped.push(escapeRegex(parts[i]));
    }
    if (!escaped.length) return null;
    return new RegExp("(^|_|[^A-Za-z0-9])" + escaped.join("[.\\-_\\s]+") + "($|_|[^A-Za-z0-9])", "i");
  }

  function matchesTerm(value, term) {
    if (value === undefined || value === null) return false;
    var re = buildJavaScriptRegex(term);
    return !!re && re.test(String(value));
  }

  function resultTemplate(mode) {
    return {
      mode: mode,
      target: null,
      matched: { scenes: 0, images: 0 },
      updated: { scenes: 0, images: 0 },
      skipped: { alreadyTagged: 0, organized: 0, ignoreAutoTag: 0 },
      samples: [],
      errors: [],
    };
  }

  function getGQL(options) {
    if (options && options.gql) return options.gql;
    if (typeof gql !== "undefined") return gql;
    throw new Error("gql API is not available");
  }

  function getLog(options) {
    if (options && options.log) return options.log;
    if (typeof log !== "undefined") return log;
    return {
      Info: function () {},
      Warn: function () {},
      Error: function () {},
      Progress: function () {},
    };
  }

  function gqlDo(gqlClient, query, variables) {
    if (variables === undefined) variables = {};
    return gqlClient.Do(query, variables);
  }

  function loadTarget(gqlClient, args) {
    if (args.targetType === "performer") {
      var performerResult = gqlDo(gqlClient, FIND_PERFORMER, { id: args.targetId });
      if (!performerResult.findPerformer) throw new Error("performer not found: " + args.targetId);
      return {
        type: "performer",
        id: String(performerResult.findPerformer.id),
        name: performerResult.findPerformer.name,
        aliases: performerResult.findPerformer.alias_list || [],
        ignore_auto_tag: !!performerResult.findPerformer.ignore_auto_tag,
      };
    }

    var tagResult = gqlDo(gqlClient, FIND_TAG, { id: args.targetId });
    if (!tagResult.findTag) throw new Error("tag not found: " + args.targetId);
    return {
      type: "tag",
      id: String(tagResult.findTag.id),
      name: tagResult.findTag.name,
      aliases: tagResult.findTag.aliases || [],
      ignore_auto_tag: !!tagResult.findTag.ignore_auto_tag,
    };
  }

  function listIds(items) {
    var ret = [];
    items = items || [];
    for (var i = 0; i < items.length; i += 1) ret.push(String(items[i].id));
    return ret;
  }

  function hasTarget(row, target) {
    var items = target.type === "performer" ? row.performers : row.tags;
    items = items || [];
    for (var i = 0; i < items.length; i += 1) {
      if (String(items[i].id) === String(target.id)) return true;
    }
    return false;
  }

  function mergedTargetIds(row, target) {
    var ids = target.type === "performer" ? listIds(row.performers) : listIds(row.tags);
    var found = false;
    for (var i = 0; i < ids.length; i += 1) {
      if (String(ids[i]) === String(target.id)) found = true;
    }
    if (!found) ids.push(String(target.id));
    return ids;
  }

  function makeFindFilter(args) {
    return {
      per_page: args.pageSize,
      sort: "id",
      direction: "ASC",
    };
  }

  function makeMediaFilter(mediaType, field, regex, args, lastID) {
    var filter = {};
    filter[field] = {
      value: regex,
      modifier: "MATCHES_REGEX",
    };
    if (args.respectOrganized) {
      filter.organized = false;
    }
    if (lastID > 0) {
      filter.id = {
        value: lastID,
        modifier: "GREATER_THAN",
      };
    }
    return filter;
  }

  function queryMedia(gqlClient, mediaType, field, regex, args, lastID) {
    var variables = {
      filter: makeFindFilter(args),
    };
    if (mediaType === "scene") {
      variables.scene_filter = makeMediaFilter(mediaType, field, regex, args, lastID);
      return gqlDo(gqlClient, FIND_SCENES, variables).findScenes.scenes || [];
    }
    variables.image_filter = makeMediaFilter(mediaType, field, regex, args, lastID);
    return gqlDo(gqlClient, FIND_IMAGES, variables).findImages.images || [];
  }

  function countSkipped(skippedSeen, result, mediaType, row, reason) {
    var key = reason + ":" + mediaType + ":" + row.id;
    if (own(skippedSeen, key)) return;
    skippedSeen[key] = true;
    result.skipped[reason] += 1;
  }

  function addCandidate(candidates, skippedSeen, result, mediaType, row, field, term, target, args) {
    if (args.respectOrganized && row.organized) {
      countSkipped(skippedSeen, result, mediaType, row, "organized");
      return;
    }
    if (hasTarget(row, target)) {
      countSkipped(skippedSeen, result, mediaType, row, "alreadyTagged");
      return;
    }

    var key = mediaType + ":" + row.id;
    if (!own(candidates, key)) {
      candidates[key] = {
        mediaType: mediaType,
        id: String(row.id),
        title: row.title || "",
        details: row.details || "",
        field: field,
        term: term,
        row: row,
      };
      if (mediaType === "scene") result.matched.scenes += 1;
      if (mediaType === "image") result.matched.images += 1;
      if (result.samples.length < args.previewLimit) {
        result.samples.push({
          mediaType: mediaType,
          id: String(row.id),
          title: row.title || "",
          field: field,
          term: term,
        });
      }
    }
  }

  function collectCandidates(gqlClient, target, terms, args, result) {
    var candidates = {};
    var skippedSeen = {};
    var mediaTypes = [];
    var fields = [];
    var mi;
    var fi;
    var ti;

    if (args.matchScenes) mediaTypes.push("scene");
    if (args.matchImages) mediaTypes.push("image");
    if (args.matchTitle) fields.push("title");
    if (args.matchDetails) fields.push("details");

    for (mi = 0; mi < mediaTypes.length; mi += 1) {
      for (fi = 0; fi < fields.length; fi += 1) {
        for (ti = 0; ti < terms.length; ti += 1) {
          var regex = buildGraphQLRegex(terms[ti]);
          var lastID = 0;
          while (true) {
            var rows = queryMedia(gqlClient, mediaTypes[mi], fields[fi], regex, args, lastID);
            for (var ri = 0; ri < rows.length; ri += 1) {
              addCandidate(candidates, skippedSeen, result, mediaTypes[mi], rows[ri], fields[fi], terms[ti], target, args);
              var idInt = parseInt(rows[ri].id, 10);
              if (!isNaN(idInt) && idInt > lastID) lastID = idInt;
            }
            if (rows.length < args.pageSize) break;
            if (lastID <= 0) break;
          }
        }
      }
    }

    return candidates;
  }

  function updateCandidate(gqlClient, candidate, target) {
    var input = { id: candidate.id };
    if (target.type === "performer") {
      input.performer_ids = mergedTargetIds(candidate.row, target);
    } else {
      input.tag_ids = mergedTargetIds(candidate.row, target);
    }

    if (candidate.mediaType === "scene") {
      gqlDo(gqlClient, UPDATE_SCENE, { input: input });
    } else {
      gqlDo(gqlClient, UPDATE_IMAGE, { input: input });
    }
  }

  function candidateList(candidates) {
    var ret = [];
    for (var key in candidates) {
      if (own(candidates, key)) ret.push(candidates[key]);
    }
    ret.sort(function (a, b) {
      if (a.mediaType !== b.mediaType) return a.mediaType < b.mediaType ? -1 : 1;
      return parseInt(a.id, 10) - parseInt(b.id, 10);
    });
    return ret;
  }

  function runAutoTag(args, options) {
    args = normalizeArgs(args);
    var gqlClient = getGQL(options);
    var logger = getLog(options);

    if (args.mode === "compatibilityCheck") {
      return compatibilityCheck(gqlClient);
    }

    var result = resultTemplate(args.mode);
    var target = loadTarget(gqlClient, args);
    result.target = {
      type: target.type,
      id: target.id,
      name: target.name,
    };

    if (args.respectIgnoreAutoTag && target.ignore_auto_tag) {
      result.skipped.ignoreAutoTag = 1;
      return result;
    }

    var terms = uniqueTerms(target.name, target.aliases, args.includeAliases);
    var candidates = collectCandidates(gqlClient, target, terms, args, result);
    var list = candidateList(candidates);

    if (args.mode === "preview") {
      return result;
    }

    logger.Info("AutoTag Extended applying " + list.length + " updates for " + target.type + " " + target.name);
    for (var i = 0; i < list.length; i += 1) {
      try {
        updateCandidate(gqlClient, list[i], target);
        if (list[i].mediaType === "scene") result.updated.scenes += 1;
        if (list[i].mediaType === "image") result.updated.images += 1;
      } catch (err) {
        result.errors.push({
          mediaType: list[i].mediaType,
          id: list[i].id,
          error: String(err && err.message ? err.message : err),
        });
        logger.Warn("AutoTag Extended failed to update " + list[i].mediaType + " " + list[i].id + ": " + result.errors[result.errors.length - 1].error);
      }
      if (list.length > 0) logger.Progress((i + 1) / list.length);
    }

    return result;
  }

  function fieldNames(typeInfo) {
    var ret = {};
    var fields = typeInfo && typeInfo.inputFields ? typeInfo.inputFields : [];
    for (var i = 0; i < fields.length; i += 1) ret[fields[i].name] = true;
    return ret;
  }

  function operationNames(schemaType) {
    var ret = {};
    var fields = schemaType && schemaType.fields ? schemaType.fields : [];
    for (var i = 0; i < fields.length; i += 1) ret[fields[i].name] = true;
    return ret;
  }

  function requireFields(name, actual, required, missing) {
    for (var i = 0; i < required.length; i += 1) {
      if (!actual[required[i]]) missing.push(name + "." + required[i]);
    }
  }

  function compatibilityCheck(gqlClient) {
    var data = gqlDo(gqlClient, INTROSPECTION, {});
    var missing = [];
    requireFields("SceneFilterType", fieldNames(data.sceneFilter), ["id", "title", "details", "organized"], missing);
    requireFields("ImageFilterType", fieldNames(data.imageFilter), ["id", "title", "details", "organized"], missing);
    requireFields("SceneUpdateInput", fieldNames(data.sceneUpdate), ["id", "performer_ids", "tag_ids"], missing);
    requireFields("ImageUpdateInput", fieldNames(data.imageUpdate), ["id", "performer_ids", "tag_ids"], missing);
    requireFields("Query", operationNames(data.queryType && data.queryType.queryType), ["findScenes", "findImages", "findPerformer", "findTag"], missing);
    requireFields("Mutation", operationNames(data.queryType && data.queryType.mutationType), ["sceneUpdate", "imageUpdate", "runPluginTask", "runPluginOperation"], missing);
    return {
      mode: "compatibilityCheck",
      ok: missing.length === 0,
      missing: missing,
      pluginID: PLUGIN_ID,
      taskName: TASK_NAME,
    };
  }

  function main() {
    try {
      return {
        Output: runAutoTag(input.Args || {}),
      };
    } catch (err) {
      return {
        Error: String(err && err.message ? err.message : err),
      };
    }
  }

  var api = {
    DEFAULTS: DEFAULTS,
    PLUGIN_ID: PLUGIN_ID,
    TASK_NAME: TASK_NAME,
    normalizeArgs: normalizeArgs,
    normalizeTerm: normalizeTerm,
    uniqueTerms: uniqueTerms,
    escapeRegex: escapeRegex,
    buildGraphQLRegex: buildGraphQLRegex,
    buildJavaScriptRegex: buildJavaScriptRegex,
    matchesTerm: matchesTerm,
    runAutoTag: runAutoTag,
    compatibilityCheck: compatibilityCheck,
    _queries: {
      FIND_PERFORMER: FIND_PERFORMER,
      FIND_TAG: FIND_TAG,
      FIND_SCENES: FIND_SCENES,
      FIND_IMAGES: FIND_IMAGES,
      UPDATE_SCENE: UPDATE_SCENE,
      UPDATE_IMAGE: UPDATE_IMAGE,
      INTROSPECTION: INTROSPECTION,
    },
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }

  root.AutoTagExtendedTask = api;

  if (typeof input !== "undefined") {
    return main();
  }
})(this);
