(function hold4speedBootstrap() {
  const GLOBAL_KEY = "__hold4speedController";

  if (window[GLOBAL_KEY] && typeof window[GLOBAL_KEY].destroy === "function") {
    window[GLOBAL_KEY].destroy("reinitialize");
  }

  const DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    holdKey: "b",
    speedUpStep: 1,
    slowDownStep: 2,
    rewindStartRate: 2,
    rewindSpeedUpStep: 1,
    rewindSlowDownStep: 2,
    scrollAcceleration: true,
    jumpBack: true,
    jumpBackMinSpeed: 4,
    jumpBackReactionMs: 400,
    ignoreEditableFields: true,
  });

  const MIN_RATE = 0.25;
  const MAX_RATE = 16;
  // Browsers reject negative playbackRate, so rewind pauses the video and
  // seeks backwards on this interval, skipping ticks while a seek is pending.
  const REWIND_TICK_MS = 50;

  // Each wheel event is at most one notch. Trackpads send many small events,
  // so within a stream a notch needs this much distance: about one mouse notch
  // in Chrome, or 3 lines in Firefox.
  const NOTCH_PIXELS = 100;
  const LINE_PIXELS = NOTCH_PIXELS / 3;
  // An event this long after the previous one is a notch on its own, so a
  // single click always steps whatever distance the device reports.
  const DISCRETE_GAP_MS = 100;
  // Fast scrolling multiplies the step. The rate is measured over the last
  // three notches in the same direction, so the first two always step by 1x.
  // Notches are one per event, so a large delta is never mistaken for speed.
  const ACCELERATION_SAMPLES = 3;
  const ACCELERATION_TIERS = Object.freeze([
    Object.freeze({ notchesPerSecond: 15, multiplier: 4 }),
    Object.freeze({ notchesPerSecond: 8, multiplier: 2 }),
  ]);

  // Jump back: releasing a fast hold returns to where the video was the
  // reaction time ago, so the jump scales with how fast it was moving. The
  // position is sampled during the hold to look that up.
  const MAX_REACTION_MS = 2000;
  const HISTORY_SAMPLE_MS = 50;
  // Jumps shorter than this are not worth the seek.
  const MIN_JUMP_SECONDS = 0.1;
  const JUMP_BADGE_MS = 700;

  function dispatch(type, detail) {
    document.dispatchEvent(new CustomEvent(type, { detail }));
  }

  function normalizeKey(value, fallback) {
    if (typeof value !== "string") return fallback;
    const normalized = value.trim().toLowerCase();
    return normalized || fallback;
  }

  function normalizeRate(value, fallback) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    if (n < MIN_RATE) return MIN_RATE;
    if (n > MAX_RATE) return MAX_RATE;
    return n;
  }

  function normalizeStep(value, fallback) {
    if (value === null || value === undefined || value === "") return fallback;
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return fallback;
    return Math.min(n, MAX_RATE);
  }

  // Stash shows unset NUMBER settings as 0, so 0 means "use the default".
  function normalizeSpeed(value, fallback) {
    if (value === null || value === undefined || value === "") return fallback;
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return fallback;
    return Math.min(MAX_RATE, Math.max(1, n));
  }

  function normalizeReactionMs(value, fallback) {
    if (value === null || value === undefined || value === "") return fallback;
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return fallback;
    return Math.min(MAX_REACTION_MS, n);
  }

  function normalizeBoolean(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }

  function normalizeSettings(raw) {
    const source = raw && typeof raw === "object" ? raw : {};

    return {
      enabled: normalizeBoolean(source.enabled, DEFAULT_SETTINGS.enabled),
      holdKey: normalizeKey(source.holdKey, DEFAULT_SETTINGS.holdKey),
      speedUpStep: normalizeStep(source.speedUpStep, DEFAULT_SETTINGS.speedUpStep),
      slowDownStep: normalizeStep(source.slowDownStep, DEFAULT_SETTINGS.slowDownStep),
      rewindStartRate: normalizeSpeed(source.rewindStartRate, DEFAULT_SETTINGS.rewindStartRate),
      rewindSpeedUpStep: normalizeStep(source.rewindSpeedUpStep, DEFAULT_SETTINGS.rewindSpeedUpStep),
      rewindSlowDownStep: normalizeStep(source.rewindSlowDownStep, DEFAULT_SETTINGS.rewindSlowDownStep),
      scrollAcceleration: normalizeBoolean(source.scrollAcceleration, DEFAULT_SETTINGS.scrollAcceleration),
      jumpBack: normalizeBoolean(source.jumpBack, DEFAULT_SETTINGS.jumpBack),
      jumpBackMinSpeed: normalizeSpeed(source.jumpBackMinSpeed, DEFAULT_SETTINGS.jumpBackMinSpeed),
      jumpBackReactionMs: normalizeReactionMs(source.jumpBackReactionMs, DEFAULT_SETTINGS.jumpBackReactionMs),
      ignoreEditableFields: normalizeBoolean(source.ignoreEditableFields, DEFAULT_SETTINGS.ignoreEditableFields),
    };
  }

  function stepScrollRate(rate, deltaY, speedUpStep, slowDownStep, steps = 1) {
    const current = Number.isFinite(rate) ? rate : 1;
    if (!Number.isFinite(deltaY) || deltaY === 0) return current;
    const next = deltaY < 0 ? current + speedUpStep * steps : current - slowDownStep * steps;
    return Math.min(MAX_RATE, Math.max(1, next));
  }

  // deltaMode 1 is lines and 2 is pages; treat a page as one notch.
  function wheelPixels(deltaY, deltaMode) {
    if (deltaMode === 1) return deltaY * LINE_PIXELS;
    if (deltaMode === 2) return deltaY * NOTCH_PIXELS;
    return deltaY;
  }

  function accelerationMultiplier(notchTimes) {
    if (notchTimes.length < ACCELERATION_SAMPLES) return 1;
    const recent = notchTimes.slice(-ACCELERATION_SAMPLES);
    const elapsed = recent[recent.length - 1] - recent[0];
    const notchesPerSecond = elapsed > 0 ? ((recent.length - 1) * 1000) / elapsed : Infinity;
    const tier = ACCELERATION_TIERS.find((t) => notchesPerSecond >= t.notchesPerSecond);
    return tier ? tier.multiplier : 1;
  }

  // Turns wheel events into notches (0 or 1 per event) plus the acceleration
  // multiplier for the current scroll speed. Reversing direction starts over.
  function createWheelTracker() {
    let direction = 0;
    let lastTime = -Infinity;
    let pending = 0;
    let notchTimes = [];

    function reset() {
      direction = 0;
      lastTime = -Infinity;
      pending = 0;
      notchTimes = [];
    }

    function push(pixels, time) {
      if (!Number.isFinite(pixels) || pixels === 0) return { notches: 0, multiplier: 1 };
      const sign = pixels < 0 ? -1 : 1;
      if (sign !== direction) {
        pending = 0;
        notchTimes = [];
      }
      const isolated = time - lastTime > DISCRETE_GAP_MS;
      direction = sign;
      lastTime = time;
      pending = isolated ? 0 : pending + Math.abs(pixels);
      if (!isolated && pending < NOTCH_PIXELS) return { notches: 0, multiplier: 1 };
      pending = 0;
      notchTimes.push(time);
      if (notchTimes.length > ACCELERATION_SAMPLES) notchTimes = notchTimes.slice(-ACCELERATION_SAMPLES);
      return { notches: 1, multiplier: accelerationMultiplier(notchTimes) };
    }

    return { push, reset };
  }

  function rewindTarget(anchorTime, rate, elapsedMs) {
    const target = anchorTime - (rate * Math.max(0, elapsedMs)) / 1000;
    return Math.max(0, target);
  }

  // Media position at a wall-clock time, interpolated from samples taken
  // during the hold. Times before the first sample clamp to it, so a jump
  // never goes past where the hold started.
  function positionAt(history, wall) {
    if (!history.length) return null;
    if (wall <= history[0].wall) return history[0].time;
    for (let i = 1; i < history.length; i += 1) {
      const next = history[i];
      if (wall <= next.wall) {
        const prev = history[i - 1];
        const span = next.wall - prev.wall;
        return span > 0 ? prev.time + ((next.time - prev.time) * (wall - prev.wall)) / span : next.time;
      }
    }
    return history[history.length - 1].time;
  }

  function formatRate(rate) {
    return `${Number.isInteger(rate) ? rate : Number(rate.toFixed(2))}x`;
  }

  function formatSeconds(seconds) {
    return `${Number(seconds.toFixed(1))}s`;
  }

  function now() {
    return typeof performance !== "undefined" && typeof performance.now === "function"
      ? performance.now()
      : Date.now();
  }

  function getEventKey(evt) {
    return typeof evt?.key === "string" ? evt.key.toLowerCase() : "";
  }

  function isEditableTarget(target) {
    if (!target || typeof target !== "object") return false;
    if (target.isContentEditable) return true;
    const tagName = typeof target.tagName === "string" ? target.tagName.toLowerCase() : "";
    return tagName === "input" || tagName === "textarea" || tagName === "select";
  }

  async function loadSettings() {
    const query = `
      query Hold4SpeedConfiguration {
        configuration {
          plugins
        }
      }
    `;

    const headers = { "Content-Type": "application/json" };
    const apiKey = window?.PluginApi?.apiKey;
    if (typeof apiKey === "string" && apiKey) headers.ApiKey = apiKey;

    try {
      const endpoint = "/graphql";
      const response = await fetch(endpoint, {
        method: "POST",
        headers,
        body: JSON.stringify({ query, variables: {} }),
      });
      if (!response.ok) return DEFAULT_SETTINGS;

      const json = await response.json();
      const pluginSettings = json?.data?.configuration?.plugins;
      const hold4speedSettings =
        pluginSettings && typeof pluginSettings === "object" ? pluginSettings["hold4speed"] : null;

      return normalizeSettings(hold4speedSettings);
    } catch (_err) {
      return DEFAULT_SETTINGS;
    }
  }

  function createController() {
    let currentSettings = DEFAULT_SETTINGS;
    let attachedElement = null;
    let attachedPlayer = null;
    let holding = false;
    // The first wheel step of a hold picks its direction: null, "forward" or
    // "rewind". It stays fixed until release, so the wheel can slow the hold
    // down to 1x but never cross into the other direction.
    let holdDirection = null;
    let scrollRate = 1;
    let rewindRate = 1;
    const wheelTracker = createWheelTracker();
    let rewind = null;
    let positionHistory = [];
    let historyTimer = null;
    let indicator = null;
    let indicatorTimer = null;
    let observer = null;
    let observerStopTimer = null;
    let scheduledAttachTimer = null;
    let destroyed = false;
    let routeListener = null;

    function stopObserver() {
      if (observer) {
        observer.disconnect();
        observer = null;
      }
      if (observerStopTimer) {
        clearTimeout(observerStopTimer);
        observerStopTimer = null;
      }
    }

    function emitRateChange(rate, key, previousRate, reason) {
      dispatch("hold4speed:ratechange", { rate, key: key || null, previousRate, reason });
    }

    function setPlaybackRate(rate, key, reason) {
      if (!attachedPlayer || typeof attachedPlayer.playbackRate !== "function") return;
      const previousRate = Number(attachedPlayer.playbackRate());
      const normalized = normalizeRate(rate, 1);
      if (previousRate === normalized) return;
      attachedPlayer.playbackRate(normalized);
      emitRateChange(normalized, key, previousRate, reason);
    }

    function emitRewindChange(active, rate, previousRate, reason) {
      dispatch("hold4speed:rewindchange", { active, rate, previousRate, reason });
    }

    // On-screen speed badge for fast-forward and rewind, placed inside the player
    // so it also shows in fullscreen. It ignores pointer events so clicks and
    // wheel pass through.
    function setIndicatorText(text) {
      if (indicatorTimer) {
        clearTimeout(indicatorTimer);
        indicatorTimer = null;
      }
      if (!attachedElement || typeof attachedElement.appendChild !== "function") return;
      if (typeof document.createElement !== "function") return;
      if (!indicator) {
        indicator = document.createElement("div");
        indicator.className = "hold4speed-indicator";
        if (typeof indicator.setAttribute === "function") indicator.setAttribute("aria-live", "polite");
        Object.assign(indicator.style, {
          position: "absolute",
          top: "12%",
          left: "50%",
          transform: "translateX(-50%)",
          padding: "6px 14px",
          borderRadius: "6px",
          background: "rgba(0, 0, 0, 0.65)",
          color: "#fff",
          fontSize: "20px",
          fontWeight: "600",
          lineHeight: "1.2",
          pointerEvents: "none",
          zIndex: "2",
        });
        attachedElement.appendChild(indicator);
      }
      indicator.textContent = text;
    }

    function showIndicator(direction, rate) {
      const arrows = direction === "rewind" ? "\u25C0\u25C0" : "\u25B6\u25B6";
      setIndicatorText(`${arrows} ${formatRate(rate)}`);
    }

    // Shows text briefly after the key is released, then hides the badge.
    function flashIndicator(text) {
      setIndicatorText(text);
      if (indicator) indicatorTimer = setTimeout(hideIndicator, JUMP_BADGE_MS);
    }

    function hideIndicator() {
      if (indicatorTimer) {
        clearTimeout(indicatorTimer);
        indicatorTimer = null;
      }
      if (!indicator) return;
      if (indicator.parentNode && typeof indicator.parentNode.removeChild === "function") {
        indicator.parentNode.removeChild(indicator);
      }
      indicator = null;
    }

    function currentRewindTarget() {
      return rewindTarget(rewind.anchorTime, rewindRate, now() - rewind.anchorWall);
    }

    function rewindTick() {
      if (!rewind || !attachedPlayer) return;
      if (typeof attachedPlayer.seeking === "function" && attachedPlayer.seeking()) return;
      const target = currentRewindTarget();
      if (Math.abs(Number(attachedPlayer.currentTime()) - target) < 0.01) return;
      attachedPlayer.currentTime(target);
    }

    function startRewind(reason) {
      if (!attachedPlayer || typeof attachedPlayer.currentTime !== "function") return;
      const wasPlaying = typeof attachedPlayer.paused === "function" ? !attachedPlayer.paused() : false;
      if (wasPlaying && typeof attachedPlayer.pause === "function") attachedPlayer.pause();
      rewindRate = currentSettings.rewindStartRate;
      rewind = {
        anchorTime: Number(attachedPlayer.currentTime()) || 0,
        anchorWall: now(),
        wasPlaying,
        timer: setInterval(rewindTick, REWIND_TICK_MS),
      };
      showIndicator("rewind", rewindRate);
      emitRewindChange(true, rewindRate, 0, reason);
    }

    function setRewindRate(next, reason) {
      if (!rewind || next === rewindRate) return;
      rewind.anchorTime = currentRewindTarget();
      rewind.anchorWall = now();
      const previousRate = rewindRate;
      rewindRate = next;
      showIndicator("rewind", rewindRate);
      emitRewindChange(true, rewindRate, previousRate, reason);
    }

    function stopRewind(reason, resume) {
      if (!rewind) return;
      clearInterval(rewind.timer);
      const { wasPlaying } = rewind;
      const previousRate = rewindRate;
      rewind = null;
      rewindRate = 1;
      hideIndicator();
      if (resume && wasPlaying && attachedPlayer && typeof attachedPlayer.play === "function") {
        const played = attachedPlayer.play();
        if (played && typeof played.catch === "function") played.catch(() => {});
      }
      emitRewindChange(false, 0, previousRate, reason);
    }

    function samplePosition() {
      if (!attachedPlayer || typeof attachedPlayer.currentTime !== "function") return;
      const wall = now();
      positionHistory.push({ wall, time: Number(attachedPlayer.currentTime()) || 0 });
      // Keep one sample older than the longest reaction time to interpolate from.
      while (positionHistory.length > 2 && positionHistory[1].wall <= wall - MAX_REACTION_MS) {
        positionHistory.shift();
      }
    }

    function startHistory() {
      stopHistory();
      samplePosition();
      historyTimer = setInterval(samplePosition, HISTORY_SAMPLE_MS);
    }

    function stopHistory() {
      if (historyTimer) clearInterval(historyTimer);
      historyTimer = null;
      positionHistory = [];
    }

    // Where to jump on releasing a fast hold, or null: fast-forward jumps
    // back and rewind jumps forward, to where the video was the reaction time
    // ago. Holds released below the minimum speed are left alone.
    function jumpBackTarget() {
      if (!currentSettings.jumpBack || !holdDirection) return null;
      const rate = holdDirection === "rewind" ? rewindRate : scrollRate;
      if (rate < currentSettings.jumpBackMinSpeed) return null;
      samplePosition();
      if (!positionHistory.length) return null;
      const from = positionHistory[positionHistory.length - 1].time;
      const to = positionAt(positionHistory, now() - currentSettings.jumpBackReactionMs);
      const offset = to - from;
      const wanted = holdDirection === "rewind" ? offset >= MIN_JUMP_SECONDS : offset <= -MIN_JUMP_SECONDS;
      return wanted ? { from, to, offset, rate } : null;
    }

    // Only a key release jumps; losing focus or navigating away does not.
    function release(reason, resume, jump) {
      const target = jump ? jumpBackTarget() : null;
      holding = false;
      scrollRate = 1;
      holdDirection = null;
      wheelTracker.reset();
      stopHistory();
      if (rewind) {
        stopRewind(reason, resume);
      } else {
        hideIndicator();
        setPlaybackRate(1, null, reason);
      }
      if (target && attachedPlayer) {
        attachedPlayer.currentTime(target.to);
        const arrow = target.offset < 0 ? "\u21B6" : "\u21B7";
        flashIndicator(`${arrow} ${formatSeconds(Math.abs(target.offset))}`);
        dispatch("hold4speed:jumpback", target);
      }
    }

    function isHoldKey(evt) {
      return getEventKey(evt) === currentSettings.holdKey;
    }

    function shouldIgnoreEvent(evt) {
      return !!(currentSettings.ignoreEditableFields && isEditableTarget(evt?.target));
    }

    // Plugin keys must not reach Stash's document-level hotkeys (Mousetrap
    // listens for keypress/keydown/keyup on document).
    function claimEvent(evt) {
      if (evt && typeof evt.preventDefault === "function") evt.preventDefault();
      if (evt && typeof evt.stopPropagation === "function") evt.stopPropagation();
    }

    function handleKeyDown(evt) {
      if (!isHoldKey(evt) || shouldIgnoreEvent(evt)) return;

      claimEvent(evt);

      // Auto-repeat keydowns must not reset the rate built up while held.
      if (holding) return;

      holding = true;
      scrollRate = 1;
      holdDirection = null;
      wheelTracker.reset();
      startHistory();
      setPlaybackRate(scrollRate, currentSettings.holdKey, "keydown");
      showIndicator("forward", scrollRate);
    }

    function handleKeyPress(evt) {
      if (isHoldKey(evt) && !shouldIgnoreEvent(evt)) claimEvent(evt);
    }

    function handleKeyUp(evt) {
      if (!isHoldKey(evt) || shouldIgnoreEvent(evt)) return;

      claimEvent(evt);

      if (holding) release("keyup", true, true);
    }

    function handleWheel(evt) {
      if (!holding) return;

      const deltaY = Number(evt?.deltaY);
      if (!Number.isFinite(deltaY) || deltaY === 0) return;

      if (evt && typeof evt.preventDefault === "function") evt.preventDefault();

      const time = Number.isFinite(evt?.timeStamp) ? evt.timeStamp : now();
      const { notches, multiplier } = wheelTracker.push(wheelPixels(deltaY, evt?.deltaMode), time);
      if (!notches) return;
      let steps = currentSettings.scrollAcceleration ? multiplier : 1;

      if (!holdDirection) holdDirection = deltaY < 0 ? "forward" : "rewind";

      if (holdDirection === "rewind") {
        if (!rewind) {
          startRewind("wheel");
          steps -= 1;
          if (steps <= 0) return;
        }
        // Wheel down started this rewind, so wheel down speeds it up and wheel
        // up slows it.
        setRewindRate(
          stepScrollRate(
            rewindRate,
            -deltaY,
            currentSettings.rewindSpeedUpStep,
            currentSettings.rewindSlowDownStep,
            steps,
          ),
          "wheel",
        );
      } else {
        scrollRate = stepScrollRate(
          scrollRate,
          deltaY,
          currentSettings.speedUpStep,
          currentSettings.slowDownStep,
          steps,
        );
        setPlaybackRate(scrollRate, currentSettings.holdKey, "wheel");
        showIndicator("forward", scrollRate);
      }
    }

    // A keyup is never delivered once the window loses focus, so release then.
    function handleBlur() {
      if (holding) release("blur", true, false);
    }

    function detach(reason) {
      stopObserver();
      if (holding) release(reason || "detach", false, false);
      hideIndicator();
      if (attachedPlayer && typeof attachedPlayer.off === "function") {
        attachedPlayer.off("keydown", handleKeyDown);
        attachedPlayer.off("keypress", handleKeyPress);
        attachedPlayer.off("keyup", handleKeyUp);
        attachedPlayer.off("wheel", handleWheel);
      }
      if (typeof window.removeEventListener === "function") window.removeEventListener("blur", handleBlur);
      if (attachedPlayer || attachedElement) {
        dispatch("hold4speed:detached", { reason: reason || "detach" });
      }
      attachedPlayer = null;
      attachedElement = null;
    }

    function findVideoElement() {
      const element = document.querySelector("video-js");
      if (!element) return null;
      const player = element.player;
      if (!player || typeof player.on !== "function" || typeof player.playbackRate !== "function") return null;
      return { element, player };
    }

    function attach(found, reason) {
      if (!found || !found.element || !found.player) return false;
      if (attachedElement === found.element && attachedPlayer === found.player) return true;

      if (attachedPlayer && attachedPlayer !== found.player) {
        detach("player-replaced");
      }

      attachedElement = found.element;
      attachedPlayer = found.player;
      holding = false;
      holdDirection = null;
      scrollRate = 1;

      attachedPlayer.on("keydown", handleKeyDown);
      attachedPlayer.on("keypress", handleKeyPress);
      attachedPlayer.on("keyup", handleKeyUp);
      attachedPlayer.on("wheel", handleWheel);
      if (typeof window.addEventListener === "function") window.addEventListener("blur", handleBlur);

      stopObserver();
      dispatch("hold4speed:ready", { player: attachedPlayer, element: attachedElement, reason: reason || "attach" });
      return true;
    }

    function startObserverFallback() {
      if (observer || destroyed) return;
      if (!document.body) return;

      observer = new MutationObserver(() => {
        scheduleAttach("observer");
      });
      observer.observe(document.body, { childList: true, subtree: true });

      observerStopTimer = setTimeout(() => {
        stopObserver();
      }, 10000);
    }

    function scheduleAttach(reason) {
      if (destroyed) return;
      if (scheduledAttachTimer) clearTimeout(scheduledAttachTimer);

      scheduledAttachTimer = setTimeout(async () => {
        if (destroyed) return;
        currentSettings = await loadSettings();

        if (!currentSettings.enabled) {
          detach("disabled");
          return;
        }

        const found = findVideoElement();
        if (found) {
          attach(found, reason);
          return;
        }

        startObserverFallback();
      }, 0);
    }

    function bindRouteEvents() {
      const eventApi = window?.PluginApi?.Event;
      if (!eventApi || typeof eventApi.addEventListener !== "function") return;

      routeListener = () => scheduleAttach("location");
      eventApi.addEventListener("stash:location", routeListener);
    }

    function unbindRouteEvents() {
      const eventApi = window?.PluginApi?.Event;
      if (!eventApi || typeof eventApi.removeEventListener !== "function" || !routeListener) return;
      eventApi.removeEventListener("stash:location", routeListener);
      routeListener = null;
    }

    async function init() {
      bindRouteEvents();
      scheduleAttach("initial");
    }

    function destroy(reason) {
      destroyed = true;
      if (scheduledAttachTimer) {
        clearTimeout(scheduledAttachTimer);
        scheduledAttachTimer = null;
      }
      unbindRouteEvents();
      detach(reason || "destroy");
    }

    return {
      init,
      destroy,
      _internals: {
        normalizeSettings,
      },
    };
  }

  // ─── Test-Only Exports ───────────────────────────────────────────────

  if (window.__HOLD4SPEED_TEST__) {
    window.hold4speedTestApi = {
      DEFAULT_SETTINGS,
      MIN_RATE,
      MAX_RATE,
      normalizeKey,
      normalizeRate,
      normalizeStep,
      normalizeSpeed,
      normalizeReactionMs,
      normalizeSettings,
      stepScrollRate,
      wheelPixels,
      accelerationMultiplier,
      createWheelTracker,
      NOTCH_PIXELS,
      DISCRETE_GAP_MS,
      rewindTarget,
      positionAt,
      formatSeconds,
      MAX_REACTION_MS,
      formatRate,
      REWIND_TICK_MS,
      getEventKey,
      isEditableTarget,
    };
  }

  // ─── Bootstrap ───────────────────────────────────────────────────────

  const controller = createController();
  window[GLOBAL_KEY] = controller;
  controller.init();
})();
