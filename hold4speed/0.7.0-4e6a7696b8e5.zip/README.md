# hold4speed

Hold a key and scroll the mouse wheel over the Stash scene player to fast-forward or rewind at an adjustable speed. Releasing the key returns to normal playback.

## Implemented behavior

### Hold key (`b`): fast-forward or rewind

- Hold key: `b` by default, re-bindable with the `holdKey` setting.
- Holding the key without scrolling plays at `1x`. With the pointer over the player, the first wheel step of each hold picks its direction:
  - **Wheel up fast-forwards.** Each wheel step up adds `speedUpStep` (default `1x`), up to `16x`. Each wheel step down removes `slowDownStep` (default `2x`), never below `1x`.
  - **Wheel down rewinds**, pausing the video and starting at `rewindStartRate` (default `2x`). Each further wheel step down adds `rewindSpeedUpStep` (default `1x`), up to `16x`. Each wheel step up removes `rewindSlowDownStep` (default `2x`), never below `1x` rewind. Rewind stops at `0:00`.
- The direction stays fixed until the key is released: scrolling back only slows the hold to `1x` in its direction and never crosses into the other one. Release and hold again to change direction.
- Releasing the key restores `1x` forward playback, resuming it if a rewind paused a playing video, and the next hold starts again from `1x`.
- **Jump back** (`jumpBack`, on by default) makes up for overshooting while you react. Releasing the key after a hold at `jumpBackMinSpeed` (default `4x`) or faster returns to where the video was `jumpBackReactionMs` (default 400 ms) earlier. Fast-forward jumps back and rewind jumps forward, so at 8x the jump is 3.2 seconds of video.
  - The speed at release decides, not the peak speed: slowing to below the minimum before letting go means no jump.
  - The position is sampled every 50 ms during the hold, so the jump reflects how far the video actually moved, including speed changes. It never goes past where the hold started, and jumps under 0.1 s are skipped.
  - The badge briefly shows the jump (for example `↶ 3.2s`, or `↷` for rewind) so it does not look like a glitch.
  - Only a key release jumps. Losing window focus or leaving the page does not.
  - On Stash's transcoded streams a jump is a seek, which restarts the transcode.
- While it is held, a badge near the top of the player shows the speed (for example `▶▶ 3x` or `◀◀ 2x`), including in fullscreen. This duplicates Stash's playback-rate button on purpose, because the control bar hides when the mouse is idle.
- Key auto-repeat while held does not reset the speed already reached.
- Releasing also happens when the browser window loses focus, because the key release would never arrive.
- The hold key does not propagate to Stash's own keyboard shortcuts while the player has focus.
- Wheel events are only handled, and page scrolling suppressed, while the key is held. Horizontal-only scrolling is ignored.
- **Scroll acceleration** (`scrollAcceleration`, on by default): scrolling quickly takes bigger steps. The speed is measured over the last three notches in the same direction, so the first two notches of a burst always step normally. Above about 8 notches a second each notch counts 2x, and above about 15 a second, 4x. It applies to speeding up and slowing down, for both fast-forward and rewind, and the 1x floor and 16x cap still apply. Reversing direction or starting a new hold resets it.
- Each wheel event counts as at most one notch. A wheel event more than 100 ms after the previous one is always a notch, so a single click steps whatever distance the device reports. Within a faster stream, such as a trackpad swipe, a notch needs 100px of scrolling (3 lines in Firefox), so trackpads step by distance rather than per event.
- Key events are ignored for editable targets (`input`, `textarea`, `select`, contenteditable) when enabled.
- Events: `hold4speed:ratechange` for fast-forward, `hold4speed:rewindchange` (`active`, `rate`, `previousRate`, `reason`) for rewind, and `hold4speed:jumpback` (`from`, `to`, `offset`, `rate`) for jumps on release.

### How rewind works

- Browsers reject negative `playbackRate`, so rewind is simulated: every 50 ms the plugin seeks back to where the video should be at the current rewind speed, skipping a tick while the previous seek is still pending. Speed stays accurate, but the picture is only as smooth as the browser can seek. Videos the browser plays directly, and HLS/DASH streams, rewind smoothly; Stash's transcoded MP4/WEBM streams restart the transcode on every seek, so rewind there is slow and choppy.

## Plugin settings

Settings are declared in `hold4speed.yml` and read at runtime from Stash plugin configuration.

- `enabled` (`BOOLEAN`, default `true`)
- `holdKey` (`STRING`, default `b`; trimmed and lowercased, empty falls back to `b`)
- `speedUpStep` (`NUMBER`, default `1`; must be greater than `0`, capped at `16`)
- `slowDownStep` (`NUMBER`, default `2`; must be greater than `0`, capped at `16`)
- `rewindStartRate` (`NUMBER`, default `2`; `0` or less uses the default, otherwise clamped to `1`-`16`; rewind speed when a hold-key hold starts with wheel down)
- `rewindSpeedUpStep` (`NUMBER`, default `1`; must be greater than `0`, capped at `16`; per wheel step down while rewinding)
- `rewindSlowDownStep` (`NUMBER`, default `2`; must be greater than `0`, capped at `16`; per wheel step up while rewinding)
- `scrollAcceleration` (`BOOLEAN`, default `true`)
- `jumpBack` (`BOOLEAN`, default `true`)
- `jumpBackMinSpeed` (`NUMBER`, default `4`; `0` or less uses the default, otherwise clamped to `1`-`16`)
- `jumpBackReactionMs` (`NUMBER`, default `400`; `0` or less uses the default, capped at `2000`)
- `ignoreEditableFields` (`BOOLEAN`, default `true`)

Stash plugin settings have no default values, so the settings page shows `0` for unset `NUMBER` settings, blank for unset `STRING` settings and unchecked for unset `BOOLEAN` settings. The plugin treats unset, `0` and blank values as the default, and each setting description starts with its default. Stash's number input also only accepts whole numbers; fractional steps can only be set through GraphQL.

Version `0.4.0` removed the `slowKey`/`mediumKey`/`fastKey` presets, their rates, and the `scrollKey` setting. Version `0.7.0` removed the separate `rewindKey` (`x`), since scrolling down while holding the hold key rewinds. Stale values for all removed settings are ignored, and `x` passes through to Stash again.

Avoid `c` as a key: Stash binds `c c` to "generate screenshot", which replaces the scene cover, and holding a key repeats it.

## Testing

### Unit Tests

```bash
npm run stash -- test --plugin hold4speed --suite unit
```

Runs 143 tests covering pure helpers (`normalizeKey`, `normalizeRate`, `normalizeStep`, `normalizeSpeed`, `normalizeReactionMs`, `normalizeSettings`, `stepScrollRate`, `wheelPixels`, `accelerationMultiplier`, `createWheelTracker`, `rewindTarget`, `positionAt`, `formatSeconds`, `formatRate`, `getEventKey`, `isEditableTarget`), constants (`DEFAULT_SETTINGS`, `MIN_RATE`, `MAX_RATE`, `REWIND_TICK_MS`), and the fast-forward and rewind behavior of the controller, including the speed indicator, against a fake player. Does not require Stash or Docker.

### Integration Tests

```bash
npm run stash -- test --plugin hold4speed --suite integration
```

Requires Docker. Spins up a managed Stash instance, installs the plugin, and verifies:
- Plugin loads and appears in `plugins` query
- Exactly the 12 plugin settings are registered, each with its expected type
- Plugin JavaScript asset is served correctly
- Plugin has no tasks (UI-only plugin)

### UI/Harness Tests

```bash
npm run stash -- test --plugin hold4speed --suite ui
```

Requires Docker. Spins up a managed Stash instance, installs the plugin, and runs Playwright tests verifying the plugin JavaScript asset is served correctly.

### Run All Tests

```bash
npm run stash -- test --plugin hold4speed --suite all
```

Runs the unit, integration, and UI suites, plus the shared harness and deployment checks.

## Notes on Stash / Video.js shortcuts

- This plugin only handles its configured hold key and does not replace Stash's built-in shortcuts.
- Unconfigured keys are left untouched and do not call `preventDefault`.
- Previous README content describing broader YouTube-style shortcut parity is out of scope for this plugin change.
