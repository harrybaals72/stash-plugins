(function hold4speedBootstrap() {
  const GLOBAL_KEY = "__hold4speedController";

  if (window[GLOBAL_KEY] && typeof window[GLOBAL_KEY].destroy === "function") {
    window[GLOBAL_KEY].destroy("reinitialize");
  }

  const DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    holdKey: "b",
    speedUpStep: 1,
    slowDownStep: 2,
    rewindKey: "x",
    rewindSpeedUpStep: 1,
    rewindSlowDownStep: 2,
    ignoreEditableFields: true,
  });

  const MIN_RATE = 0.25;
  const MAX_RATE = 16;
  // Browsers reject negative playbackRate, so rewind pauses the video and
  // seeks backwards on this interval, skipping ticks while a seek is pending.
  const REWIND_TICK_MS = 50;

  function dispatch(type, detail) {
    document.dispatchEvent(new CustomEvent(type, { detail }));
  }

  function normalizeKey(value, fallback) {
    if (typeof value !== "string") return fallback;
    const normalized = value.trim().toLowerCase();
    return normalized || fallback;
  }

  function normalizeRate(value, fallback) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    if (n < MIN_RATE) return MIN_RATE;
    if (n > MAX_RATE) return MAX_RATE;
    return n;
  }

  function normalizeStep(value, fallback) {
    if (value === null || value === undefined || value === "") return fallback;
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return fallback;
    return Math.min(n, MAX_RATE);
  }

  function normalizeSettings(raw) {
    const source = raw && typeof raw === "object" ? raw : {};

    const holdKey = normalizeKey(source.holdKey, DEFAULT_SETTINGS.holdKey);
    // The rewind key must differ from the hold key: fall back to its default,
    // and disable rewind ("") if the hold key was rebound to that default.
    let rewindKey = normalizeKey(source.rewindKey, DEFAULT_SETTINGS.rewindKey);
    if (rewindKey === holdKey) rewindKey = DEFAULT_SETTINGS.rewindKey;
    if (rewindKey === holdKey) rewindKey = "";

    return {
      enabled: typeof source.enabled === "boolean" ? source.enabled : DEFAULT_SETTINGS.enabled,
      holdKey,
      speedUpStep: normalizeStep(source.speedUpStep, DEFAULT_SETTINGS.speedUpStep),
      slowDownStep: normalizeStep(source.slowDownStep, DEFAULT_SETTINGS.slowDownStep),
      rewindKey,
      rewindSpeedUpStep: normalizeStep(source.rewindSpeedUpStep, DEFAULT_SETTINGS.rewindSpeedUpStep),
      rewindSlowDownStep: normalizeStep(source.rewindSlowDownStep, DEFAULT_SETTINGS.rewindSlowDownStep),
      ignoreEditableFields:
        typeof source.ignoreEditableFields === "boolean"
          ? source.ignoreEditableFields
          : DEFAULT_SETTINGS.ignoreEditableFields,
    };
  }

  function stepScrollRate(rate, deltaY, speedUpStep, slowDownStep) {
    const current = Number.isFinite(rate) ? rate : 1;
    if (!Number.isFinite(deltaY) || deltaY === 0) return current;
    const next = deltaY < 0 ? current + speedUpStep : current - slowDownStep;
    return Math.min(MAX_RATE, Math.max(1, next));
  }

  function rewindTarget(anchorTime, rate, elapsedMs) {
    const target = anchorTime - (rate * Math.max(0, elapsedMs)) / 1000;
    return Math.max(0, target);
  }

  function formatRate(rate) {
    return `${Number.isInteger(rate) ? rate : Number(rate.toFixed(2))}x`;
  }

  function now() {
    return typeof performance !== "undefined" && typeof performance.now === "function"
      ? performance.now()
      : Date.now();
  }

  function getEventKey(evt) {
    return typeof evt?.key === "string" ? evt.key.toLowerCase() : "";
  }

  function isEditableTarget(target) {
    if (!target || typeof target !== "object") return false;
    if (target.isContentEditable) return true;
    const tagName = typeof target.tagName === "string" ? target.tagName.toLowerCase() : "";
    return tagName === "input" || tagName === "textarea" || tagName === "select";
  }

  async function loadSettings() {
    const query = `
      query Hold4SpeedConfiguration {
        configuration {
          plugins
        }
      }
    `;

    const headers = { "Content-Type": "application/json" };
    const apiKey = window?.PluginApi?.apiKey;
    if (typeof apiKey === "string" && apiKey) headers.ApiKey = apiKey;

    try {
      const endpoint = "/graphql";
      const response = await fetch(endpoint, {
        method: "POST",
        headers,
        body: JSON.stringify({ query, variables: {} }),
      });
      if (!response.ok) return DEFAULT_SETTINGS;

      const json = await response.json();
      const pluginSettings = json?.data?.configuration?.plugins;
      const hold4speedSettings =
        pluginSettings && typeof pluginSettings === "object" ? pluginSettings["hold4speed"] : null;

      return normalizeSettings(hold4speedSettings);
    } catch (_err) {
      return DEFAULT_SETTINGS;
    }
  }

  function createController() {
    let currentSettings = DEFAULT_SETTINGS;
    let attachedElement = null;
    let attachedPlayer = null;
    // mode is null, "forward" (hold key) or "rewind" (rewind key).
    let mode = null;
    let scrollRate = 1;
    let rewindRate = 1;
    let rewind = null;
    let indicator = null;
    let observer = null;
    let observerStopTimer = null;
    let scheduledAttachTimer = null;
    let destroyed = false;
    let routeListener = null;

    function stopObserver() {
      if (observer) {
        observer.disconnect();
        observer = null;
      }
      if (observerStopTimer) {
        clearTimeout(observerStopTimer);
        observerStopTimer = null;
      }
    }

    function emitRateChange(rate, key, previousRate, reason) {
      dispatch("hold4speed:ratechange", { rate, key: key || null, previousRate, reason });
    }

    function setPlaybackRate(rate, key, reason) {
      if (!attachedPlayer || typeof attachedPlayer.playbackRate !== "function") return;
      const previousRate = Number(attachedPlayer.playbackRate());
      const normalized = normalizeRate(rate, 1);
      if (previousRate === normalized) return;
      attachedPlayer.playbackRate(normalized);
      emitRateChange(normalized, key, previousRate, reason);
    }

    function emitRewindChange(active, rate, previousRate, reason) {
      dispatch("hold4speed:rewindchange", { active, rate, previousRate, reason });
    }

    // On-screen speed badge for fast-forward and rewind, placed inside the player
    // so it also shows in fullscreen. It ignores pointer events so clicks and
    // wheel pass through.
    function showIndicator(direction, rate) {
      if (!attachedElement || typeof attachedElement.appendChild !== "function") return;
      if (typeof document.createElement !== "function") return;
      if (!indicator) {
        indicator = document.createElement("div");
        indicator.className = "hold4speed-indicator";
        if (typeof indicator.setAttribute === "function") indicator.setAttribute("aria-live", "polite");
        Object.assign(indicator.style, {
          position: "absolute",
          top: "12%",
          left: "50%",
          transform: "translateX(-50%)",
          padding: "6px 14px",
          borderRadius: "6px",
          background: "rgba(0, 0, 0, 0.65)",
          color: "#fff",
          fontSize: "20px",
          fontWeight: "600",
          lineHeight: "1.2",
          pointerEvents: "none",
          zIndex: "2",
        });
        attachedElement.appendChild(indicator);
      }
      const arrows = direction === "rewind" ? "\u25C0\u25C0" : "\u25B6\u25B6";
      indicator.textContent = `${arrows} ${formatRate(rate)}`;
    }

    function hideIndicator() {
      if (!indicator) return;
      if (indicator.parentNode && typeof indicator.parentNode.removeChild === "function") {
        indicator.parentNode.removeChild(indicator);
      }
      indicator = null;
    }

    function currentRewindTarget() {
      return rewindTarget(rewind.anchorTime, rewindRate, now() - rewind.anchorWall);
    }

    function rewindTick() {
      if (!rewind || !attachedPlayer) return;
      if (typeof attachedPlayer.seeking === "function" && attachedPlayer.seeking()) return;
      const target = currentRewindTarget();
      if (Math.abs(Number(attachedPlayer.currentTime()) - target) < 0.01) return;
      attachedPlayer.currentTime(target);
    }

    function startRewind(reason) {
      if (!attachedPlayer || typeof attachedPlayer.currentTime !== "function") return;
      const wasPlaying = typeof attachedPlayer.paused === "function" ? !attachedPlayer.paused() : false;
      if (wasPlaying && typeof attachedPlayer.pause === "function") attachedPlayer.pause();
      rewindRate = 1;
      rewind = {
        anchorTime: Number(attachedPlayer.currentTime()) || 0,
        anchorWall: now(),
        wasPlaying,
        timer: setInterval(rewindTick, REWIND_TICK_MS),
      };
      showIndicator("rewind", rewindRate);
      emitRewindChange(true, rewindRate, 0, reason);
    }

    function setRewindRate(next, reason) {
      if (!rewind || next === rewindRate) return;
      rewind.anchorTime = currentRewindTarget();
      rewind.anchorWall = now();
      const previousRate = rewindRate;
      rewindRate = next;
      showIndicator("rewind", rewindRate);
      emitRewindChange(true, rewindRate, previousRate, reason);
    }

    function stopRewind(reason, resume) {
      if (!rewind) return;
      clearInterval(rewind.timer);
      const { wasPlaying } = rewind;
      const previousRate = rewindRate;
      rewind = null;
      rewindRate = 1;
      hideIndicator();
      if (resume && wasPlaying && attachedPlayer && typeof attachedPlayer.play === "function") {
        const played = attachedPlayer.play();
        if (played && typeof played.catch === "function") played.catch(() => {});
      }
      emitRewindChange(false, 0, previousRate, reason);
    }

    function endMode(reason, resume) {
      if (mode === "forward") {
        scrollRate = 1;
        hideIndicator();
        setPlaybackRate(1, null, reason);
      } else if (mode === "rewind") {
        stopRewind(reason, resume);
      }
      mode = null;
    }

    function keyMode(key) {
      if (!key) return null;
      if (key === currentSettings.holdKey) return "forward";
      if (currentSettings.rewindKey && key === currentSettings.rewindKey) return "rewind";
      return null;
    }

    function shouldIgnoreEvent(evt) {
      return !!(currentSettings.ignoreEditableFields && isEditableTarget(evt?.target));
    }

    // Plugin keys must not reach Stash's document-level hotkeys (Mousetrap
    // listens for keypress/keydown/keyup on document).
    function claimEvent(evt) {
      if (evt && typeof evt.preventDefault === "function") evt.preventDefault();
      if (evt && typeof evt.stopPropagation === "function") evt.stopPropagation();
    }

    function handleKeyDown(evt) {
      const next = keyMode(getEventKey(evt));
      if (!next || shouldIgnoreEvent(evt)) return;

      claimEvent(evt);

      // Auto-repeat keydowns must not reset the rate built up while held.
      if (mode === next) return;
      if (mode) endMode("switch", true);

      mode = next;
      if (next === "forward") {
        scrollRate = 1;
        setPlaybackRate(scrollRate, currentSettings.holdKey, "keydown");
        showIndicator("forward", scrollRate);
      } else {
        setPlaybackRate(1, null, "keydown");
        startRewind("keydown");
      }
    }

    function handleKeyPress(evt) {
      if (keyMode(getEventKey(evt)) && !shouldIgnoreEvent(evt)) claimEvent(evt);
    }

    function handleKeyUp(evt) {
      const released = keyMode(getEventKey(evt));
      if (!released || shouldIgnoreEvent(evt)) return;

      claimEvent(evt);

      if (mode === released) endMode("keyup", true);
    }

    function handleWheel(evt) {
      if (!mode) return;

      const deltaY = Number(evt?.deltaY);
      if (!Number.isFinite(deltaY) || deltaY === 0) return;

      if (evt && typeof evt.preventDefault === "function") evt.preventDefault();

      if (mode === "forward") {
        scrollRate = stepScrollRate(scrollRate, deltaY, currentSettings.speedUpStep, currentSettings.slowDownStep);
        setPlaybackRate(scrollRate, currentSettings.holdKey, "wheel");
        showIndicator("forward", scrollRate);
      } else {
        setRewindRate(
          stepScrollRate(rewindRate, deltaY, currentSettings.rewindSpeedUpStep, currentSettings.rewindSlowDownStep),
          "wheel",
        );
      }
    }

    // A keyup is never delivered once the window loses focus, so release then.
    function handleBlur() {
      if (mode) endMode("blur", true);
    }

    function detach(reason) {
      stopObserver();
      if (mode) endMode(reason || "detach", false);
      hideIndicator();
      if (attachedPlayer && typeof attachedPlayer.off === "function") {
        attachedPlayer.off("keydown", handleKeyDown);
        attachedPlayer.off("keypress", handleKeyPress);
        attachedPlayer.off("keyup", handleKeyUp);
        attachedPlayer.off("wheel", handleWheel);
      }
      if (typeof window.removeEventListener === "function") window.removeEventListener("blur", handleBlur);
      if (attachedPlayer || attachedElement) {
        dispatch("hold4speed:detached", { reason: reason || "detach" });
      }
      attachedPlayer = null;
      attachedElement = null;
    }

    function findVideoElement() {
      const element = document.querySelector("video-js");
      if (!element) return null;
      const player = element.player;
      if (!player || typeof player.on !== "function" || typeof player.playbackRate !== "function") return null;
      return { element, player };
    }

    function attach(found, reason) {
      if (!found || !found.element || !found.player) return false;
      if (attachedElement === found.element && attachedPlayer === found.player) return true;

      if (attachedPlayer && attachedPlayer !== found.player) {
        detach("player-replaced");
      }

      attachedElement = found.element;
      attachedPlayer = found.player;
      mode = null;
      scrollRate = 1;

      attachedPlayer.on("keydown", handleKeyDown);
      attachedPlayer.on("keypress", handleKeyPress);
      attachedPlayer.on("keyup", handleKeyUp);
      attachedPlayer.on("wheel", handleWheel);
      if (typeof window.addEventListener === "function") window.addEventListener("blur", handleBlur);

      stopObserver();
      dispatch("hold4speed:ready", { player: attachedPlayer, element: attachedElement, reason: reason || "attach" });
      return true;
    }

    function startObserverFallback() {
      if (observer || destroyed) return;
      if (!document.body) return;

      observer = new MutationObserver(() => {
        scheduleAttach("observer");
      });
      observer.observe(document.body, { childList: true, subtree: true });

      observerStopTimer = setTimeout(() => {
        stopObserver();
      }, 10000);
    }

    function scheduleAttach(reason) {
      if (destroyed) return;
      if (scheduledAttachTimer) clearTimeout(scheduledAttachTimer);

      scheduledAttachTimer = setTimeout(async () => {
        if (destroyed) return;
        currentSettings = await loadSettings();

        if (!currentSettings.enabled) {
          detach("disabled");
          return;
        }

        const found = findVideoElement();
        if (found) {
          attach(found, reason);
          return;
        }

        startObserverFallback();
      }, 0);
    }

    function bindRouteEvents() {
      const eventApi = window?.PluginApi?.Event;
      if (!eventApi || typeof eventApi.addEventListener !== "function") return;

      routeListener = () => scheduleAttach("location");
      eventApi.addEventListener("stash:location", routeListener);
    }

    function unbindRouteEvents() {
      const eventApi = window?.PluginApi?.Event;
      if (!eventApi || typeof eventApi.removeEventListener !== "function" || !routeListener) return;
      eventApi.removeEventListener("stash:location", routeListener);
      routeListener = null;
    }

    async function init() {
      bindRouteEvents();
      scheduleAttach("initial");
    }

    function destroy(reason) {
      destroyed = true;
      if (scheduledAttachTimer) {
        clearTimeout(scheduledAttachTimer);
        scheduledAttachTimer = null;
      }
      unbindRouteEvents();
      detach(reason || "destroy");
    }

    return {
      init,
      destroy,
      _internals: {
        normalizeSettings,
      },
    };
  }

  // ─── Test-Only Exports ───────────────────────────────────────────────

  if (window.__HOLD4SPEED_TEST__) {
    window.hold4speedTestApi = {
      DEFAULT_SETTINGS,
      MIN_RATE,
      MAX_RATE,
      normalizeKey,
      normalizeRate,
      normalizeStep,
      normalizeSettings,
      stepScrollRate,
      rewindTarget,
      formatRate,
      REWIND_TICK_MS,
      getEventKey,
      isEditableTarget,
    };
  }

  // ─── Bootstrap ───────────────────────────────────────────────────────

  const controller = createController();
  window[GLOBAL_KEY] = controller;
  controller.init();
})();
