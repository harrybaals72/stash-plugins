# hold4speed

Hold a key and scroll the mouse wheel over the Stash scene player to fast-forward or rewind at an adjustable speed. Releasing the key returns to normal playback.

## Implemented behavior

### Fast-forward (`b`)

- Fast-forward key: `b` by default, re-bindable with the `holdKey` setting.
- While it is held, with the pointer over the player:
  - Each wheel step up adds `speedUpStep` (default `1x`), up to `16x`.
  - Each wheel step down removes `slowDownStep` (default `2x`), never below `1x`.
- Holding the key without scrolling plays at `1x`. Releasing it restores `1x`, and the next hold starts again from `1x`.
- While it is held, a badge near the top of the player shows the speed (for example `▶▶ 3x`). This duplicates Stash's playback-rate button on purpose, because the control bar hides when the mouse is idle.

### Rewind (`x`)

- Rewind key: `x` by default, re-bindable with the `rewindKey` setting.
- Holding it pauses the video and rewinds at `1x`. While it is held, with the pointer over the player:
  - Each wheel step up adds `rewindSpeedUpStep` (default `1x`), up to `16x`.
  - Each wheel step down removes `rewindSlowDownStep` (default `2x`), never below `1x`.
- While rewinding, a badge near the top of the player shows the rewind speed (for example `◀◀ 4x`). It updates on each wheel step, disappears on release, and shows in fullscreen too.
- Releasing it stops rewinding and resumes playback if the video was playing before. Rewind stops at `0:00`.
- Browsers reject negative `playbackRate`, so rewind is simulated: every 50 ms the plugin seeks back to where the video should be at the current rewind speed, skipping a tick while the previous seek is still pending. Speed stays accurate, but the picture is only as smooth as the browser can seek. Videos the browser plays directly, and HLS/DASH streams, rewind smoothly; Stash's transcoded MP4/WEBM streams restart the transcode on every seek, so rewind there is slow and choppy.

### Both keys

- Key auto-repeat while held does not reset the speed already reached.
- Pressing one key while the other is held switches to the newly pressed mode.
- Releasing everything also happens when the browser window loses focus, because the key release would never arrive.
- The fast-forward and rewind keys do not propagate to Stash's own keyboard shortcuts while the player has focus.
- Wheel events are only handled, and page scrolling suppressed, while a key is held. Horizontal-only scrolling is ignored.
- Each `wheel` event counts as one step, so high-resolution trackpads step faster than a notched mouse wheel.
- Key events are ignored for editable targets (`input`, `textarea`, `select`, contenteditable) when enabled.
- Both modes share one badge element (`.hold4speed-indicator`), which updates when switching between them.
- Events: `hold4speed:ratechange` for fast-forward and `hold4speed:rewindchange` (`active`, `rate`, `previousRate`, `reason`) for rewind.

## Plugin settings

Settings are declared in `hold4speed.yml` and read at runtime from Stash plugin configuration.

- `enabled` (`BOOLEAN`, default `true`)
- `holdKey` (`STRING`, default `b`; trimmed and lowercased, empty falls back to `b`)
- `speedUpStep` (`NUMBER`, default `1`; must be greater than `0`, capped at `16`)
- `slowDownStep` (`NUMBER`, default `2`; must be greater than `0`, capped at `16`)
- `rewindKey` (`STRING`, default `x`; if it equals `holdKey` it falls back to `x`, and rewind is disabled if `holdKey` is `x`)
- `rewindSpeedUpStep` (`NUMBER`, default `1`; must be greater than `0`, capped at `16`)
- `rewindSlowDownStep` (`NUMBER`, default `2`; must be greater than `0`, capped at `16`)
- `ignoreEditableFields` (`BOOLEAN`, default `true`)

Version `0.4.0` removed the `slowKey`/`mediumKey`/`fastKey` presets, their rates, and the `scrollKey` setting. Stale values for those settings are ignored.

Avoid `c` as a key: Stash binds `c c` to "generate screenshot", which replaces the scene cover, and holding a key repeats it.

## Testing

### Unit Tests

```bash
npm run stash -- test --plugin hold4speed --suite unit
```

Runs 110 tests covering pure helpers (`normalizeKey`, `normalizeRate`, `normalizeStep`, `normalizeSettings`, `stepScrollRate`, `rewindTarget`, `formatRate`, `getEventKey`, `isEditableTarget`), constants (`DEFAULT_SETTINGS`, `MIN_RATE`, `MAX_RATE`, `REWIND_TICK_MS`), and the fast-forward and rewind behavior of the controller, including the speed indicator, against a fake player. Does not require Stash or Docker.

### Integration Tests

```bash
npm run stash -- test --plugin hold4speed --suite integration
```

Requires Docker. Spins up a managed Stash instance, installs the plugin, and verifies:
- Plugin loads and appears in `plugins` query
- Exactly the 8 plugin settings are registered
- Plugin JavaScript asset is served correctly
- Plugin has no tasks (UI-only plugin)

### UI/Harness Tests

```bash
npm run stash -- test --plugin hold4speed --suite ui
```

Requires Docker. Spins up a managed Stash instance, installs the plugin, and runs Playwright tests verifying the plugin JavaScript asset is served correctly.

### Run All Tests

```bash
npm run stash -- test --plugin hold4speed --suite all
```

Runs the unit, integration, and UI suites, plus the shared harness and deployment checks.

## Notes on Stash / Video.js shortcuts

- This plugin only handles its configured fast-forward and rewind keys and does not replace Stash's built-in shortcuts.
- Unconfigured keys are left untouched and do not call `preventDefault`.
- Previous README content describing broader YouTube-style shortcut parity is out of scope for this plugin change.
