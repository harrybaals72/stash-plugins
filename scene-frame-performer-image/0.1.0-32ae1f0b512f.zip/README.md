# Scene Frame Performer Image Picker

A UI-only Stash plugin that captures a presented frame from the active scene player and saves it as the image of one performer attached to that scene. It never generates or changes the scene cover.

## Use

Install the package and reload plugins. Use **Choose performer image from frame** beside the scene player, or press `Alt+I` (configurable in plugin settings). Navigation is time-based and visual-near-frame; it does not promise an exact encoded-frame index. Cancel restores the opening time and play state. A successful save leaves playback paused at the selected time. The frame editor starts with the largest centered **9:16** crop that fits the source. Drag the bright crop box on touch/pointer devices to choose the part of the frame to use. The visually distinct top-right handle resizes the box while retaining its current aspect ratio; drag it without clicking afterward. You can also adjust its position with the visible horizontal and vertical position sliders or the **Left**, **Right**, **Up**, and **Down** buttons. Use **Widen**, **Narrow**, **Taller**, and **Shorter** to reshape the selection, or choose **Reset to 9:16** to restore the performer-oriented default. The gold **↗** handle at the top-right resizes proportionally around the opposite bottom-left corner, preserving the crop's current ratio—including a custom ratio—during pointer, touch, or keyboard resizing. Resizing is free-aspect and clamped to the source; output is downscaled only when its long edge exceeds the configured maximum, never upscaled or stretched. The proposed preview shows the exact boxed region that will be uploaded—only that selected crop is encoded and sent to Stash, never the full scene frame.

The plugin requires an origin-clean browser media source. If the browser cannot export the active source to JPEG, it reports that source as unsupported instead of using a server fallback.

## Development

Managed tests use the sibling `stash-test-harness` checkout (see the repository README). Unit tests run without Docker; the integration and UI checks each start their own disposable Stash and need Docker and `ffmpeg`:

```sh
npm run test:scene-frame:unit
npm run test:scene-frame:integration
npm run test:scene-frame:ui
npm run build:packages
```

Sanitized harness diagnostics are retained under `.stash-dev/harness/`. The currently validated baseline is Chromium with an origin-clean direct MP4. Firefox, WebKit, HLS, DASH, and unauthenticated-source combinations remain unvalidated; unsupported combinations must fail clearly rather than use a server fallback.

Settings: launch hotkey (`alt+i`), local window (`2` seconds each side), maximum JPEG long edge (`1920`), and JPEG quality (`0.9`). Numeric ranges are 0.25–30 seconds, 256–4096 pixels, and 0.1–1.0.
