(function (root, factory) {
  var api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root && root.PluginApi) api.install(root.PluginApi);
})(typeof window !== "undefined" ? window : globalThis, function (window) {
  "use strict";

  const ID = "scene-frame-performer-image";
  const DEFAULTS = Object.freeze({ launchHotkey: "alt+i", localWindow: 5, maximumDimension: 1920, jpegQuality: 0.9 });
  const STATES = Object.freeze({
    IDLE: "IDLE",
    PICKING: "PICKING",
    CHECKING: "CHECKING",
    CONFIRMING: "CONFIRMING",
    SAVING: "SAVING",
  });
  const ASPECTS = Object.freeze([
    { key: "9:16", label: "9:16", ratio: 9 / 16 },
    { key: "2:3", label: "2:3", ratio: 2 / 3 },
    { key: "3:4", label: "3:4", ratio: 3 / 4 },
    { key: "1:1", label: "1:1", ratio: 1 },
    { key: "free", label: "Free", ratio: null },
  ]);
  const DEFAULT_ASPECT = "9:16";
  const ASPECT_STORAGE_KEY = ID + ":aspect";
  // Frames are captured at native resolution up to this long edge so crops
  // keep their detail; maximumDimension applies to the encoded crop only.
  const MAX_SOURCE_DIMENSION = 4096;
  const SEEK_TIMEOUT_MS = 4000;
  // After `seeked`, wait this long for a matching video-frame callback before
  // trusting the paint. Seeking to the frame already shown fires no callback.
  const PRESENT_GRACE_MS = 200;
  // Pointer travel, in screen pixels, before a press on the frame becomes a drag.
  const DRAG_THRESHOLD = 4;

  // ---------------------------------------------------------------------------
  // Settings

  function number(value, fallback, min, max) {
    const n = typeof value === "number" ? value : Number(value);
    return isFinite(n) && n >= min && n <= max ? n : fallback;
  }
  function normalizeHotkey(value, warn) {
    const hotkey = typeof value === "string" ? value.trim().toLowerCase() : "";
    if (!hotkey || /[\s,]/.test(hotkey)) {
      if (warn) warn("Invalid frame-picker hotkey; using Alt+I.");
      return DEFAULTS.launchHotkey;
    }
    return hotkey;
  }
  function hasOwn(object, key) { return !!object && Object.prototype.hasOwnProperty.call(object, key); }
  function hotkeyConfiguration(value) {
    const explicit = hasOwn(value, "launchHotkey");
    const requested = explicit ? value.launchHotkey : undefined;
    const normalized = normalizeHotkey(requested);
    const invalid = explicit && normalized === DEFAULTS.launchHotkey &&
      !(typeof requested === "string" && requested.trim().toLowerCase() === DEFAULTS.launchHotkey);
    return { explicit, invalid, requested, normalized, warningKey: explicit ? typeof requested + ":" + String(requested) : "" };
  }
  // Stash shows unset NUMBER settings as 0, which falls outside every range
  // below and so means "use the default".
  function normalizeSettings(value, warn) {
    value = value || {};
    return {
      launchHotkey: hasOwn(value, "launchHotkey") ? normalizeHotkey(value.launchHotkey, warn) : DEFAULTS.launchHotkey,
      localWindow: number(value.localWindow, DEFAULTS.localWindow, 0.25, 30),
      maximumDimension: Math.round(number(value.maximumDimension, DEFAULTS.maximumDimension, 256, 4096)),
      jpegQuality: number(value.jpegQuality, DEFAULTS.jpegQuality, 0.1, 1),
    };
  }
  function aspectByKey(key) { return ASPECTS.find((aspect) => aspect.key === key) || aspectByKey(DEFAULT_ASPECT); }
  function loadAspect() {
    try { return aspectByKey(window.localStorage.getItem(ASPECT_STORAGE_KEY)).key; } catch (_) { return DEFAULT_ASPECT; }
  }
  function storeAspect(key) {
    try { window.localStorage.setItem(ASPECT_STORAGE_KEY, key); } catch (_) {}
  }
  function isEditableTarget(target) {
    if (!target) return false;
    const el = target.nodeType === 1 || target.tagName ? target : target.parentElement;
    if (!el) return false;
    const tag = String(el.tagName || "").toLowerCase();
    return tag === "input" || tag === "textarea" || tag === "select" || el.isContentEditable === true ||
      !!(el.getAttribute && el.getAttribute("contenteditable") === "true");
  }

  // ---------------------------------------------------------------------------
  // Time

  function clamp(value, lower, upper) { return Math.max(lower, Math.min(upper, Number(value) || 0)); }
  function bounds(time, duration, localWindow) {
    const t = Math.max(0, Number(time) || 0);
    let d = Number(duration);
    if (!isFinite(d) || d < t) d = t;
    return { lower: Math.max(0, t - localWindow), upper: Math.min(d, t + localWindow) };
  }
  function frameStep(frameRate) { return isFinite(Number(frameRate)) && Number(frameRate) > 0 ? 1 / Number(frameRate) : 1 / 30; }
  // Steps target the middle of the neighbouring frame: a time on a frame
  // boundary can present either frame, and float error decides which.
  function stepTarget(time, direction, frameRate) {
    const step = frameStep(frameRate);
    const index = Math.floor((Number(time) || 0) / step + 1e-6);
    return Math.max(0, (index + direction + 0.5) * step);
  }
  function formatTime(time) {
    const total = Math.max(0, Number(time) || 0);
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = (total % 60).toFixed(3).padStart(6, "0");
    return (hours ? hours + ":" + String(minutes).padStart(2, "0") : String(minutes)) + ":" + seconds;
  }
  function formatOffset(delta) {
    const value = Number(delta) || 0;
    if (Math.abs(value) < 0.0005) return "opening frame";
    return (value > 0 ? "+" : "−") + Math.abs(value).toFixed(3) + " s";
  }

  // ---------------------------------------------------------------------------
  // Crop geometry. Crops are { x, y, width, height } in captured-frame pixels.

  function isPlaceholder(path) { return typeof path === "string" && /default=true/i.test(path); }
  function imageIdentity(path) { return path || ""; }
  function scaledDimensions(width, height, maximum) {
    width = Number(width); height = Number(height); maximum = Number(maximum);
    if (!(width > 0 && height > 0 && maximum > 0)) throw new Error("The video has no drawable dimensions.");
    const scale = Math.min(1, maximum / Math.max(width, height));
    return { width: Math.max(1, Math.round(width * scale)), height: Math.max(1, Math.round(height * scale)) };
  }
  function fitSize(width, height, maxWidth, maxHeight) {
    const scale = Math.min(maxWidth / width, maxHeight / height);
    return { width: width * scale, height: height * scale };
  }
  function minimumCropSize(sourceWidth, sourceHeight) { return Math.max(8, Math.round(Math.min(sourceWidth, sourceHeight) * 0.04)); }
  // The largest centred crop of the ratio, or the whole frame for a free ratio.
  function defaultCrop(width, height, ratio) {
    width = Number(width); height = Number(height);
    if (!(width > 0 && height > 0)) throw new Error("The source has no drawable dimensions.");
    if (!(ratio > 0)) return { x: 0, y: 0, width, height };
    let cropWidth = width, cropHeight = cropWidth / ratio;
    if (cropHeight > height) { cropHeight = height; cropWidth = cropHeight * ratio; }
    return { x: (width - cropWidth) / 2, y: (height - cropHeight) / 2, width: cropWidth, height: cropHeight };
  }
  function clampCrop(crop, sourceWidth, sourceHeight, minimum) {
    sourceWidth = Number(sourceWidth); sourceHeight = Number(sourceHeight); minimum = Number(minimum) || 1;
    if (!(sourceWidth > 0 && sourceHeight > 0)) throw new Error("The source has no drawable dimensions.");
    const width = Math.max(minimum, Math.min(sourceWidth, Number(crop && crop.width) || minimum));
    const height = Math.max(minimum, Math.min(sourceHeight, Number(crop && crop.height) || minimum));
    let x = Number(crop && crop.x), y = Number(crop && crop.y);
    if (!isFinite(x)) x = (sourceWidth - width) / 2;
    if (!isFinite(y)) y = (sourceHeight - height) / 2;
    return { x: Math.max(0, Math.min(sourceWidth - width, x)), y: Math.max(0, Math.min(sourceHeight - height, y)), width, height };
  }
  function moveCrop(crop, dx, dy, sourceWidth, sourceHeight) {
    crop = clampCrop(crop, sourceWidth, sourceHeight);
    return clampCrop({ x: crop.x + (Number(dx) || 0), y: crop.y + (Number(dy) || 0), width: crop.width, height: crop.height }, sourceWidth, sourceHeight);
  }
  function centerCropAt(crop, x, y, sourceWidth, sourceHeight) {
    return clampCrop({ x: x - crop.width / 2, y: y - crop.height / 2, width: crop.width, height: crop.height }, sourceWidth, sourceHeight);
  }
  // Resize by dragging a handle ("n", "se", ...). The opposite edge or corner
  // stays fixed; an axis the handle does not move stays centred. With a ratio
  // the crop keeps that ratio, following whichever axis the pointer moved most.
  function resizeCrop(start, handle, dx, dy, sourceWidth, sourceHeight, ratio, minimum) {
    minimum = Math.max(1, Number(minimum) || 1); dx = Number(dx) || 0; dy = Number(dy) || 0;
    const west = handle.indexOf("w") >= 0, east = handle.indexOf("e") >= 0;
    const north = handle.indexOf("n") >= 0, south = handle.indexOf("s") >= 0;
    const horizontal = west || east, vertical = north || south;
    const right = start.x + start.width, bottom = start.y + start.height;
    const centerX = start.x + start.width / 2, centerY = start.y + start.height / 2;
    const roomX = horizontal ? (west ? right : sourceWidth - start.x) : 2 * Math.min(centerX, sourceWidth - centerX);
    const roomY = vertical ? (north ? bottom : sourceHeight - start.y) : 2 * Math.min(centerY, sourceHeight - centerY);
    let width = horizontal ? start.width + (west ? -dx : dx) : start.width;
    let height = vertical ? start.height + (north ? -dy : dy) : start.height;
    if (ratio > 0) {
      if (horizontal && vertical) {
        if (Math.abs(width - start.width) >= Math.abs(height - start.height) * ratio) height = width / ratio;
        else width = height * ratio;
      } else if (horizontal) height = width / ratio;
      else width = height * ratio;
      const maxHeight = Math.min(roomY, roomX / ratio);
      const minHeight = Math.max(minimum, minimum / ratio);
      height = maxHeight < minHeight ? maxHeight : clamp(height, minHeight, maxHeight);
      width = height * ratio;
    } else {
      width = clamp(width, Math.min(minimum, roomX), roomX);
      height = clamp(height, Math.min(minimum, roomY), roomY);
    }
    return {
      x: horizontal ? (west ? right - width : start.x) : centerX - width / 2,
      y: vertical ? (north ? bottom - height : start.y) : centerY - height / 2,
      width,
      height,
    };
  }
  // Scale about the centre, shifting back inside the frame where needed.
  function scaleCrop(crop, factor, sourceWidth, sourceHeight, ratio, minimum) {
    minimum = Math.max(1, Number(minimum) || 1);
    const centerX = crop.x + crop.width / 2, centerY = crop.y + crop.height / 2;
    let width, height;
    if (ratio > 0) {
      height = clamp(crop.height * factor, Math.max(minimum, minimum / ratio), Math.min(sourceHeight, sourceWidth / ratio));
      width = height * ratio;
    } else {
      width = clamp(crop.width * factor, minimum, sourceWidth);
      height = clamp(crop.height * factor, minimum, sourceHeight);
    }
    return clampCrop({ x: centerX - width / 2, y: centerY - height / 2, width, height }, sourceWidth, sourceHeight);
  }
  // Reshape to a new ratio around the same centre with roughly the same area.
  function cropWithAspect(crop, ratio, sourceWidth, sourceHeight) {
    if (!(ratio > 0)) return clampCrop(crop, sourceWidth, sourceHeight);
    let height = Math.sqrt((crop.width * crop.height) / ratio), width = height * ratio;
    const fit = Math.min(1, sourceWidth / width, sourceHeight / height);
    width *= fit; height *= fit;
    return clampCrop({ x: crop.x + crop.width / 2 - width / 2, y: crop.y + crop.height / 2 - height / 2, width, height }, sourceWidth, sourceHeight);
  }
  function cropDimensions(crop) { return { width: Math.max(1, Math.round(crop.width)), height: Math.max(1, Math.round(crop.height)) }; }
  function outputDimensions(crop, maximum) {
    const size = cropDimensions(crop);
    return scaledDimensions(size.width, size.height, maximum);
  }

  // ---------------------------------------------------------------------------
  // Capture and encoding

  function context2d(canvas) {
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Canvas drawing is unavailable.");
    return context;
  }
  // Draws the presented video frame into `canvas` (reused across seeks).
  function captureSource(video, canvas) {
    const size = scaledDimensions(video.videoWidth, video.videoHeight, MAX_SOURCE_DIMENSION);
    canvas = canvas || document.createElement("canvas");
    if (canvas.width !== size.width) canvas.width = size.width;
    if (canvas.height !== size.height) canvas.height = size.height;
    const context = context2d(canvas);
    try { context.drawImage(video, 0, 0, size.width, size.height); } catch (e) { throw new Error("The video frame cannot be drawn: " + e.message); }
    // A cross-origin or protected source draws but cannot be exported. Find
    // out now rather than after the user has framed a crop.
    if (typeof context.getImageData === "function") {
      try { context.getImageData(0, 0, 1, 1); } catch (e) {
        throw new Error("The browser does not allow this video source to be captured (" + (e.name || "security error") + "). Try the Direct stream source.");
      }
    }
    return { canvas, width: size.width, height: size.height };
  }
  function encodeCrop(source, crop, settings) {
    crop = clampCrop(crop, source.width, source.height);
    const output = outputDimensions(crop, settings.maximumDimension);
    const canvas = document.createElement("canvas");
    canvas.width = output.width; canvas.height = output.height;
    const context = context2d(canvas);
    context.imageSmoothingQuality = "high";
    context.drawImage(source.canvas, crop.x, crop.y, crop.width, crop.height, 0, 0, output.width, output.height);
    let dataUrl;
    try { dataUrl = canvas.toDataURL("image/jpeg", settings.jpegQuality); } catch (e) { throw new Error("The browser could not export this frame: " + e.message); }
    if (typeof dataUrl !== "string" || dataUrl.indexOf("data:image/jpeg") !== 0) throw new Error("The browser could not encode this crop as JPEG.");
    return { dataUrl, width: output.width, height: output.height };
  }
  function activationGuard(player, video) {
    return !!(player && video && video.readyState >= 2 && video.videoWidth > 0 && video.videoHeight > 0);
  }
  function videoFromPlayer(player) {
    if (!player) return null;
    const element = typeof player.el === "function" ? player.el() : player.el_;
    if (!element) return null;
    if (element.tagName && element.tagName.toLowerCase() === "video") return element;
    return element.querySelector ? element.querySelector("video") : null;
  }
  function activePlayer(PluginApi) {
    const utils = PluginApi && PluginApi.utils && PluginApi.utils.InteractiveUtils;
    return utils && utils.getPlayer ? utils.getPlayer() : null;
  }
  // Stash's live-transcode sources reload the stream on every seek, so they
  // cannot be browsed frame by frame.
  function isLiveTranscode(player) {
    try { const source = player && player.currentSource && player.currentSource(); return !!(source && source.offset); } catch (_) { return false; }
  }

  // Seek `video` to `target` and resolve once the frame at that time has been
  // presented, using video-frame callbacks where the browser supports them.
  function waitForPresentation(video, target, token, currentToken, timeout, step) {
    return new Promise(function (resolve, reject) {
      // Targets sit mid-frame, so the presented frame starts at most one frame
      // earlier; the previous frame (1.5 frames away) must not match.
      const tolerance = Math.max((step || 1 / 30) * 1.1, 0.01);
      const hasFrameCallback = typeof video.requestVideoFrameCallback === "function";
      let done = false, seeked = false, mediaTime = null, frameHandle = null, graceTimer = null, cancelPaint = null;
      const timer = setTimeout(onTimeout, timeout || SEEK_TIMEOUT_MS);
      function matches() { return mediaTime !== null && isFinite(mediaTime) && Math.abs(mediaTime - target) <= tolerance; }
      function finish(error) {
        if (done) return;
        done = true;
        clearTimeout(timer); clearTimeout(graceTimer);
        if (cancelPaint) cancelPaint();
        if (frameHandle !== null && video.cancelVideoFrameCallback) { try { video.cancelVideoFrameCallback(frameHandle); } catch (_) {} }
        video.removeEventListener("seeked", onSeeked);
        if (error) reject(error);
        else if (token !== currentToken()) reject(new Error("Stale frame request."));
        else resolve(mediaTime);
      }
      function settleAfterPaint() {
        if (done || cancelPaint) return;
        if (video.readyState <= 1) return finish(new Error("The video was not ready after seeking."));
        const raf = window.requestAnimationFrame;
        if (typeof raf === "function") {
          const handle = raf.call(window, function () { cancelPaint = null; finish(); });
          cancelPaint = function () { window.cancelAnimationFrame(handle); };
        } else {
          const handle = setTimeout(function () { cancelPaint = null; finish(); }, 0);
          cancelPaint = function () { clearTimeout(handle); };
        }
      }
      function onSeeked() {
        seeked = true;
        if (!hasFrameCallback) return settleAfterPaint();
        if (matches()) return finish();
        graceTimer = setTimeout(settleAfterPaint, PRESENT_GRACE_MS);
      }
      function onFrame(_, info) {
        if (done) return;
        mediaTime = Number(info && info.mediaTime);
        if (seeked && matches()) return finish();
        frameHandle = video.requestVideoFrameCallback(onFrame);
      }
      function onTimeout() {
        if (token !== currentToken()) return finish(new Error("Frame request was superseded."));
        if (seeked) return settleAfterPaint();
        finish(new Error("Timed out waiting for the video to seek."));
      }
      video.addEventListener("seeked", onSeeked);
      if (hasFrameCallback) frameHandle = video.requestVideoFrameCallback(onFrame);
      try { video.currentTime = target; } catch (error) { finish(error); }
    });
  }

  // ---------------------------------------------------------------------------
  // GraphQL

  function graphql(query, variables) {
    return fetch("/graphql", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, variables: variables || {} }),
    }).then(function (response) {
      return response.text().then(function (text) {
        let body;
        try { body = JSON.parse(text); } catch (e) { throw new Error("Stash returned non-JSON HTTP " + response.status); }
        if (!response.ok || body.errors) throw new Error((body.errors || []).map((e) => e.message).join("; ") || "HTTP " + response.status);
        return body.data;
      });
    });
  }
  const FIND_PERFORMER = "query SfpiPerformer($id: ID!) { findPerformer(id: $id) { id name image_path } }";
  const UPDATE_PERFORMER = "mutation SfpiUpdate($input: PerformerUpdateInput!) { performerUpdate(input: $input) { id name image_path } }";
  function readPerformer(id) {
    return graphql(FIND_PERFORMER, { id: String(id) }).then(function (data) {
      if (!data || !data.findPerformer) throw new Error("The performer no longer exists.");
      return data.findPerformer;
    });
  }
  function updatePerformer(id, image) { return graphql(UPDATE_PERFORMER, { input: { id: String(id), image } }); }

  // ---------------------------------------------------------------------------
  // Picker model: owns playback, seeking, the captured frame, the crop, and
  // the save flow. Views subscribe and re-render on every change.

  function PickerModel(options) {
    options = options || {};
    this.settings = options.settings || normalizeSettings();
    this.player = options.player;
    this.video = options.video;
    this.scene = options.scene || {};
    this.update = options.update;
    this.readPerformer = options.readPerformer || readPerformer;
    this.state = STATES.IDLE;
    this.generation = 0;
    this.listeners = [];
    this.opening = null;
    this.duration = 0;
    this.range = null;
    this.time = 0;
    this.canNavigate = true;
    this.seeking = false;
    this.pendingSeek = null;
    this.seekLoop = null;
    this.source = null;
    this.sourceCanvas = null;
    this.frameVersion = 0;
    this.aspect = aspectByKey(options.aspect || DEFAULT_ASPECT).key;
    this.crop = null;
    this.performer = null;
    this.existing = null;
    this.proposal = null;
    this.error = "";
    this.notice = "";
    this.fatal = false;
  }
  PickerModel.prototype.subscribe = function (fn) {
    const self = this;
    this.listeners.push(fn);
    return function () { self.listeners = self.listeners.filter((item) => item !== fn); };
  };
  PickerModel.prototype.emit = function () { this.listeners.slice().forEach((fn) => fn()); };
  PickerModel.prototype.frameRate = function () { const file = this.scene.files && this.scene.files[0]; return file && file.frame_rate; };
  PickerModel.prototype.step = function () { return frameStep(this.frameRate()); };
  PickerModel.prototype.ratio = function () { return aspectByKey(this.aspect).ratio; };
  PickerModel.prototype.minimumCrop = function () { return this.source ? minimumCropSize(this.source.width, this.source.height) : 1; };
  PickerModel.prototype.busy = function () { return this.state === STATES.CHECKING || this.state === STATES.SAVING; };
  PickerModel.prototype.editable = function () { return this.state === STATES.PICKING && !!this.source && !!this.crop; };
  PickerModel.prototype.canSave = function () {
    return this.state === STATES.PICKING && !this.seeking && !this.fatal && !!this.performer && !!this.source && !!this.crop;
  };

  PickerModel.prototype.open = function () {
    if (this.state !== STATES.IDLE) return false;
    if (!activationGuard(this.player, this.video)) { this.error = "The active video is not ready for capture."; this.emit(); return false; }
    const player = this.player;
    const time = Number(player.currentTime()) || 0;
    const fileDuration = Number((this.scene.files && this.scene.files[0] || {}).duration);
    const playerDuration = Number(typeof player.duration === "function" ? player.duration() : player.duration);
    this.duration = playerDuration > 0 ? playerDuration : fileDuration > 0 ? fileDuration : time + this.settings.localWindow;
    this.opening = { time, playing: typeof player.paused === "function" ? !player.paused() : false };
    this.time = time;
    this.range = bounds(time, this.duration, this.settings.localWindow);
    this.canNavigate = !isLiveTranscode(player);
    if (!this.canNavigate) this.notice = "This scene is playing through a live transcode, so only the current frame can be captured. Switch the player to the Direct stream source to browse nearby frames.";
    const performers = this.scene.performers || [];
    this.performer = performers.length === 1 ? performers[0] : null;
    if (typeof player.pause === "function") player.pause();
    this.state = STATES.PICKING;
    this.capture();
    this.emit();
    return true;
  };
  PickerModel.prototype.capture = function () {
    try {
      const source = captureSource(this.video, this.sourceCanvas);
      const resized = !!this.source && (this.source.width !== source.width || this.source.height !== source.height);
      this.sourceCanvas = source.canvas;
      this.source = source;
      this.frameVersion += 1;
      if (!this.crop || resized) this.crop = defaultCrop(source.width, source.height, this.ratio());
      if (resized) this.notice = "The video size changed, so the crop was reset.";
    } catch (error) {
      this.error = error.message;
      this.fatal = true;
    }
  };

  PickerModel.prototype.seek = function (time) {
    if (this.state !== STATES.PICKING || !this.canNavigate || this.fatal) return Promise.resolve();
    const target = clamp(time, 0, this.duration);
    this.time = target;
    if (target < this.range.lower || target > this.range.upper) this.range = bounds(target, this.duration, this.settings.localWindow);
    this.pendingSeek = target;
    this.error = "";
    if (!this.seekLoop) {
      const self = this;
      this.seekLoop = this.runSeeks().then(function () { self.seekLoop = null; });
    }
    this.emit();
    return this.seekLoop;
  };
  PickerModel.prototype.stepFrame = function (direction) { return this.seek(stepTarget(this.time, direction, this.frameRate())); };
  PickerModel.prototype.jump = function (seconds) { return this.seek(this.time + seconds); };
  PickerModel.prototype.returnToOpening = function () { return this.opening ? this.seek(this.opening.time) : Promise.resolve(); };
  // Seeks are coalesced: while one is in flight only the newest requested time
  // is kept, so scrubbing never queues a backlog of stale frames.
  PickerModel.prototype.runSeeks = async function () {
    const generation = this.generation, self = this;
    this.seeking = true;
    try {
      while (this.pendingSeek !== null && generation === this.generation) {
        const target = this.pendingSeek;
        this.pendingSeek = null;
        try {
          await waitForPresentation(this.video, target, generation, function () { return self.generation; }, SEEK_TIMEOUT_MS, this.step());
          if (generation !== this.generation) return;
          this.capture();
          this.emit();
        } catch (error) {
          if (generation !== this.generation) return;
          if (this.pendingSeek === null) this.error = error.message;
        }
      }
    } finally {
      if (generation === this.generation) { this.seeking = false; this.emit(); }
    }
  };

  PickerModel.prototype.setCrop = function (crop) {
    if (!this.editable()) return;
    this.crop = clampCrop(crop, this.source.width, this.source.height);
    this.emit();
  };
  PickerModel.prototype.nudgeCrop = function (fractionX, fractionY) {
    if (!this.editable()) return;
    this.setCrop(moveCrop(this.crop, fractionX * this.source.width, fractionY * this.source.height, this.source.width, this.source.height));
  };
  PickerModel.prototype.zoomCrop = function (factor) {
    if (!this.editable()) return;
    this.setCrop(scaleCrop(this.crop, factor, this.source.width, this.source.height, this.ratio(), this.minimumCrop()));
  };
  PickerModel.prototype.setAspect = function (key) {
    if (this.state !== STATES.PICKING) return;
    this.aspect = aspectByKey(key).key;
    storeAspect(this.aspect);
    if (this.source && this.crop) this.crop = cropWithAspect(this.crop, this.ratio(), this.source.width, this.source.height);
    this.emit();
  };
  PickerModel.prototype.resetCrop = function () {
    if (!this.editable()) return;
    this.setCrop(defaultCrop(this.source.width, this.source.height, this.ratio()));
  };
  PickerModel.prototype.selectPerformer = function (performer) {
    if (this.busy()) return;
    this.performer = performer;
    this.existing = null;
    this.proposal = null;
    this.error = "";
    if (this.state === STATES.CONFIRMING) this.state = STATES.PICKING;
    this.emit();
  };
  PickerModel.prototype.backToEditing = function () {
    if (this.state !== STATES.CONFIRMING) return;
    this.state = STATES.PICKING;
    this.existing = null;
    this.proposal = null;
    this.error = "";
    this.emit();
  };

  // Resolves true once saved, or false when the performer already has an
  // image and the user must confirm the replacement first.
  PickerModel.prototype.save = async function () {
    if (!this.canSave()) throw new Error("Choose a performer and wait for the frame to load first.");
    const generation = this.generation, performer = this.performer;
    this.state = STATES.CHECKING;
    this.error = "";
    this.emit();
    try {
      const proposal = encodeCrop(this.source, this.crop, this.settings);
      const latest = await this.readPerformer(performer.id);
      if (generation !== this.generation) return false;
      this.proposal = proposal;
      if (!isPlaceholder(latest.image_path)) {
        this.existing = latest;
        this.state = STATES.CONFIRMING;
        this.emit();
        return false;
      }
      return await this.commit(generation, performer, proposal.dataUrl);
    } catch (error) {
      if (generation === this.generation) { this.state = STATES.PICKING; this.proposal = null; this.error = error.message; this.emit(); }
      throw error;
    }
  };
  PickerModel.prototype.replace = async function () {
    if (this.state !== STATES.CONFIRMING || !this.existing || !this.proposal) throw new Error("A save is already in progress.");
    const generation = this.generation, performer = this.performer, proposal = this.proposal;
    const shown = imageIdentity(this.existing.image_path);
    this.state = STATES.CHECKING;
    this.error = "";
    this.emit();
    try {
      const latest = await this.readPerformer(performer.id);
      if (generation !== this.generation) return false;
      if (imageIdentity(latest.image_path) !== shown && !isPlaceholder(latest.image_path)) {
        this.existing = latest;
        this.state = STATES.CONFIRMING;
        this.error = "The stored image changed while this was open. Compare again before replacing it.";
        this.emit();
        return false;
      }
      return await this.commit(generation, performer, proposal.dataUrl);
    } catch (error) {
      if (generation === this.generation) { this.state = STATES.CONFIRMING; this.error = error.message; this.emit(); }
      throw error;
    }
  };
  PickerModel.prototype.commit = async function (generation, performer, image) {
    this.state = STATES.SAVING;
    this.emit();
    const input = { id: String(performer.id), image };
    const result = await (this.update ? this.update({ variables: { input } }) : updatePerformer(performer.id, image));
    if (generation !== this.generation) return false;
    // Saving leaves playback paused on the chosen frame rather than restoring it.
    this.generation += 1;
    this.state = STATES.IDLE;
    this.opening = null;
    this.emit();
    return result || true;
  };
  PickerModel.prototype.cancel = function () {
    if (this.state === STATES.SAVING) return false;
    const opening = this.opening;
    this.generation += 1;
    this.state = STATES.IDLE;
    this.opening = null;
    this.pendingSeek = null;
    this.seeking = false;
    if (opening && this.player) {
      this.player.currentTime(opening.time);
      if (opening.playing) this.player.play();
    }
    this.emit();
    return true;
  };

  // ---------------------------------------------------------------------------
  // Views

  function toast(dispatch, message, type) {
    if (dispatch) {
      if (type === "success" && dispatch.success) return dispatch.success(message);
      if (type === "error" && dispatch.error) return dispatch.error(message);
      if (dispatch.toast) return dispatch.toast({ content: message, variant: type === "warning" ? "warning" : undefined });
    }
    if (window && window.console) (type === "error" ? console.error : console.info)("[" + ID + "] " + message);
  }
  function setCapture(element, pointerId, capture) {
    if (!element) return;
    try { if (capture) element.setPointerCapture(pointerId); else element.releasePointerCapture(pointerId); } catch (_) {}
  }
  const HANDLES_CORNER = ["nw", "ne", "sw", "se"];
  const HANDLES_EDGE = ["n", "e", "s", "w"];
  const STAGE_PADDING = 14;

  function createComponents(PluginApi) {
    const React = PluginApi.React, ReactDOM = PluginApi.ReactDOM, h = React.createElement;

    function useModel(model) {
      const pair = React.useState(0), setVersion = pair[1];
      React.useEffect(function () {
        return model.subscribe(function () { setVersion((value) => value + 1); });
      }, [model]);
    }

    function icon(path, size) {
      return h("svg", { viewBox: "0 0 24 24", width: size || 18, height: size || 18, fill: "currentColor", "aria-hidden": "true", focusable: "false" }, h("path", { d: path }));
    }
    const ICONS = {
      // A portrait inside a viewfinder.
      capture: "M3 7V5a2 2 0 0 1 2-2h2v2H5v2H3zm14-4h2a2 2 0 0 1 2 2v2h-2V5h-2V3zM5 17v2h2v2H5a2 2 0 0 1-2-2v-2h2zm14 0h2v2a2 2 0 0 1-2 2h-2v-2h2v-2zM12 7a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm-5 10c0-2 3.3-3 5-3s5 1 5 3v1H7v-1z",
      close: "M18.3 5.7a1 1 0 0 0-1.4 0L12 10.6 7.1 5.7a1 1 0 1 0-1.4 1.4l4.9 4.9-4.9 4.9a1 1 0 1 0 1.4 1.4l4.9-4.9 4.9 4.9a1 1 0 0 0 1.4-1.4L13.4 12l4.9-4.9a1 1 0 0 0 0-1.4z",
      prevFrame: "M6 6h2v12H6zm3.5 6 8.5 6V6z",
      nextFrame: "M16 6h2v12h-2zM6 18l8.5-6L6 6z",
      back: "M11 18V6l-8.5 6 8.5 6zm.5-6 8.5 6V6l-8.5 6z",
      forward: "M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z",
      reset: "M12 5V1L7 6l5 5V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z",
    };

    function FrameStage(props) {
      const model = props.model, source = model.source, crop = model.crop;
      const stageRef = React.useRef(null), frameRef = React.useRef(null), holderRef = React.useRef(null), dragRef = React.useRef(null);
      const sizePair = React.useState({ width: 0, height: 0 }), size = sizePair[0], setSize = sizePair[1];
      const dragPair = React.useState(""), dragging = dragPair[0], setDragging = dragPair[1];

      React.useEffect(function () {
        const stage = stageRef.current;
        if (!stage) return undefined;
        function measure() {
          setSize((previous) => previous.width === stage.clientWidth && previous.height === stage.clientHeight ? previous : { width: stage.clientWidth, height: stage.clientHeight });
        }
        measure();
        if (typeof ResizeObserver === "function") {
          const observer = new ResizeObserver(measure);
          observer.observe(stage);
          return function () { observer.disconnect(); };
        }
        window.addEventListener("resize", measure);
        return function () { window.removeEventListener("resize", measure); };
      }, []);

      let frameStyle = null;
      if (source && size.width > 0 && size.height > 0) {
        const fit = fitSize(source.width, source.height, Math.max(1, size.width - 2 * STAGE_PADDING), Math.max(1, size.height - 2 * STAGE_PADDING));
        frameStyle = { left: (size.width - fit.width) / 2 + "px", top: (size.height - fit.height) / 2 + "px", width: fit.width + "px", height: fit.height + "px" };
      }

      // The model draws every captured frame into one canvas; show it directly.
      // The holder only exists once the stage has been measured.
      const canvas = source && source.canvas, hasFrame = !!frameStyle;
      React.useEffect(function () {
        const holder = holderRef.current;
        if (!holder || !canvas) return undefined;
        canvas.className = "sfpi-frame-canvas";
        holder.appendChild(canvas);
        return function () { if (canvas.parentNode === holder) holder.removeChild(canvas); };
      }, [canvas, hasFrame]);

      function sourcePoint(event) {
        const rect = frameRef.current.getBoundingClientRect();
        const scale = source.width / Math.max(1, rect.width);
        return { x: clamp((event.clientX - rect.left) * scale, 0, source.width), y: clamp((event.clientY - rect.top) * (source.height / Math.max(1, rect.height)), 0, source.height), scale };
      }
      function onPointerDown(event) {
        if (!model.editable() || (event.pointerType === "mouse" && event.button !== 0)) return;
        const target = event.target;
        const handle = target.getAttribute && target.getAttribute("data-handle");
        const inCrop = !!(target.closest && target.closest(".sfpi-crop"));
        const mode = handle ? "resize" : inCrop ? "move" : "select";
        dragRef.current = { mode, handle, start: Object.assign({}, model.crop), origin: sourcePoint(event), pointerId: event.pointerId, moved: false };
        setCapture(frameRef.current, event.pointerId, true);
        event.preventDefault();
        if (inCrop) { const box = frameRef.current.querySelector(".sfpi-crop"); if (box) box.focus({ preventScroll: true }); }
      }
      function onPointerMove(event) {
        const drag = dragRef.current;
        if (!drag || event.pointerId !== drag.pointerId) return;
        const point = sourcePoint(event), dx = point.x - drag.origin.x, dy = point.y - drag.origin.y;
        if (!drag.moved) {
          if (Math.hypot(dx, dy) / drag.origin.scale < DRAG_THRESHOLD) return;
          drag.moved = true;
          setDragging(drag.mode);
        }
        const width = source.width, height = source.height, ratio = model.ratio(), minimum = model.minimumCrop();
        if (drag.mode === "move") model.setCrop(moveCrop(drag.start, dx, dy, width, height));
        else if (drag.mode === "resize") model.setCrop(resizeCrop(drag.start, drag.handle, dx, dy, width, height, ratio, minimum));
        else {
          // Dragging on the frame outside the crop draws a new one from the press point.
          const handle = (dy < 0 ? "n" : "s") + (dx < 0 ? "w" : "e");
          model.setCrop(resizeCrop({ x: drag.origin.x, y: drag.origin.y, width: 0, height: 0 }, handle, dx, dy, width, height, ratio, minimum));
        }
      }
      function endDrag(event, cancelled) {
        const drag = dragRef.current;
        if (!drag || event.pointerId !== drag.pointerId) return;
        dragRef.current = null;
        setCapture(frameRef.current, event.pointerId, false);
        setDragging("");
        // A click outside the crop recentres it there.
        if (!cancelled && !drag.moved && drag.mode === "select") model.setCrop(centerCropAt(model.crop, drag.origin.x, drag.origin.y, source.width, source.height));
      }
      function onCropKeyDown(event) {
        const big = event.shiftKey ? 0.1 : 0.01;
        const moves = { ArrowLeft: [-big, 0], ArrowRight: [big, 0], ArrowUp: [0, -big], ArrowDown: [0, big] };
        if (moves[event.key]) model.nudgeCrop(moves[event.key][0], moves[event.key][1]);
        else if (event.key === "+" || event.key === "=") model.zoomCrop(event.shiftKey ? 1.2 : 1.05);
        else if (event.key === "-" || event.key === "_") model.zoomCrop(event.shiftKey ? 1 / 1.2 : 1 / 1.05);
        else return;
        event.preventDefault();
        event.stopPropagation();
      }

      const handles = model.ratio() ? HANDLES_CORNER : HANDLES_CORNER.concat(HANDLES_EDGE);
      const percent = (value, total) => (value / total) * 100 + "%";
      const cropStyle = crop && source ? { left: percent(crop.x, source.width), top: percent(crop.y, source.height), width: percent(crop.width, source.width), height: percent(crop.height, source.height) } : null;
      const status = model.fatal ? null : !source ? "Capturing frame…" : model.seeking ? "Loading frame…" : "";

      return h("div", { className: "sfpi-stage", ref: stageRef },
        frameStyle && h("div", {
          className: "sfpi-frame" + (dragging ? " is-dragging is-" + dragging : ""),
          ref: frameRef,
          style: frameStyle,
          onPointerDown,
          onPointerMove,
          onPointerUp: (event) => endDrag(event, false),
          onPointerCancel: (event) => endDrag(event, true),
          onLostPointerCapture: (event) => endDrag(event, true),
        },
          h("div", { className: "sfpi-frame-holder", ref: holderRef }),
          cropStyle && h("div", { className: "sfpi-shade-layer", "aria-hidden": "true" }, h("div", { className: "sfpi-shade", style: cropStyle })),
          cropStyle && h("div", {
            className: "sfpi-crop",
            style: cropStyle,
            tabIndex: 0,
            role: "group",
            "aria-label": "Crop area. Drag or use arrow keys to move it; plus and minus resize it.",
            onKeyDown: onCropKeyDown,
          },
            h("div", { className: "sfpi-grid", "aria-hidden": "true" }, h("span"), h("span"), h("span"), h("span")),
            handles.map((handle) => h("span", { key: handle, className: "sfpi-handle sfpi-handle-" + handle, "data-handle": handle, "aria-hidden": "true" })))),
        model.fatal && h("div", { className: "sfpi-stage-error", role: "alert" }, model.error),
        status ? h("div", { className: "sfpi-stage-status" }, status) : null);
    }

    function CropPreview(props) {
      const model = props.model, source = model.source, crop = model.crop;
      const canvasRef = React.useRef(null);
      React.useEffect(function () {
        const canvas = canvasRef.current;
        if (!canvas || !source || !crop) return;
        const ratio = window.devicePixelRatio || 1;
        const fit = fitSize(crop.width, crop.height, 260, 300);
        canvas.width = Math.max(1, Math.round(fit.width * ratio));
        canvas.height = Math.max(1, Math.round(fit.height * ratio));
        canvas.style.width = fit.width + "px";
        canvas.style.height = fit.height + "px";
        const context = canvas.getContext("2d");
        if (!context) return;
        context.imageSmoothingQuality = "high";
        context.drawImage(source.canvas, crop.x, crop.y, crop.width, crop.height, 0, 0, canvas.width, canvas.height);
      }, [model.frameVersion, source, crop && crop.x, crop && crop.y, crop && crop.width, crop && crop.height]);
      const output = source && crop ? outputDimensions(crop, model.settings.maximumDimension) : null;
      return h("section", { className: "sfpi-section" },
        h("h3", { className: "sfpi-section-title" }, "Result"),
        h("div", { className: "sfpi-preview-box" }, source && crop && h("canvas", { ref: canvasRef, className: "sfpi-preview-canvas", role: "img", "aria-label": "Preview of the cropped image" })),
        h("div", { className: "sfpi-output-size", "aria-live": "polite" }, output ? output.width + " × " + output.height + " px" : ""));
    }

    function CropControls(props) {
      const model = props.model, disabled = !model.editable();
      return h("section", { className: "sfpi-section" },
        h("h3", { className: "sfpi-section-title", id: "sfpi-aspect-label" }, "Shape"),
        h("div", { className: "sfpi-aspects", role: "radiogroup", "aria-labelledby": "sfpi-aspect-label" },
          ASPECTS.map((aspect) => h("button", {
            key: aspect.key,
            type: "button",
            role: "radio",
            "aria-checked": model.aspect === aspect.key ? "true" : "false",
            className: "btn btn-sm " + (model.aspect === aspect.key ? "btn-primary" : "btn-secondary"),
            disabled,
            onClick: () => model.setAspect(aspect.key),
          }, aspect.label)),
          h("button", { type: "button", className: "btn btn-sm btn-secondary sfpi-reset-crop", disabled, onClick: () => model.resetCrop(), title: "Largest centred crop of this shape" }, "Fit")));
    }

    function PerformerPicker(props) {
      const model = props.model, performers = model.scene.performers || [];
      return h("section", { className: "sfpi-section" },
        h("h3", { className: "sfpi-section-title", id: "sfpi-performer-label" }, "Performer"),
        performers.length
          ? h("div", { className: "sfpi-performers", role: "radiogroup", "aria-labelledby": "sfpi-performer-label" },
            performers.map(function (performer) {
              const selected = !!model.performer && String(model.performer.id) === String(performer.id);
              return h("button", {
                key: performer.id,
                type: "button",
                role: "radio",
                "aria-checked": selected ? "true" : "false",
                className: "sfpi-performer" + (selected ? " selected" : ""),
                disabled: model.busy(),
                onClick: () => model.selectPerformer(performer),
              },
                h("span", { className: "sfpi-performer-thumb" },
                  performer.image_path ? h("img", { src: performer.image_path, alt: "", loading: "lazy" }) : null,
                  isPlaceholder(performer.image_path) ? h("span", { className: "sfpi-badge" }, "No image") : null),
                h("span", { className: "sfpi-performer-name" }, performer.name));
            }))
          : h("p", { className: "sfpi-muted" }, "This scene has no performers. Add one to the scene to save an image."));
    }

    function Timeline(props) {
      const model = props.model, range = model.range;
      const disabled = !model.canNavigate || model.fatal || model.state !== STATES.PICKING;
      const span = Math.max(1e-6, range.upper - range.lower);
      const openingOffset = ((model.opening ? model.opening.time : model.time) - range.lower) / span;
      const button = (label, iconPath, onClick, text) => h("button", { type: "button", className: "btn btn-secondary sfpi-step", "aria-label": label, title: label, disabled, onClick }, icon(iconPath), text ? h("span", { className: "sfpi-step-text" }, text) : null);
      return h("div", { className: "sfpi-timeline" },
        h("div", { className: "sfpi-scrub-row" },
          button("Back 1 second", ICONS.back, () => model.jump(-1), "1s"),
          button("Previous frame", ICONS.prevFrame, () => model.stepFrame(-1)),
          h("div", { className: "sfpi-scrubber-wrap" },
            h("input", {
              type: "range",
              className: "sfpi-scrubber",
              min: range.lower,
              max: range.upper,
              step: model.step(),
              value: model.time,
              disabled,
              onChange: (event) => model.seek(Number(event.target.value)),
              "aria-label": "Frame time",
              "aria-valuetext": formatTime(model.time),
            }),
            openingOffset >= 0 && openingOffset <= 1 ? h("span", { className: "sfpi-opening-marker", style: { left: openingOffset * 100 + "%" }, title: "Where you opened the picker" }) : null),
          button("Next frame", ICONS.nextFrame, () => model.stepFrame(1)),
          button("Forward 1 second", ICONS.forward, () => model.jump(1), "1s")),
        h("div", { className: "sfpi-time-row" },
          h("span", { className: "sfpi-time" }, formatTime(model.time)),
          h("span", { className: "sfpi-muted sfpi-offset" }, model.opening ? formatOffset(model.time - model.opening.time) : ""),
          h("span", { className: "sfpi-range-label sfpi-muted" }, formatTime(range.lower) + " – " + formatTime(range.upper)),
          h("button", { type: "button", className: "btn btn-link btn-sm sfpi-return", disabled: disabled || !model.opening || Math.abs(model.time - model.opening.time) < 0.0005, onClick: () => model.returnToOpening() }, icon(ICONS.reset, 14), " Return to opening frame")));
    }

    function ConfirmReplace(props) {
      const model = props.model, existing = model.existing;
      return h("div", { className: "sfpi-confirm" },
        h("h3", null, "Replace " + (existing.name || "this performer") + "'s image?"),
        h("div", { className: "sfpi-compare" },
          h("figure", null, h("img", { src: existing.image_path, alt: existing.name + " current image" }), h("figcaption", null, "Current")),
          h("figure", null, h("img", { src: model.proposal.dataUrl, alt: "New image from this frame" }), h("figcaption", null, "New · " + model.proposal.width + " × " + model.proposal.height + " px"))));
    }

    function PickerDialog(props) {
      const model = props.model;
      useModel(model);
      const dialogRef = React.useRef(null);
      React.useEffect(function () { if (dialogRef.current) dialogRef.current.focus({ preventScroll: true }); }, []);

      const confirming = model.state === STATES.CONFIRMING || (model.state === STATES.CHECKING && !!model.existing) || (model.state === STATES.SAVING && !!model.existing);
      function save() { props.onSave(function () { return model.save(); }); }
      function replace() { props.onSave(function () { return model.replace(); }); }

      function onKeyDown(event) {
        // Keep keys away from Stash's page-wide shortcuts while the picker is open.
        event.stopPropagation();
        const target = event.target, key = event.key;
        if (key === "Escape") {
          event.preventDefault();
          if (model.state === STATES.CONFIRMING) model.backToEditing();
          else props.onClose();
          return;
        }
        if (key === "Tab") return trapFocus(event);
        const onScrubber = !!target && target.type === "range";
        if ((isEditableTarget(target) && !onScrubber) || event.altKey || event.ctrlKey || event.metaKey) return;
        if (key === "," || key === ".") { event.preventDefault(); model.stepFrame(key === "," ? -1 : 1); return; }
        // A focused scrubber already steps one frame per arrow key.
        if (!onScrubber && (key === "ArrowLeft" || key === "ArrowRight")) {
          const direction = key === "ArrowLeft" ? -1 : 1;
          event.preventDefault();
          if (event.shiftKey) model.jump(direction); else model.stepFrame(direction);
        }
      }
      function trapFocus(event) {
        const items = Array.prototype.filter.call(
          dialogRef.current.querySelectorAll("button:not([disabled]), input:not([disabled]), [tabindex=\"0\"]"),
          (item) => item.offsetParent !== null);
        if (!items.length) return;
        const first = items[0], last = items[items.length - 1];
        if (event.shiftKey && (document.activeElement === first || document.activeElement === dialogRef.current)) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }

      const performer = model.performer;
      const saveLabel = model.state === STATES.SAVING ? "Saving…" : model.state === STATES.CHECKING ? "Checking…" : performer ? "Save to " + performer.name : "Save image";
      const message = model.fatal ? "" : model.error;
      return h("div", { className: "sfpi-backdrop", role: "presentation" },
        h("div", { className: "sfpi-dialog", ref: dialogRef, role: "dialog", "aria-modal": "true", "aria-labelledby": "sfpi-title", tabIndex: -1, onKeyDown },
          h("header", { className: "sfpi-header" },
            h("h2", { id: "sfpi-title" }, "Performer image from frame"),
            h("button", { type: "button", className: "sfpi-close", onClick: props.onClose, "aria-label": "Cancel frame picker", title: "Cancel (Esc)", disabled: model.busy() }, icon(ICONS.close, 20))),
          h("div", { className: "sfpi-main" },
            confirming ? h(ConfirmReplace, { model }) : h(FrameStage, { model }),
            !confirming && model.range ? h(Timeline, { model }) : null),
          h("aside", { className: "sfpi-side" },
            h(CropPreview, { model }),
            h(CropControls, { model }),
            h(PerformerPicker, { model })),
          h("footer", { className: "sfpi-footer" },
            message ? h("p", { className: "sfpi-message sfpi-error", role: "alert" }, message)
              : model.notice ? h("p", { className: "sfpi-message sfpi-muted", role: "status" }, model.notice)
                : h("p", { className: "sfpi-message sfpi-hints" },
                  h("kbd", null, ","), " ", h("kbd", null, "."), " or ", h("kbd", null, "←"), " ", h("kbd", null, "→"), " frame · ",
                  h("kbd", null, "Shift"), "+", h("kbd", null, "←"), " ", h("kbd", null, "→"), " 1 s · drag on the frame to draw a crop"),
            confirming
              ? [
                h("button", { key: "back", type: "button", className: "btn btn-secondary", disabled: model.busy(), onClick: () => model.backToEditing() }, "Back"),
                h("button", { key: "replace", type: "button", className: "btn btn-danger", disabled: model.state !== STATES.CONFIRMING, onClick: replace }, model.state === STATES.SAVING ? "Saving…" : model.state === STATES.CHECKING ? "Checking…" : "Replace image"),
              ]
              : [
                h("button", { key: "cancel", type: "button", className: "btn btn-secondary", disabled: model.busy(), onClick: props.onClose }, "Cancel"),
                h("button", { key: "save", type: "button", className: "btn btn-primary sfpi-save", disabled: !model.canSave(), onClick: save, title: performer ? "" : "Choose a performer first" }, saveLabel),
              ])));
    }

    function Controller(props) {
      const scene = props.scene;
      const showToast = PluginApi.hooks && PluginApi.hooks.useToast ? PluginApi.hooks.useToast() : null;
      const service = PluginApi.utils && PluginApi.utils.StashService;
      const updateHook = service && service.usePerformerUpdate ? service.usePerformerUpdate() : null;
      const configurationResult = service && typeof service.useConfiguration === "function" ? service.useConfiguration() : null;
      const pluginSettings = configurationResult && configurationResult.data && configurationResult.data.configuration &&
        configurationResult.data.configuration.plugins && configurationResult.data.configuration.plugins[ID];
      const rawSettings = pluginSettings || (PluginApi.configuration && PluginApi.configuration.plugins && PluginApi.configuration.plugins[ID]) || {};
      const hotkey = hotkeyConfiguration(rawSettings), settings = normalizeSettings(rawSettings);

      const modelPair = React.useState(null), model = modelPair[0], setModel = modelPair[1];
      const readyPair = React.useState(false), ready = readyPair[0], setReady = readyPair[1];
      const slotPair = React.useState(null), slot = slotPair[0], setSlot = slotPair[1];
      const tickPair = React.useState(0), setTick = tickPair[1];
      const modelRef = React.useRef(null), triggerRef = React.useRef(null), hotkeyWarningRef = React.useRef(null), openRef = React.useRef(null);
      const player = activePlayer(PluginApi), video = videoFromPlayer(player);
      modelRef.current = model;

      // Video.js creates the player after ScenePlayer first renders.
      React.useEffect(function () {
        if (player) return undefined;
        const timer = setInterval(function () { if (activePlayer(PluginApi)) setTick((value) => value + 1); }, 500);
        return function () { clearInterval(timer); };
      }, [player]);

      React.useEffect(function () {
        if (!video) { setReady(false); return undefined; }
        const events = ["loadeddata", "canplay", "seeked", "emptied"];
        const update = function () { setReady(activationGuard(player, video)); };
        update();
        events.forEach((name) => video.addEventListener(name, update));
        return function () { events.forEach((name) => video.removeEventListener(name, update)); };
      }, [player, video]);

      // The launcher lives in the player's control bar, beside fullscreen; a
      // button under the player sits below the fold on tall layouts.
      React.useEffect(function () {
        const bar = player && player.controlBar && typeof player.controlBar.el === "function" ? player.controlBar.el() : null;
        if (!bar || typeof document === "undefined" || !document.createElement) { setSlot(null); return undefined; }
        const element = document.createElement("div");
        element.className = "sfpi-control-slot";
        bar.insertBefore(element, bar.querySelector(".vjs-fullscreen-control"));
        setSlot(element);
        return function () { if (element.parentNode) element.parentNode.removeChild(element); setSlot(null); };
      }, [player]);

      openRef.current = function () {
        if (modelRef.current) return;
        const currentPlayer = activePlayer(PluginApi), currentVideo = videoFromPlayer(currentPlayer);
        if (!activationGuard(currentPlayer, currentVideo)) { toast(showToast, "The video isn't ready yet. Start playback, then try again.", "error"); return; }
        if (currentPlayer.isFullscreen && currentPlayer.isFullscreen() && currentPlayer.exitFullscreen) currentPlayer.exitFullscreen();
        const next = new PickerModel({ player: currentPlayer, video: currentVideo, scene, settings, update: updateHook && updateHook[0], aspect: loadAspect() });
        if (!next.open()) return;
        modelRef.current = next;
        setModel(next);
      };

      React.useEffect(function () {
        if (!hotkey.explicit || !hotkey.invalid) { hotkeyWarningRef.current = null; return; }
        const key = "invalid:" + hotkey.warningKey;
        if (hotkeyWarningRef.current !== key) { hotkeyWarningRef.current = key; toast(showToast, "Invalid frame-picker hotkey; using Alt+I.", "warning"); }
      }, [hotkey.explicit, hotkey.invalid, hotkey.warningKey]);

      React.useEffect(function () {
        const Mousetrap = PluginApi.libraries && PluginApi.libraries.Mousetrap;
        if (!Mousetrap) return undefined;
        const trap = new Mousetrap(document);
        let key = settings.launchHotkey;
        const handler = function (event) {
          if (isEditableTarget(event.target)) return;
          if (event.preventDefault) event.preventDefault();
          openRef.current();
        };
        try { trap.bind(key, handler); } catch (_) {
          if (hotkey.explicit && !hotkey.invalid) {
            const warningKey = "unbindable:" + hotkey.warningKey;
            if (hotkeyWarningRef.current !== warningKey) { hotkeyWarningRef.current = warningKey; toast(showToast, "Invalid frame-picker hotkey; using Alt+I.", "warning"); }
          }
          if (key !== DEFAULTS.launchHotkey) { try { key = DEFAULTS.launchHotkey; trap.bind(key, handler); } catch (__) {} }
        }
        return function () { if (trap.reset) trap.reset(); else if (trap.unbind) trap.unbind(key); };
      }, [settings.launchHotkey, hotkey.explicit, hotkey.invalid, hotkey.warningKey]);

      React.useEffect(function () {
        return function () { if (modelRef.current) modelRef.current.cancel(); modelRef.current = null; };
      }, []);

      // Other plugins open the picker with an OPEN_EVENT (see openPicker).
      React.useEffect(function () {
        if (typeof window === "undefined" || !window.addEventListener) return undefined;
        const listener = function () { openRef.current(); };
        window.addEventListener(OPEN_EVENT, listener);
        return function () { window.removeEventListener(OPEN_EVENT, listener); };
      }, []);

      function dismiss() {
        modelRef.current = null;
        setModel(null);
        setTimeout(function () { if (triggerRef.current) triggerRef.current.focus(); }, 0);
      }
      function close() {
        const current = modelRef.current;
        if (current && current.busy()) return;
        if (current) current.cancel();
        dismiss();
      }
      function runSave(operation) {
        const current = modelRef.current;
        operation().then(function (saved) {
          if (saved === false || modelRef.current !== current) return;
          toast(showToast, "Saved image for " + (current.performer ? current.performer.name : "the performer") + ".", "success");
          dismiss();
        }).catch(function (error) { toast(showToast, error.message, "error"); });
      }

      const label = "Choose performer image from frame";
      const trigger = h("button", {
        ref: triggerRef,
        type: "button",
        className: "sfpi-trigger" + (slot ? " vjs-control vjs-button" : " btn btn-secondary btn-sm"),
        disabled: !ready || !!model,
        onClick: function (event) { event.stopPropagation(); openRef.current(); },
        "aria-label": label,
        title: label + " (" + settings.launchHotkey.replace(/\b\w/g, (c) => c.toUpperCase()) + ")",
      }, icon(ICONS.capture, slot ? 20 : 16), slot ? null : h("span", null, " Performer image"));
      const canPortal = ReactDOM && ReactDOM.createPortal && typeof document !== "undefined" && document.body;
      return h(React.Fragment, null,
        slot && canPortal ? ReactDOM.createPortal(trigger, slot) : h("div", { className: "sfpi-trigger-wrap" }, trigger),
        model && canPortal ? ReactDOM.createPortal(h(PickerDialog, { model, onClose: close, onSave: runSave }), document.body) : null);
    }

    return { Controller, PickerDialog };
  }

  // ---------------------------------------------------------------------------
  // Used by other plugins (the Stash Bridge controllers) through
  // window.SceneFramePerformerImage.

  const OPEN_EVENT = ID + ":open";
  const CONFIG_QUERY = "query SfpiConfiguration { configuration { plugins } }";

  // Opens the picker on the current frame, as the hotkey does.
  function openPicker() {
    window.dispatchEvent(new CustomEvent(OPEN_EVENT));
  }

  // Saves the current frame, centred and cropped to the last-used shape, as a
  // performer's image. A performer who already has an image is only changed
  // when `replaceImage` is the image_path the user agreed to replace;
  // otherwise this resolves { saved: false, needsConfirmation, image } and
  // changes nothing.
  async function quickSave(PluginApi, options) {
    options = options || {};
    if (!isId(options.performerId)) throw new Error("Choose a performer first.");
    const player = activePlayer(PluginApi), video = videoFromPlayer(player);
    if (!activationGuard(player, video)) throw new Error("The video isn't ready yet. Start playback, then try again.");
    const config = await graphql(CONFIG_QUERY);
    const plugins = config && config.configuration && config.configuration.plugins;
    const settings = normalizeSettings(plugins && plugins[ID]);
    const source = captureSource(video);
    const proposal = encodeCrop(source, defaultCrop(source.width, source.height, aspectByKey(loadAspect()).ratio), settings);
    const latest = await readPerformer(options.performerId);
    if (!isPlaceholder(latest.image_path) && imageIdentity(latest.image_path) !== imageIdentity(options.replaceImage)) {
      return { saved: false, needsConfirmation: true, performer: latest.name, image: latest.image_path };
    }
    await updatePerformer(latest.id, proposal.dataUrl);
    return { saved: true, performer: latest.name };
  }

  function isId(value) { return /^[1-9][0-9]*$/.test(String(value || "")); }

  function install(PluginApi) {
    if (!PluginApi || !PluginApi.patch || !PluginApi.patch.after || !PluginApi.React) return;
    if (typeof window !== "undefined") window.SceneFramePerformerImage = { open: openPicker, quickSave: function (options) { return quickSave(PluginApi, options); } };
    const components = createComponents(PluginApi);
    PluginApi.patch.after("ScenePlayer", function () {
      const args = Array.prototype.slice.call(arguments), result = args[args.length - 1], props = args[0] || {};
      if (!props.scene) return result;
      return PluginApi.React.createElement(PluginApi.React.Fragment, null, result, PluginApi.React.createElement(components.Controller, { key: "sfpi", scene: props.scene }));
    });
  }

  return {
    ID, DEFAULTS, STATES, ASPECTS,
    normalizeSettings, normalizeHotkey, hotkeyConfiguration, isEditableTarget, aspectByKey,
    bounds, frameStep, stepTarget, clamp, formatTime, formatOffset,
    isPlaceholder, imageIdentity, scaledDimensions, fitSize,
    defaultCrop, clampCrop, moveCrop, centerCropAt, resizeCrop, scaleCrop, cropWithAspect, cropDimensions, outputDimensions, minimumCropSize,
    captureSource, encodeCrop, activationGuard, videoFromPlayer, isLiveTranscode, waitForPresentation,
    PickerModel, createComponents, install, openPicker, quickSave, OPEN_EVENT,
  };
});
