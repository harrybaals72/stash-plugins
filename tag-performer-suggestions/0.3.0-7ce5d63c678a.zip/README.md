# Tag & Performer Suggestions

A UI-only Stash plugin that suggests tags and performers for a scene or image, based on how the rest of your library is tagged. It never changes anything by itself: a suggestion is applied only when you press its **Add** button, and that adds exactly that one tag or performer.

## Use

- **Scenes:** open the **Suggestions** tab on the scene page. Nothing is calculated until you open the tab.
- **Images:** the suggestions appear in a **Suggestions** section at the bottom of the image's Details panel.

Each suggestion shows why it was made, for example *On 15 of 15 tagged items featuring Alice*. If more than one thing supports it, **+N more sources** expands the list. For each suggestion you can:

| Button | Effect |
|---|---|
| **Add** | Adds that one tag or performer to the scene or image. Existing tags and performers are kept. |
| **Dismiss** | Hides the suggestion until you leave the page. Nothing is saved. |
| **Exclude** (tags only) | Adds the tag's name to the **Excluded tags** setting, so it and its child tags are never suggested again. |

**Recalculate** loads fresh suggestions, for example after editing the scene. Dismissed suggestions stay hidden until you leave the page.

## How suggestions are chosen

A *related item* is any other scene or image that shares something with the one you're viewing: a performer, a tag, the studio, a group (scenes only) or a gallery. Scenes and images are counted together. For each candidate the plugin asks how consistently it appears among related items, compared with how common it is across the whole library.

- **Support:** the number of related items that carry the candidate.
- **Confidence:** the share of related items that carry it, smoothed toward the library-wide rate so that a small sample (two for two) is not treated as certainty.
- **Lift:** confidence divided by the library-wide rate. A tag that is on most of your library can never reach the minimum lift, however often it appears.

A candidate is suggested if one source clears all three thresholds. When several sources qualify independently, the suggestion ranks slightly higher. The rules that keep the list short:

- Only items with at least one tag count toward tag rates. Only items with at least one performer count toward performer rates. Untagged items are not evidence that a tag doesn't belong.
- The scene or image itself is never counted.
- Tags and performers already on the item are not suggested, and neither are the parents of tags already on it.
- If both a tag and its parent qualify, only the child is suggested.
- Performers are suggested only when the item already has a performer, group or gallery. The studio alone is never enough.
- Performers' own profile tags are not used.
- Each list is capped at a maximum length.

Large sources (over 1,000 scenes or images) are sampled at random, using a sample that stays the same for a given item. The explanation then says *(sampled)*.

## Tuning tools

Turn on **Show tuning tools** in the plugin settings to add a read-only **Tuning** section to the panel. It never writes to Stash.

- **Numbers on each suggestion:** smoothed confidence, lift, the library-wide base rate, and the ranking score.
- **Why not?:** search for any tag or performer to see whether this scene or image would get it, and why. Each source shows its support, confidence and lift, with ✓ or ✗ against the current thresholds. The verdict is one of:

  | Verdict | Meaning |
  |---|---|
  | Suggested | Shown, with its rank. |
  | Already on item | The scene or image already has it. |
  | Parent of an item tag | One of its child tags is already on the item. |
  | Excluded | It, or one of its parents, matches an entry in Excluded tags. |
  | No performer evidence | The item has no performer, group or gallery. A studio alone is not enough. |
  | Not related | No related item carries it. |
  | Below thresholds | No single source clears support, confidence and lift together. The closest source and the thresholds it misses are named. |
  | Child suggested instead | It qualifies, but so does one of its child tags, and only the child is shown. |
  | Over the limit | It qualifies, but ranks below the maximum number shown. |

- **Near misses:** up to five tags and five performers that were seen among related items but not shown, closest first. Select one to explain it.
- **Trial thresholds:** re-score this scene or image with other thresholds, without saving them. A **Trial thresholds** badge shows while they apply. **Reset to saved** returns to your settings. Suggestions shown under trial thresholds can still be added, one button press at a time.
- **Data:** the library totals and each source of related items, with its size and whether it was sampled.

With tuning on, the plugin also loads counts for every candidate it sees, not just those that reach the minimum support, so trial thresholds can lower support immediately. On a large library this makes the panel slower to load.

## Settings

| Setting | Default | Range |
|---|---|---|
| Excluded tags | none | Comma-separated tag names, matched case-insensitively. Excluding a tag also excludes its child tags. |
| Maximum tag suggestions | 5 | 1–50 |
| Maximum performer suggestions | 3 | 1–50 |
| Tag minimum support | 3 | 1–10000 |
| Tag minimum confidence (%) | 50 | 1–100 |
| Tag minimum lift | 2 | 1–1000 |
| Performer minimum support | 4 | 1–10000 |
| Performer minimum confidence (%) | 60 | 1–100 |
| Performer minimum lift | 2 | 1–1000 |
| Show tuning tools | off | Adds the read-only tuning tools described above. |

An unset or out-of-range number uses the default. Tag names that contain a comma can't be excluded.

## Used by other plugins

The plugin's functions are available to other UI plugins as `window.TagPerformerSuggestions`. The Stash Bridge controllers (`touchPortalBridge`) use `computeSuggestions` and `addToItem` for their suggestion keys, so the same suggestions, thresholds, and exclusions apply on Stream Deck and Touch Portal.

## What it writes

The plugin reads through a guard that refuses anything other than a GraphQL query. There are only three writes, each made only when you press a button:

- **Add tag / Add performer:** `bulkSceneUpdate` or `bulkImageUpdate` for that one item in `ADD` mode, touching only `tag_ids` or `performer_ids`. Stash's reply must confirm the addition, or an error is shown.
- **Exclude:** `configurePlugin` for this plugin only. The current settings are read back first and only `excludedTags` is extended.

## Development

Unit tests run without Docker. They cover the scoring rules and the read guard, and pin every write. They also run the fixture library through an in-memory fake of Stash. Integration and UI tests each start a disposable Stash (Docker required), seed the same fixture library, and compare full before/after snapshots of every scene, image, tag, performer, studio, group, gallery and plugin setting.

```sh
npm run test:tps:unit
npm run test:tps:integration
npm run test:tps:ui
npm run stash -- build --plugin tag-performer-suggestions
```

The UI check drives Chromium through the scene tab and the image section. It covers:

- Nothing is queried before the tab is opened.
- The exact suggestions appear, and nothing is written until a button is pressed.
- Each button writes exactly what it says.
- Empty and error states, and recovery from an error.
- Keyboard focus after an action.
- Layout and tap targets at 1280 px and 390 px widths.
- The tuning tools: the numbers on each suggestion, lookups, near misses, trial thresholds and their validation, and proof that no writes are sent.

To try the plugin by hand, install the built ZIP into the harness sandbox (see "Manual testing in the sandbox" in the repository's AGENTS.md). The sandbox library has only 6 scenes and 6 images, so at the default thresholds nothing is consistent enough to suggest, and each panel shows its empty state. To see suggestions there, lower the thresholds in the plugin settings, or add related items.

Set `TPS_UI_SCREENSHOTS=<dir>` to keep screenshots. Sanitized harness diagnostics are kept under `.stash-dev/harness/`. The validated baseline is Stash v0.31.1 with Chromium.
