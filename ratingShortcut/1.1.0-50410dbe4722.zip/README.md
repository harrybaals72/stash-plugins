# Rating Shortcut Plugin

Keyboard shortcuts for quickly adjusting scene and performer ratings in Stash.

## Default Shortcuts

| Shortcut | Action |
|----------|--------|
| `Shift + [` | Decrease rating by 5 |
| `Shift + ]` | Increase rating by 5 |
| `Alt + [` | Decrease rating by 1 |
| `Alt + ]` | Increase rating by 1 |

## Target Pages

Shortcuts are active only on:
- **Scene detail pages** (`/scenes/<id>`)
- **Performer detail pages** (`/performers/<id>`)

Shortcuts automatically clean up when you navigate away from these pages.

## Settings

All settings are optional. Configure them in Stash under **Settings → Plugins → Rating Shortcut**. Checkboxes are named so that unchecked is the default.

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `disableScenes` | BOOLEAN | off | Turn off shortcuts on scene pages |
| `disablePerformers` | BOOLEAN | off | Turn off shortcuts on performer pages |
| `coarseDecreaseShortcut` | STRING | `shift+[` | Key combo for coarse decrease |
| `coarseIncreaseShortcut` | STRING | `shift+]` | Key combo for coarse increase |
| `fineDecreaseShortcut` | STRING | `alt+[` | Key combo for fine decrease |
| `fineIncreaseShortcut` | STRING | `alt+]` | Key combo for fine increase |
| `coarseStep` | NUMBER | `5` | Change on the 0–100 scale for coarse shortcuts (20 = one star) |
| `fineStep` | NUMBER | `1` | Change on the 0–100 scale for fine shortcuts |
| `hideSuccessToasts` | BOOLEAN | off | Don't show a toast after a rating is saved (errors are always shown) |
| `allowInEditableFields` | BOOLEAN | off | Let shortcuts fire while typing in input fields |

Shortcut strings use [Mousetrap](https://craig.is/killing/mice) syntax. Spaces around `+` are removed and modifier names are lowercased, so `Shift + ]` becomes `shift+]`. Invalid values are logged to the browser console with a `[ratingShortcut]` prefix:

- A non-positive or non-integer step falls back to its default.
- A customized shortcut that collides with another action falls back to its default; if collisions remain, all four shortcuts use their defaults.

## Behavior

- **Rating range**: Ratings are clamped between 0 and 100 (Stash's `rating100` scale).
- **Rapid key presses**: Presses accumulate from the last requested rating, not stale page props. Only one update request is in flight at a time; presses made while it is pending are combined and the latest value is sent when it completes. Pressing `Shift+]` three times rapidly from 10 sends 15, then 25, and the scene ends at 25. A held key sends at most one request per round trip.
- **External changes**: A rating changed elsewhere (for example the star widget) is picked up when the page props change, as long as no shortcut update is pending.
- **Toasts**: One success toast is shown after the last pending update is saved, formatted in your Stash rating system (for example `2.5/5 stars` or `4.5/10`). When the display precision hides the change, the 0–100 value is appended, for example `2/5 stars (45/100)`.
- **Editable fields**: Unless `allowInEditableFields` is checked, shortcuts are ignored while the key event comes from an `<input>`, `<textarea>`, `<select>`, or contenteditable element.
- **Scoped bindings**: The plugin uses one Mousetrap instance of its own, separate from Stash's global instance. Each page binds its shortcuts on mount and unbinds them on unmount, leaving Stash's and other plugins' shortcuts intact. Handled shortcuts prevent the browser default action.
- **Image lightbox**: Shortcuts are ignored while Stash's image lightbox is open (for example an image opened from a performer's Images tab), matching Stash's own shortcuts, which pause there.
- **Navigation**: A press made just before navigating away is still saved.
- **Error handling**: Failed mutations dispatch a `ratingShortcut:error` event and show an error toast. Presses queued behind the failed request are dropped and the next press starts from the last saved rating.
- **Events**: Every accepted shortcut dispatches a `ratingShortcut:changed` custom event with `{ targetType, id, previousRating, rating, delta, shortcut }`.

## Limitations

- Shortcuts only work on scene and performer detail pages (not gallery, image, or tag pages).
- Requires Stash's UI Plugin API (`window.PluginApi`) with `patch.before`, `useSceneUpdate`/`usePerformerUpdate`, and `libraries.Mousetrap`.
- Custom shortcut strings must be valid Mousetrap key combinations.

## Testing

### Unit Tests

```bash
npm run stash -- test --plugin ratingShortcut --suite unit
```

Covers pure helpers (`clampRating`, `nextRating`, `normalizeShortcutString`, `normalizeSettings`, `createShortcutMap`, `isEditableTarget`, `formatRating`), the rating controller (one request in flight, coalesced presses, prop sync, boundary guards, cleanup, events, toasts), and the page wiring (`useRatingShortcut`) under a minimal hooks runtime that checks shortcuts are not rebound on re-render.

### Integration Tests

```bash
npm run stash -- test --plugin ratingShortcut --suite integration
```

Requires Docker. Spins up a managed Stash instance, installs the plugin, and verifies:
- Plugin loads and appears in `plugins` query
- All 10 plugin settings are registered
- Plugin JavaScript asset is served correctly
- Scene/performer rating mutations work (what the plugin calls internally)
- Rating boundary clamping (0–100)

### UI/Harness Tests

```bash
npm run stash -- test --plugin ratingShortcut --suite ui
```

Requires Docker. Spins up a managed Stash instance, installs the plugin, and runs Playwright tests verifying:
- Plugin JavaScript asset is served correctly
- Scene rating updates via keyboard shortcut persist through GraphQL
- Performer rating updates via keyboard shortcut persist through GraphQL
- A saved step setting changes the increment
- Rapid presses with no saved settings and a slow server persist the accumulated final rating in two requests
- Shortcuts are ignored while a lightbox element is present
- Shortcut bindings are cleaned up when navigating away from pages

### Run All Tests

```bash
npm run stash -- test --plugin ratingShortcut --suite all
```
