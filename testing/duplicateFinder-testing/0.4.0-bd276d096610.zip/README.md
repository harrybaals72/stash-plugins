# Duplicate Finder

A **read-only prototype**: a vidupe-like duplicate-video finder for Stash. It lists perceptual-hash (phash) duplicate candidates, lets you review them pair by pair, checks them against the generated sprites, and records your labels so thresholds can be tuned before any merge or replace feature exists.

It never changes Stash data. It sends GraphQL queries only (every query passes a read-only guard that rejects `mutation` and `subscription`), makes no `configurePlugin` calls, and stores its data only in your browser's IndexedDB.

## Opening it

Click the clone icon (**Duplicate finder**) in the top navigation bar, or go to `/duplicate-finder`. The plugin has no Stash settings; its controls are on the page and saved in the browser.

## Workflow

1. **Load.** The page reads the phash of every scene's primary file (5000 scenes per query, a few queries in flight). Scenes without a phash are skipped and counted. The index and the computed pairs are cached in IndexedDB; the page shows the index date and a **Reload** button.
2. **Candidates.** Web Workers find all pairs within the **distance ceiling** (default 12, up to 16). Changing the ceiling recomputes. The page shows the elapsed time, the pair count, and a histogram of pairs per distance.
3. **Pairs.** The main list shows candidates 20 per page. By default it hides pairs whose durations differ by more than the **Max duration difference** (default 20 s) and says so ("5,890 pairs within 20 s of 63,439"); a checkbox includes them. Filters: distance range, status (confirmed, not confirmed, not checked), has framing badge, has colour badge, duration match and label. Sort by distance, score, coverage (checked pairs first) or duration. The order is frozen while results arrive; **Refresh list** applies them to the filters and sort.
4. **Check.** The pairs on the shown page are checked automatically (two at a time): the page fetches each scene's sprite and VTT, hashes every tile, aligns the two videos in time and compares brightness, contrast, colour and framing. **Check all** does the whole current list in the background with progress, an estimate, **Pause**/**Resume** and **Stop**, and keeps running while you browse tabs and pages inside Duplicate Finder; leaving the page stops it. Pairs whose scene has no sprite or VTT (a missing path or a 404) are remembered as no sprite and can be cleared with **Recheck no-sprite pairs**; any other error (a failed image, a timeout, a server error) is a failure that is retried, and Check all pauses after 10 failures in a row. Results are cached, so after a reload Check all skips the pairs already checked.
5. **Verdict.** A pair is **Confirmed** when its coverage is at least **Min coverage** (default 0.4) over enough overlapping frames, otherwise **Not confirmed**; **Not checked** until a result exists. Changing Min coverage re-judges stored results without a re-check. Confirmed pairs also show **Framing** (cropped copy, different picture shape, black bars) and **Colour** (brightness, contrast, colour shift) badges with the details; they describe how the copies differ and do not decide the verdict.
6. **Sample and label.** The Sample tab draws a seeded, stratified sample (up to *per stratum* pairs for each distance and duration-match combination); **Check all in sample** checks it. Mark each pair **Duplicate**, **Not duplicate** or **Unsure** (keys `1`, `2`, `3` for the focused card; `j` and `k` move focus; clicking the active label again clears it) with an optional note.
7. **Export.** The Results tab shows dup / not / unsure counts by distance and by coverage bucket, and exports or imports the labels as JSON. The export includes the settings (with max duration difference and min coverage) and every current check result with its verdict.

On a labelled sample of 80 pairs, distance of at most 12, durations within 20 s and coverage of at least 0.4 found 30 of 34 duplicates with no false positives; the old 1 s duration rule missed duplicates with trimmed intros.

## Limiting to a Stash filter (0.4.0)

To look for duplicates only among some scenes, build the filter with Stash's own controls (the Scenes page, or the Scenes tab of a performer, studio, tag or group; saved filters work too) and press **Find duplicates in these scenes** above the list. Duplicate Finder opens with that filter as its **scope** (the filter's criteria, search text and the entity page's own scenes).

- The scope bar above the tabs shows the filter, how many scenes match now, **Edit in Stash** (back to the filtered list, to change the filter and press the button again), **Refresh** (look the scenes up again after the library changed; it also happens on every page load) and **Clear**.
- **Pairs:** everything on the Pairs tab follows the scope: the list, the counts line ("N pairs within 20 s of M in scope (K in all)"), the pair count and distance histogram above the tabs, the no-sprite count and **Recheck no-sprite pairs** (which clears only in-scope results), automatic checking and **Check all**. **Scope matches** chooses *either scene* (default: the duplicate of a tagged scene is often an untagged copy the filter would not find) or *both scenes*.
- **Within scenes:** only scenes in scope; the summary says "in scope".
- **Sample** and **Results** ignore the scope (Sample says so).
- The scope is kept in this browser's localStorage (session or memory storage if that is blocked) and survives reloads; the Scope matches choice is saved with the other settings. The scene count equals the count of the list you came from (its pagination), which can differ from the number on a performer, tag or studio tab because the list also applies your default filter for that page. Refresh keeps the previous scenes in use until the new lookup finishes; a filter that Stash rejects, or that no longer matches anything, shows a message in the scope bar. The button is not shown on a list with no filter and no search, or an empty list. A stored scope with unexpected contents is ignored. Only read-only queries are used.

## Within scenes (0.3.0)

The **Within scenes** tab lists scenes that already hold more than one file: Stash attaches a file to an existing scene during a scan when its checksum matches, and merges leave several files too. Nothing needs merging; the question is which files are redundant. It loads on first open (500 scenes per query, kept in memory, **Reload** to refresh; a failed reload keeps the scenes already loaded). It does not use the phash index or the pair search, and has its own controls: **Re-encode threshold (d)** (default 12, even values 0-32) and **Max duration difference (s)** (default 20). They are saved in the browser and only reclassify the files.

- **Summary:** "N scenes have more than one file · X identical copies · Y re-encodes · Z different videos [· U unknown] · W in extra files" (sizes in the same binary units as everywhere on the page; the unknown count appears only when it is not zero).
- **Filters and sort:** kind (has identical copy, re-encode, different video, unknown); sort by extra size (default), most notable first (different, unknown, re-encode, identical), or scene id; 20 per page.
- **Cards:** one per scene with its screenshot and a table with a column per file (Primary first). Each extra file is labelled Identical copy · md5 or · oshash, Re-encode · d N · Δ ±x s, Different video · d N · Δ ±x s, or Unknown — no phash. Green marks the best value per row (bigger, longer, higher; the oldest modified date is marked "oldest"), amber marks a value that is the same in every compared file. Files classified as different videos are not compared.
- **Identical copy:** an md5 match is a byte-for-byte copy. An oshash match means the same size and the same first and last 64 KB: almost certainly the same file, but an incomplete download can share it with the complete one, so check that the shorter or older file plays fully before deleting it.
- **Acting on it:** the page is read-only. To remove an extra file or change which file is primary, open the scene in Stash and use its File Info tab (Make primary, Delete file). The frame check is not available here because Stash generates thumbnails only for the primary file.

## Glossary

On the page, hover over any metric, badge, setting, filter or metadata row (a help cursor or dotted underline marks them) for a longer explanation of what it is and what it means.

- **Primary file:** the file Stash plays; the scene's sprite and thumbnails are generated from it only. Stash lists it first.
- **Identical copy:** an extra file with the same md5 (byte-for-byte) or the same oshash (same size, first and last 64 KB) as the primary.
- **Re-encode:** an extra file whose phash is within the re-encode threshold of the primary's and whose length is within the max duration difference.
- **Different video:** an extra file beyond either limit, probably another video attached by a merge or scan.
- **Unknown:** the primary or the file has no phash.
- **Extra size:** the total size of a scene's non-primary files.
- **Distance (d):** Hamming distance between two 64-bit phashes. Stash's phashes have exactly 32 bits set, so distances are always even.
- **Duration match:** the durations differ by no more than the tolerance (default 1 s, under Advanced). It only feeds the vidupe score and an optional filter; the Pairs list uses the max duration difference.
- **Vidupe score:** `64 - d`, plus 1 if the durations match or minus 4 if not, capped at 64.
- **Coverage:** of the section where the two videos overlap, the share of distinct (non-flat) tiles of A that have a matching tile in B at the best time offset.
- **Offset:** the time shift in seconds (B time = A time + offset) at which most tiles agree. It handles trimmed intros and outros.
- **Focus:** the share of all tile matches that fall in the winning offset window. Low focus means the matches are scattered across offsets.
- **SSIM:** mean structural similarity of the matched tiles (1 is identical).
- **Overlap:** the overlapping time as a share of the shorter video. The header also shows matched/overlapping tile counts and the flat (black or solid) tile counts for A/B.
- **Framing badge:** the best match needed centre-cropping one side, the picture shapes differ by more than 3 %, or one side has black bars covering 4 % more of its frame.
- **Colour badge:** B's matched frames differ from A's by more than 10 brightness levels, 1.18x contrast, or a chromaticity shift of 20.
- **Tile threshold:** the tile phash distance under which two sprite tiles count as the same frame. The default comes from the core; changing it (on Enter or leaving the field, after a confirmation) clears the saved check results.

## Where data is stored

Only in this browser's IndexedDB (database `duplicate-finder-prototype`): the settings, the index, the cached pairs, the check results (version 2; results saved by 0.1.0 are checked again) and your labels. Nothing is written to Stash. If IndexedDB is unavailable the page falls back to memory and loses everything on reload, so export labels before closing. Clearing the site data for Stash removes it all.

## Testing

```text
npm run stash -- test --plugin duplicateFinder --suite unit
```

- **Unit** tests cover hashing and pair search (including stride partitions against brute force), scoring, VTT parsing, image features on synthetic sprites (flat tiles, letterbox detection, trims, unrelated video, aspect-ratio crops, brightness and colour shifts, verdicts), strips and sampling, label statistics, the read-only guard, and the page's registration, pair model, duration filter, verdict badges, result versions, export, and the pausable Check all runner.

There are no integration or UI suites yet. The page was smoke-tested headlessly against a populated Stash.
