# Duplicate Finder

A **read-only prototype**: a vidupe-like duplicate-video finder for Stash. It lists perceptual-hash (phash) duplicate candidates, lets you review them pair by pair, checks them against the generated sprites, and records your labels so thresholds can be tuned before any merge or replace feature exists.

It never changes Stash data. It sends GraphQL queries only (every query passes a read-only guard that rejects `mutation` and `subscription`), makes no `configurePlugin` calls, and stores its data only in your browser's IndexedDB.

## Opening it

Click the clone icon (**Duplicate finder**) in the top navigation bar, or go to `/duplicate-finder`. The plugin has no Stash settings; its controls are on the page and saved in the browser.

## Workflow

1. **Load.** The page reads the phash of every scene's primary file (5000 scenes per query, a few queries in flight). Scenes without a phash are skipped and counted. The index and the computed pairs are cached in IndexedDB; the page shows the index date and a **Reload** button.
2. **Candidates.** Web Workers find all pairs within the **distance ceiling** (default 12, up to 16). Changing the ceiling recomputes. The page shows the elapsed time, the pair count, and a histogram of pairs per distance.
3. **Pairs.** The main list shows candidates 20 per page. By default it hides pairs whose durations differ by more than the **Max duration difference** (default 20 s) and says so ("5,890 pairs within 20 s of 63,439"); a checkbox includes them. Filters: distance range, status (confirmed, not confirmed, not checked), has framing badge, has colour badge, duration match and label. Sort by distance, score, coverage (checked pairs first) or duration. The order is frozen while results arrive; **Refresh list** applies them to the filters and sort.
4. **Check.** The pairs on the shown page are checked automatically (two at a time): the page fetches each scene's sprite and VTT, hashes every tile, aligns the two videos in time and compares brightness, contrast, colour and framing. **Check all** does the whole current list in the background with progress, an estimate, **Pause**/**Resume** and **Stop**, and keeps running while you browse tabs and pages inside Duplicate Finder; leaving the page stops it. Pairs whose scene has no sprite or VTT (a missing path or a 404) are remembered as no sprite and can be cleared with **Recheck no-sprite pairs**; any other error (a failed image, a timeout, a server error) is a failure that is retried, and Check all pauses after 10 failures in a row. Results are cached, so after a reload Check all skips the pairs already checked.
5. **Verdict.** A pair is **Confirmed** when its coverage is at least **Min coverage** (default 0.4) over enough overlapping frames, otherwise **Not confirmed**; **Not checked** until a result exists. Changing Min coverage re-judges stored results without a re-check. Confirmed pairs also show **Framing** (cropped copy, different picture shape, black bars) and **Colour** (brightness, contrast, colour shift) badges with the details; they describe how the copies differ and do not decide the verdict.
6. **Sample and label.** The Sample tab draws a seeded, stratified sample (up to *per stratum* pairs for each distance and duration-match combination); **Check all in sample** checks it. Mark each pair **Duplicate**, **Not duplicate** or **Unsure** (keys `1`, `2`, `3` for the focused card; `j` and `k` move focus; clicking the active label again clears it) with an optional note.
7. **Export.** The Results tab shows dup / not / unsure counts by distance and by coverage bucket, and exports or imports the labels as JSON. The export includes the settings (with max duration difference and min coverage) and every current check result with its verdict.

On a labelled sample of 80 pairs, distance of at most 12, durations within 20 s and coverage of at least 0.4 found 30 of 34 duplicates with no false positives; the old 1 s duration rule missed duplicates with trimmed intros.

## Glossary

On the page, hover over any metric, badge, setting, filter or metadata row (a help cursor or dotted underline marks them) for a longer explanation of what it is and what it means.

- **Distance (d):** Hamming distance between two 64-bit phashes. Stash's phashes have exactly 32 bits set, so distances are always even.
- **Duration match:** the durations differ by no more than the tolerance (default 1 s, under Advanced). It only feeds the vidupe score and an optional filter; the Pairs list uses the max duration difference.
- **Vidupe score:** `64 - d`, plus 1 if the durations match or minus 4 if not, capped at 64.
- **Coverage:** of the section where the two videos overlap, the share of distinct (non-flat) tiles of A that have a matching tile in B at the best time offset.
- **Offset:** the time shift in seconds (B time = A time + offset) at which most tiles agree. It handles trimmed intros and outros.
- **Focus:** the share of all tile matches that fall in the winning offset window. Low focus means the matches are scattered across offsets.
- **SSIM:** mean structural similarity of the matched tiles (1 is identical).
- **Overlap:** the overlapping time as a share of the shorter video. The header also shows matched/overlapping tile counts and the flat (black or solid) tile counts for A/B.
- **Framing badge:** the best match needed centre-cropping one side, the picture shapes differ by more than 3 %, or one side has black bars covering 4 % more of its frame.
- **Colour badge:** B's matched frames differ from A's by more than 10 brightness levels, 1.18x contrast, or a chromaticity shift of 20.
- **Tile threshold:** the tile phash distance under which two sprite tiles count as the same frame. The default comes from the core; changing it (on Enter or leaving the field, after a confirmation) clears the saved check results.

## Where data is stored

Only in this browser's IndexedDB (database `duplicate-finder-prototype`): the settings, the index, the cached pairs, the check results (version 2; results saved by 0.1.0 are checked again) and your labels. Nothing is written to Stash. If IndexedDB is unavailable the page falls back to memory and loses everything on reload, so export labels before closing. Clearing the site data for Stash removes it all.

## Testing

```text
npm run stash -- test --plugin duplicateFinder --suite unit
```

- **Unit** tests cover hashing and pair search (including stride partitions against brute force), scoring, VTT parsing, image features on synthetic sprites (flat tiles, letterbox detection, trims, unrelated video, aspect-ratio crops, brightness and colour shifts, verdicts), strips and sampling, label statistics, the read-only guard, and the page's registration, pair model, duration filter, verdict badges, result versions, export, and the pausable Check all runner.

There are no integration or UI suites yet. The page was smoke-tested headlessly against a populated Stash.
