// Duplicate Finder core: pure matching functions shared by the UI and the unit tests.
// No DOM access except the optional Worker glue in findPairsParallel.
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.DuplicateFinderCore = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";

  var TILE_SIZE = 32; // tiles are resampled to 32x32 grayscale before hashing
  var SSIM_BLOCK = 8;

  var DEFAULTS = {
    maxDistance: 12, // ceiling for the candidate search (Stash phash bits)
    durationTolerance: 1, // seconds; vidupe treats durations within 1 s as "same"
    sameBonus: 1, // vidupe _sameDurationModifier
    differentPenalty: 4, // vidupe _differentDurationModifier
    // Tile phash bits (63 usable) for two tiles to count as the same frame. On the mirror,
    // 14 kept 100 random pairs below 0.2 coverage; 16 let 2 of them through.
    tileMaxDistance: 14,
    flatStd: 5, // tiles whose grayscale std dev is below this are treated as black/solid
    minOverlapTiles: 4,
    // Candidate filter: durations further apart than this are not compared. In the labelled
    // sample every duplicate was within 16.1 s and nearly every non-duplicate within 1 s or
    // more than 22 s apart, so 20 s keeps duplicates with trimmed intros or outros.
    maxDurationDiff: 20,
    // A pair is "confirmed" when at least this share of the overlapping frames match. In the
    // labelled sample 0.4 found 30 of 34 duplicates and no non-duplicates.
    minCoverage: 0.4,
    // Badge thresholds (see pairVerdict). In the labelled sample, duplicates you noted as
    // differently coloured shifted mean brightness by 21 and 45 levels and scored 50 and 64 on
    // colour; every other duplicate stayed within 4.3 levels, 10.8 colour and 0.91-1.07 contrast.
    brightnessBadge: 10, // mean luma difference, 0-255
    colourBadge: 20, // chromaticity distance x 1000
    contrastBadge: 1.18, // std dev ratio above this, or below its inverse
    aspectBadge: 0.03, // content aspect ratios differing by more than 3 %
    barsBadge: 0.04, // black bars covering 4 % more of one side's frame than the other's
  };

  // ---------------------------------------------------------------- bit helpers

  function popcount32(x) {
    x = x - ((x >>> 1) & 0x55555555);
    x = (x & 0x33333333) + ((x >>> 2) & 0x33333333);
    return Math.imul((x + (x >>> 4)) & 0x0f0f0f0f, 0x01010101) >>> 24;
  }

  function hamming(hiA, loA, hiB, loB) {
    return popcount32(hiA ^ hiB) + popcount32(loA ^ loB);
  }

  // Stash returns phash fingerprints as unpadded lowercase hex of a uint64.
  function parsePhash(hex) {
    if (typeof hex !== "string" || !/^[0-9a-fA-F]{1,16}$/.test(hex)) return null;
    var padded = ("0000000000000000" + hex).slice(-16);
    return [parseInt(padded.slice(0, 8), 16) | 0, parseInt(padded.slice(8), 16) | 0];
  }

  function pairKey(idA, idB) {
    var a = Number(idA);
    var b = Number(idB);
    return a < b ? a + "-" + b : b + "-" + a;
  }

  // ---------------------------------------------------------------- candidate search

  // Self-contained (it is stringified into a Worker): returns [i, j, d, ...] triples with
  // i < j and Hamming distance d <= maxDistance, for rows i = start, start+stride, ...
  function findPairsRange(hi, lo, maxDistance, start, stride) {
    var n = hi.length;
    var out = [];
    for (var i = start; i < n; i += stride) {
      var h = hi[i];
      var l = lo[i];
      for (var j = i + 1; j < n; j++) {
        var x = h ^ hi[j];
        x = x - ((x >>> 1) & 0x55555555);
        x = (x & 0x33333333) + ((x >>> 2) & 0x33333333);
        var d = Math.imul((x + (x >>> 4)) & 0x0f0f0f0f, 0x01010101) >>> 24;
        if (d > maxDistance) continue;
        var y = l ^ lo[j];
        y = y - ((y >>> 1) & 0x55555555);
        y = (y & 0x33333333) + ((y >>> 2) & 0x33333333);
        d += Math.imul((y + (y >>> 4)) & 0x0f0f0f0f, 0x01010101) >>> 24;
        if (d <= maxDistance) out.push(i, j, d);
      }
    }
    return Int32Array.from(out);
  }

  function workerSource() {
    return (
      "var findPairsRange = " +
      findPairsRange.toString() +
      ";\nself.onmessage = function (e) { var d = e.data;" +
      " var r = findPairsRange(d.hi, d.lo, d.maxDistance, d.start, d.stride);" +
      " self.postMessage(r, [r.buffer]); };"
    );
  }

  // Resolves to an Int32Array of [i, j, d] triples. Falls back to a single synchronous pass
  // when Workers are unavailable (Node tests) or workers <= 1.
  function findPairsParallel(hi, lo, maxDistance, opts) {
    opts = opts || {};
    var hasWorkers = typeof Worker !== "undefined" && typeof Blob !== "undefined" && typeof URL !== "undefined";
    var cores = typeof navigator !== "undefined" && navigator.hardwareConcurrency ? navigator.hardwareConcurrency : 2;
    var count = opts.workers || Math.max(1, Math.min(8, cores - 1));
    if (!hasWorkers || count <= 1) return Promise.resolve(findPairsRange(hi, lo, maxDistance, 0, 1));

    var url = URL.createObjectURL(new Blob([workerSource()], { type: "text/javascript" }));
    var workers = [];
    var jobs = [];
    for (var k = 0; k < count; k++) {
      jobs.push(
        new Promise(function (resolve, reject) {
          var w = new Worker(url);
          workers.push(w);
          w.onmessage = function (e) {
            resolve(e.data);
          };
          w.onerror = function (e) {
            reject(new Error("pair search worker failed: " + (e && e.message ? e.message : "unknown error")));
          };
          w.postMessage({ hi: hi, lo: lo, maxDistance: maxDistance, start: k, stride: count });
        }),
      );
    }
    function cleanup() {
      workers.forEach(function (w) {
        w.terminate();
      });
      URL.revokeObjectURL(url);
    }
    return Promise.all(jobs).then(
      function (parts) {
        cleanup();
        var total = parts.reduce(function (s, p) {
          return s + p.length;
        }, 0);
        var all = new Int32Array(total);
        var offset = 0;
        parts.forEach(function (p) {
          all.set(p, offset);
          offset += p.length;
        });
        return all;
      },
      function (err) {
        cleanup();
        throw err;
      },
    );
  }

  // vidupe-style similarity: 64 - distance, nudged by whether durations agree. Capped at 64.
  function scorePair(distance, durA, durB, opts) {
    opts = Object.assign({}, DEFAULTS, opts);
    var same = Math.abs(durA - durB) <= opts.durationTolerance;
    var score = 64 - distance + (same ? opts.sameBonus : -opts.differentPenalty);
    return Math.min(64, score);
  }

  // ---------------------------------------------------------------- sprite VTT

  function parseTimestamp(text) {
    var parts = text.trim().split(":");
    var seconds = 0;
    for (var i = 0; i < parts.length; i++) seconds = seconds * 60 + parseFloat(parts[i]);
    return seconds;
  }

  // Returns [{start, end, url, x, y, w, h}] in file order. Each Stash sprite tile shows the
  // frame at its cue's start time.
  function parseVtt(text) {
    var cues = [];
    var lines = String(text).replace(/\r/g, "").split("\n");
    for (var i = 0; i < lines.length; i++) {
      var m = /^\s*([\d:.]+)\s*-->\s*([\d:.]+)/.exec(lines[i]);
      if (!m) continue;
      var ref = (lines[i + 1] || "").trim();
      var xywh = /#xywh=(\d+),(\d+),(\d+),(\d+)/.exec(ref);
      if (!xywh) continue;
      cues.push({
        start: parseTimestamp(m[1]),
        end: parseTimestamp(m[2]),
        url: ref.split("#")[0],
        x: +xywh[1],
        y: +xywh[2],
        w: +xywh[3],
        h: +xywh[4],
      });
    }
    return cues;
  }

  // ---------------------------------------------------------------- image features

  // One byte per pixel keeps whole sprites cheap to cache (a 9x9 sprite of 160x284 tiles is 3.7 MB).
  function toGray(rgba, width, height) {
    var out = new Uint8ClampedArray(width * height);
    for (var p = 0, q = 0; p < out.length; p++, q += 4) {
      out[p] = 0.299 * rgba[q] + 0.587 * rgba[q + 1] + 0.114 * rgba[q + 2];
    }
    return out;
  }

  // Builds the sprite object the comparison functions take from decoded RGBA pixels. Keeps
  // grayscale pixels plus each cue's mean colour inside the content box (bars excluded), so the
  // RGBA buffer itself can be dropped.
  function spriteFromRgba(rgba, width, height, cues) {
    var gray = toGray(rgba, width, height);
    var valid = (cues || []).filter(function (c) {
      return c.w > 0 && c.h > 0 && c.x + c.w <= width && c.y + c.h <= height;
    });
    var rgb = new Float32Array((cues || []).length * 3).fill(NaN);
    if (valid.length) {
      var box = detectContentBox(gray, width, valid);
      cues.forEach(function (c, k) {
        if (!(c.w > 0 && c.h > 0 && c.x + c.w <= width && c.y + c.h <= height)) return;
        var r = 0, g = 0, b = 0, n = 0;
        var x0 = c.x + box.x, y0 = c.y + box.y;
        var bw = Math.min(box.w, c.w), bh = Math.min(box.h, c.h);
        for (var y = 0; y < bh; y += 2) {
          for (var x = 0; x < bw; x += 2) {
            var q = ((y0 + y) * width + x0 + x) * 4;
            r += rgba[q];
            g += rgba[q + 1];
            b += rgba[q + 2];
            n++;
          }
        }
        if (n) {
          rgb[k * 3] = r / n;
          rgb[k * 3 + 1] = g / n;
          rgb[k * 3 + 2] = b / n;
        }
      });
    }
    return { gray: gray, width: width, height: height, cues: cues, rgb: rgb };
  }

  // Box-filter resample of the region (x0, y0, w, h) of a srcW-wide grayscale image to n x n.
  function resizeArea(src, srcW, x0, y0, w, h, n) {
    var out = new Float32Array(n * n);
    for (var oy = 0; oy < n; oy++) {
      var ya = Math.floor((oy * h) / n);
      var yb = Math.max(Math.floor(((oy + 1) * h) / n), ya + 1);
      for (var ox = 0; ox < n; ox++) {
        var xa = Math.floor((ox * w) / n);
        var xb = Math.max(Math.floor(((ox + 1) * w) / n), xa + 1);
        var sum = 0;
        var count = 0;
        for (var y = ya; y < yb; y++) {
          var row = (y0 + y) * srcW + x0;
          for (var x = xa; x < xb; x++) {
            sum += src[row + x];
            count++;
          }
        }
        out[oy * n + ox] = sum / count;
      }
    }
    return out;
  }

  function stdDev(values) {
    var mean = 0;
    for (var i = 0; i < values.length; i++) mean += values[i];
    mean /= values.length;
    var v = 0;
    for (var k = 0; k < values.length; k++) v += (values[k] - mean) * (values[k] - mean);
    return Math.sqrt(v / values.length);
  }

  // Finds the [start, end) span of a row/column-mean profile that is not a dark border.
  function trimBars(means) {
    var n = means.length;
    var a = Math.floor(n / 3);
    var b = Math.max(Math.ceil((2 * n) / 3), a + 1);
    var center = 0;
    for (var i = a; i < b; i++) center += means[i];
    center /= b - a;
    var limit = Math.min(20, center * 0.5);
    var lo = 0;
    var hi = n;
    while (lo < n && means[lo] < limit) lo++;
    while (hi > lo && means[hi - 1] < limit) hi--;
    if (hi - lo < n * 0.5) return [0, n];
    return [lo, hi];
  }

  // Letterbox/pillarbox detection over all tiles of one sprite. Returns a tile-relative box.
  function detectContentBox(src, srcW, cues) {
    var w = cues[0].w;
    var h = cues[0].h;
    var rowSum = new Float64Array(h);
    var colSum = new Float64Array(w);
    cues.forEach(function (c) {
      for (var y = 0; y < h; y++) {
        var row = (c.y + y) * srcW + c.x;
        for (var x = 0; x < w; x++) {
          var v = src[row + x];
          rowSum[y] += v;
          colSum[x] += v;
        }
      }
    });
    var rows = Array.prototype.map.call(rowSum, function (s) {
      return s / (cues.length * w);
    });
    var cols = Array.prototype.map.call(colSum, function (s) {
      return s / (cues.length * h);
    });
    var ry = trimBars(rows);
    var rx = trimBars(cols);
    return { x: rx[0], y: ry[0], w: rx[1] - rx[0], h: ry[1] - ry[0] };
  }

  var COS = (function () {
    var t = new Float64Array(8 * TILE_SIZE);
    for (var u = 0; u < 8; u++) {
      for (var x = 0; x < TILE_SIZE; x++) t[u * TILE_SIZE + x] = Math.cos(((2 * x + 1) * u * Math.PI) / (2 * TILE_SIZE));
    }
    return t;
  })();

  // 63-bit DCT perceptual hash of a 32x32 grayscale tile (bit 0, the DC term, is always 0).
  function phash32(gray) {
    var n = TILE_SIZE;
    var rows = new Float64Array(n * 8);
    for (var y = 0; y < n; y++) {
      for (var u = 0; u < 8; u++) {
        var s = 0;
        for (var x = 0; x < n; x++) s += gray[y * n + x] * COS[u * n + x];
        rows[y * 8 + u] = s;
      }
    }
    var coef = new Float64Array(64);
    for (var v = 0; v < 8; v++) {
      for (var uu = 0; uu < 8; uu++) {
        var t = 0;
        for (var yy = 0; yy < n; yy++) t += COS[v * n + yy] * rows[yy * 8 + uu];
        coef[v * 8 + uu] = t;
      }
    }
    var ac = Array.prototype.slice.call(coef, 1).sort(function (a, b) {
      return a - b;
    });
    var median = ac[31];
    var hi = 0;
    var lo = 0;
    for (var k = 1; k < 64; k++) {
      if (coef[k] > median) {
        if (k < 32) lo |= 1 << k;
        else hi |= 1 << (k - 32);
      }
    }
    return [hi | 0, lo | 0];
  }

  // Mean SSIM over non-overlapping block x block windows of two n x n grayscale images.
  function ssim(a, b, n, block) {
    n = n || TILE_SIZE;
    block = block || SSIM_BLOCK;
    var C1 = 6.5025; // (0.01 * 255)^2
    var C2 = 58.5225; // (0.03 * 255)^2
    var total = 0;
    var blocks = 0;
    var cnt = block * block;
    for (var by = 0; by + block <= n; by += block) {
      for (var bx = 0; bx + block <= n; bx += block) {
        var ma = 0;
        var mb = 0;
        for (var y = by; y < by + block; y++) {
          for (var x = bx; x < bx + block; x++) {
            ma += a[y * n + x];
            mb += b[y * n + x];
          }
        }
        ma /= cnt;
        mb /= cnt;
        var va = 0;
        var vb = 0;
        var cov = 0;
        for (var y2 = by; y2 < by + block; y2++) {
          for (var x2 = bx; x2 < bx + block; x2++) {
            var da = a[y2 * n + x2] - ma;
            var db = b[y2 * n + x2] - mb;
            va += da * da;
            vb += db * db;
            cov += da * db;
          }
        }
        va /= cnt;
        vb /= cnt;
        cov /= cnt;
        total += ((2 * ma * mb + C1) * (2 * cov + C2)) / ((ma * ma + mb * mb + C1) * (va + vb + C2));
        blocks++;
      }
    }
    return blocks ? total / blocks : 0;
  }

  function medianStep(times, fallback) {
    var diffs = [];
    for (var i = 1; i < times.length; i++) diffs.push(times[i] - times[i - 1]);
    if (!diffs.length) return fallback;
    diffs.sort(function (a, b) {
      return a - b;
    });
    return diffs[Math.floor(diffs.length / 2)] || fallback;
  }

  // Centre-crops a tile-relative box to the given width/height aspect ratio.
  function cropToAspect(box, aspect) {
    var current = box.w / box.h;
    if (!(aspect > 0) || Math.abs(current - aspect) < 1e-6) return box;
    if (current > aspect) {
      var w = Math.max(1, Math.round(box.h * aspect));
      return { x: box.x + Math.floor((box.w - w) / 2), y: box.y, w: w, h: box.h };
    }
    var h = Math.max(1, Math.round(box.w / aspect));
    return { x: box.x, y: box.y + Math.floor((box.h - h) / 2), w: box.w, h: h };
  }

  // Per-tile features of one scene's sprite. src is the whole sprite as grayscale (srcW x srcH).
  // opts.cropAspect centre-crops every tile's content box to that aspect ratio first.
  function tileFeatures(src, srcW, srcH, cues, opts) {
    opts = Object.assign({}, DEFAULTS, opts);
    var validIndex = [];
    var valid = (cues || []).filter(function (c, k) {
      var ok = c.w > 0 && c.h > 0 && c.x + c.w <= srcW && c.y + c.h <= srcH;
      if (ok) validIndex.push(k);
      return ok;
    });
    if (!valid.length) return null;
    var content = detectContentBox(src, srcW, valid);
    var box = opts.cropAspect ? cropToAspect(content, opts.cropAspect) : content;
    var count = valid.length;
    var times = new Float64Array(count);
    var hi = new Int32Array(count);
    var lo = new Int32Array(count);
    var flat = new Uint8Array(count);
    var grays = [];
    var lumaMean = new Float32Array(count);
    var lumaStd = new Float32Array(count);
    var rgb = opts.rgb ? new Float32Array(count * 3) : null;
    var flatCount = 0;
    for (var k = 0; k < count; k++) {
      var c = valid[k];
      var g = resizeArea(src, srcW, c.x + box.x, c.y + box.y, box.w, box.h, TILE_SIZE);
      times[k] = c.start;
      var m = 0;
      for (var p = 0; p < g.length; p++) m += g[p];
      lumaMean[k] = m / g.length;
      lumaStd[k] = stdDev(g);
      if (rgb) for (var ch = 0; ch < 3; ch++) rgb[k * 3 + ch] = opts.rgb[validIndex[k] * 3 + ch];
      if (lumaStd[k] < opts.flatStd) {
        flat[k] = 1;
        flatCount++;
      }
      var h = phash32(g);
      hi[k] = h[0];
      lo[k] = h[1];
      grays.push(g);
    }
    return {
      count: count,
      times: times,
      hi: hi,
      lo: lo,
      flat: flat,
      flatCount: flatCount,
      grays: grays,
      lumaMean: lumaMean,
      lumaStd: lumaStd,
      rgb: rgb,
      box: box,
      contentAspect: content.w / content.h,
      frameAspect: valid[0].w / valid[0].h,
      bars: 1 - (content.w * content.h) / (valid[0].w * valid[0].h),
      step: medianStep(times, 1),
    };
  }

  // ---------------------------------------------------------------- alignment / confirmation

  // Finds the time offset (B time = A time + offset) at which the most distinct tiles of both
  // sprites agree, then measures how much of the overlapping section matches at that offset.
  // Handles trimmed intros/outros because the offset is searched, not assumed to be zero.
  function alignTiles(fa, fb, durA, durB, opts) {
    opts = Object.assign({}, DEFAULTS, opts);
    var T = opts.tileMaxDistance;
    var W = opts.windowSeconds || Math.max(fa.step, fb.step, 0.5);
    var base = {
      tilesA: fa.count,
      tilesB: fb.count,
      flatA: fa.flatCount,
      flatB: fb.flatCount,
      windowSeconds: W,
    };

    var votes = [];
    for (var i = 0; i < fa.count; i++) {
      if (fa.flat[i]) continue;
      for (var j = 0; j < fb.count; j++) {
        if (fb.flat[j]) continue;
        var d = hamming(fa.hi[i], fa.lo[i], fb.hi[j], fb.lo[j]);
        if (d <= T) votes.push({ delta: fb.times[j] - fa.times[i], i: i, j: j });
      }
    }
    if (!votes.length) {
      return Object.assign(base, {
        offset: null,
        coverage: 0,
        focus: 0,
        votes: 0,
        matched: 0,
        overlapTiles: 0,
        overlapSeconds: 0,
        overlapOfShorter: 0,
        overlapOfLonger: 0,
        meanSsim: null,
        insufficient: true,
        matches: [],
        brightness: null,
        contrast: null,
        colour: null,
      });
    }
    votes.sort(function (a, b) {
      return a.delta - b.delta;
    });

    // Sliding window over offsets: maximise min(distinct A tiles, distinct B tiles) so one
    // static B frame matching many A frames does not win on its own.
    var cntA = new Int32Array(fa.count);
    var cntB = new Int32Array(fb.count);
    var distinctA = 0;
    var distinctB = 0;
    var best = -1;
    var bestL = 0;
    var bestR = 0;
    var l = 0;
    for (var r = 0; r < votes.length; r++) {
      var v = votes[r];
      if (cntA[v.i]++ === 0) distinctA++;
      if (cntB[v.j]++ === 0) distinctB++;
      while (v.delta - votes[l].delta > W) {
        var u = votes[l++];
        if (--cntA[u.i] === 0) distinctA--;
        if (--cntB[u.j] === 0) distinctB--;
      }
      var s = Math.min(distinctA, distinctB);
      if (s > best || (s === best && r + 1 - l > bestR - bestL)) {
        best = s;
        bestL = l;
        bestR = r + 1;
      }
    }
    var offset = votes[bestL + Math.floor((bestR - bestL) / 2)].delta;

    // Confirm at that offset: every informative A tile that lands inside B must find a
    // near-identical B tile within one window.
    var matched = 0;
    var overlapTiles = 0;
    var ssimSum = 0;
    var matches = [];
    for (var a = 0; a < fa.count; a++) {
      if (fa.flat[a]) continue;
      var t = fa.times[a] + offset;
      if (t < 0 || t > durB) continue;
      overlapTiles++;
      var bestD = 65;
      var bestJ = -1;
      for (var b = 0; b < fb.count; b++) {
        if (fb.flat[b] || Math.abs(fb.times[b] - t) > W) continue;
        var dd = hamming(fa.hi[a], fa.lo[a], fb.hi[b], fb.lo[b]);
        if (dd < bestD) {
          bestD = dd;
          bestJ = b;
        }
      }
      if (bestJ >= 0 && bestD <= T) {
        matched++;
        ssimSum += ssim(fa.grays[a], fb.grays[bestJ], TILE_SIZE, SSIM_BLOCK);
        matches.push([a, bestJ, bestD]);
      }
    }
    var overlapSeconds = Math.max(0, Math.min(durA, durB - offset) - Math.max(0, -offset));
    var photo = photometrics(fa, fb, matches);
    var shorter = Math.min(durA, durB);
    var longer = Math.max(durA, durB);
    return Object.assign(base, {
      offset: offset,
      coverage: overlapTiles ? matched / overlapTiles : 0,
      focus: (bestR - bestL) / votes.length,
      votes: votes.length,
      matched: matched,
      overlapTiles: overlapTiles,
      overlapSeconds: overlapSeconds,
      overlapOfShorter: shorter > 0 ? overlapSeconds / shorter : 0,
      overlapOfLonger: longer > 0 ? overlapSeconds / longer : 0,
      meanSsim: matched ? ssimSum / matched : null,
      insufficient: overlapTiles < opts.minOverlapTiles,
      matches: matches,
      brightness: photo.brightness,
      contrast: photo.contrast,
      colour: photo.colour,
    });
  }

  // Brightness and contrast use the compared (possibly cropped) tiles; the colour means come
  // from spriteFromRgba and always cover the full content box, which is close enough for a
  // badge because a crop rarely changes a frame's average colour much.
  // How B's matched frames differ from A's in brightness (mean luma, B minus A, 0-255),
  // contrast (geometric mean of B/A luma std dev) and colour (mean distance between the
  // frames' chromaticity, r/(r+g+b) etc., times 1000; null without colour data).
  function photometrics(fa, fb, matches) {
    var n = 0, bright = 0, logC = 0, nc = 0, col = 0, ncol = 0;
    matches.forEach(function (m) {
      var a = m[0], b = m[1];
      n++;
      bright += fb.lumaMean[b] - fa.lumaMean[a];
      if (fa.lumaStd[a] >= 2 && fb.lumaStd[b] >= 2) {
        logC += Math.log(fb.lumaStd[b] / fa.lumaStd[a]);
        nc++;
      }
      if (fa.rgb && fb.rgb) {
        var sa = fa.rgb[a * 3] + fa.rgb[a * 3 + 1] + fa.rgb[a * 3 + 2];
        var sb = fb.rgb[b * 3] + fb.rgb[b * 3 + 1] + fb.rgb[b * 3 + 2];
        if (sa > 30 && sb > 30) {
          var d = 0;
          for (var ch = 0; ch < 3; ch++) {
            var x = fa.rgb[a * 3 + ch] / sa - fb.rgb[b * 3 + ch] / sb;
            d += x * x;
          }
          col += Math.sqrt(d) * 1000;
          ncol++;
        }
      }
    });
    return {
      brightness: n ? bright / n : null,
      contrast: nc ? Math.exp(logC / nc) : null,
      colour: ncol ? col / ncol : null,
    };
  }

  // sprite: {gray, width, height, cues}. Features are memoised on the sprite object so the
  // caller's sprite cache bounds memory.
  function spriteFeatures(sprite, cropAspect, opts) {
    if (!sprite || !sprite.cues || !sprite.cues.length) return null;
    var memo = sprite.__dfFeatures || (sprite.__dfFeatures = {});
    var key = (cropAspect ? cropAspect.toFixed(4) : "plain") + "|" + (opts && opts.flatStd);
    if (!(key in memo)) {
      memo[key] = tileFeatures(
        sprite.gray,
        sprite.width,
        sprite.height,
        sprite.cues,
        Object.assign({}, opts, { cropAspect: cropAspect || 0, rgb: sprite.rgb || null }),
      );
    }
    return memo[key];
  }

  // Confirms a candidate pair from both sprites. Besides the plain comparison it tries centre
  // crops when the content aspect ratios differ (portrait vs landscape re-uploads, blurred
  // side padding, 4:3 vs 16:9 crops) and returns the variant with the best coverage:
  // "plain", "cropA"/"cropB" (that side cropped to the other's aspect ratio).
  function confirmPair(spriteA, spriteB, durA, durB, opts) {
    opts = Object.assign({}, DEFAULTS, opts);
    var fa = spriteFeatures(spriteA, 0, opts);
    var fb = spriteFeatures(spriteB, 0, opts);
    if (!fa || !fb) return null;
    var framing = {
      aspectA: fa.contentAspect,
      aspectB: fb.contentAspect,
      frameAspectA: fa.frameAspect,
      frameAspectB: fb.frameAspect,
      barsA: fa.bars,
      barsB: fb.bars,
    };
    var best = Object.assign(alignTiles(fa, fb, durA, durB, opts), { variant: "plain" }, framing);
    var arA = fa.contentAspect;
    var arB = fb.contentAspect;
    if (Math.max(arA, arB) / Math.min(arA, arB) < 1.15) return best;
    var aIsWider = arA > arB;
    var tries = [
      // crop the wider video to the narrower aspect ratio
      aIsWider
        ? { variant: "cropA", a: spriteFeatures(spriteA, arB, opts), b: fb }
        : { variant: "cropB", a: fa, b: spriteFeatures(spriteB, arA, opts) },
      // crop the taller video to the wider aspect ratio
      aIsWider
        ? { variant: "cropB", a: fa, b: spriteFeatures(spriteB, arA, opts) }
        : { variant: "cropA", a: spriteFeatures(spriteA, arB, opts), b: fb },
    ];
    tries.forEach(function (t) {
      var r = alignTiles(t.a, t.b, durA, durB, opts);
      if (r.coverage > best.coverage) best = Object.assign(r, { variant: t.variant }, framing);
    });
    return best;
  }

  // A missing or zero duration cannot be judged, so such pairs are kept rather than hidden.
  function withinDuration(durA, durB, opts) {
    opts = Object.assign({}, DEFAULTS, opts);
    if (!(durA > 0) || !(durB > 0)) return true;
    return Math.abs(durA - durB) <= opts.maxDurationDiff;
  }

  // Turns a confirmPair result into what the page shows. status: "unchecked" (no result),
  // "confirmed" (coverage >= minCoverage over enough frames) or "unconfirmed". framing and
  // colour are null or {kind, detail} badges; they describe how the copies differ, they do not
  // decide whether the pair is a duplicate.
  function pairVerdict(v, opts) {
    opts = Object.assign({}, DEFAULTS, opts);
    if (!v) return { status: "unchecked", framing: null, colour: null };
    var confirmed = !v.insufficient && (v.coverage || 0) >= opts.minCoverage;
    var framing = null;
    var parts = [];
    if (v.variant && v.variant !== "plain") parts.push(v.variant === "cropA" ? "A matched after cropping" : "B matched after cropping");
    if (v.aspectA && v.aspectB && Math.max(v.aspectA, v.aspectB) / Math.min(v.aspectA, v.aspectB) - 1 > opts.aspectBadge) {
      parts.push("picture shape " + v.aspectA.toFixed(2) + " vs " + v.aspectB.toFixed(2));
    }
    if (v.barsA != null && v.barsB != null && Math.abs(v.barsA - v.barsB) > opts.barsBadge) {
      parts.push((v.barsA > v.barsB ? "A" : "B") + " has black bars (" + Math.round(Math.max(v.barsA, v.barsB) * 100) + "% of frame)");
    }
    if (parts.length) framing = { kind: "framing", detail: parts.join("; ") };
    var colour = null;
    var cparts = [];
    if (v.brightness != null && Math.abs(v.brightness) > opts.brightnessBadge) {
      cparts.push("B is " + (v.brightness > 0 ? "brighter" : "darker") + " by " + Math.round(Math.abs(v.brightness)));
    }
    if (v.contrast != null && (v.contrast > opts.contrastBadge || v.contrast < 1 / opts.contrastBadge)) {
      cparts.push("B has " + (v.contrast > 1 ? "more" : "less") + " contrast (x" + v.contrast.toFixed(2) + ")");
    }
    if (v.colour != null && v.colour > opts.colourBadge) cparts.push("colour shift " + Math.round(v.colour));
    if (cparts.length) colour = { kind: "colour", detail: cparts.join("; ") };
    return { status: confirmed ? "confirmed" : "unconfirmed", framing: framing, colour: colour };
  }

  function nearestIndex(sorted, t) {
    var lo = 0;
    var hi = sorted.length - 1;
    while (lo < hi) {
      var mid = (lo + hi) >> 1;
      if (sorted[mid] < t) lo = mid + 1;
      else hi = mid;
    }
    if (lo > 0 && Math.abs(sorted[lo - 1] - t) <= Math.abs(sorted[lo] - t)) return lo - 1;
    return lo;
  }

  // Chooses k tile index pairs [i, j] for side-by-side strips: spread over the overlapping
  // section when an offset is known, otherwise matched by relative position.
  function stripPairs(timesA, timesB, durA, durB, offset, k) {
    var out = [];
    if (!timesA.length || !timesB.length || !(durA > 0) || !(durB > 0)) return out;
    var startA = 0;
    var endA = durA;
    var useOffset = offset !== null && offset !== undefined;
    if (useOffset) {
      startA = Math.max(0, -offset);
      endA = Math.min(durA, durB - offset);
      if (endA <= startA) {
        startA = 0;
        endA = durA;
        useOffset = false;
      }
    }
    for (var s = 0; s < k; s++) {
      var t = startA + ((endA - startA) * (s + 0.5)) / k;
      var i = nearestIndex(timesA, t);
      var tb = useOffset ? timesA[i] + offset : (timesA[i] / durA) * durB;
      out.push([i, nearestIndex(timesB, tb)]);
    }
    return out;
  }

  // ---------------------------------------------------------------- review helpers

  function hashString(s) {
    var h = 0x811c9dc5;
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return h >>> 0;
  }

  function mulberry32(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // pairs: [{key, d, durationMatch, ...}]. Takes up to perStratum pairs from each
  // (distance, durationMatch) stratum with a seeded shuffle, ordered by distance.
  function stratifiedSample(pairs, opts) {
    opts = opts || {};
    var per = opts.perStratum || 10;
    var seed = opts.seed || "duplicate-finder";
    var minD = opts.minDistance === undefined ? 0 : opts.minDistance;
    var maxD = opts.maxDistance === undefined ? 64 : opts.maxDistance;
    var strata = new Map();
    pairs.forEach(function (p) {
      if (p.d < minD || p.d > maxD) return;
      var key = p.d + "|" + (p.durationMatch ? 1 : 0);
      if (!strata.has(key)) strata.set(key, []);
      strata.get(key).push(p);
    });
    var keys = Array.from(strata.keys()).sort(function (a, b) {
      var pa = a.split("|");
      var pb = b.split("|");
      return pa[0] - pb[0] || pb[1] - pa[1];
    });
    var out = [];
    keys.forEach(function (key) {
      var list = strata.get(key).slice().sort(function (a, b) {
        return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
      });
      var rng = mulberry32(hashString(seed + "|" + key));
      for (var i = list.length - 1; i > 0; i--) {
        var j = Math.floor(rng() * (i + 1));
        var tmp = list[i];
        list[i] = list[j];
        list[j] = tmp;
      }
      out.push.apply(out, list.slice(0, per));
    });
    return out;
  }

  var FIELD_RULES = {
    size: { better: "higher", tolerance: 100 * 1024 },
    duration: { better: "higher", tolerance: 1 },
    pixels: { better: "higher", tolerance: 0 },
    bitrate: { better: "higher", tolerance: 0 },
    frameRate: { better: "higher", tolerance: 0.1 },
    count: { better: "higher", tolerance: 0 },
    date: { better: "lower", tolerance: 0 }, // "a" means a is older
  };

  // Returns "a", "b", "equal", or null (not comparable).
  function compareValues(a, b, rule) {
    if (a === null || a === undefined || b === null || b === undefined) return null;
    if (typeof a !== "number" || typeof b !== "number" || isNaN(a) || isNaN(b)) return null;
    rule = rule || FIELD_RULES.count;
    if (Math.abs(a - b) <= (rule.tolerance || 0)) return "equal";
    return a > b === (rule.better !== "lower") ? "a" : "b";
  }

  // rows: [{d, coverage, label}] with label "dup" | "not" | "unsure".
  function labelStats(rows) {
    function empty() {
      return { dup: 0, not: 0, unsure: 0, total: 0 };
    }
    function add(map, key, label) {
      if (!map.has(key)) map.set(key, empty());
      var e = map.get(key);
      if (e[label] !== undefined) e[label]++;
      e.total++;
    }
    var byDistance = new Map();
    var byCoverage = new Map();
    rows.forEach(function (r) {
      add(byDistance, r.d, r.label);
      var bucket =
        r.coverage === null || r.coverage === undefined
          ? "unverified"
          : (Math.min(9, Math.floor(r.coverage * 10)) / 10).toFixed(1);
      add(byCoverage, bucket, r.label);
    });
    function toList(map, sortFn) {
      return Array.from(map.entries())
        .sort(sortFn)
        .map(function (e) {
          return Object.assign({ key: e[0] }, e[1]);
        });
    }
    return {
      byDistance: toList(byDistance, function (a, b) {
        return a[0] - b[0];
      }),
      byCoverage: toList(byCoverage, function (a, b) {
        if (a[0] === "unverified") return 1;
        if (b[0] === "unverified") return -1;
        return a[0] - b[0];
      }),
    };
  }

  // The prototype must never change Stash data.
  function assertReadOnly(query) {
    var stripped = String(query)
      .replace(/"""[\s\S]*?"""/g, "")
      .replace(/"(?:\\.|[^"\\])*"/g, "")
      .replace(/#[^\n]*/g, "");
    if (/\b(mutation|subscription)\b/.test(stripped)) {
      throw new Error("Duplicate Finder is read-only: GraphQL mutations and subscriptions are not allowed");
    }
    return query;
  }

  return {
    DEFAULTS: DEFAULTS,
    TILE_SIZE: TILE_SIZE,
    FIELD_RULES: FIELD_RULES,
    popcount32: popcount32,
    hamming: hamming,
    parsePhash: parsePhash,
    pairKey: pairKey,
    findPairsRange: findPairsRange,
    findPairsParallel: findPairsParallel,
    workerSource: workerSource,
    scorePair: scorePair,
    parseVtt: parseVtt,
    toGray: toGray,
    resizeArea: resizeArea,
    detectContentBox: detectContentBox,
    phash32: phash32,
    ssim: ssim,
    tileFeatures: tileFeatures,
    alignTiles: alignTiles,
    cropToAspect: cropToAspect,
    spriteFeatures: spriteFeatures,
    spriteFromRgba: spriteFromRgba,
    photometrics: photometrics,
    withinDuration: withinDuration,
    pairVerdict: pairVerdict,
    confirmPair: confirmPair,
    nearestIndex: nearestIndex,
    stripPairs: stripPairs,
    stratifiedSample: stratifiedSample,
    compareValues: compareValues,
    labelStats: labelStats,
    assertReadOnly: assertReadOnly,
  };
});
