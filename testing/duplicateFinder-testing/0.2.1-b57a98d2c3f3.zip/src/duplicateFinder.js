// Duplicate Finder UI: a read-only prototype page for reviewing perceptual-hash duplicate
// candidates. It only sends GraphQL queries and stores its data in browser IndexedDB.
(function (root) {
  "use strict";

  // Not under /plugin: the server owns that prefix.
  var ROUTE = "/duplicate-finder";
  var DB_NAME = "duplicate-finder-prototype";
  var STORES = ["meta", "labels", "verify"];
  var PAGE_SIZE = 20;
  var STRIP_COUNT = 8;
  var MAX_CEILING = 16;
  var LRU_SIZE = 60;
  var SCENE_CONCURRENCY = 4;
  var AUTO_CONCURRENCY = 2; // pairs checked at once on the shown page
  var BULK_CONCURRENCY = 2; // pairs checked at once by Check all
  var RESULT_VERSION = 2; // stored results without this version (0.1.0) are checked again
  var FAIL_STREAK = 10; // Check all pauses after this many failed checks in a row
  var TIMEOUT_MS = 30000; // VTT and sprite requests
  var CACHE_TRIM = 800; // details and cues kept in memory before unused ones are dropped
  var VTT_CONCURRENCY = 6;
  var INDEX_PAGE = 5000;
  var INDEX_CONCURRENCY = 3;
  var DETAIL_CHUNK = 100;
  var LABELS = { dup: "Duplicate", not: "Not duplicate", unsure: "Unsure" };
  var LABEL_KEYS = { "1": "dup", "2": "not", "3": "unsure" };
  var DEFAULT_SETTINGS = { ceiling: 12, perStratum: 10, seed: "v1", minDistance: 6, maxDistance: null, tileMaxDistance: null, durationTolerance: 1, maxDurationDiff: 20, minCoverage: 0.4 };

  var INDEX_QUERY = "query DfIndex($filter: FindFilterType){ findScenes(filter:$filter){ count scenes{ id files{ duration fingerprint(type:\"phash\") } } } }";
  var DETAILS_QUERY = "query DfDetails($ids: [ID!], $filter: FindFilterType){ findScenes(ids:$ids, filter:$filter){ scenes{ id title date created_at rating100 o_counter play_count organized studio{ name } tags{ id } performers{ id } scene_markers{ id } stash_ids{ stash_id } paths{ sprite vtt } files{ path basename size duration width height video_codec audio_codec frame_rate bit_rate mod_time parent_folder{ path } } } } }";

  function now() { return typeof performance !== "undefined" ? performance.now() : Date.now(); }

  // The core is looked up when used so load order and tests do not matter.
  function getCore() {
    if (root && root.DuplicateFinderCore) return root.DuplicateFinderCore;
    if (typeof require === "function") return require("./duplicateFinder-core.js");
    throw new Error("DuplicateFinderCore is not loaded");
  }

  // Every query is checked by the core's read-only guard before anything is sent.
  function gql(query, variables, signal) {
    return Promise.resolve().then(function () {
      getCore().assertReadOnly(query);
      return fetch("/graphql", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: query, variables: variables || {} }),
        signal: signal,
      });
    }).then(function (r) { return r.json(); }).then(function (json) {
      if (json.errors && json.errors.length) throw new Error(json.errors[0].message || "GraphQL error");
      return json.data;
    });
  }

  // ─── Formatting ──────────────────────────────────────────────────────

  function pad2(n) { return (n < 10 ? "0" : "") + n; }
  function fmtClock(sec) {
    sec = Math.max(0, Math.round(sec));
    var h = Math.floor(sec / 3600);
    var m = Math.floor((sec % 3600) / 60);
    return (h ? h + ":" + pad2(m) : m) + ":" + pad2(sec % 60);
  }
  function fmtSize(bytes) {
    if (typeof bytes !== "number") return "";
    var units = ["B", "KB", "MB", "GB", "TB"];
    var i = 0;
    while (bytes >= 1024 && i < units.length - 1) { bytes /= 1024; i++; }
    return (i ? bytes.toFixed(bytes >= 100 ? 0 : 1) : bytes) + " " + units[i];
  }
  function fmtPct(x) { return typeof x === "number" ? Math.round(x * 100) + "%" : "–"; }
  function fmtSigned(x, digits) { return (x > 0 ? "+" : x < 0 ? "−" : "±") + Math.abs(x).toFixed(digits); }
  function fmtDate(s) { return s ? String(s).slice(0, 16).replace("T", " ") : ""; }
  function toLocalUrl(url) {
    try { var u = new URL(url, root.location.href); return u.pathname + u.search; } catch (e) { return url; }
  }

  // ─── Tooltips ────────────────────────────────────────────────────────
  // Hover text for every metric and technical term on the page. Dynamic tips (current
  // settings, this pair's values) are built by the functions below the table.

  var TIPS = {
    coverage: "Coverage: the share of A's thumbnail frames, within the part both videos share, that found a near-identical frame in B at the same moment (after the offset). 100% means every comparable frame matched.",
    notChecked: "The frame comparison has not run for this pair yet. It runs automatically for the pairs on screen; Check all runs it for the whole list.",
    checking: "Comparing the two scenes' thumbnail frames now.",
    noSprite: "Stash has no sprite sheet (the grid of thumbnails used for the scrubber) or no VTT (the file that says which thumbnail belongs to which moment) for one of the scenes, so their frames cannot be compared. Generate sprites in Stash, then use Recheck no-sprite pairs.",
    failed: "The sprite or VTT could not be loaded (network error, timeout or server error). The pair is checked again the next time it is shown or Check all runs.",
    distance: "Hash distance (d): how many of the 64 bits differ between the two scenes' perceptual hashes (phash). Stash computes a phash from 25 frames spread across each video, so videos that look alike get similar hashes. 0 means identical hashes; lower is more similar. It is always even because every Stash phash has exactly 32 bits set. Stash's own duplicate checker offers 0, 4, 8 and 10.",
    durationDiff: "Duration difference: B's length minus A's, in seconds.",
    score: "Similarity score as vidupe computes it: 64 minus the hash distance, plus 1 when the durations are within the duration tolerance or minus 4 when they are not, capped at 64. Higher is more similar; vidupe's default threshold is 57. Used for sorting only.",
    offset: "Offset: the time shift that lines B up with A. A frame at time t in A matches B at t + offset. A non-zero offset usually means an intro or outro was cut or added. – means no frames matched.",
    focus: "Focus: the share of all frame-to-frame matches (at any time) that agree with the chosen offset. Low focus is normal for videos with many similar-looking moments; high focus means the alignment is unambiguous. Information only.",
    ssim: "SSIM (structural similarity): how alike the matched frames' pixels are, averaged, from -1 to 1 (1 = identical). It drops with brightness, colour, sharpness or compression changes even when the footage is the same, so it does not decide whether a pair is confirmed. Information only.",
    overlap: "Overlap: how much of the shorter video falls inside the longer one once they are lined up by the offset. 100% means one is contained in the other; less means only part of them overlaps.",
    tiles: "Matched / comparable frames: of A's thumbnail frames that fall inside B after the offset (black and solid-colour frames excluded), how many found a near-identical frame in B. Coverage is this ratio.",
    flat: "Flat frames in A / B: thumbnail frames that are black or a single colour (fades, blank screens). They carry no picture information, so matching skips them.",
    insufficient: "Fewer than 4 comparable frames overlap, so the pair cannot be confirmed. Usually the durations differ a lot or most frames are black.",
    framing: "Framing: the copies show different picture areas. Black bars: one side has black borders covering that share of its frame. Picture shape: width divided by height of the actual picture after removing black bars (1.78 = 16:9, 1.33 = 4:3, 0.56 = vertical). Matched after cropping: the frames only matched once one side was cropped to the other's shape. The copy without bars or cropping usually shows more of the picture.",
    colour: "Colour: the matched frames look different in tone. Brighter/darker by N: difference in average light level on a 0-255 scale, B minus A (shown above 10). Contrast xN: B's spread between dark and light divided by A's (shown below x0.85 or above x1.18). Colour shift N: difference in the frames' average tint, x1000 (shown above 20). Typical for re-encodes with different colour settings.",
    stripA: "Scene A's thumbnails, lined up in time with B's below using the offset. Click a frame to open the scene at that moment.",
    stripB: "Scene B's thumbnails at the moments that line up with A's above. Click a frame to open the scene at that moment.",
    better: "Better value (green): the higher size, length, resolution, bitrate, frame rate or count.",
    equal: "Same in both copies (amber).",
    older: "The earlier date of the two. An older file is often the original download.",
    newer: "The later date of the two.",
    ceiling: "Distance ceiling: the largest hash distance searched for candidate pairs. Each step up adds many more pairs (often several times as many), and most of the extra ones are unrelated videos. In the calibration sample, duplicates were found up to d 12.",
    maxDurationDiff: "Pairs whose lengths differ by more than this many seconds are hidden and not checked unless you include them. Copies with a trimmed intro differ by a few seconds; in the calibration sample every duplicate was within 16 s.",
    minCoverage: "Min coverage: a checked pair is Confirmed when at least this share (0-1) of its comparable frames match. Lower finds more duplicates but risks false matches; in the calibration sample 0.4 found 30 of 34 duplicates with no false matches. Changing it re-judges stored results at once.",
    tileThreshold: "Tile threshold: how many of a thumbnail frame hash's 63 bits may differ for two frames to count as the same picture. Higher tolerates heavier re-encoding but lets unrelated frames match: 14 kept 100 random pairs below 20% coverage, 16 did not. Changing it discards stored check results.",
    durationTolerance: "Durations within this many seconds count as the same: they add 1 to the score instead of subtracting 4, and they decide the Duration filter's same/different. vidupe uses 1 s.",
    perStratum: "How many pairs the sample takes from each group. Groups are hash distance x same/different duration, so every kind of pair gets labelled.",
    seed: "Text that fixes the random sample: the same seed always gives the same pairs. Change it for a fresh sample.",
    minDistance: "Smallest hash distance (d) to include.",
    maxDistance: "Largest hash distance (d) to include.",
    status: "Confirmed: coverage at or above the minimum. Not confirmed: checked but below it. Not checked: no comparison yet.",
    hasFraming: "Only confirmed pairs whose copies show different picture areas (black bars, picture shape or cropping).",
    hasColour: "Only confirmed pairs whose copies differ in brightness, contrast or colour.",
    durationFilter: "Same: durations within the duration tolerance (Advanced). Different: further apart.",
    labelFilter: "Filter by your own labels: duplicate, not, unsure, any label, or none.",
    sort: "Distance: most similar hashes first. Score: highest vidupe-style score first. Coverage: best-matching checked pairs first. Duration: longest videos first.",
    includeLong: "Also list pairs whose durations differ by more than the max duration difference. They are rarely duplicates and slow down Check all.",
    histogram: "Number of candidate pairs at each hash distance (d).",
    index: "Every scene's perceptual hash (phash), duration and size, loaded once from Stash and cached in this browser.",
    storage: "Where labels and check results are kept: this browser's IndexedDB (survives reloads) or memory only (lost on reload).",
    checkAll: "Checks every pair in this list in the background, two at a time, skipping pairs with a stored result. It keeps going while you browse Duplicate Finder and stops when you leave it.",
    statsDup: "Pairs you labelled duplicate.",
    statsNot: "Pairs you labelled not a duplicate.",
    statsUnsure: "Pairs you labelled unsure.",
    statsTotal: "All labelled pairs in this row.",
    statsShare: "Share of this row's labelled pairs you marked duplicate.",
    statsDistance: "Labelled pairs grouped by hash distance (d).",
    statsCoverage: "Labelled pairs grouped by coverage from the frame check; unverified means the pair had no check result.",
  };

  var ROW_TIPS = {
    Title: "Scene title, or the file name when the scene has no title. Opens the scene.",
    Folder: "Folder of the scene's main file. Amber when both are in the same folder.",
    Size: "File size. Green: the bigger file (differences under 100 KB count as equal).",
    Duration: "Video length. Green: the longer one (within 1 s counts as equal).",
    Resolution: "Width x height in pixels. Green: more pixels.",
    Bitrate: "Average amount of data per second of video (megabits per second). At the same resolution and codec, higher usually means better quality. Green: higher.",
    "Frame rate": "Frames per second. Green: higher (within 0.1 counts as equal).",
    "Video codec": "Video compression format (for example h264, hevc, av1). Amber when both use the same one.",
    "Audio codec": "Audio compression format (for example aac, mp3, opus). Amber when both use the same one.",
    "File modified": "When the file was last modified on disk. The older one is marked: often the original download.",
    "Scene created": "When the scene was added to Stash. The older one is marked.",
    Date: "The scene's release date in Stash. The older one is marked.",
    Studio: "Studio set in Stash. Amber when both have the same one.",
    Tags: "Number of tags. Green: more.",
    Performers: "Number of performers. Green: more.",
    "Stash IDs": "Number of links to StashDB or other stash-box databases (identified scenes). Green: more.",
    Markers: "Number of scene markers. Green: more.",
    "Play count": "How many times the scene has been played. Green: more.",
    "O-count": "The scene's O-counter. Green: higher.",
    Rating: "Rating out of 100. Green: higher.",
    Organized: "Whether the scene is marked organized in Stash.",
    Files: "Number of files attached to the scene. Green: more.",
  };

  function pct(v) { return Math.round(v * 100) + "%"; }

  // Verdict chip: what the status means, with this pair's numbers and the current setting.
  function verdictTip(status, summary, minCoverage) {
    var min = pct(minCoverage);
    if (status === "confirmed") return "Confirmed: " + summary.matched + " of " + summary.overlapTiles + " comparable frames match (" + pct(summary.coverage) + "), at or above the min coverage of " + min + ". " + TIPS.coverage;
    if (status === "unconfirmed") {
      var why = summary.insufficient ? "too few comparable frames overlap" : "only " + summary.matched + " of " + summary.overlapTiles + " comparable frames match (" + pct(summary.coverage) + "), below the min coverage of " + min;
      return "Not confirmed: " + why + ". This does not prove they differ: zooms, heavy edits and very long videos can score low. " + TIPS.coverage;
    }
    return TIPS.notChecked;
  }

  function durationTip(pair, settings) {
    var diff = Math.abs(pair.durB - pair.durA);
    var tol = settings && settings.durationTolerance != null ? settings.durationTolerance : 1;
    var max = settings && settings.maxDurationDiff != null ? settings.maxDurationDiff : 20;
    return TIPS.durationDiff + " " + (diff <= tol ? "Within the duration tolerance of " + tol + " s, so it counts as the same length." : "More than the duration tolerance of " + tol + " s (amber)" + (diff > max ? ", and beyond the max duration difference of " + max + " s." : ", but within the max duration difference of " + max + " s."));
  }

  // ─── Metadata rows ───────────────────────────────────────────────────

  function fileOf(s) { return s && s.files && s.files[0] ? s.files[0] : null; }
  function len(list) { return list ? list.length : 0; }
  function timeOf(v) { var t = v ? Date.parse(v) : NaN; return isNaN(t) ? null : t; }

  // text: displayed string; num: value compared with FIELD_RULES[rule]; textEqual: amber when identical.
  var ROWS = [
    { label: "Title", link: true, text: function (s) { var f = fileOf(s); return s.title || (f && f.basename) || "Scene " + s.id; } },
    { label: "Folder", textEqual: true, text: function (s) { var f = fileOf(s); return f && f.parent_folder ? f.parent_folder.path : ""; } },
    { label: "Size", rule: "size", text: function (s) { var f = fileOf(s); return f ? fmtSize(f.size) : ""; }, num: function (s) { var f = fileOf(s); return f ? f.size : null; } },
    { label: "Duration", rule: "duration", text: function (s) { var f = fileOf(s); return f ? fmtClock(f.duration) + " (" + f.duration.toFixed(1) + " s)" : ""; }, num: function (s) { var f = fileOf(s); return f ? f.duration : null; } },
    { label: "Resolution", rule: "pixels", text: function (s) { var f = fileOf(s); return f ? f.width + "×" + f.height : ""; }, num: function (s) { var f = fileOf(s); return f ? f.width * f.height : null; } },
    { label: "Bitrate", rule: "bitrate", text: function (s) { var f = fileOf(s); return f ? (f.bit_rate / 1e6).toFixed(2) + " Mbps" : ""; }, num: function (s) { var f = fileOf(s); return f ? f.bit_rate : null; } },
    { label: "Frame rate", rule: "frameRate", text: function (s) { var f = fileOf(s); return f ? f.frame_rate.toFixed(2) + " fps" : ""; }, num: function (s) { var f = fileOf(s); return f ? f.frame_rate : null; } },
    { label: "Video codec", textEqual: true, text: function (s) { var f = fileOf(s); return f ? f.video_codec : ""; } },
    { label: "Audio codec", textEqual: true, text: function (s) { var f = fileOf(s); return f ? f.audio_codec : ""; } },
    { label: "File modified", rule: "date", date: true, text: function (s) { var f = fileOf(s); return f ? fmtDate(f.mod_time) : ""; }, num: function (s) { var f = fileOf(s); return f ? timeOf(f.mod_time) : null; } },
    { label: "Scene created", rule: "date", date: true, text: function (s) { return fmtDate(s.created_at); }, num: function (s) { return timeOf(s.created_at); } },
    { label: "Date", rule: "date", date: true, text: function (s) { return s.date || ""; }, num: function (s) { return timeOf(s.date); } },
    { label: "Studio", textEqual: true, text: function (s) { return s.studio ? s.studio.name : ""; } },
    { label: "Tags", rule: "count", text: function (s) { return String(len(s.tags)); }, num: function (s) { return len(s.tags); } },
    { label: "Performers", rule: "count", text: function (s) { return String(len(s.performers)); }, num: function (s) { return len(s.performers); } },
    { label: "Stash IDs", rule: "count", text: function (s) { return String(len(s.stash_ids)); }, num: function (s) { return len(s.stash_ids); } },
    { label: "Markers", rule: "count", text: function (s) { return String(len(s.scene_markers)); }, num: function (s) { return len(s.scene_markers); } },
    { label: "Play count", rule: "count", text: function (s) { return String(s.play_count || 0); }, num: function (s) { return s.play_count || 0; } },
    { label: "O-count", rule: "count", text: function (s) { return String(s.o_counter || 0); }, num: function (s) { return s.o_counter || 0; } },
    { label: "Rating", rule: "count", text: function (s) { return s.rating100 ? s.rating100 + "/100" : ""; }, num: function (s) { return s.rating100 || 0; } },
    { label: "Organized", text: function (s) { return s.organized ? "yes" : "no"; } },
    { label: "Files", rule: "count", text: function (s) { return String(len(s.files)); }, num: function (s) { return len(s.files); } },
  ];

  // Returns [{label, a, b, link, cmp}] where cmp is "a" | "b" | "equal" | null.
  function buildRows(core, sa, sb) {
    return ROWS.map(function (row) {
      var ta = row.text(sa);
      var tb = row.text(sb);
      var cmp = null;
      if (row.rule) cmp = core.compareValues(row.num(sa), row.num(sb), core.FIELD_RULES[row.rule]);
      else if (row.textEqual && ta && ta === tb) cmp = "equal";
      return { label: row.label, a: ta, b: tb, link: !!row.link, date: !!row.date, cmp: cmp };
    });
  }

  // ─── Storage: IndexedDB with an in-memory fallback ───────────────────

  function memoryStore() {
    var data = {};
    STORES.forEach(function (n) { data[n] = new Map(); });
    return {
      kind: "memory",
      get: function (s, k) { return Promise.resolve(data[s].get(k)); },
      put: function (s, k, v) { data[s].set(k, v); return Promise.resolve(); },
      putMany: function (s, entries) { entries.forEach(function (e) { data[s].set(e[0], e[1]); }); return Promise.resolve(); },
      all: function (s) { return Promise.resolve(Array.from(data[s].values())); },
      remove: function (s, k) { data[s].delete(k); return Promise.resolve(); },
      clear: function (s) { data[s].clear(); return Promise.resolve(); },
    };
  }

  function idbStore(db) {
    function run(storeName, mode, fn) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(storeName, mode);
        var req = fn(tx.objectStore(storeName));
        tx.oncomplete = function () { resolve(req ? req.result : undefined); };
        tx.onerror = function () { reject(tx.error); };
        tx.onabort = function () { reject(tx.error || new Error("transaction aborted")); };
      });
    }
    return {
      kind: "indexeddb",
      get: function (s, k) { return run(s, "readonly", function (os) { return os.get(k); }); },
      put: function (s, k, v) { return run(s, "readwrite", function (os) { return os.put(v, k); }); },
      putMany: function (s, entries) { return run(s, "readwrite", function (os) { entries.forEach(function (e) { os.put(e[1], e[0]); }); return null; }); },
      all: function (s) { return run(s, "readonly", function (os) { return os.getAll(); }); },
      remove: function (s, k) { return run(s, "readwrite", function (os) { return os.delete(k); }); },
      clear: function (s) { return run(s, "readwrite", function (os) { return os.clear(); }); },
    };
  }

  function openStore() {
    return new Promise(function (resolve, reject) {
      if (typeof indexedDB === "undefined" || !indexedDB) return reject(new Error("IndexedDB is unavailable"));
      var req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = function () {
        STORES.forEach(function (n) { if (!req.result.objectStoreNames.contains(n)) req.result.createObjectStore(n); });
      };
      req.onsuccess = function () { resolve(idbStore(req.result)); };
      req.onerror = function () { reject(req.error); };
      req.onblocked = function () { reject(new Error("IndexedDB is blocked")); };
    }).catch(function () { return memoryStore(); });
  }

  // Writes are best effort: a quota or private-mode failure must not break review.
  function quiet(promise) { return promise.catch(function () {}); }

  // ─── Index and pairs ─────────────────────────────────────────────────

  function buildIndex(core, results, total, t0) {
    var ids = [];
    var hi = [];
    var lo = [];
    var dur = [];
    var skipped = 0;
    results.forEach(function (scenes) {
      scenes.forEach(function (s) {
        var f = s.files && s.files[0];
        var parsed = f ? core.parsePhash(f.fingerprint) : null;
        if (!parsed) { skipped++; return; }
        ids.push(Number(s.id));
        hi.push(parsed[0]);
        lo.push(parsed[1]);
        dur.push(f.duration || 0);
      });
    });
    return { ids: Int32Array.from(ids), hi: Int32Array.from(hi), lo: Int32Array.from(lo), dur: Float32Array.from(dur), total: total, skipped: skipped, loadedAt: Date.now(), loadMs: now() - t0 };
  }

  function fetchIndex(core, onProgress) {
    var t0 = now();
    function page(n) {
      return gql(INDEX_QUERY, { filter: { per_page: INDEX_PAGE, page: n, sort: "id", direction: "ASC" } }).then(function (d) { return d.findScenes; });
    }
    return page(1).then(function (first) {
      var pages = Math.max(1, Math.ceil(first.count / INDEX_PAGE));
      var results = new Array(pages);
      results[0] = first.scenes;
      var loaded = first.scenes.length;
      onProgress(loaded, first.count);
      var next = 1;
      function worker() {
        if (next >= pages) return Promise.resolve();
        var n = next++;
        return page(n + 1).then(function (r) {
          results[n] = r.scenes;
          loaded += r.scenes.length;
          onProgress(loaded, first.count);
          return worker();
        });
      }
      var workers = [];
      for (var k = 0; k < Math.min(INDEX_CONCURRENCY, pages - 1); k++) workers.push(worker());
      return Promise.all(workers).then(function () { return buildIndex(core, results, first.count, t0); });
    });
  }

  function makePairs(core, index, triples, tolerance) {
    var out = new Array(triples.length / 3);
    for (var k = 0, n = 0; k < triples.length; k += 3, n++) {
      var i = triples[k];
      var j = triples[k + 1];
      var d = triples[k + 2];
      var durA = index.dur[i];
      var durB = index.dur[j];
      out[n] = {
        key: core.pairKey(index.ids[i], index.ids[j]),
        a: index.ids[i],
        b: index.ids[j],
        d: d,
        durA: durA,
        durB: durB,
        durationMatch: Math.abs(durA - durB) <= tolerance,
        score: core.scorePair(d, durA, durB, { durationTolerance: tolerance }),
      };
    }
    return out;
  }

  function filterTriples(triples, ceiling) {
    var out = [];
    for (var k = 0; k < triples.length; k += 3) if (triples[k + 2] <= ceiling) out.push(triples[k], triples[k + 1], triples[k + 2]);
    return Int32Array.from(out);
  }

  function histogram(triples, ceiling) {
    var counts = {};
    for (var k = 2; k < triples.length; k += 3) counts[triples[k]] = (counts[triples[k]] || 0) + 1;
    var rows = [];
    for (var d = 0; d <= ceiling; d += 2) rows.push({ d: d, count: counts[d] || 0 });
    return rows;
  }

  function summarise(r, tmd, ms) {
    return {
      offset: r.offset, coverage: r.coverage, focus: r.focus, meanSsim: r.meanSsim,
      overlapOfShorter: r.overlapOfShorter, overlapOfLonger: r.overlapOfLonger,
      matched: r.matched, overlapTiles: r.overlapTiles, tilesA: r.tilesA, tilesB: r.tilesB,
      flatA: r.flatA, flatB: r.flatB, votes: r.votes, insufficient: r.insufficient, variant: r.variant || "plain",
      brightness: r.brightness, contrast: r.contrast, colour: r.colour,
      aspectA: r.aspectA, aspectB: r.aspectB, frameAspectA: r.frameAspectA, frameAspectB: r.frameAspectB, barsA: r.barsA, barsB: r.barsB,
      rv: RESULT_VERSION, tmd: tmd, ms: Math.round(ms), at: Date.now(),
    };
  }

  // The verdict options a settings object supplies; unset values fall back to the core's defaults.
  function verdictOpts(settings) {
    var o = {};
    if (settings && typeof settings.minCoverage === "number") o.minCoverage = settings.minCoverage;
    return o;
  }

  // What a pair's verify entry ({status, summary}) says, as pairVerdict returns it.
  function verdictOf(core, v, settings) {
    return core.pairVerdict(v && v.status === "done" ? v.summary : null, verdictOpts(settings));
  }

  function fmtInt(n) { return Number(n).toLocaleString("en-US"); }

  // {within, total}: pairs whose durations differ by at most maxDurationDiff, of all pairs.
  function durationCounts(core, pairs, settings) {
    var within = 0;
    var opts = { maxDurationDiff: settings.maxDurationDiff };
    for (var k = 0; k < pairs.length; k++) if (core.withinDuration(pairs[k].durA, pairs[k].durB, opts)) within++;
    return { within: within, total: pairs.length };
  }

  // The Pairs list: filters, then sorts. Pure; the page freezes the result until a filter, sort
  // or the Refresh button changes it. f: {minD, maxD, dur, includeLong, label, status, framing,
  // colour, sort}. ctx: {labels, vmap, settings}.
  function buildPairList(core, pairs, f, ctx) {
    var vopts = verdictOpts(ctx.settings);
    var dopts = { maxDurationDiff: ctx.settings.maxDurationDiff };
    var needVerdict = f.status !== "all" || f.framing || f.colour;
    var list = pairs.filter(function (p) {
      if (p.d < f.minD || p.d > f.maxD) return false;
      if (!f.includeLong && !core.withinDuration(p.durA, p.durB, dopts)) return false;
      if (f.dur === "same" && !p.durationMatch) return false;
      if (f.dur === "different" && p.durationMatch) return false;
      var rec = ctx.labels.get(p.key);
      if (f.label === "unlabeled") { if (rec) return false; }
      else if (f.label === "labeled") { if (!rec) return false; }
      else if (f.label !== "any" && !(rec && rec.label === f.label)) return false;
      if (needVerdict) {
        var verdict = verdictOf(core, ctx.vmap.get(p.key), ctx.settings);
        if (f.status !== "all" && verdict.status !== f.status) return false;
        if (f.framing && !(verdict.status === "confirmed" && verdict.framing)) return false;
        if (f.colour && !(verdict.status === "confirmed" && verdict.colour)) return false;
      }
      return true;
    });
    var coverageOf = function (key) { var v = ctx.vmap.get(key); return v && v.status === "done" ? v.summary.coverage || 0 : -1; };
    var byKey = function (a, b) { return a.key < b.key ? -1 : a.key > b.key ? 1 : 0; };
    if (f.sort === "score") list.sort(function (a, b) { return b.score - a.score || a.d - b.d || byKey(a, b); });
    else if (f.sort === "coverage") list.sort(function (a, b) { return coverageOf(b.key) - coverageOf(a.key) || a.d - b.d || byKey(a, b); });
    else if (f.sort === "duration") list.sort(function (a, b) { return Math.max(b.durA, b.durB) - Math.max(a.durA, a.durB) || a.d - b.d || byKey(a, b); });
    else list.sort(function (a, b) { return a.d - b.d || byKey(a, b); });
    return list;
  }

  // Yields to the page. MessageChannel tasks are not throttled in hidden tabs, unlike timers.
  function yieldToUi() {
    if (typeof MessageChannel === "undefined") return new Promise(function (resolve) { setTimeout(resolve, 0); });
    return new Promise(function (resolve) {
      var ch = new MessageChannel();
      ch.port1.onmessage = function () { ch.port1.onmessage = null; ch.port1.close(); resolve(); };
      ch.port2.postMessage(0);
    });
  }

  // Runs fn(signal) and rejects when it takes longer than ms, aborting the signal.
  function withTimeout(fn, ms, label) {
    return new Promise(function (resolve, reject) {
      var ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
      var timer = setTimeout(function () { if (ctrl) ctrl.abort(); reject(new Error(label + " timed out")); }, ms);
      Promise.resolve().then(function () { return fn(ctrl ? ctrl.signal : undefined); }).then(
        function (v) { clearTimeout(timer); resolve(v); },
        function (e) { clearTimeout(timer); reject(e); });
    });
  }

  // Forgets every stored "no sprite" result so the pairs are checked again. Returns the new map
  // and the keys that were removed.
  function clearNoSprite(vmap) {
    var next = new Map();
    var keys = [];
    vmap.forEach(function (v, k) { if (v.status === "nosprite") keys.push(k); else next.set(k, v); });
    return { next: next, keys: keys };
  }

  // Whether to apply a new tile threshold: only when it differs, and after confirmation when
  // stored results would be thrown away. confirmFn(message) -> boolean.
  function askThresholdChange(current, value, storedCount, confirmFn) {
    if (typeof value !== "number" || isNaN(value) || value < 0 || value > 63 || value === current) return false;
    if (!storedCount) return true;
    return !!confirmFn("Changing the tile threshold from " + current + " to " + value + " clears " + fmtInt(storedCount) + " stored check results; they will be checked again. Continue?");
  }

  // Runs run(item, index) over the items that still need it (needs(item)), `concurrency` at a
  // time, yielding to the page after every item. Pausing lets running items finish and starts
  // no new ones; stop() or cancelled() returning true ends the run the same way. Items are
  // counted when the run starts, so done/total and the estimate cover only the work left.
  function createRunner(items, opts) {
    var clock = opts.now || now;
    var yielder = opts.yieldFn || yieldToUi;
    var queue = [];
    var cached = 0;
    items.forEach(function (it, i) { if (opts.needs(it)) queue.push(i); else cached++; });
    var st = { total: queue.length, cached: cached, done: 0, failed: 0, status: queue.length ? "running" : "finished", activeMs: 0, since: clock(), streak: 0, message: null };
    var waiters = [];
    var next = 0;

    function state() {
      var active = st.activeMs + (st.status === "running" ? clock() - st.since : 0);
      return {
        status: st.status, total: st.total, done: st.done, failed: st.failed, cached: st.cached, activeMs: active, message: st.message,
        etaMs: st.status === "running" && st.done > 0 ? ((st.total - st.done) * active) / st.done : null,
      };
    }
    function notify() { if (opts.onProgress) opts.onProgress(state()); }
    function wake() { var w = waiters; waiters = []; w.forEach(function (fn) { fn(); }); }
    function end(status) {
      if (st.status !== "running" && st.status !== "paused") return;
      if (st.status === "running") st.activeMs += clock() - st.since;
      st.status = status;
      wake();
      notify();
    }

    function step() {
      if (st.status === "paused") return new Promise(function (resolve) { waiters.push(resolve); }).then(step);
      if (st.status !== "running") return undefined;
      if (opts.cancelled && opts.cancelled()) { end("stopped"); return undefined; }
      if (next >= queue.length) return undefined;
      var idx = queue[next++];
      var item = items[idx];
      if (!opts.needs(item)) { st.total--; return Promise.resolve().then(step); }
      // run starts synchronously, so the item is claimed (its "verifying" mark is set) before
      // another runner can look at it.
      var started;
      try { started = Promise.resolve(opts.run(item, idx)); } catch (e) { started = Promise.reject(e); }
      return started.then(function () { st.streak = 0; }, function () { st.failed++; st.streak++; }).then(function () {
        st.done++;
        if (opts.maxFailureStreak && st.streak >= opts.maxFailureStreak && st.status === "running") pause("Paused: " + st.streak + " checks in a row failed — is Stash reachable?");
        else notify();
        return yielder();
      }).then(step);
    }

    function pause(message) {
      if (st.status !== "running") return;
      st.activeMs += clock() - st.since;
      st.status = "paused";
      st.message = message || null;
      notify();
    }

    var workers = [];
    if (st.status === "running") for (var k = 0; k < (opts.concurrency || 1); k++) workers.push(Promise.resolve().then(step));
    var done = Promise.all(workers).then(function () { end("finished"); return state(); });
    return {
      state: state,
      done: done,
      pause: function () { pause(null); },
      resume: function () { if (st.status !== "paused") return; st.since = clock(); st.status = "running"; st.streak = 0; st.message = null; wake(); notify(); },
      stop: function () { end("stopped"); },
    };
  }

  function limiter(max) {
    var running = 0;
    var waiting = [];
    function next() {
      if (running >= max || !waiting.length) return;
      var job = waiting.shift();
      running++;
      job.fn().then(job.resolve, job.reject).then(function () { running--; next(); });
    }
    return function (fn) {
      return new Promise(function (resolve, reject) { waiting.push({ fn: fn, resolve: resolve, reject: reject }); next(); });
    };
  }

  // The cues of a scene's sprite. Only a missing sprite/VTT path or a 404 VTT is "no sprite";
  // every other problem (network, timeout, HTTP error, unreadable VTT) throws and is retried.
  function loadCues(core, det, fetchImpl, timeoutMs) {
    if (!det || !det.paths || !det.paths.vtt || !det.paths.sprite) return Promise.resolve({ status: "nosprite" });
    return withTimeout(function (signal) {
      return fetchImpl(toLocalUrl(det.paths.vtt), { signal: signal }).then(function (r) {
        if (r.status === 404) return { missing: true };
        if (!r.ok) throw new Error("VTT HTTP " + r.status);
        return r.text().then(function (text) { return { text: text }; });
      });
    }, timeoutMs, "VTT request").then(function (r) {
      if (r.missing) return { status: "nosprite" };
      var cues = core.parseVtt(r.text);
      if (!cues.length) throw new Error("VTT has no cues");
      var sw = 0;
      var sh = 0;
      cues.forEach(function (c) { sw = Math.max(sw, c.x + c.w); sh = Math.max(sh, c.y + c.h); });
      return { status: "ok", cues: cues, sprite: toLocalUrl(det.paths.sprite), sw: sw, sh: sh };
    });
  }

  // An image that fails to load or decode is a failure (retryable), not a missing sprite.
  function loadSprite(core, url, cues, timeoutMs) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      var timer = setTimeout(function () { img.onload = img.onerror = null; img.src = ""; reject(new Error("sprite timed out")); }, timeoutMs || TIMEOUT_MS);
      img.onload = function () {
        clearTimeout(timer);
        try {
          var c = document.createElement("canvas");
          c.width = img.naturalWidth;
          c.height = img.naturalHeight;
          var ctx = c.getContext("2d", { willReadFrequently: true });
          ctx.drawImage(img, 0, 0);
          var data = ctx.getImageData(0, 0, c.width, c.height);
          // The RGBA buffer is not kept: the sprite holds grayscale pixels and per-cue colour.
          resolve(core.spriteFromRgba(data.data, c.width, c.height, cues));
        } catch (e) { reject(e); }
      };
      img.onerror = function () { clearTimeout(timer); reject(new Error("sprite failed to load")); };
      img.src = url;
    });
  }

  // ─── Labels, export and import (pure) ────────────────────────────────

  // The verify summary to report for a label: the current one when it was computed at the
  // current tile threshold, otherwise the snapshot stored with the label.
  function effectiveVerify(rec, vmap, tmd) {
    var v = vmap && vmap.get(rec.key);
    if (v && v.status === "done" && v.summary && v.summary.tmd === tmd) return v.summary;
    return rec.verify || null;
  }

  // labels: array of label records. Returns the export document: every label carries its
  // effective verify summary and that summary's tmd, and `verify` lists every summary computed
  // at the current threshold (numbers only) so unlabelled pairs can be analysed too.
  function buildExport(labels, vmap, tmd, pairs, settings, exportedAt) {
    var wanted = new Map();
    vmap.forEach(function (v, key) {
      if (v.status === "done" && v.summary && v.summary.tmd === tmd) wanted.set(key, v.summary);
    });
    var info = new Map();
    if (wanted.size && pairs) {
      pairs.forEach(function (p) {
        if (wanted.has(p.key)) info.set(p.key, { d: p.d, durA: p.durA, durB: p.durB, durDiff: Math.abs(p.durA - p.durB), durationMatch: p.durationMatch });
      });
    }
    var verify = [];
    wanted.forEach(function (summary, key) {
      var ids = key.split("-");
      var verdict = getCore().pairVerdict(summary, verdictOpts(settings));
      // The summary's numeric measures (colour, brightness, ...) stay as they are; the badge texts are separate.
      verify.push(Object.assign({ key: key, a: Number(ids[0]), b: Number(ids[1]) }, info.get(key) || {}, summary, {
        status: verdict.status, framingBadge: verdict.framing ? verdict.framing.detail : null, colourBadge: verdict.colour ? verdict.colour.detail : null,
      }));
    });
    return {
      exportedAt: exportedAt,
      settings: settings,
      labels: labels.map(function (rec) {
        var v = effectiveVerify(rec, vmap, tmd);
        return Object.assign({}, rec, { verify: v, tmd: v ? v.tmd : null });
      }),
      verify: verify,
    };
  }

  // Merges imported label records into the current Map without mutating it. Each key is
  // recomputed from a and b; records that are malformed or whose key disagrees are skipped.
  // The newer labeledAt wins.
  function mergeImport(core, current, records, labelNames) {
    var next = new Map(current);
    var out = { next: next, writes: [], added: 0, updated: 0, kept: 0, skipped: 0 };
    records.forEach(function (rec) {
      if (!rec || rec.a === undefined || rec.a === null || rec.b === undefined || rec.b === null || !labelNames[rec.label]) { out.skipped++; return; }
      var key = core.pairKey(rec.a, rec.b);
      if (rec.key !== key || key.indexOf("NaN") !== -1) { out.skipped++; return; }
      var at = typeof rec.labeledAt === "number" ? rec.labeledAt : Date.parse(rec.labeledAt) || 0;
      var cur = next.get(key);
      if (cur && cur.labeledAt >= at) { out.kept++; return; }
      if (cur) out.updated++; else out.added++;
      var merged = Object.assign({}, rec, { key: key, a: Number(rec.a), b: Number(rec.b), labeledAt: at });
      next.set(key, merged);
      out.writes.push([key, merged]);
    });
    return out;
  }

  // Persisted results are current when stored by this result version at this tile threshold.
  // Records from 0.1.0 (no rv, no photometric or framing fields) and other thresholds are
  // stale and checked again. A "no sprite" record has no summary.
  function isCurrentRecord(x, tmd) {
    if (!x) return false;
    if (x.nosprite) return x.rv === RESULT_VERSION && x.tmd === tmd;
    var s = x.summary;
    return !!s && x.rv === RESULT_VERSION && s.rv === RESULT_VERSION && s.tmd === tmd && "barsA" in s && "brightness" in s;
  }
  function currentVerifyRecords(records, tmd) {
    return records.filter(function (x) { return isCurrentRecord(x, tmd); });
  }

  // Key of the card to focus after moving delta places; focus is tracked by pair key.
  function moveFocus(keys, focusKey, delta) {
    if (!keys.length) return null;
    var i = keys.indexOf(focusKey);
    if (i < 0) i = 0;
    return keys[Math.max(0, Math.min(keys.length - 1, i + delta))];
  }

  // ─── Module exports (Node) ───────────────────────────────────────────

  var exported = {
    ROUTE: ROUTE, PAGE_SIZE: PAGE_SIZE, DEFAULT_SETTINGS: DEFAULT_SETTINGS, INDEX_QUERY: INDEX_QUERY, DETAILS_QUERY: DETAILS_QUERY,
    gql: gql, buildRows: buildRows, makePairs: makePairs, filterTriples: filterTriples, histogram: histogram,
    fmtClock: fmtClock, fmtSize: fmtSize, fmtSigned: fmtSigned, summarise: summarise,
    RESULT_VERSION: RESULT_VERSION, verdictOf: verdictOf, durationCounts: durationCounts, buildPairList: buildPairList, createRunner: createRunner, withTimeout: withTimeout, clearNoSprite: clearNoSprite, askThresholdChange: askThresholdChange, loadSprite: loadSprite, loadCues: loadCues, fmtInt: fmtInt, isCurrentRecord: isCurrentRecord,
    effectiveVerify: effectiveVerify, buildExport: buildExport, mergeImport: mergeImport, moveFocus: moveFocus, currentVerifyRecords: currentVerifyRecords,
    LABELS: LABELS, TIPS: TIPS, ROW_TIPS: ROW_TIPS, ROWS: ROWS, verdictTip: verdictTip, durationTip: durationTip,
  };
  if (typeof module === "object" && module.exports) module.exports = exported;
  if (root) root.DuplicateFinderUi = exported;

  // ─── Stash UI ────────────────────────────────────────────────────────

  var api = root && root.PluginApi;
  if (!api) return;

  var React = api.React;
  var h = React.createElement;
  var useCallback = React.useCallback;
  var useEffect = React.useEffect;
  var useMemo = React.useMemo;
  var useRef = React.useRef;
  var useState = React.useState;
  var libs = api.libraries || {};
  var Router = libs.ReactRouterDOM;
  var Bootstrap = libs.Bootstrap || {};
  var FontAwesomeIcon = libs.ReactFontAwesome && libs.ReactFontAwesome.FontAwesomeIcon;
  var solidIcons = libs.FontAwesomeSolid || {};
  var Button = Bootstrap.Button || "button";
  var Nav = Bootstrap.Nav;
  var ProgressBar = Bootstrap.ProgressBar;

  function btn(props, children) {
    var p = Object.assign({ type: "button" }, props);
    if (Button !== "button") p = Object.assign({ size: "sm" }, p);
    else p.className = "btn btn-" + (props.variant || "secondary") + " btn-sm " + (props.className || "");
    return h(Button, p, children);
  }

  function progress(value, max, label) {
    var pct = max ? Math.min(100, Math.round((value / max) * 100)) : 0;
    if (ProgressBar) return h("div", { className: "df-progress" }, h(ProgressBar, { now: pct, label: label || pct + "%" }));
    return h("div", { className: "df-progress" }, h("progress", { value: value, max: max || 1 }), " ", label || pct + "%");
  }

  function icon() {
    var faClone = solidIcons.faClone;
    if (!FontAwesomeIcon || !faClone) return null;
    return h(FontAwesomeIcon, { icon: faClone, className: "fa-icon" });
  }

  function closeNavMenu() {
    var toggle = document.querySelector(".top-nav .nav-menu-toggle");
    if (toggle && document.querySelector(".top-nav .navbar-collapse.show")) toggle.click();
  }

  function NavButton() {
    return h(Router.NavLink, { className: "nav-utility duplicate-finder-nav", exact: true, to: ROUTE, onClick: closeNavMenu },
      h("button", { type: "button", className: "btn minimal d-flex align-items-center h-100", title: "Duplicate finder", "aria-label": "Duplicate finder" },
        icon() || "Duplicates"));
  }

  // Cards ---------------------------------------------------------------

  function Strip(props) {
    var cues = props.cues;
    var scale = 104 / cues.cues[0].w;
    var tileH = Math.round(cues.cues[0].h * scale);
    return h("div", { className: "df-strip" }, props.indices.map(function (idx, n) {
      var c = cues.cues[idx];
      var url = "/scenes/" + props.id + "?t=" + Math.floor(c.start);
      return h("a", { key: n, className: "df-tile", href: url, target: "_blank", rel: "noopener", title: "Open at " + fmtClock(c.start) },
        h("div", {
          className: "df-tile-img",
          style: {
            height: tileH + "px",
            backgroundImage: "url(" + cues.sprite + ")",
            backgroundSize: cues.sw * scale + "px " + cues.sh * scale + "px",
            backgroundPosition: -c.x * scale + "px " + -c.y * scale + "px",
          },
        }),
        h("div", { className: "df-tile-time" }, fmtClock(c.start)));
    }));
  }

  function MetaCell(props) {
    var row = props.row;
    var side = props.side;
    var cmp = row.cmp;
    var cls = "df-cell";
    var badge = null;
    var tip;
    if (cmp === "equal") { cls += " df-equal"; tip = TIPS.equal; }
    else if (cmp === side) {
      if (row.date) badge = h("span", { className: "df-badge df-badge-date df-tip", title: TIPS.older }, "older");
      else { cls += " df-better"; tip = TIPS.better; }
    } else if (cmp && row.date) badge = h("span", { className: "df-badge df-badge-date df-tip", title: TIPS.newer }, "newer");
    var text = side === "a" ? row.a : row.b;
    var content = text;
    if (row.link) content = h("a", { href: "/scenes/" + props.id, target: "_blank", rel: "noopener" }, text);
    return h("td", { className: cls, title: tip }, content, badge);
  }

  function Header(props) {
    var p = props.pair;
    var v = props.verify;
    var done = v && v.status === "done";
    var verdict = verdictOf(getCore(), v, props.settings);
    var parts = [];
    if (done) {
      var s = v.summary;
      var confirmed = verdict.status === "confirmed";
      var minCov = props.settings && props.settings.minCoverage != null ? props.settings.minCoverage : getCore().DEFAULTS.minCoverage;
      parts.push(h("span", { key: "verdict", className: "df-chip df-tip df-verdict df-verdict-" + verdict.status, title: verdictTip(verdict.status, s, minCov) },
        (confirmed ? "Confirmed" : "Not confirmed") + " · coverage " + fmtPct(s.coverage)));
    } else {
      var text = !v ? "Not checked" : v.status === "verifying" ? "Checking…" : v.status === "nosprite" ? "No sprite" : "Check failed: " + v.error;
      var stTip = !v ? TIPS.notChecked : v.status === "verifying" ? TIPS.checking : v.status === "nosprite" ? TIPS.noSprite : TIPS.failed;
      parts.push(h("span", { key: "verdict", className: "df-chip df-tip df-verdict df-verdict-unchecked df-status-" + (v ? v.status : "none"), title: stTip }, text));
    }
    parts.push(
      h("span", { key: "d", className: "df-chip df-tip df-chip-main", title: TIPS.distance }, "d " + p.d),
      h("span", { key: "dur", className: "df-chip df-tip" + (p.durationMatch ? "" : " df-chip-warn"), title: durationTip(p, props.settings) }, "Δ " + fmtSigned(p.durB - p.durA, 1) + " s"),
      h("span", { key: "score", className: "df-chip df-tip", title: TIPS.score }, "score " + p.score));
    if (done) {
      var r = v.summary;
      parts.push(
        h("span", { key: "off", className: "df-chip df-tip", title: TIPS.offset }, "offset " + (r.offset === null ? "–" : fmtSigned(r.offset, 1) + " s")),
        h("span", { key: "foc", className: "df-chip df-tip", title: TIPS.focus }, "focus " + fmtPct(r.focus)),
        h("span", { key: "ssim", className: "df-chip df-tip", title: TIPS.ssim }, "SSIM " + (r.meanSsim === null ? "–" : r.meanSsim.toFixed(2))),
        h("span", { key: "ovl", className: "df-chip df-tip", title: TIPS.overlap }, "overlap " + fmtPct(r.overlapOfShorter)),
        h("span", { key: "m", className: "df-chip df-tip", title: TIPS.tiles }, r.matched + "/" + r.overlapTiles + " tiles"),
        h("span", { key: "f", className: "df-chip df-tip", title: TIPS.flat }, "flat " + r.flatA + "/" + r.flatB));
      if (r.insufficient) parts.push(h("span", { key: "ins", className: "df-chip df-tip df-chip-warn", title: TIPS.insufficient }, "insufficient overlap"));
    }
    var badges = [];
    if (verdict.status === "confirmed") {
      if (verdict.framing) badges.push(h("span", { key: "framing", className: "df-chip df-tip df-diff df-diff-framing", title: verdict.framing.detail + ". " + TIPS.framing }, h("b", null, "Framing"), " " + verdict.framing.detail));
      if (verdict.colour) badges.push(h("span", { key: "colour", className: "df-chip df-tip df-diff df-diff-colour", title: verdict.colour.detail + ". " + TIPS.colour }, h("b", null, "Colour"), " " + verdict.colour.detail));
    }
    return h("div", { className: "df-card-head" }, parts, badges.length ? h("div", { className: "df-diffs" }, badges) : null);
  }

  function Card(props) {
    var core = getCore();
    var p = props.pair;
    var rec = props.label;
    var note = props.note;
    var detA = props.details.get(String(p.a));
    var detB = props.details.get(String(p.b));
    var cuesA = props.cues.get(p.a);
    var cuesB = props.cues.get(p.b);
    var v = props.verify;
    var offset = v && v.status === "done" && v.summary.offset !== null ? v.summary.offset : null;

    var strips = null;
    if (cuesA && cuesB && cuesA.status === "ok" && cuesB.status === "ok") {
      var timesA = cuesA.cues.map(function (c) { return c.start; });
      var timesB = cuesB.cues.map(function (c) { return c.start; });
      var pairsIdx = core.stripPairs(timesA, timesB, p.durA, p.durB, offset, STRIP_COUNT);
      strips = h("div", { className: "df-strips" },
        h("div", { className: "df-strip-row" }, h("span", { className: "df-strip-label df-tip", title: TIPS.stripA }, "A"), h(Strip, { id: p.a, cues: cuesA, indices: pairsIdx.map(function (x) { return x[0]; }) })),
        h("div", { className: "df-strip-row" }, h("span", { className: "df-strip-label df-tip", title: TIPS.stripB }, "B"), h(Strip, { id: p.b, cues: cuesB, indices: pairsIdx.map(function (x) { return x[1]; }) })));
    } else if ((cuesA && cuesA.status !== "ok" && cuesA.status !== "loading") || (cuesB && cuesB.status !== "ok" && cuesB.status !== "loading")) {
      strips = h("div", { className: "df-muted" }, "No sprite for " + (cuesA && cuesA.status !== "ok" ? "A" : "B") + (cuesA && cuesB && cuesA.status !== "ok" && cuesB.status !== "ok" ? " and B" : "") + ".");
    } else {
      strips = h("div", { className: "df-muted" }, "Loading thumbnails…");
    }

    var table = null;
    if (detA && detB) {
      var rows = buildRows(core, detA, detB);
      table = h("table", { className: "df-meta" },
        h("thead", null, h("tr", null, h("th"), h("th", null, "A · #" + p.a), h("th", null, "B · #" + p.b))),
        h("tbody", null, rows.map(function (row) {
          return h("tr", { key: row.label }, h("th", { className: ROW_TIPS[row.label] ? "df-tip" : undefined, title: ROW_TIPS[row.label] }, row.label), h(MetaCell, { row: row, side: "a", id: p.a }), h(MetaCell, { row: row, side: "b", id: p.b }));
        })));
    } else {
      table = h("div", { className: props.detailsError ? "df-error" : "df-muted" }, props.detailsError ? "Details unavailable." : "Loading details…");
    }

    return h("div", { className: "df-card" + (props.focused ? " df-focused" : "") + (rec ? " df-labeled df-label-" + rec.label : ""), onClick: props.onFocus, "data-key": p.key },
      h(Header, { pair: p, verify: v, settings: props.settings }),
      strips,
      table,
      h("div", { className: "df-labels" },
        Object.keys(LABELS).map(function (k, n) {
          var active = rec && rec.label === k;
          return h("span", { key: k }, btn({
            variant: active ? (k === "dup" ? "success" : k === "not" ? "danger" : "warning") : "outline-secondary",
            className: "df-label-btn" + (active ? " df-active" : ""),
            onClick: function () { props.onLabel(p, k, "toggle"); },
            title: "Key " + (n + 1),
          }, (n + 1) + " " + LABELS[k]), " ");
        }),
        h("input", {
          type: "text", className: "form-control form-control-sm df-note", placeholder: "Note (optional)", value: note,
          onChange: function (e) { props.onNote(p.key, e.target.value); },
          onBlur: function () { props.onNoteCommit(p); },
        })));
  }

  // Focus is tracked by pair key and the page order is frozen by the caller, so a key press
  // always labels the card that is highlighted.
  function PairList(props) {
    var focusState = useState(null);
    var pairs = props.pairs;
    var keys = pairs.map(function (p) { return p.key; });
    var focusKey = focusState[0] !== null && keys.indexOf(focusState[0]) !== -1 ? focusState[0] : keys[0] || null;
    var ref = useRef({});
    ref.current = { keys: keys, pairs: pairs, focusKey: focusKey, onLabel: props.onLabel };

    useEffect(function () {
      function onKey(e) {
        var t = e.target;
        var tag = t && t.tagName ? t.tagName.toLowerCase() : "";
        if (tag === "input" || tag === "textarea" || tag === "select" || (t && t.isContentEditable)) return;
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        var s = ref.current;
        if (!s.keys.length) return;
        if (e.key === "j" || e.key === "k") {
          var next = moveFocus(s.keys, s.focusKey, e.key === "j" ? 1 : -1);
          focusState[1](next);
          var el = document.querySelector('.df-card[data-key="' + next + '"]');
          if (el && el.scrollIntoView) el.scrollIntoView({ block: "start", behavior: "smooth" });
        } else if (LABEL_KEYS[e.key]) {
          if (e.repeat) return;
          var pair = s.pairs[s.keys.indexOf(s.focusKey)];
          if (pair) s.onLabel(pair, LABEL_KEYS[e.key], "set");
        }
      }
      document.addEventListener("keydown", onKey);
      return function () { document.removeEventListener("keydown", onKey); };
    }, []);

    if (!pairs.length) return h("div", { className: "df-muted" }, "No pairs to show.");
    return h("div", { className: "df-list" }, pairs.map(function (p) {
      return h(Card, {
        key: p.key, pair: p, focused: p.key === focusKey, onFocus: function () { focusState[1](p.key); },
        details: props.details, detailsError: props.detailsError, cues: props.cues, verify: props.vmap.get(p.key), settings: props.settings, label: props.labels.get(p.key),
        note: props.notes.has(p.key) ? props.notes.get(p.key) : props.labels.has(p.key) ? props.labels.get(p.key).note || "" : "",
        onLabel: props.onLabel, onNote: props.onNote, onNoteCommit: props.onNoteCommit,
      });
    }));
  }

  function Pager(props) {
    var pages = Math.max(1, Math.ceil(props.total / PAGE_SIZE));
    return h("div", { className: "df-pager" },
      btn({ disabled: props.page <= 0, onClick: function () { props.onPage(props.page - 1); } }, "‹ Prev"),
      h("span", { className: "df-pager-text" }, "Page " + (props.page + 1) + " of " + pages + " · " + props.total + " pairs"),
      btn({ disabled: props.page >= pages - 1, onClick: function () { props.onPage(props.page + 1); } }, "Next ›"));
  }

  function fieldLabel(props) {
    return h("span", { className: props.tip ? "df-tip" : undefined, title: props.tip }, props.label);
  }

  function NumberField(props) {
    return h("label", { className: "df-field" }, fieldLabel(props),
      h("input", {
        type: "number", className: "form-control form-control-sm", value: props.value === null || props.value === undefined ? "" : props.value,
        min: props.min, max: props.max, step: props.step || 1,
        onChange: function (e) { var t = e.target.value; props.onChange(t === "" ? null : Number(t)); },
      }));
  }

  // A number applied on blur or Enter, not on every keystroke.
  function CommitField(props) {
    var draftState = useState(null);
    var draft = draftState[0];
    function commit() {
      draftState[1](null);
      if (draft !== null && draft !== "") props.onCommit(Number(draft));
    }
    return h("label", { className: "df-field" }, fieldLabel(props),
      h("input", {
        type: "number", className: "form-control form-control-sm", value: draft !== null ? draft : props.value,
        min: props.min, max: props.max, step: 1,
        onChange: function (e) { draftState[1](e.target.value); },
        onBlur: commit,
        onKeyDown: function (e) { if (e.key === "Enter") commit(); },
      }));
  }

  // Results --------------------------------------------------------------

  function StatsTable(props) {
    return h("table", { className: "df-stats" },
      h("thead", null, h("tr", null, [["", props.tip], ["Duplicate", TIPS.statsDup], ["Not", TIPS.statsNot], ["Unsure", TIPS.statsUnsure], ["Total", TIPS.statsTotal], ["Dup share", TIPS.statsShare]].map(function (t, i) { return h("th", { key: i, className: t[1] ? "df-tip" : undefined, title: t[1] }, t[0] || (i === 0 && props.title) || ""); }))),
      h("tbody", null, props.rows.length ? props.rows.map(function (r) {
        return h("tr", { key: r.key }, h("th", null, props.name(r.key)), h("td", null, r.dup), h("td", null, r.not), h("td", null, r.unsure), h("td", null, r.total), h("td", null, fmtPct(r.total ? r.dup / r.total : 0)));
      }) : h("tr", null, h("td", { colSpan: 6, className: "df-muted" }, "No labels yet."))));
  }

  function Results(props) {
    var core = getCore();
    var stats = useMemo(function () {
      var rows = [];
      props.labels.forEach(function (rec) {
        var v = effectiveVerify(rec, props.vmap, props.tmd);
        var coverage = v && typeof v.coverage === "number" ? v.coverage : null;
        rows.push({ d: rec.d, coverage: coverage, label: rec.label });
      });
      return core.labelStats(rows);
    }, [props.labels, props.vmap, props.tmd]);
    var fileInput = useRef(null);
    return h("div", { className: "df-results" },
      h("div", { className: "df-toolbar" },
        btn({ onClick: props.onExport }, "Export JSON"), " ",
        btn({ onClick: function () { fileInput.current && fileInput.current.click(); } }, "Import JSON"),
        h("input", { ref: fileInput, type: "file", accept: "application/json,.json", hidden: true, onChange: function (e) { var f = e.target.files && e.target.files[0]; if (f) props.onImport(f); e.target.value = ""; } }),
        props.message ? h("span", { className: "df-muted df-msg" }, props.message) : null),
      h("p", { className: "df-muted" }, "Dup share is duplicates divided by all labeled pairs in the row. Coverage buckets are [x, x+0.1) of verified coverage."),
      h("h4", null, "By distance"),
      h(StatsTable, { rows: stats.byDistance, title: "Distance", tip: TIPS.statsDistance, name: function (k) { return "d " + k; } }),
      h("h4", null, "By coverage"),
      h(StatsTable, { rows: stats.byCoverage, title: "Coverage", tip: TIPS.statsCoverage, name: function (k) { return k === "unverified" ? "unverified" : k + "–" + (Number(k) + 0.1).toFixed(1); } }));
  }

  // Page -----------------------------------------------------------------

  function Page() {
    var core = getCore();
    var defaults = useMemo(function () { return Object.assign({}, DEFAULT_SETTINGS, { tileMaxDistance: core.DEFAULTS.tileMaxDistance, maxDurationDiff: core.DEFAULTS.maxDurationDiff, minCoverage: core.DEFAULTS.minCoverage }); }, []);
    var storeRef = useRef(null);
    var bootState = useState("opening");
    var settingsState = useState(defaults);
    var settings = settingsState[0];
    var settingsRef = useRef(settings);
    settingsRef.current = settings;
    var indexState = useState(null);
    var index = indexState[0];
    var loadState = useState({ status: "idle", loaded: 0, total: 0, error: null });
    var load = loadState[0];
    var searchState = useState({ status: "idle", ms: null, triples: null, cached: false, error: null });
    var search = searchState[0];
    var labelsState = useState(new Map());
    var labels = labelsState[0];
    var labelsRef = useRef(labels);
    labelsRef.current = labels;
    var vmapState = useState(new Map());
    var vmap = vmapState[0];
    var vmapRef = useRef(vmap);
    var tabState = useState("pairs");
    var tab = tabState[0];
    var tickState = useState(0);
    var pageState = useState(0);
    var browseState = useState({ minD: 0, maxD: 16, dur: "any", includeLong: false, label: "any", status: "all", framing: false, colour: false, sort: "distance" });
    var browse = browseState[0];
    var msgState = useState("");
    var warnState = useState([]);
    var detailsErrState = useState(null);
    var retryState = useState(0);
    var listRevState = useState(0);
    var notesRef = useRef(new Map());
    var genRef = useRef(0);
    var pairsRec = useRef(null);
    var pairsNowRef = useRef([]);
    var detailsRef = useRef(new Map());
    var detailPromises = useRef(new Map());
    var cuesRef = useRef(new Map());
    var cuePromises = useRef(new Map());
    var featRef = useRef(new Map());
    var aliveRef = useRef(true);
    var unsavedRef = useRef(0); // check results that could not be written to browser storage
    var autoRef = useRef(null); // the runner for the shown page
    var bulkRef = useRef(null); // the Check all runner, kept while the user browses
    var visibleIdsRef = useRef(new Set());
    var prefetchedRef = useRef({ list: null, upTo: 0, from: 0 });
    var limits = useRef({ scene: limiter(SCENE_CONCURRENCY), vtt: limiter(VTT_CONCURRENCY) });
    var bump = useCallback(function () { if (aliveRef.current) tickState[1](function (t) { return t + 1; }); }, []);
    // After the page is left nothing may start or write: stop both runners and invalidate results in flight.
    useEffect(function () {
      aliveRef.current = true;
      return function () {
        aliveRef.current = false;
        genRef.current++;
        if (bulkRef.current) bulkRef.current.stop();
        if (autoRef.current) autoRef.current.stop();
      };
    }, []);

    // Storage failures that lose user data are shown, never swallowed.
    function warn(message) {
      if (!aliveRef.current) return;
      warnState[1](function (w) { return w.indexOf(message) === -1 ? w.concat([message]) : w; });
    }
    function persist(promise, what) {
      if (!promise) return Promise.resolve(false);
      return promise.then(function () { return true; }, function (e) {
        warn("Not saved: " + what + " could not be written to browser storage (" + (e && e.message ? e.message : "unknown error") + "). Export your labels now.");
        return false;
      });
    }

    function setSettings(patch) {
      var next = Object.assign({}, settingsRef.current, patch);
      settingsRef.current = next;
      settingsState[1](next);
      if (storeRef.current) persist(storeRef.current.put("meta", "settings", next), "the settings");
    }

    function writeVerify(key, entry) {
      if (!aliveRef.current) return;
      var next = new Map(vmapRef.current);
      if (entry) next.set(key, entry); else next.delete(key);
      vmapRef.current = next;
      vmapState[1](next);
    }

    // Boot: open storage, then restore settings, labels, verify summaries and the index.
    useEffect(function () {
      var cancelled = false;
      openStore().then(function (store) {
        storeRef.current = store;
        return Promise.all([store.get("meta", "settings"), store.all("labels"), store.all("verify"), store.get("meta", "index"), store.get("meta", "pairs")]).then(function (r) {
          if (cancelled) return;
          if (r[0]) { settingsRef.current = Object.assign({}, defaults, r[0]); settingsState[1](settingsRef.current); }
          labelsState[1](new Map(r[1].map(function (x) { return [x.key, x]; })));
          var vm = new Map();
          var fresh = currentVerifyRecords(r[2], settingsRef.current.tileMaxDistance);
          fresh.forEach(function (x) { vm.set(x.key, x.nosprite ? { status: "nosprite" } : { status: "done", summary: x.summary }); });
          if (fresh.length !== r[2].length) {
            var freshSet = new Set(fresh);
            r[2].forEach(function (x) { if (x && !freshSet.has(x)) quiet(store.remove("verify", x.key)); });
          }
          vmapRef.current = vm;
          vmapState[1](vm);
          pairsRec.current = r[4] || null;
          bootState[1]("ready");
          if (r[3]) indexState[1](r[3]); else loadIndex();
        });
      }).catch(function (e) { if (!cancelled) loadState[1]({ status: "error", loaded: 0, total: 0, error: e.message }); });
      return function () { cancelled = true; };
    }, []);

    function loadIndex() {
      // Reload starts from clean in-memory caches; persisted verify summaries stay.
      detailsRef.current.clear();
      detailPromises.current.clear();
      cuesRef.current.clear();
      cuePromises.current.clear();
      featRef.current.clear();
      genRef.current++;
      stopBulk();
      var kept = new Map();
      vmapRef.current.forEach(function (v, k) { if (v.status === "done" || v.status === "nosprite") kept.set(k, v); });
      vmapRef.current = kept;
      vmapState[1](kept);
      detailsErrState[1](null);
      bump();
      loadState[1]({ status: "loading", loaded: 0, total: 0, error: null });
      fetchIndex(core, function (loaded, total) { loadState[1]({ status: "loading", loaded: loaded, total: total, error: null }); }).then(function (idx) {
        pairsRec.current = null;
        if (storeRef.current) quiet(Promise.all([storeRef.current.put("meta", "index", idx), storeRef.current.remove("meta", "pairs")]));
        loadState[1]({ status: "ready", loaded: idx.total, total: idx.total, error: null });
        indexState[1](idx);
      }, function (e) { loadState[1]({ status: "error", loaded: 0, total: 0, error: e.message }); });
    }

    // Candidate search.
    useEffect(function () {
      if (!index) return;
      var cancelled = false;
      var ceiling = settings.ceiling;
      var rec = pairsRec.current;
      if (rec && rec.indexAt === index.loadedAt && rec.ceiling >= ceiling) {
        searchState[1]({ status: "ready", ms: rec.ms, triples: rec.ceiling === ceiling ? rec.triples : filterTriples(rec.triples, ceiling), cached: true, error: null });
        return;
      }
      searchState[1]({ status: "running", ms: null, triples: null, cached: false, error: null });
      var t0 = now();
      core.findPairsParallel(index.hi, index.lo, ceiling).then(function (triples) {
        if (cancelled) return;
        var ms = now() - t0;
        pairsRec.current = { ceiling: ceiling, indexAt: index.loadedAt, ms: ms, triples: triples };
        if (storeRef.current) quiet(storeRef.current.put("meta", "pairs", pairsRec.current));
        searchState[1]({ status: "ready", ms: ms, triples: triples, cached: false, error: null });
      }, function (e) { if (!cancelled) searchState[1]({ status: "error", ms: null, triples: null, cached: false, error: e.message }); });
      return function () { cancelled = true; };
    }, [index, settings.ceiling]);

    var pairs = useMemo(function () {
      return index && search.triples ? makePairs(core, index, search.triples, settings.durationTolerance) : [];
    }, [index, search.triples, settings.durationTolerance]);
    pairsNowRef.current = pairs;
    var hist = useMemo(function () { return search.triples ? histogram(search.triples, settings.ceiling) : []; }, [search.triples, settings.ceiling]);

    var sampleMax = settings.maxDistance === null ? settings.ceiling : settings.maxDistance;
    var sample = useMemo(function () {
      return core.stratifiedSample(pairs, { perStratum: settings.perStratum, seed: settings.seed, minDistance: settings.minDistance, maxDistance: sampleMax });
    }, [pairs, settings.perStratum, settings.seed, settings.minDistance, sampleMax]);

    // The order of a list is computed when the user changes tab, sort or a filter, or presses
    // Refresh, and then frozen: label, verify and page changes never move cards under the cursor.
    var browseList = useMemo(function () {
      if (tab !== "pairs") return [];
      return buildPairList(core, pairs, browse, { labels: labelsRef.current, vmap: vmapRef.current, settings: settingsRef.current });
    }, [tab, pairs, browse, settings.maxDurationDiff, settings.minCoverage, listRevState[0]]);
    var counts = useMemo(function () { return durationCounts(core, pairs, settings); }, [pairs, settings.maxDurationDiff]);

    var activeList = tab === "sample" ? sample : tab === "pairs" ? browseList : [];
    var pageCount = Math.max(1, Math.ceil(activeList.length / PAGE_SIZE));
    var page = Math.min(pageState[0], pageCount - 1);
    var visible = useMemo(function () { return activeList.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE); }, [activeList, page]);

    // Details, fetched once per page in one query by ids.
    function ensureDetails(ids) {
      var missing = [];
      var waits = [];
      ids.forEach(function (id) {
        id = String(id);
        if (detailsRef.current.has(id)) return;
        if (detailPromises.current.has(id)) { waits.push(detailPromises.current.get(id)); return; }
        missing.push(id);
      });
      for (var s = 0; s < missing.length; s += DETAIL_CHUNK) {
        (function (chunk) {
          var p = gql(DETAILS_QUERY, { ids: chunk, filter: { per_page: chunk.length } }).then(function (d) {
            d.findScenes.scenes.forEach(function (sc) { detailsRef.current.set(String(sc.id), sc); });
            chunk.forEach(function (id) { detailPromises.current.delete(id); });
            bump();
          }, function (e) { chunk.forEach(function (id) { detailPromises.current.delete(id); }); throw e; });
          chunk.forEach(function (id) { detailPromises.current.set(id, p); });
          waits.push(p);
        })(missing.slice(s, s + DETAIL_CHUNK));
      }
      return Promise.all(waits);
    }

    // Check all walks thousands of scenes: drop details and cues that neither the shown page nor
    // the running Check all's look-ahead window (the pairs just done up to those prefetched) uses.
    function trimCaches() {
      if (detailsRef.current.size <= CACHE_TRIM && cuesRef.current.size <= CACHE_TRIM) return;
      var keep = new Set(visibleIdsRef.current);
      var pf = prefetchedRef.current;
      if (pf.list && bulkRef.current && bulkRef.current.state().status !== "stopped" && bulkRef.current.state().status !== "finished") {
        pf.list.slice(Math.max(0, pf.from - 4), pf.upTo).forEach(function (p) { keep.add(p.a); keep.add(p.b); });
      }
      [detailsRef.current, cuesRef.current].forEach(function (m) {
        Array.from(m.keys()).forEach(function (k) {
          if (!keep.has(Number(k)) && !detailPromises.current.has(String(k)) && !cuePromises.current.has(k)) m.delete(k);
        });
      });
    }

    // Cues (VTT) for the strips; cheap, so cards request them as soon as details arrive.
    function requestCues(id) {
      if (cuesRef.current.has(id) && cuesRef.current.get(id).status !== "failed") return Promise.resolve(cuesRef.current.get(id));
      if (cuePromises.current.has(id)) return cuePromises.current.get(id);
      var p = ensureDetails([id]).then(function () {
        var det = detailsRef.current.get(String(id));
        if (!det || !det.paths || !det.paths.vtt || !det.paths.sprite) return { status: "nosprite" };
        return limits.current.vtt(function () { return loadCues(core, det, fetch, TIMEOUT_MS); });
      }).catch(function (e) { return { status: "failed", error: e.message }; }).then(function (res) {
        cuePromises.current.delete(id);
        cuesRef.current.set(id, res);
        bump();
        return res;
      });
      cuePromises.current.set(id, p);
      return p;
    }

    // Whole sprites (gray pixels + cues) in an LRU of recent scenes; never persisted. The core
    // memoises tile features on each sprite object, so evicting a sprite frees them too.
    function loadFeatures(id) {
      var lru = featRef.current;
      if (lru.has(id)) { var hit = lru.get(id); lru.delete(id); lru.set(id, hit); return hit; }
      var p = limits.current.scene(function () {
        return requestCues(id).then(function (c) {
          if (c.status === "failed") throw new Error(c.error);
          if (c.status !== "ok") return { status: "nosprite" };
          return loadSprite(core, c.sprite, c.cues).then(function (sprite) { return { status: "ok", sprite: sprite }; });
        });
      }).catch(function (e) {
        lru.delete(id);
        throw e;
      });
      lru.set(id, p);
      while (lru.size > LRU_SIZE) lru.delete(lru.keys().next().value);
      return p;
    }

    // Resolves when the pair has a result or was discarded; rejects when the check failed, so
    // the runner counts it. Failures are never persisted.
    function runVerify(pair) {
      var t0 = now();
      var gen = genRef.current;
      var tmd = settingsRef.current.tileMaxDistance;
      // A result from an older threshold or run is discarded: never written, never deleted.
      var current = function () { return gen === genRef.current && aliveRef.current; };
      var save = function (record, what) {
        if (!storeRef.current) return;
        persist(storeRef.current.put("verify", pair.key, record), what).then(function (ok) { if (!ok) { unsavedRef.current++; bump(); } });
      };
      writeVerify(pair.key, { status: "verifying" });
      // Persisted only when the scene has no sprite or VTT (a 404 or no path).
      var markNoSprite = function (store) {
        if (store) save({ key: pair.key, rv: RESULT_VERSION, tmd: tmd, nosprite: true }, "a check result");
        writeVerify(pair.key, { status: "nosprite" });
      };
      return Promise.all([loadFeatures(pair.a), loadFeatures(pair.b)]).then(function (fs) {
        if (!current()) return;
        if (fs[0].status !== "ok" || fs[1].status !== "ok") return markNoSprite(true);
        var res = core.confirmPair(fs[0].sprite, fs[1].sprite, pair.durA, pair.durB, { tileMaxDistance: tmd });
        if (!res) return markNoSprite(false); // no comparable frames: shown, but checked again next time
        var summary = summarise(res, tmd, now() - t0);
        save({ key: pair.key, rv: RESULT_VERSION, summary: summary }, "a check result"); // matches are not kept: nothing reads them later
        writeVerify(pair.key, { status: "done", summary: summary });
        var rec = labelsRef.current.get(pair.key);
        if (rec) {
          // Keep a labelled pair's snapshot current.
          var updated = Object.assign({}, rec, { verify: summary });
          var next = new Map(labelsRef.current);
          next.set(pair.key, updated);
          labelsRef.current = next;
          labelsState[1](next);
          if (storeRef.current) persist(storeRef.current.put("labels", pair.key, updated), "a label's verify snapshot");
        }
      }).catch(function (e) {
        if (current()) writeVerify(pair.key, { status: "failed", error: e && e.message ? e.message : String(e) });
        if (current()) throw e;
      });
    }

    // A pair needs a check when it has no current result (cached results are skipped, which is
    // how Check all resumes after a reload) and nobody is checking it right now.
    function needsCheck(pair) {
      var known = vmapRef.current.get(pair.key);
      return !known || known.status === "failed";
    }

    // The pairs on the shown page are checked automatically; changing page, filter or
    // threshold cancels the ones not yet started.
    useEffect(function () {
      visibleIdsRef.current = new Set();
      visible.forEach(function (p) { visibleIdsRef.current.add(p.a); visibleIdsRef.current.add(p.b); });
      if (!visible.length) return;
      var ids = [];
      visible.forEach(function (p) { ids.push(p.a, p.b); });
      var cancelled = false;
      var runner = null;
      detailsErrState[1](null);
      ensureDetails(ids).then(function () {
        if (cancelled) return;
        ids.forEach(function (id) { requestCues(id); });
        runner = createRunner(visible, { needs: needsCheck, run: runVerify, concurrency: AUTO_CONCURRENCY, cancelled: function () { return cancelled; } });
        autoRef.current = runner;
      }).catch(function (e) { if (!cancelled) detailsErrState[1](e && e.message ? e.message : "request failed"); });
      return function () { cancelled = true; if (runner) runner.stop(); };
    }, [visible, settings.tileMaxDistance, retryState[0]]);

    function changeTileThreshold(value) {
      var stored = 0;
      vmapRef.current.forEach(function (v) { if (v.status === "done" || v.status === "nosprite") stored++; });
      if (!askThresholdChange(settingsRef.current.tileMaxDistance, value, stored, function (m) { return typeof window !== "undefined" && window.confirm ? window.confirm(m) : true; })) return;
      genRef.current++;
      stopBulk();
      vmapRef.current = new Map();
      vmapState[1](vmapRef.current);
      if (storeRef.current) quiet(storeRef.current.clear("verify"));
      setSettings({ tileMaxDistance: value });
    }

    // Check all: runs over a snapshot of the list in the background, two pairs at a time, and
    // keeps going while the user browses. Details are fetched a few pairs ahead in one query.
    function prefetchAhead(list, idx) {
      var pf = prefetchedRef.current;
      if (pf.list !== list) { pf.list = list; pf.upTo = 0; }
      pf.from = idx;
      if (pf.upTo < idx) pf.upTo = idx; // a resumed run starts past the pairs already checked
      if (idx + 10 < pf.upTo) return;
      var chunk = list.slice(pf.upTo, pf.upTo + 40);
      pf.upTo += 40;
      var ids = [];
      chunk.forEach(function (p) { ids.push(p.a, p.b); });
      if (ids.length) ensureDetails(ids).catch(function () {});
    }

    // Forgets the stored "no sprite" results so those pairs are checked again.
    function recheckNoSprite() {
      var r = clearNoSprite(vmapRef.current);
      if (!r.keys.length) return;
      vmapRef.current = r.next;
      vmapState[1](r.next);
      cuesRef.current.forEach(function (c, id) { if (c.status === "nosprite") cuesRef.current.delete(id); });
      featRef.current.clear();
      if (storeRef.current) persist(storeRef.current.putMany ? Promise.all(r.keys.map(function (k) { return storeRef.current.remove("verify", k); })) : null, "the cleared no-sprite results");
      msgState[1]("Cleared " + fmtInt(r.keys.length) + " no-sprite results; they are checked again when shown or by Check all.");
      bump();
    }

    function stopBulk() {
      if (bulkRef.current) bulkRef.current.stop();
    }

    function startCheckAll(list) {
      stopBulk();
      var gen = genRef.current;
      var runner = createRunner(list, {
        needs: needsCheck,
        concurrency: BULK_CONCURRENCY,
        cancelled: function () { return gen !== genRef.current; },
        run: function (pair, idx) {
          prefetchAhead(list, idx);
          return runVerify(pair).then(trimCaches, function (e) { trimCaches(); throw e; });
        },
        maxFailureStreak: FAIL_STREAK,
        onProgress: bump,
      });
      bulkRef.current = runner;
      msgState[1]("");
      bump();
      runner.done.then(bump);
    }

    // Labels. mode: "toggle" (button: clicking the active label clears it), "set" (keyboard:
    // never clears), "note" (a note edit on an existing label). The note is the pending text.
    function setLabel(pair, label, mode) {
      var existing = labelsRef.current.get(pair.key);
      var store = storeRef.current;
      if (!store) return;
      var next = new Map(labelsRef.current);
      var write;
      var note = notesRef.current.has(pair.key) ? notesRef.current.get(pair.key) : existing ? existing.note || "" : "";
      if (mode === "toggle" && existing && existing.label === label) {
        next.delete(pair.key);
        notesRef.current.delete(pair.key);
        write = store.remove("labels", pair.key);
      } else {
        if (mode === "set" && existing && existing.label === label && existing.note === note) return;
        var v = vmapRef.current.get(pair.key);
        var rec = { key: pair.key, a: pair.a, b: pair.b, label: label, note: note, d: pair.d, durA: pair.durA, durB: pair.durB, verify: v && v.status === "done" ? v.summary : existing ? existing.verify : null, labeledAt: Date.now() };
        next.set(pair.key, rec);
        write = store.put("labels", pair.key, rec);
      }
      labelsRef.current = next;
      labelsState[1](next);
      persist(write, "the label for pair " + pair.key);
    }

    function onNote(key, text) {
      notesRef.current.set(key, text);
      bump();
    }

    function commitNote(pair) {
      var rec = labelsRef.current.get(pair.key);
      if (rec && notesRef.current.has(pair.key) && rec.note !== notesRef.current.get(pair.key)) setLabel(pair, rec.label, "note");
    }

    function exportLabels() {
      var payload = buildExport(Array.from(labelsRef.current.values()), vmapRef.current, settingsRef.current.tileMaxDistance, pairsNowRef.current, settingsRef.current, new Date().toISOString());
      var blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = "duplicate-finder-labels-" + payload.exportedAt.slice(0, 10) + ".json";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
      msgState[1]("Exported " + payload.labels.length + " labels and " + payload.verify.length + " verify summaries.");
    }

    function importLabels(file) {
      file.text().then(function (text) {
        var data = JSON.parse(text);
        if (!data || !Array.isArray(data.labels)) throw new Error("no labels array");
        var m = mergeImport(core, labelsRef.current, data.labels, LABELS);
        var done = function (saved) {
          labelsRef.current = m.next;
          labelsState[1](m.next);
          msgState[1]((saved ? "Imported: " : "Imported into this page only (not saved): ") + m.added + " new, " + m.updated + " updated, " + m.kept + " kept (local was newer), " + m.skipped + " skipped.");
        };
        if (!m.writes.length) return done(true);
        return persist(storeRef.current ? storeRef.current.putMany("labels", m.writes) : null, "the imported labels").then(done);
      }).catch(function (e) { msgState[1]("Import failed: " + e.message); });
    }

    // Render.
    var tabs = [["pairs", "Pairs"], ["sample", "Sample"], ["results", "Results"]];
    var labeledInSample = sample.filter(function (p) { return labels.has(p.key); }).length;
    var bulk = bulkRef.current ? bulkRef.current.state() : null;
    var bulkActive = !!bulk && (bulk.status === "running" || bulk.status === "paused");
    var leftIn = function (list) { var n = 0; list.forEach(function (p) { if (needsCheck(p)) n++; }); return n; };
    var tmd = settings.tileMaxDistance;

    var header = h("div", { className: "df-info" },
      h("div", null,
        index ? h("span", { className: "df-tip", title: TIPS.index }, "Index:") : null, index ? " " + index.ids.length + " scenes with a phash" + (index.skipped ? " (" + index.skipped + " without)" : "") + ", loaded " + fmtDate(new Date(index.loadedAt).toISOString()) + " UTC" + (index.loadMs ? " in " + (index.loadMs / 1000).toFixed(1) + " s" : "") + ". " : "No index yet. ",
        btn({ disabled: load.status === "loading", onClick: loadIndex }, "Reload"),
        " ", h("span", { className: "df-muted df-tip", title: TIPS.storage }, "Storage: " + (storeRef.current ? (storeRef.current.kind === "indexeddb" ? "browser IndexedDB" : "memory only") : "opening…"))),
      load.status === "loading" ? progress(load.loaded, load.total, load.loaded + " / " + (load.total || "?") + " scenes") : null,
      load.status === "error" ? h("div", { className: "df-error" }, "Index failed: " + load.error) : null);

    var warnings = warnState[0].slice();
    if (storeRef.current && storeRef.current.kind === "memory") warnings.push("Browser storage is unavailable: labels and verify results are kept in memory only and are lost on reload. Export your labels before closing.");
    var banner = warnings.length ? h("div", { className: "df-warning", role: "alert" }, warnings.map(function (w, i) { return h("div", { key: i }, w); }), btn({ onClick: exportLabels }, "Export labels now")) : null;
    var detailsBanner = detailsErrState[0] ? h("div", { className: "df-error" }, "Could not load scene details: " + detailsErrState[0] + " ", btn({ onClick: function () { retryState[1](function (n) { return n + 1; }); } }, "Retry")) : null;

    var searchBar = index ? h("div", { className: "df-search" },
      h("label", { className: "df-field" }, h("span", { className: "df-tip", title: TIPS.ceiling }, "Distance ceiling"),
        h("select", { className: "form-control form-control-sm", value: settings.ceiling, onChange: function (e) { setSettings({ ceiling: Number(e.target.value), maxDistance: null }); pageState[1](0); } },
          [2, 4, 6, 8, 10, 12, 14, 16].filter(function (d) { return d <= MAX_CEILING; }).map(function (d) { return h("option", { key: d, value: d }, d); }))),
      h(NumberField, { label: "Max duration difference (s)", tip: TIPS.maxDurationDiff, value: settings.maxDurationDiff, min: 0, step: 1, onChange: function (v) { if (v !== null) setSettings({ maxDurationDiff: v }); } }),
      h(NumberField, { label: "Min coverage (confirmed at or above)", tip: TIPS.minCoverage, value: settings.minCoverage, min: 0, max: 1, step: 0.05, onChange: function (v) { if (v !== null) setSettings({ minCoverage: v }); } }),
      search.status === "running" ? h("span", { className: "df-muted" }, "Searching pairs…") : null,
      search.status === "error" ? h("span", { className: "df-error" }, "Search failed: " + search.error) : null,
      search.status === "ready" ? h("span", null, pairs.length + " pairs at d ≤ " + settings.ceiling + " in " + (search.ms / 1000).toFixed(1) + " s" + (search.cached ? " (cached)" : "")) : null,
      hist.length ? h("div", { className: "df-hist" }, hist.map(function (r) {
        var max = Math.max.apply(null, hist.map(function (x) { return x.count; })) || 1;
        return h("div", { key: r.d, className: "df-hist-row", title: fmtInt(r.count) + " pairs at hash distance " + r.d + ". " + TIPS.histogram }, h("span", { className: "df-hist-d" }, "d " + r.d), h("span", { className: "df-hist-bar" }, h("span", { style: { width: (r.count / max) * 100 + "%" } })), h("span", { className: "df-hist-n" }, r.count));
      })) : null) : null;

    var advanced = h("details", { className: "df-advanced" }, h("summary", null, "Advanced"),
      h("div", { className: "df-controls" },
        h(CommitField, { label: "Tile threshold (bits; applied on Enter or leaving the field, clears stored results)", tip: TIPS.tileThreshold, value: tmd, min: 0, max: 63, onCommit: changeTileThreshold }),
        h(NumberField, { label: "Duration tolerance (s)", tip: TIPS.durationTolerance, value: settings.durationTolerance, min: 0, step: 0.5, onChange: function (v) { if (v !== null) setSettings({ durationTolerance: v }); } })));

    var checkPanel = bulk ? h("div", { className: "df-bulk" },
      progress(bulk.done, bulk.total, (bulk.status === "finished" ? "Done " : bulk.status === "stopped" ? "Stopped at " : bulk.status === "paused" ? "Paused at " : "Checking ") + fmtInt(bulk.done) + " / " + fmtInt(bulk.total) + (bulk.etaMs !== null ? " · about " + fmtClock(bulk.etaMs / 1000) + " left" : "")),
      h("div", { className: "df-bulk-row" },
        bulk.status === "running" ? btn({ onClick: function () { bulkRef.current.pause(); } }, "Pause") : null,
        bulk.status === "paused" ? btn({ onClick: function () { bulkRef.current.resume(); }, variant: "primary" }, "Resume") : null,
        bulkActive ? btn({ onClick: function () { bulkRef.current.stop(); } }, "Stop") : null,
        h("span", { className: "df-muted" }, fmtInt(bulk.cached) + " already checked" + (bulk.failed ? " · " + bulk.failed + " failed" : "") + (unsavedRef.current ? " · " + unsavedRef.current + " not saved" : "") + (bulkActive ? " · keeps running while you browse Duplicate Finder, stops when you leave it" : ""))),
        bulk.message ? h("div", { className: "df-error" }, bulk.message) : null) : null;
    var noSpriteCount = 0;
    vmap.forEach(function (v) { if (v.status === "nosprite") noSpriteCount++; });

    var body = null;
    if (!index || !search.triples) {
      body = h("div", { className: "df-muted" }, load.status === "loading" ? "Loading the phash index…" : search.status === "running" ? "Searching…" : bootState[0] === "opening" ? "Opening storage…" : "");
    } else if (tab === "sample") {
      body = h("div", null,
        h("div", { className: "df-controls" },
          h(NumberField, { label: "Per stratum", tip: TIPS.perStratum, value: settings.perStratum, min: 1, onChange: function (v) { if (v) { setSettings({ perStratum: v }); pageState[1](0); } } }),
          h("label", { className: "df-field" }, h("span", { className: "df-tip", title: TIPS.seed }, "Seed"), h("input", { type: "text", className: "form-control form-control-sm", value: settings.seed, onChange: function (e) { setSettings({ seed: e.target.value }); pageState[1](0); } })),
          h(NumberField, { label: "Min distance", tip: TIPS.minDistance, value: settings.minDistance, min: 0, step: 2, onChange: function (v) { if (v !== null) { setSettings({ minDistance: v }); pageState[1](0); } } }),
          h(NumberField, { label: "Max distance", tip: TIPS.maxDistance, value: sampleMax, min: 0, max: settings.ceiling, step: 2, onChange: function (v) { if (v !== null) { setSettings({ maxDistance: v }); pageState[1](0); } } }),
          h("div", { className: "df-field df-count" }, "labeled " + labeledInSample + " / " + sample.length),
          h("div", { className: "df-field" }, btn({ onClick: function () { startCheckAll(sample); }, disabled: !sample.length || bulkActive, title: TIPS.checkAll }, "Check all in sample (" + fmtInt(leftIn(sample)) + " left)"))),
        advanced,
        h(Pager, { page: page, total: sample.length, onPage: pageState[1] }),
        h(PairList, { pairs: visible, details: detailsRef.current, detailsError: detailsErrState[0], cues: cuesRef.current, vmap: vmap, labels: labels, notes: notesRef.current, settings: settings, onLabel: setLabel, onNote: onNote, onNoteCommit: commitNote }),
        h(Pager, { page: page, total: sample.length, onPage: pageState[1] }));
    } else if (tab === "pairs") {
      var set = function (patch) { browseState[1](Object.assign({}, browse, patch)); pageState[1](0); };
      var select = function (label, key, options, tip) {
        return h("label", { className: "df-field" }, h("span", { className: tip ? "df-tip" : undefined, title: tip }, label), h("select", { className: "form-control form-control-sm", value: browse[key], onChange: function (e) { set(Object.fromEntries([[key, e.target.value]])); } }, options.map(function (o) {
          return h("option", { key: o[0], value: o[0] }, o[1]);
        })));
      };
      var check = function (label, key, tip) {
        return h("label", { className: "df-field df-check" + (tip ? " df-tip" : ""), title: tip }, h("span", null, h("input", { type: "checkbox", checked: browse[key], onChange: function (e) { set(Object.fromEntries([[key, e.target.checked]])); } }), " " + label));
      };
      var left = leftIn(browseList);
      body = h("div", null,
        h("div", { className: "df-controls" },
          h(NumberField, { label: "Min distance", tip: TIPS.minDistance, value: browse.minD, min: 0, step: 2, onChange: function (v) { set({ minD: v === null ? 0 : v }); } }),
          h(NumberField, { label: "Max distance", tip: TIPS.maxDistance, value: browse.maxD, min: 0, max: settings.ceiling, step: 2, onChange: function (v) { set({ maxD: v === null ? settings.ceiling : v }); } }),
          select("Status", "status", [["all", "all"], ["confirmed", "confirmed"], ["unconfirmed", "not confirmed"], ["unchecked", "not checked"]], TIPS.status),
          check("Has framing badge", "framing", TIPS.hasFraming),
          check("Has colour badge", "colour", TIPS.hasColour),
          select("Duration", "dur", [["any", "any"], ["same", "same"], ["different", "different"]], TIPS.durationFilter),
          select("Label", "label", ["any", "unlabeled", "labeled", "dup", "not", "unsure"].map(function (o) { return [o, o]; }), TIPS.labelFilter),
          select("Sort", "sort", [["distance", "distance"], ["score", "score"], ["coverage", "coverage (checked)"], ["duration", "duration (longest)"]], TIPS.sort),
          btn({ onClick: function () { listRevState[1](function (n) { return n + 1; }); pageState[1](0); }, title: "Apply new check results to the filters and sort" }, "Refresh list")),
        h("div", { className: "df-controls" },
          check("Include pairs more than " + settings.maxDurationDiff + " s apart", "includeLong", TIPS.includeLong),
          h("span", { className: "df-count-line" }, fmtInt(counts.within) + " pairs within " + settings.maxDurationDiff + " s of " + fmtInt(counts.total) + (browse.includeLong ? " (all shown)" : "") + " · " + fmtInt(browseList.length) + " in this list"),
          btn({ onClick: function () { startCheckAll(browseList); }, disabled: bulkActive || !left, variant: "primary", title: TIPS.checkAll }, "Check all (" + fmtInt(left) + " left of " + fmtInt(browseList.length) + ")")),
        advanced,
        h(Pager, { page: page, total: browseList.length, onPage: pageState[1] }),
        h(PairList, { pairs: visible, details: detailsRef.current, detailsError: detailsErrState[0], cues: cuesRef.current, vmap: vmap, labels: labels, notes: notesRef.current, settings: settings, onLabel: setLabel, onNote: onNote, onNoteCommit: commitNote }),
        h(Pager, { page: page, total: browseList.length, onPage: pageState[1] }));
    } else {
      body = h(Results, { labels: labels, vmap: vmap, tmd: tmd, onExport: exportLabels, onImport: importLabels, message: msgState[0] });
    }

    var tabBar = Nav
      ? h(Nav, { variant: "tabs", activeKey: tab, onSelect: function (k) { tabState[1](k); pageState[1](0); } },
        tabs.map(function (t) { return h(Nav.Item, { key: t[0] }, h(Nav.Link, { eventKey: t[0] }, t[1])); }))
      : h("ul", { className: "nav nav-tabs" }, tabs.map(function (t) {
        return h("li", { key: t[0], className: "nav-item" }, h("a", { href: "#", className: "nav-link" + (tab === t[0] ? " active" : ""), onClick: function (e) { e.preventDefault(); tabState[1](t[0]); pageState[1](0); } }, t[1]));
      }));

    return h("div", { className: "duplicate-finder" },
      h("h1", { className: "df-heading" }, "Duplicate finder ", h("span", { className: "df-badge" }, "read-only prototype")),
      header, banner, searchBar, checkPanel, noSpriteCount ? h("div", { className: "df-muted" }, fmtInt(noSpriteCount) + " pairs have no sprite or VTT. ", btn({ onClick: recheckNoSprite, disabled: bulkActive }, "Recheck no-sprite pairs")) : null, tabBar, detailsBanner, h("div", { className: "df-body" }, tab !== "results" && msgState[0] ? h("div", { className: "df-muted" }, msgState[0]) : null, body));
  }

  exported.PairList = PairList;
  exported.Header = Header;
  api.register.route(ROUTE, Page);

  api.patch.before("MainNavBar.UtilityItems", function (props) {
    return [Object.assign({}, props, {
      children: [h(NavButton, { key: "duplicate-finder" }), h(React.Fragment, { key: "stash" }, props.children)],
    })];
  });
})(typeof window !== "undefined" ? window : undefined);
