(function (root, factory) {
  var api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root && root.PluginApi) { root.SemanticTagger = api; api.install(root.PluginApi); }
})(typeof window !== "undefined" ? window : globalThis, function (window) {
  "use strict";

  // Review surface for the semantic tagger worker (semantic-tagger/ in the
  // plugin repository). The worker writes proposals into scene custom fields;
  // this plugin shows them and turns a decision into a Stash change:
  //   accept: the tag is added to the scene, the proposal removed, and its
  //           evidence kept in the scene's applied field so Stash can still
  //           show why the tag is there;
  //   reject: the tag is added to the scene's rejected list, so the worker
  //           never proposes it for that scene again; an optional reason
  //           goes to the scene's feedback field;
  //   report as wrong: for a tag applied through a proposal; removes the tag,
  //           rejects it for the scene, and records the reason as feedback;
  //   re-analyse: flags the scene for the worker's next watch cycle.
  // Nothing is written until a button is pressed, except that the page asks the
  // worker for its status when it opens. The page also holds the worker's
  // set-up (Providers and Profiles tabs) and starts its analyses (Run tab):
  // it writes this plugin's settings map, the worker reads it through GraphQL
  // and answers in its own map, "<plugin ID>-worker".

  const ID = "semanticTagger-testing";
  // Not under /plugin/: Stash's server owns that prefix for plugin assets, so
  // reloading or bookmarking such a page would never reach the web app.
  const ROUTE = "/semantic-tagger";
  const FIELDS = Object.freeze({
    pending: "semanticTagger_pending",
    proposals: "semanticTagger_proposals",
    rejected: "semanticTagger_rejected",
    request: "semanticTagger_request",
    // Written only by this plugin; the worker reads the feedback field.
    applied: "semanticTagger_applied",
    feedback: "semanticTagger_feedback",
  });
  const PAGE_SIZE = 40;
  // Defensive caps on what is stored in a custom field.
  const LIMITS = Object.freeze({ quote: 200, reason: 160, note: 500, tagName: 100, model: 120, feedback: 50, sources: 6, sourceLabel: 80 });
  // Why a tag was wrong. A missing category is allowed.
  const CATEGORIES = Object.freeze([
    { id: "not_in_text", label: "Text doesn\u2019t say this" },
    { id: "excluded", label: "Excluded by the tag\u2019s definition" },
    { id: "from_path", label: "Came from the folder or file name" },
    { id: "definition_too_broad", label: "Definition is too broad" },
    { id: "other", label: "Other" },
  ]);

  // ---------------------------------------------------------------------------
  // Field values (pure)

  function decodeIds(value) {
    const ids = [];
    String(value || "").split("|").forEach(function (part) {
      const id = part.trim();
      if (/^\d+$/.test(id) && ids.indexOf(id) === -1) ids.push(id);
    });
    return ids;
  }

  function encodeIds(ids) {
    const list = [];
    ids.forEach(function (id) { id = String(id); if (list.indexOf(id) === -1) list.push(id); });
    list.sort(function (a, b) { return Number(a) - Number(b); });
    return list.length ? "|" + list.join("|") + "|" : "";
  }

  // Why a model set-up ("source") looked at a tag and did not propose it, in words.
  const DECLINES = Object.freeze({
    not_proposed: "did not propose it",
    quote_check: "its quote failed the check",
    verify_no: "its verify pass said no",
    below_threshold: "below the confidence threshold",
    child_proposed: "proposed a more specific tag",
  });
  const SOURCE_KEY = /^[A-Za-z0-9_-]{1,32}$/;
  const CONFIDENCES = ["high", "medium", "low"];

  // The proposals field. Version 1: { v: 1, model, items: [{ t, n, f, q, c, r?, l?, p?, vm? }] }
  // (p: the decisions verifier's probability, vm: its model; both optional).
  // Version 2 adds { sources: { key: { label, model?, thinking?, verify? } } } and,
  // per item, by: [{ s, c, f?, q?, r? }] (the sources that proposed it; f, q and r
  // only where they differ from the item's) and no: [{ s, why }] (the sources
  // that looked and declined it). A version 1 item reads as one unnamed source
  // (key ""), labelled with the field's model. Tag IDs become links, so
  // anything but digits is dropped; unknown or malformed sources are skipped.
  function parseProposals(value) {
    let data;
    try { data = JSON.parse(value || "null"); } catch (_) { return { model: null, version: 1, sources: {}, items: [] }; }
    if (!data || !Array.isArray(data.items)) return { model: null, version: 1, sources: {}, items: [] };
    const version = Number(data.v) >= 2 ? 2 : 1;
    const model = data.model ? String(data.model) : null;
    const sources = {};
    if (version === 2 && isObject(data.sources)) {
      Object.keys(data.sources).forEach(function (key) {
        const entry = data.sources[key];
        if (!SOURCE_KEY.test(key) || !isObject(entry)) return;
        const out = { label: clip(entry.label || key, LIMITS.sourceLabel) || key };
        if (typeof entry.model === "string" && entry.model) out.model = clip(entry.model, LIMITS.model);
        if (typeof entry.thinking === "boolean") out.thinking = entry.thinking;
        if (typeof entry.verify === "boolean") out.verify = entry.verify;
        sources[key] = out;
      });
    }
    const label = function (key) { return sources[key] ? sources[key].label : key; };
    return {
      model: model,
      version: version,
      sources: sources,
      items: data.items.filter(function (item) { return item && item.t != null && /^\d+$/.test(String(item.t)); }).map(function (item) {
        const out = { tagId: String(item.t), tagName: String(item.n || ""), field: String(item.f || ""), quote: String(item.q || ""), confidence: String(item.c || ""), reason: String(item.r || ""), literal: !!item.l };
        // The decisions verifier's probability and model, when the worker checked the proposal with one.
        if (typeof item.p === "number" && isFinite(item.p) && item.p >= 0 && item.p <= 1) {
          out.p = Math.round(item.p * 100) / 100;
          if (typeof item.vm === "string" && item.vm) out.verifier = clip(item.vm, LIMITS.model);
        }
        if (version === 2 && Array.isArray(item.by)) {
          const seen = {};
          out.by = item.by.filter(function (entry) { return isObject(entry) && SOURCE_KEY.test(String(entry.s)) && !seen[entry.s] && (seen[entry.s] = true); }).slice(0, LIMITS.sources).map(function (entry) {
            return {
              source: String(entry.s), label: label(String(entry.s)), confidence: CONFIDENCES.indexOf(entry.c) !== -1 ? entry.c : out.confidence,
              field: entry.f != null ? String(entry.f) : out.field, quote: entry.q != null ? String(entry.q) : out.quote, reason: entry.r != null ? String(entry.r) : out.reason,
            };
          });
          const declined = {};
          out.no = (Array.isArray(item.no) ? item.no : []).filter(function (entry) { return isObject(entry) && SOURCE_KEY.test(String(entry.s)) && !seen[entry.s] && !declined[entry.s] && (declined[entry.s] = true); }).slice(0, LIMITS.sources).map(function (entry) {
            return { source: String(entry.s), label: label(String(entry.s)), why: Object.prototype.hasOwnProperty.call(DECLINES, entry.why) ? entry.why : "not_proposed" };
          });
        }
        if (!out.by || !out.by.length) {
          out.by = [{ source: "", label: model || "", confidence: out.confidence, field: out.field, quote: out.quote, reason: out.reason }];
          if (!out.no) out.no = [];
        }
        return out;
      }),
    };
  }

  // How the sources that looked at a proposal agree: "disagree" (at least one
  // proposed it and at least one declined), "agree" (two or more proposed it,
  // none declined) or "single" (only one looked).
  function agreementOf(item) {
    const by = (item && item.by || []).length, no = (item && item.no || []).length;
    if (by && no) return "disagree";
    if (by >= 2) return "agree";
    return "single";
  }

  // The sources as the applied record and feedback entries keep them: keys and labels.
  function sourceRecord(item) {
    if (!item) return {};
    const by = (item.by || []).filter(function (entry) { return entry.source; }).map(function (entry) { return { s: entry.source, label: clip(entry.label || entry.source, LIMITS.sourceLabel) }; });
    const no = (item.no || []).filter(function (entry) { return entry.source; }).map(function (entry) { return { s: entry.source, label: clip(entry.label || entry.source, LIMITS.sourceLabel), why: entry.why }; });
    const out = {};
    if (by.length) out.by = by.slice(0, LIMITS.sources);
    if (no.length) out.no = no.slice(0, LIMITS.sources);
    return out;
  }

  // A stored by or no list, defensively.
  function cleanSourceList(list, withWhy) {
    if (!Array.isArray(list)) return [];
    const out = [];
    list.forEach(function (entry) {
      if (out.length >= LIMITS.sources || !isObject(entry) || !SOURCE_KEY.test(String(entry.s))) return;
      if (out.some(function (other) { return other.s === entry.s; })) return;
      const clean = { s: String(entry.s), label: clip(entry.label, LIMITS.sourceLabel) || String(entry.s) };
      if (withWhy) clean.why = Object.prototype.hasOwnProperty.call(DECLINES, entry.why) ? entry.why : "not_proposed";
      out.push(clean);
    });
    return out;
  }

  // Pending proposals of a scene, taken from both fields: a tag counts only
  // while it is still listed as pending, and not once it is on the scene
  // (added by hand, or before the worker's next publish caught up).
  function sceneProposals(customFields, sceneTags) {
    const fields = customFields || {};
    const pending = decodeIds(fields[FIELDS.pending]);
    const present = (sceneTags || []).map(function (tag) { return String(tag && tag.id != null ? tag.id : tag); });
    const parsed = parseProposals(fields[FIELDS.proposals]);
    return {
      model: parsed.model,
      version: parsed.version,
      sources: parsed.sources,
      items: parsed.items.filter(function (item) { return pending.indexOf(item.tagId) !== -1 && present.indexOf(item.tagId) === -1; }),
    };
  }

  // ---------------------------------------------------------------------------
  // Applied evidence and feedback (pure)

  function clip(value, max) {
    const text = String(value == null ? "" : value).replace(/\s+/g, " ").trim();
    return text.length > max ? text.slice(0, max - 1).trimEnd() + "\u2026" : text;
  }

  function validDate(value) {
    return typeof value === "string" && value.length <= 40 && !isNaN(Date.parse(value)) ? value : "";
  }

  function isObject(value) { return !!value && typeof value === "object" && !Array.isArray(value); }

  function sceneTagIds(tags) {
    return (tags || []).map(function (tag) { return String(tag && tag.id != null ? tag.id : tag); });
  }

  // One tag's applied record: the evidence the model gave when the tag was
  // accepted. Only known keys survive, clipped; empty ones are left out.
  function cleanApplied(record) {
    const out = {};
    const put = function (key, value) { if (value) out[key] = value; };
    put("quote", clip(record.quote, LIMITS.quote));
    put("field", clip(record.field, 20));
    put("reason", clip(record.reason, LIMITS.reason));
    put("confidence", clip(record.confidence, 10));
    put("model", clip(record.model, LIMITS.model));
    put("at", validDate(record.at));
    const by = cleanSourceList(record.by, false), no = cleanSourceList(record.no, true);
    if (by.length) out.by = by;
    if (no.length) out.no = no;
    return out;
  }

  // The applied field: a map of tag ID to record. Anything malformed is
  // ignored, never thrown.
  function parseApplied(value) {
    let data;
    try { data = JSON.parse(value || "null"); } catch (_) { return {}; }
    if (!isObject(data)) return {};
    const out = {};
    Object.keys(data).forEach(function (id) {
      if (/^\d+$/.test(id) && isObject(data[id])) out[id] = cleanApplied(data[id]);
    });
    return out;
  }

  // Tags on the scene that carry a record, newest first.
  function sceneApplied(customFields, sceneTags) {
    const applied = parseApplied((customFields || {})[FIELDS.applied]);
    const list = [];
    (sceneTags || []).forEach(function (tag) {
      const id = String(tag && tag.id != null ? tag.id : tag);
      if (applied[id] && !list.some(function (entry) { return entry.tagId === id; })) {
        list.push({ tagId: id, tagName: String(tag && tag.name || ""), record: applied[id] });
      }
    });
    return list.sort(function (a, b) { return Date.parse(b.record.at || 0) - Date.parse(a.record.at || 0); });
  }

  function categoryOf(value) {
    return CATEGORIES.some(function (entry) { return entry.id === value; }) ? String(value) : "";
  }

  function cleanFeedback(entry) {
    if (!isObject(entry) || !/^\d+$/.test(String(entry.tagId)) || !validDate(entry.at)) return null;
    if (entry.kind !== "reported" && entry.kind !== "rejected") return null;
    const out = {
      tagId: String(entry.tagId), tagName: clip(entry.tagName, LIMITS.tagName), kind: entry.kind, category: categoryOf(entry.category),
      note: clip(entry.note, LIMITS.note), quote: clip(entry.quote, LIMITS.quote), field: clip(entry.field, 20),
      reason: clip(entry.reason, LIMITS.reason), model: clip(entry.model, LIMITS.model), at: entry.at,
    };
    // Which sources proposed and declined the tag; entries written before sources existed have neither.
    const by = cleanSourceList(entry.by, false), no = cleanSourceList(entry.no, true);
    if (by.length) out.by = by;
    if (no.length) out.no = no;
    return out;
  }

  // The feedback field: an array, oldest first. Bad entries are skipped.
  function parseFeedback(value) {
    let data;
    try { data = JSON.parse(value || "null"); } catch (_) { return []; }
    return Array.isArray(data) ? data.map(cleanFeedback).filter(Boolean) : [];
  }

  // What the user said: a category from CATEGORIES (or none) and a note.
  function cleanReason(reason) {
    const input = reason || {};
    return { category: categoryOf(input.category), note: clip(input.note, LIMITS.note) };
  }

  function setApplied(fields, applied, set, remove) {
    const value = Object.keys(applied).length ? JSON.stringify(applied) : null;
    if (value == null) { if (fields[FIELDS.applied] != null) remove.push(FIELDS.applied); }
    else if (value !== fields[FIELDS.applied]) set[FIELDS.applied] = value;
  }

  function pruneApplied(applied, presentIds) {
    Object.keys(applied).forEach(function (id) { if (presentIds.indexOf(id) === -1) delete applied[id]; });
  }

  function appendFeedback(fields, entries, set) {
    const list = parseFeedback(fields[FIELDS.feedback]).concat(entries.map(cleanFeedback).filter(Boolean)).slice(-LIMITS.feedback);
    set[FIELDS.feedback] = JSON.stringify(list);
  }

  // The custom-field change that removes tags from a scene's proposals, and
  // optionally records them as rejected. Returns { set, remove } for
  // sceneUpdate's custom_fields input, or null when nothing changes.
  // options.applied: keep each tag's evidence in the applied field (accept).
  //   Every accepted tag gets a record, whether or not its proposal item is
  //   still there: that record is what keeps the tag marked as added from an
  //   AI proposal for as long as the scene carries it. options.sceneTags, the
  //   scene's tags after the change, prunes the records of tags that are gone;
  //   nothing else removes one (a reject, an answer, a new analysis and the
  //   worker's publish leave them alone).
  // options.reason: with a reject, record a feedback entry per tag
  //   ({ category, note }, both optional).
  //   Only tags that were pending get an entry; a tag already rejected or no
  //   longer pending adds none.
  // options.tagNames: names for a pending tag whose proposal item is missing.
  function resolveChange(customFields, tagIds, reject, options) {
    const fields = customFields || {};
    const opts = options || {};
    const drop = tagIds.map(String);
    const pending = decodeIds(fields[FIELDS.pending]);
    const remaining = pending.filter(function (id) { return drop.indexOf(id) === -1; });
    const set = {}, remove = [];
    if (remaining.length !== pending.length) {
      if (remaining.length) {
        let parsed = null;
        try { parsed = JSON.parse(fields[FIELDS.proposals] || "null"); } catch (_) { parsed = null; }
        if (!parsed || typeof parsed !== "object" || !Array.isArray(parsed.items)) parsed = { v: 1, items: [] };
        parsed.items = parsed.items.filter(function (item) { return item && drop.indexOf(String(item.t)) === -1; });
        set[FIELDS.pending] = encodeIds(remaining);
        set[FIELDS.proposals] = JSON.stringify(parsed);
      } else {
        if (fields[FIELDS.pending] != null) remove.push(FIELDS.pending);
        if (fields[FIELDS.proposals] != null) remove.push(FIELDS.proposals);
      }
    }
    if (reject) {
      const rejected = decodeIds(fields[FIELDS.rejected]);
      const next = encodeIds(rejected.concat(drop));
      if (next !== encodeIds(rejected)) set[FIELDS.rejected] = next;
    }
    const proposals = parseProposals(fields[FIELDS.proposals]);
    const at = opts.at || new Date().toISOString();
    if (opts.applied) {
      const applied = parseApplied(fields[FIELDS.applied]);
      drop.forEach(function (id) {
        const item = proposals.items.find(function (entry) { return entry.tagId === id; });
        if (item) applied[id] = cleanApplied(Object.assign({ quote: item.quote, field: item.field, reason: item.reason, confidence: item.confidence, model: proposals.model, at: at }, sourceRecord(item)));
        // Every accept leaves the mark that the tag came from an AI proposal, even when the proposal itself is
        // gone (another tab or the worker's publish removed it): the time and the model, whatever is known.
        // A record already there is not rewritten by an accept that has no evidence of its own.
        else if (!applied[id]) applied[id] = cleanApplied({ model: proposals.model, at: at });
      });
      if (opts.sceneTags) pruneApplied(applied, sceneTagIds(opts.sceneTags));
      setApplied(fields, applied, set, remove);
    }
    if (reject && opts.reason) {
      const reason = cleanReason(opts.reason), names = opts.tagNames || {};
      const entries = [];
      drop.forEach(function (id) {
        // Only a tag this change takes off the pending list is a decision to
        // record: a repeated click, a stale tab or an already rejected tag is not.
        if (pending.indexOf(id) === -1) return;
        const item = proposals.items.find(function (entry) { return entry.tagId === id; });
        const name = item ? item.tagName : names[id];
        // A pending tag with neither a proposal nor a name has nothing to record.
        if (!item && !name) return;
        entries.push(Object.assign({
          tagId: id, tagName: name || "", kind: "rejected", category: reason.category, note: reason.note,
          quote: item ? item.quote : "", field: item ? item.field : "", reason: item ? item.reason : "", model: proposals.model || "", at: at,
        }, sourceRecord(item)));
      });
      if (entries.length) appendFeedback(fields, entries, set);
    }
    return Object.keys(set).length || remove.length ? { set: set, remove: remove } : null;
  }

  // Reporting an applied tag as wrong: one change that removes the tag from
  // the scene (`tagIds` is the scene's new tag list), rejects it for the
  // scene, drops its record, and appends a feedback entry. Returns
  // { change: { set, remove }, tagIds }.
  function resolveReport(customFields, sceneTags, tagId, reason, options) {
    const fields = customFields || {};
    const opts = options || {};
    const id = String(tagId);
    const present = sceneTagIds(sceneTags).filter(function (entry) { return entry !== id; });
    const base = resolveChange(fields, [id], true) || { set: {}, remove: [] };
    const set = base.set, remove = base.remove;
    const applied = parseApplied(fields[FIELDS.applied]);
    const record = applied[id] || {};
    delete applied[id];
    pruneApplied(applied, present);
    setApplied(fields, applied, set, remove);
    const proposals = parseProposals(fields[FIELDS.proposals]);
    const clean = cleanReason(reason);
    const named = (sceneTags || []).find(function (tag) { return tag && String(tag.id) === id; });
    const reported = {
      tagId: id, tagName: opts.tagName || (named && named.name) || "", kind: "reported", category: clean.category, note: clean.note,
      quote: record.quote || "", field: record.field || "", reason: record.reason || "", model: record.model || proposals.model || "", at: opts.at || new Date().toISOString(),
    };
    // The sources on record when the tag was accepted: the report says they were wrong.
    if (record.by) reported.by = record.by;
    if (record.no) reported.no = record.no;
    appendFeedback(fields, [reported], set);
    return { change: { set: set, remove: remove }, tagIds: present };
  }


  // ---------------------------------------------------------------------------
  // Settings model (pure)
  //
  // Two settings maps in Stash, one writer each. This page writes only the map
  // named ID and reads the worker's answers from WORKER_ID, so neither side can
  // lose the other's update. The page's map holds:
  //   llmProviders        JSON text, array of providers (address, key, consent, defaults)
  //   llmProfiles         JSON text, array of profiles (provider, model, overrides)
  //   llmActiveProfile    profile used for automatic analysis and Re-analyse
  //   llmAuto             true when new and changed scenes are analysed automatically
  //   localNetworks       "My network also uses"
  //   llmRequests         JSON text, the request queue the worker answers
  //   llmSchema           2 once migrated
  // Every function takes the current map and returns a new one (or throws a
  // message for the user); none changes its input, and every key it does not own
  // survives, because configurePlugin replaces the whole map.

  const WORKER_ID = ID + "-worker";
  const SCHEMA = 2;
  const PROVIDERS_KEY = "llmProviders";
  const PROFILES_KEY = "llmProfiles";
  const ACTIVE_KEY = "llmActiveProfile";
  const AUTO_KEY = "llmAuto";
  const NETWORKS_KEY = "localNetworks";
  const REQUESTS_KEY = "llmRequests";
  const SCHEMA_KEY = "llmSchema";
  // What 0.4.2 and earlier kept in the same map; the migration removes them.
  const LEGACY_KEYS = ["llmUrl", "llmModel", "llmApiKey", "allowHosted", "llmDailyBudget", "llmThinking", "llmConcurrency", "llmVerify", "llmProvider", "llmZdr",
    "llmModelsRequest", "llmModelLists", "llmCheckRequest", "llmCheckResult"];
  // The server named in the worker's config file, shown as a read-only provider.
  const CONFIG_PROVIDER = "config";
  const MAX_PROVIDERS = 20;
  const MAX_PROFILES = 20;
  const MAX_REQUESTS = 20;
  const MAX_PROFILE_NAME = 60;
  const MAX_CONCURRENCY = 64;
  const MAX_RUN_LIMIT = 1000000;
  const MAX_SCENE_IDS = 500;
  const REQUEST_MAX_AGE_MS = 24 * 60 * 60 * 1000;
  // A request the worker has not started within this long is ignored by it
  // (except a run), so the page stops waiting for it.
  const REQUEST_FRESH_MS = 10 * 60 * 1000;
  // The waits and polling intervals below have the values shown. A test can make a few of them shorter (never longer) by
  // putting a plain object on the page before this script loads: window.__semanticTaggerTiming = { POLL_MS: 250, ... }.
  // It is read once, here. Only the names in TIMING_DEFAULTS count, each a finite number from 50 up to just under its default;
  // anything else is ignored. Nothing a scene, a setting or the address can hold reaches it: a global of the page is set
  // only by a script running in the page. Without it every value below is exactly the default.
  const TIMING_GLOBAL = "__semanticTaggerTiming";
  const TIMING_DEFAULTS = Object.freeze({ POLL_MS: 2500, SLOW_POLL_MS: 15000, CONNECT_WAIT_MS: 15000, CHECK_WAIT_MS: 30 * 1000, RESEND_MS: 30000, REFUSE_MS: 8000, OUTBOX_POLL_MS: 2500 });
  const TIMING_MIN_MS = 50;
  function timingOverrides(source) {
    const values = Object.assign({}, TIMING_DEFAULTS);
    if (!source || typeof source !== "object") return values;
    Object.keys(TIMING_DEFAULTS).forEach(function (name) {
      if (!Object.prototype.hasOwnProperty.call(source, name)) return;
      const value = source[name];
      if (typeof value === "number" && isFinite(value) && value >= TIMING_MIN_MS && value < TIMING_DEFAULTS[name]) values[name] = value;
    });
    return values;
  }
  const TIMING = timingOverrides(window[TIMING_GLOBAL]);
  const POLL_MS = TIMING.POLL_MS;
  const SLOW_POLL_MS = TIMING.SLOW_POLL_MS;
  const CONNECT_WAIT_MS = TIMING.CONNECT_WAIT_MS;
  const CHECK_WAIT_MS = TIMING.CHECK_WAIT_MS;
  const ENTRY_ID = /^[A-Za-z0-9_-]{1,64}$/;
  const OPENROUTER_URL = "https://openrouter.ai/api/v1";
  // Public and keyless; the manifest allows this origin in connect-src.
  const OPENROUTER_ALL = "https://openrouter.ai/api/v1/models";
  const OPENROUTER_MODELS = OPENROUTER_ALL + "?supported_parameters=structured_outputs";
  // A list the worker wrote is asked for again after this long, and an
  // OpenRouter list is kept in memory for this long.
  const WORKER_LIST_FRESH_MS = 10 * 60 * 1000;
  const OPENROUTER_LIST_FRESH_MS = 60 * 60 * 1000;
  const MODEL_OPTION_LIMIT = 50;

  // The six settings a provider can default and a profile can override.
  // verify is off (false), the same model (true) or a decision model ("decisions");
  // the last four matter only for the decisions model: the provider it is asked
  // through (blank: the profile's own), its model, and the thresholds the worker
  // applies when publishing.
  const OVERRIDE_KEYS = ["dailyBudget", "thinking", "verify", "concurrency", "routing", "zdr", "responseFormat", "verifyProvider", "verifyModel", "verifyKeep", "verifyHigh"];
  const DECISIONS_MODEL = "typesafe/jev-1.14";
  // What applies when neither the profile, the provider nor the worker's config file says.
  const BUILTIN = Object.freeze({ dailyBudget: null, thinking: false, verify: false, concurrency: 8, routing: null, zdr: false, responseFormat: "json_schema", verifyProvider: null, verifyModel: DECISIONS_MODEL, verifyKeep: 0.7, verifyHigh: 0.9 });
  // How the model is asked to reply (the worker's llm.responseFormat). For a server that ignores the
  // reply format, "none" describes it in the prompt instead.
  const REPLY_FORMATS = Object.freeze([
    { value: "json_schema", label: "Enforced by the server (JSON schema)" },
    { value: "json_object", label: "JSON mode" },
    { value: "none", label: "Described in the prompt only (for servers that ignore the reply format)" },
  ]);
  const replyFormatOf = function (value) { return typeof value === "string" && REPLY_FORMATS.some(function (entry) { return entry.value === value; }) ? value : null; };
  const VERIFY_CHOICES = Object.freeze([{ value: "off", label: "Off" }, { value: "on", label: "Same model" }, { value: "decisions", label: "Decisions model" }]);
  const MODES = Object.freeze([
    { id: "new", label: "New scenes this set-up has not analysed" },
    { id: "secondOpinion", label: "Second opinion on scenes that already have proposals" },
    { id: "force", label: "Again, even if a scene is unchanged" },
  ]);
  // 0.7.0 adds the evaluation requests (see the evaluation plan): a run and the answers are kept for a day, the rest for ten minutes.
  const REQUEST_KINDS = ["status", "models", "check", "run", "cancel", "evalAnswers", "evalAnswersFor", "evalQueue", "evalRun", "evalScore", "evalDetail", "evalScene"];
  const LONG_REQUESTS = ["run", "evalRun", "evalAnswers"];
  const JOB_STATES = ["queued", "running", "done", "stopped", "cancelled", "failed"];

  function stable(value) {
    if (Array.isArray(value)) return "[" + value.map(stable).join(",") + "]";
    if (isObject(value)) return "{" + Object.keys(value).sort().map(function (key) { return JSON.stringify(key) + ":" + stable(value[key]); }).join(",") + "}";
    return JSON.stringify(value === undefined ? null : value);
  }

  // A settings value that may arrive as JSON text or as the value itself.
  function jsonValue(value) {
    if (typeof value !== "string") return value;
    try { return JSON.parse(value || "null"); } catch (_) { return null; }
  }

  function slug(name) { return String(name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 30) || "item"; }

  // An ID made from a name that none of `taken` has.
  function uniqueId(name, taken) {
    const base = slug(name);
    let id = base, counter = 1;
    while (taken.indexOf(id) !== -1 || id === CONFIG_PROVIDER) { counter += 1; id = base.slice(0, 30) + "-" + counter; }
    return id;
  }

  function normalizeSettings(map) {
    const source = map && typeof map === "object" ? map : {};
    const text = function (key) { return typeof source[key] === "string" ? source[key].trim() : ""; };
    const budget = typeof source.llmDailyBudget === "string" && !source.llmDailyBudget.trim() ? NaN : Number(source.llmDailyBudget);
    return {
      llmUrl: text("llmUrl"), llmModel: text("llmModel"), llmApiKey: text("llmApiKey"),
      allowHosted: source.allowHosted === true,
      llmDailyBudget: source.llmDailyBudget != null && isFinite(budget) && budget > 0 ? budget : null,
      localNetworks: text("localNetworks"),
      llmThinking: typeof source.llmThinking === "boolean" ? source.llmThinking : null,
      llmConcurrency: concurrencyOf(source.llmConcurrency),
      llmVerify: typeof source.llmVerify === "boolean" ? source.llmVerify : null,
      llmProvider: text("llmProvider"),
      llmZdr: source.llmZdr === true,
    };
  }

  // A whole number from 1 to 64 (a number, or text such as "8"), else null.
  function concurrencyOf(value) {
    const number = typeof value === "string" ? (value.trim() ? Number(value) : NaN) : value;
    return typeof number === "number" && isFinite(number) && Math.floor(number) === number && number >= 1 && number <= MAX_CONCURRENCY ? number : null;
  }

  // The routing text as a JSON object, or why it is not one. Blank is none.
  function providerError(text) {
    const value = String(text == null ? "" : text).trim();
    if (!value) return null;
    let data;
    try { data = JSON.parse(value); } catch (_) { return "Provider routing must be a JSON object, such as {\"only\": [\"River\"]}; this is not valid JSON."; }
    if (!data || typeof data !== "object" || Array.isArray(data)) return "Provider routing must be a JSON object, such as {\"only\": [\"River\"]}.";
    return null;
  }

  // "My network also uses": IPv4 ranges (CIDR) or addresses, comma-separated,
  // for a LAN outside the private ranges. Returns the valid ranges and the
  // entries that are not one; the worker reads the same list.
  function parseNetworks(value) {
    const networks = [], invalid = [];
    String(value == null ? "" : value).split(/[\s,;]+/).forEach(function (entry) {
      if (!entry) return;
      const match = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})(?:\/(\d{1,2}))?$/.exec(entry);
      const parts = match ? match.slice(1, 5).map(Number) : [];
      const bits = match ? (match[5] == null ? 32 : Number(match[5])) : NaN;
      // Leading zeros are refused, as the worker's address parser does.
      const zeros = match && match.slice(1, 5).some(function (part) { return /^0\d/.test(part); });
      if (!match || zeros || parts.some(function (part) { return part > 255; }) || !(bits >= 0 && bits <= 32)) { invalid.push(entry); return; }
      const mask = bits === 0 ? 0 : (~0 << (32 - bits)) >>> 0;
      networks.push({ text: entry, base: (ipv4Number(parts) & mask) >>> 0, mask: mask });
    });
    return { networks: networks, invalid: invalid };
  }

  function ipv4Number(parts) {
    return parts.reduce(function (value, part) { return ((value << 8) + part) >>> 0; }, 0);
  }

  function inNetworks(host, networks) {
    const parts = host.split(".").map(Number);
    if (parts.length !== 4 || parts.some(function (part) { return !(part >= 0 && part <= 255); })) return false;
    const value = ipv4Number(parts);
    return networks.some(function (range) { return ((value & range.mask) >>> 0) === range.base; });
  }

  function hostOf(url) {
    try { return new URL(String(url)).hostname.replace(/^\[|\]$/g, "").toLowerCase(); } catch (_) { return null; }
  }

  function isPrivateIpv4(host) {
    const parts = host.split(".").map(Number);
    if (parts.length !== 4 || parts.some(function (part) { return !(part >= 0 && part <= 255); })) return false;
    const a = parts[0], b = parts[1];
    return a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168)
      || (a === 169 && b === 254) || (a === 100 && b >= 64 && b <= 127);
  }

  // A guess from the address alone, as the browser cannot resolve names:
  // localhost, private IP literals, .local names and single-label names
  // count as local. The worker checks the resolved address again.
  // `networks` is the "My network also uses" text; malformed entries in it
  // are ignored here.
  function isLocalAddress(url, networks) {
    const host = hostOf(url);
    if (!host) return false;
    if (host === "localhost" || /\.(localhost|local)$/.test(host)) return true;
    const extra = parseNetworks(networks).networks;
    if (/^[\d.]+$/.test(host)) return isPrivateIpv4(host) || inNetworks(host, extra);
    if (host.indexOf(":") !== -1) {
      if (host === "::1") return true;
      // The URL parser writes ::ffff:192.168.1.2 as ::ffff:c0a8:102.
      const mapped = /^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/.exec(host);
      if (mapped) {
        const high = parseInt(mapped[1], 16), low = parseInt(mapped[2], 16);
        const v4 = [high >> 8, high & 255, low >> 8, low & 255].join(".");
        return isPrivateIpv4(v4) || inNetworks(v4, extra);
      }
      return /^f[cd]/.test(host) || /^fe[89ab]/.test(host);
    }
    return host.indexOf(".") === -1;
  }

  // none: the worker's config file names the server.
  function providerOf(url) {
    const host = hostOf(url);
    if (!String(url || "").trim() || !host) return String(url || "").trim() ? "compatible" : "none";
    return host === "openrouter.ai" || /\.openrouter\.ai$/.test(host) ? "openrouter" : "compatible";
  }

  // The address as a key for model lists: no trailing slashes.
  function addressKey(url) { return String(url == null ? "" : url).trim().replace(/\/+$/, ""); }

  function positiveNumber(value) {
    const number = typeof value === "string" ? (value.trim() ? Number(value) : NaN) : value;
    return typeof number === "number" && isFinite(number) && number > 0 ? number : null;
  }

  // OpenRouter's provider field as a non-empty object, from the object or JSON text; else null.
  function routingOf(value) {
    const data = typeof value === "string" ? (value.trim() ? jsonValue(value) : null) : value;
    return isObject(data) && Object.keys(data).length ? JSON.parse(JSON.stringify(data)) : null;
  }

  // Zero data retention is its own setting, never a key of the routing: a zdr
  // found inside the routing moves out of it. Returns { routing, zdr }.
  function splitRouting(value) {
    const routing = routingOf(value);
    if (!routing || typeof routing.zdr !== "boolean") return { routing: routing, zdr: null };
    const zdr = routing.zdr;
    delete routing.zdr;
    return { routing: Object.keys(routing).length ? routing : null, zdr: zdr };
  }

  // The six settings as stored, defensively: only valid values survive.
  function cleanDefaults(value) {
    const out = {};
    if (!isObject(value)) return out;
    const budget = positiveNumber(value.dailyBudget);
    if (budget != null) out.dailyBudget = budget;
    if (typeof value.thinking === "boolean") out.thinking = value.thinking;
    if (typeof value.verify === "boolean" || value.verify === "decisions") out.verify = value.verify;
    if (typeof value.verifyProvider === "string" && ENTRY_ID.test(value.verifyProvider.trim())) out.verifyProvider = value.verifyProvider.trim();
    if (typeof value.verifyModel === "string" && value.verifyModel.trim()) out.verifyModel = value.verifyModel.trim().slice(0, LIMITS.model);
    ["verifyKeep", "verifyHigh"].forEach(function (key) {
      const number = thresholdOf(value[key]);
      if (number != null) out[key] = number;
    });
    const parallel = concurrencyOf(value.concurrency);
    if (parallel != null) out.concurrency = parallel;
    const split = splitRouting(value.routing);
    if (split.routing) out.routing = split.routing;
    if (typeof value.zdr === "boolean") out.zdr = value.zdr;
    else if (split.zdr != null) out.zdr = split.zdr;
    if (replyFormatOf(value.responseFormat)) out.responseFormat = value.responseFormat;
    return out;
  }

  // A threshold: a number above 0 and at most 1 (a number, or text such as "0.7"), else null.
  function thresholdOf(value) {
    const number = typeof value === "string" ? (value.trim() ? Number(value) : NaN) : value;
    return typeof number === "number" && isFinite(number) && number > 0 && number <= 1 ? number : null;
  }

  function isSet(name, value) {
    if (value == null) return false;
    if (name === "verifyProvider" || name === "verifyModel" || name === "responseFormat") return typeof value === "string" && value !== "";
    return name === "routing" ? isObject(value) && Object.keys(value).length > 0 : true;
  }

  // The value in effect for one of the six settings: the profile's override,
  // else the provider's default, else the worker's config file, else the
  // built-in default. { value, source } with source profile, provider, config or
  // default. The worker implements the same rule; both unit tests share one table.
  function effectiveSetting(name, overrides, defaults, config) {
    if (overrides && isSet(name, overrides[name])) return { value: overrides[name], source: "profile" };
    if (defaults && isSet(name, defaults[name])) return { value: defaults[name], source: "provider" };
    if (config && isSet(name, config[name])) return { value: config[name], source: "config" };
    return { value: BUILTIN[name], source: "default" };
  }

  function effectiveSettings(overrides, defaults, config) {
    const out = {};
    OVERRIDE_KEYS.forEach(function (name) { out[name] = effectiveSetting(name, overrides, defaults, config); });
    return out;
  }

  // A value in words: "5 credits", "on", "8", "{\"only\":[\"River\"]}".
  function settingText(name, value) {
    if (value == null) return name === "dailyBudget" ? "no limit" : "none";
    if (name === "dailyBudget") return value + " credit" + (value === 1 ? "" : "s");
    if (value === "decisions") return "decisions model";
    if (typeof value === "boolean") return value ? "on" : "off";
    if (isObject(value)) return JSON.stringify(value);
    return String(value);
  }

  // ---------------------------------------------------------------------------
  // Providers and profiles (pure)

  function parseList(value) {
    const data = jsonValue(value);
    return Array.isArray(data) ? data : [];
  }

  // The saved providers, defensively. A broken entry, a repeated ID or name,
  // the reserved ID "config" and anything past 20 are skipped.
  function parseProviders(value) {
    const providers = [];
    parseList(value).forEach(function (entry) {
      if (!isObject(entry) || typeof entry.id !== "string" || !ENTRY_ID.test(entry.id) || entry.id === CONFIG_PROVIDER || typeof entry.name !== "string") return;
      const name = entry.name.trim().slice(0, MAX_PROFILE_NAME);
      if (!name || typeof entry.url !== "string" || providers.length >= MAX_PROVIDERS) return;
      if (providers.some(function (other) { return other.id === entry.id || other.name.toLowerCase() === name.toLowerCase(); })) return;
      providers.push({
        id: entry.id, name: name, url: entry.url.trim(), apiKey: typeof entry.apiKey === "string" ? entry.apiKey.trim() : "",
        allowHosted: entry.allowHosted === true, defaults: cleanDefaults(entry.defaults),
      });
    });
    return providers;
  }

  // The saved profiles, defensively: { id, name, provider, model, overrides }.
  function parseProfiles(value) {
    const profiles = [];
    parseList(value).forEach(function (entry) {
      if (!isObject(entry) || typeof entry.id !== "string" || !ENTRY_ID.test(entry.id) || typeof entry.name !== "string") return;
      const name = entry.name.trim().slice(0, MAX_PROFILE_NAME);
      if (!name || typeof entry.provider !== "string" || !ENTRY_ID.test(entry.provider) || profiles.length >= MAX_PROFILES) return;
      if (profiles.some(function (other) { return other.id === entry.id || other.name.toLowerCase() === name.toLowerCase(); })) return;
      profiles.push({ id: entry.id, name: name, provider: entry.provider, model: typeof entry.model === "string" ? entry.model.trim().slice(0, LIMITS.model) : "", overrides: cleanDefaults(entry.overrides) });
    });
    return profiles;
  }

  function storedProvider(provider) {
    return { id: provider.id, name: provider.name, url: provider.url, apiKey: provider.apiKey || "", allowHosted: !!provider.allowHosted, defaults: cleanDefaults(provider.defaults) };
  }

  function storedProfile(profile) {
    return { id: profile.id, name: profile.name, provider: profile.provider, model: profile.model || "", overrides: cleanDefaults(profile.overrides) };
  }

  // Writes the lists into a copy of the map; an empty list removes its key.
  function writeLists(map, providers, profiles) {
    if (providers) { if (providers.length) map[PROVIDERS_KEY] = JSON.stringify(providers.map(storedProvider)); else delete map[PROVIDERS_KEY]; }
    if (profiles) { if (profiles.length) map[PROFILES_KEY] = JSON.stringify(profiles.map(storedProfile)); else delete map[PROFILES_KEY]; }
    return map;
  }

  // The profiles that use a provider: on it, or asking it to verify (verifyProvider).
  function profilesUsing(profiles, providerId) {
    return profiles.filter(function (profile) { return profile.provider === providerId || profile.overrides.verifyProvider === providerId; });
  }

  function activeProfileId(map) {
    const source = isObject(map) ? map : {};
    const id = typeof source[ACTIVE_KEY] === "string" ? source[ACTIVE_KEY] : "";
    return id && parseProfiles(source[PROFILES_KEY]).some(function (profile) { return profile.id === id; }) ? id : "";
  }

  // A copy of the settings as the editors and the run form read them.
  function settingsOf(map) {
    const source = isObject(map) ? map : {};
    return {
      providers: parseProviders(source[PROVIDERS_KEY]), profiles: parseProfiles(source[PROFILES_KEY]), active: activeProfileId(source),
      auto: source[AUTO_KEY] === true, networks: typeof source[NETWORKS_KEY] === "string" ? source[NETWORKS_KEY].trim() : "",
      requests: parseRequests(source[REQUESTS_KEY]), schema: Number(source[SCHEMA_KEY]) || 0,
    };
  }

  // ---------------------------------------------------------------------------
  // Migration from 0.4.2 and earlier (pure, idempotent)

  function needsMigration(map) {
    return !(isObject(map) && Number(map[SCHEMA_KEY]) >= SCHEMA);
  }

  // Whether the map holds settings of the old shape worth telling the user about.
  function hasLegacySettings(map) {
    const source = isObject(map) ? map : {};
    if (!needsMigration(source)) return false;
    return LEGACY_KEYS.some(function (key) { return source[key] != null && source[key] !== "" && source[key] !== false; }) || parseLegacyProfiles(source[PROFILES_KEY]).length > 0;
  }

  // 0.4.2's profiles: { id, name, ...the flat setting keys }.
  function parseLegacyProfiles(value) {
    const profiles = [];
    parseList(value).forEach(function (entry) {
      if (!isObject(entry) || typeof entry.id !== "string" || !ENTRY_ID.test(entry.id) || typeof entry.name !== "string") return;
      const name = entry.name.trim().slice(0, MAX_PROFILE_NAME);
      if (!name || profiles.length >= MAX_PROFILES) return;
      if (profiles.some(function (other) { return other.id === entry.id || other.name.toLowerCase() === name.toLowerCase(); })) return;
      profiles.push({ id: entry.id, name: name, settings: normalizeSettings(entry) });
    });
    return profiles;
  }

  function setupSignature(settings) {
    return stable([addressKey(settings.llmUrl), settings.llmModel, settings.llmApiKey, settings.allowHosted, settings.llmDailyBudget, settings.llmThinking, settings.llmConcurrency,
      settings.llmVerify, routingOf(settings.llmProvider), settings.llmZdr]);
  }

  function hasSetup(settings) {
    return !!(settings.llmUrl || settings.llmModel || settings.llmDailyBudget != null || settings.llmThinking != null || settings.llmConcurrency != null
      || settings.llmVerify != null || settings.llmProvider || settings.llmZdr);
  }

  function legacyOverrides(settings) {
    const out = {};
    if (settings.llmDailyBudget != null) out.dailyBudget = settings.llmDailyBudget;
    if (settings.llmThinking != null) out.thinking = settings.llmThinking;
    if (settings.llmVerify != null) out.verify = settings.llmVerify;
    if (settings.llmConcurrency != null) out.concurrency = settings.llmConcurrency;
    // Routing and zero data retention were OpenRouter's only.
    if (providerOf(settings.llmUrl) === "openrouter") {
      const split = splitRouting(settings.llmProvider);
      if (split.routing) out.routing = split.routing;
      if (settings.llmZdr) out.zdr = true;
      else if (split.zdr != null) out.zdr = split.zdr;
    }
    return out;
  }

  function providerNameFor(url) {
    if (providerOf(url) === "openrouter") return "OpenRouter";
    let port = "";
    try { port = new URL(url).port; } catch (_) { port = ""; }
    return (hostOf(url) || "Server") + (port ? ":" + port : "");
  }

  // 0.4.2 kept one set-up in flat keys and named copies in llmProfiles, each with
  // its own address and key. The result: a provider for each distinct address
  // and key (with its consent), a profile for each old profile, the flat
  // settings that match none as the profile "Current settings" (made active),
  // and no flat keys. Keys the plugin does not own survive.
  function migrateSettings(map) {
    const source = isObject(map) ? map : {};
    const out = Object.assign({}, source);
    if (!needsMigration(source)) return out;
    const flat = normalizeSettings(source);
    const legacy = parseLegacyProfiles(source[PROFILES_KEY]);
    const providers = [], profiles = [], byPair = {};
    const networks = parseNetworks(flat.localNetworks).networks.map(function (range) { return range.text; });
    legacy.forEach(function (entry) {
      parseNetworks(entry.settings.localNetworks).networks.forEach(function (range) { if (networks.indexOf(range.text) === -1) networks.push(range.text); });
    });

    function providerFor(settings) {
      const url = addressKey(settings.llmUrl);
      if (!url) return CONFIG_PROVIDER;
      const pair = url + "\n" + settings.llmApiKey;
      let provider = byPair[pair];
      if (!provider) {
        if (providers.length >= MAX_PROVIDERS) return null;
        const base = providerNameFor(url);
        let name = base, counter = 1;
        while (providers.some(function (other) { return other.name.toLowerCase() === name.toLowerCase(); })) { counter += 1; name = base + " (" + counter + ")"; }
        provider = { id: uniqueId(name, providers.map(function (other) { return other.id; })), name: name, url: url, apiKey: settings.llmApiKey, allowHosted: false, defaults: {} };
        providers.push(provider);
        byPair[pair] = provider;
      }
      if (settings.allowHosted) provider.allowHosted = true;
      return provider.id;
    }
    function addProfile(id, name, settings) {
      const providerId = providerFor(settings);
      // Without a model, only the worker's own server can fill one in.
      if (!providerId || (providerId !== CONFIG_PROVIDER && !settings.llmModel) || profiles.length >= MAX_PROFILES) return false;
      profiles.push({ id: id, name: name, provider: providerId, model: settings.llmModel, overrides: cleanDefaults(legacyOverrides(settings)) });
      return true;
    }

    legacy.forEach(function (entry) { addProfile(entry.id, entry.name, entry.settings); });
    let active = "";
    if (hasSetup(flat)) {
      const signature = setupSignature(flat);
      const matching = legacy.filter(function (entry) { return setupSignature(entry.settings) === signature && profiles.some(function (profile) { return profile.id === entry.id; }); });
      const chosen = matching.find(function (entry) { return entry.id === source[ACTIVE_KEY]; }) || matching[0];
      if (chosen) active = chosen.id;
      else {
        let name = "Current settings", counter = 1;
        while (profiles.some(function (profile) { return profile.name.toLowerCase() === name.toLowerCase(); })) { counter += 1; name = "Current settings (" + counter + ")"; }
        const id = uniqueId(name, profiles.map(function (profile) { return profile.id; }));
        if (addProfile(id, name, flat)) active = id;
        else if (!providers.length) providerFor(flat);
      }
    } else if (profiles.some(function (profile) { return profile.id === source[ACTIVE_KEY]; })) active = source[ACTIVE_KEY];

    LEGACY_KEYS.forEach(function (key) { delete out[key]; });
    delete out[PROFILES_KEY];
    delete out[ACTIVE_KEY];
    writeLists(out, providers, profiles);
    if (active) out[ACTIVE_KEY] = active;
    if (networks.length) out[NETWORKS_KEY] = networks.join(", "); else delete out[NETWORKS_KEY];
    out[SCHEMA_KEY] = SCHEMA;
    return out;
  }

  // ---------------------------------------------------------------------------
  // Editing providers and profiles (pure)

  function nameError(kind, name, list, exceptId) {
    const text = String(name == null ? "" : name).trim();
    if (!text) return "Enter a name for the " + kind + ".";
    if (text.length > MAX_PROFILE_NAME) return "A " + kind + " name can have at most " + MAX_PROFILE_NAME + " characters.";
    if (list.some(function (entry) { return entry.id !== exceptId && entry.name.toLowerCase() === text.toLowerCase(); })) return "There is already a " + kind + " called “" + text + "”.";
    return null;
  }

  function triText(value) { return value === true ? "on" : value === false ? "off" : ""; }
  function triValue(text) { return text === "on" ? true : text === "off" ? false : null; }
  // The verify setting's text is "on", "off", "decisions", or "" (not set).
  function verifyText(value) { return value === "decisions" ? "decisions" : triText(value); }
  function verifyValue(text) { return text === "decisions" ? "decisions" : triValue(text); }

  // Whether the decisions model is in effect for a form: chosen, or left unset
  // while the provider's default (`base`) chooses it. Its four settings are kept
  // only then.
  function decisionsOn(form, base) {
    return form.verify === "decisions" || (!form.verify && !!base && base.verify === "decisions");
  }

  // The six settings as form text: numbers and JSON as text, on/off as "on", "off" or "".
  function defaultsForm(values) {
    const source = values || {};
    return {
      dailyBudget: source.dailyBudget != null ? String(source.dailyBudget) : "", thinking: triText(source.thinking), verify: verifyText(source.verify),
      concurrency: source.concurrency != null ? String(source.concurrency) : "", routing: source.routing ? JSON.stringify(source.routing) : "", zdr: triText(source.zdr), responseFormat: source.responseFormat || "",
      verifyProvider: source.verifyProvider || "", verifyModel: source.verifyModel || "",
      verifyKeep: source.verifyKeep != null ? String(source.verifyKeep) : "", verifyHigh: source.verifyHigh != null ? String(source.verifyHigh) : "",
    };
  }

  // Why the six settings in a form are not valid, or null. Routing and zero
  // data retention count only for an OpenRouter address.
  // Why the decisions model's thresholds are not valid, or null: each a number
  // above 0 and at most 1, and keep not above high (a blank one is the default,
  // the provider's `base` or the built-in).
  function thresholdsError(form, base) {
    const keepText = String(form.verifyKeep == null ? "" : form.verifyKeep).trim(), highText = String(form.verifyHigh == null ? "" : form.verifyHigh).trim();
    if (keepText && thresholdOf(keepText) == null) return "Keep must be a number above 0 and at most 1.";
    if (highText && thresholdOf(highText) == null) return "High must be a number above 0 and at most 1.";
    const inherited = function (key) { return base && thresholdOf(base[key]) != null ? thresholdOf(base[key]) : BUILTIN[key]; };
    const keep = keepText ? Number(keepText) : inherited("verifyKeep"), high = highText ? Number(highText) : inherited("verifyHigh");
    if (keep > high) return "Keep (" + keep + ") must not be above high (" + high + ").";
    return null;
  }

  function defaultsError(form, kind, base) {
    const budget = String(form.dailyBudget == null ? "" : form.dailyBudget).trim();
    if (budget && !(Number(budget) >= 0)) return "The daily limit must be a number of credits, 0 or more.";
    const parallel = String(form.concurrency == null ? "" : form.concurrency).trim();
    if (parallel && concurrencyOf(/^\d+$/.test(parallel) ? Number(parallel) : NaN) == null) return "Parallel requests must be a whole number from 1 to " + MAX_CONCURRENCY + ".";
    if (decisionsOn(form, base)) {
      const bad = thresholdsError(form, base);
      if (bad) return bad;
    }
    if (String(form.responseFormat == null ? "" : form.responseFormat) && !replyFormatOf(form.responseFormat)) return "Reply format must be one of: " + REPLY_FORMATS.map(function (entry) { return entry.label; }).join("; ") + ".";
    if (kind === "openrouter") return providerError(form.routing);
    return null;
  }

  function defaultsFromForm(form, kind, base) {
    const out = {};
    const budget = positiveNumber(String(form.dailyBudget == null ? "" : form.dailyBudget));
    if (budget != null) out.dailyBudget = budget;
    if (triValue(form.thinking) != null) out.thinking = triValue(form.thinking);
    if (verifyValue(form.verify) != null) out.verify = verifyValue(form.verify);
    if (decisionsOn(form, base)) {
      if (ENTRY_ID.test(String(form.verifyProvider || ""))) out.verifyProvider = form.verifyProvider;
      if (String(form.verifyModel || "").trim()) out.verifyModel = String(form.verifyModel).trim().slice(0, LIMITS.model);
      if (thresholdOf(form.verifyKeep) != null) out.verifyKeep = thresholdOf(form.verifyKeep);
      if (thresholdOf(form.verifyHigh) != null) out.verifyHigh = thresholdOf(form.verifyHigh);
    }
    const parallel = concurrencyOf(Number(String(form.concurrency == null ? "" : form.concurrency).trim()) || null);
    if (parallel != null) out.concurrency = parallel;
    if (replyFormatOf(form.responseFormat)) out.responseFormat = form.responseFormat;
    if (kind === "openrouter") {
      const split = splitRouting(String(form.routing == null ? "" : form.routing));
      if (split.routing) out.routing = split.routing;
      if (triValue(form.zdr) != null) out.zdr = triValue(form.zdr);
      else if (split.zdr != null) out.zdr = split.zdr;
    }
    return out;
  }

  // The provider editor's form. A saved key is never part of it: it holds only
  // the key typed now, and whether one is saved.
  function providerForm(provider) {
    if (!provider) return { id: "", name: "", kind: "openrouter", url: "", newKey: "", keySaved: false, removeKey: false, allowHosted: false, defaults: defaultsForm({}) };
    return {
      id: provider.id, name: provider.name, kind: providerOf(provider.url) === "openrouter" ? "openrouter" : "compatible",
      url: provider.url, newKey: "", keySaved: !!provider.apiKey, removeKey: false, allowHosted: provider.allowHosted, defaults: defaultsForm(provider.defaults),
    };
  }

  function formAddress(form) {
    return form.kind === "openrouter" ? OPENROUTER_URL : String(form.url || "").trim();
  }

  // Why the form's address is not usable, or null: all a connection check needs.
  function providerAddressError(form) {
    const url = formAddress(form);
    if (form.kind === "compatible") {
      if (!url) return "Enter the server's address, ending in /v1.";
      if (!/^https?:\/\/[^/\s]+/i.test(url) || !hostOf(url)) return "The address must start with http:// or https://.";
    }
    return null;
  }

  // Why the provider form cannot be saved, or null.
  function providerFormError(form, networks, providers, exceptId, configProvider) {
    const named = nameError("provider", form.name, providers, exceptId);
    if (named) return named;
    const url = formAddress(form);
    const addressProblem = providerAddressError(form);
    if (addressProblem) return addressProblem;
    const bad = parseNetworks(networks).invalid;
    if (bad.length) return "“" + bad[0] + "” is not an IPv4 range or address. Write each as 192.168.5.0/24 or 192.168.5.20, separated by commas.";
    const typed = String(form.newKey || "").trim();
    if (!isLocalAddress(url, networks)) {
      if (!form.allowHosted) return "Tick the box to allow sending scene text to " + hostOf(url) + ".";
      if (/^http:/i.test(url) && (typed || form.keySaved)) return "Use the https:// address: over http:// the key would cross the internet unencrypted.";
    }
    const problem = defaultsError(form.defaults, form.kind);
    if (problem) return problem;
    return decisionsOn(form.defaults) ? decisionsProviderError(form.defaults.verifyProvider, form.kind, providers, configProvider || null) : null;
  }

  // The decisions model is asked through OpenRouter only. `chosen` is the verify
  // provider's ID (blank: the profile's own, of kind `ownKind`).
  function decisionsProviderError(chosen, ownKind, providers, configProvider) {
    const kind = chosen ? kindOfProvider(chosen, providers, configProvider) : ownKind;
    if (chosen && chosen !== CONFIG_PROVIDER && !providers.some(function (entry) { return entry.id === chosen; })) return "Choose a saved provider to verify with, or leave it as the profile’s own.";
    return kind === "openrouter" ? null : "The decisions model works only through OpenRouter. Choose an OpenRouter provider to verify with, or set the verify pass to Same model or Off.";
  }

  // The provider a form stands for. `saved` is the stored provider being
  // edited (null for a new one): its key is kept unless a new one is typed or
  // removal is chosen, and never follows a changed address.
  function providerFromForm(form, saved, networks) {
    const url = formAddress(form);
    const typed = String(form.newKey || "").trim();
    let apiKey = "";
    if (typed) apiKey = typed;
    else if (saved && !form.removeKey && addressKey(saved.url) === addressKey(url)) apiKey = saved.apiKey;
    return {
      id: saved ? saved.id : "", name: String(form.name).trim(), url: url, apiKey: apiKey,
      allowHosted: !!(form.allowHosted && !isLocalAddress(url, networks)), defaults: defaultsFromForm(form.defaults, providerOf(url) === "openrouter" ? "openrouter" : "compatible", null),
    };
  }

  function providerChanged(saved, edited) {
    return stable(storedProvider(Object.assign({}, saved, { id: "" }))) !== stable(storedProvider(Object.assign({}, edited, { id: "" })));
  }

  // The `draft` of a check request: the provider form as it is now, not saved
  // (the worker's draftFields reads it). { url, allowHosted, name? } plus the
  // key: a newly typed one travels as `apiKey`; a saved key that saving would
  // keep (the same address, not removed) is only named, `keyOf` being the saved
  // provider's id, and the worker reads it from the settings; with no key, or
  // one being removed, neither. Needs only an address (see providerAddressError).
  function providerCheckDraft(form, saved, networks) {
    const url = formAddress(form);
    const typed = String(form.newKey || "").trim();
    const draft = { url: url, allowHosted: !!(form.allowHosted && !isLocalAddress(url, networks)) };
    const name = String(form.name == null ? "" : form.name).trim().slice(0, MAX_PROFILE_NAME);
    if (name) draft.name = name;
    if (typed) draft.apiKey = typed;
    else if (saved && saved.apiKey && !form.removeKey && addressKey(saved.url) === addressKey(url)) draft.keyOf = saved.id;
    return draft;
  }

  // What a check of the form says about what it checked: "" when the values are the saved provider's,
  // else one sentence, so a pass is not taken for a saved provider.
  function checkedNote(form, saved, networks) {
    if (!saved) return "This checked the form\u2019s values, and the provider is not saved yet.";
    return providerChanged(saved, providerFromForm(form, saved, networks)) ? "This checked the form\u2019s values, which differ from the saved provider." : "";
  }

  // The worker before 0.7.2 answers a check of the form with this error.
  function oldWorkerCheck(result) {
    return !!result && /a check names a provider or a profile/.test(String(result.error || ""));
  }

  function profileForm(profile) {
    if (!profile) return { id: "", name: "", provider: "", model: "", overrides: defaultsForm({}) };
    return { id: profile.id, name: profile.name, provider: profile.provider, model: profile.model, overrides: defaultsForm(profile.overrides) };
  }

  // The kind of server a provider ID stands for: "openrouter" or "compatible".
  // The worker's config-file server is judged by the address the worker reports.
  function kindOfProvider(providerId, providers, configProvider) {
    if (providerId === CONFIG_PROVIDER) return configProvider && providerOf(configProvider.url) === "openrouter" ? "openrouter" : "compatible";
    const provider = providers.find(function (entry) { return entry.id === providerId; });
    return provider && providerOf(provider.url) === "openrouter" ? "openrouter" : "compatible";
  }

  function profileFormError(form, providers, profiles, configProvider) {
    const named = nameError("profile", form.name, profiles, form.id);
    if (named) return named;
    const known = form.provider === CONFIG_PROVIDER || providers.some(function (entry) { return entry.id === form.provider; });
    if (!known) return "Choose a provider.";
    if (form.provider !== CONFIG_PROVIDER && !String(form.model || "").trim()) return "Enter a model.";
    const base = baseDefaults(form.provider, providers);
    const own = kindOfProvider(form.provider, providers, configProvider);
    const problem = defaultsError(form.overrides, own, base);
    if (problem) return problem;
    return decisionsOn(form.overrides, base) ? decisionsProviderError(form.overrides.verifyProvider || (base && base.verifyProvider) || "", own, providers, configProvider) : null;
  }

  // The defaults of the provider a profile is on (none for the config file's).
  function baseDefaults(providerId, providers) {
    const provider = providers.find(function (entry) { return entry.id === providerId; });
    return provider ? provider.defaults : null;
  }

  function profileFromForm(form, providers, configProvider) {
    return {
      id: form.id, name: String(form.name).trim(), provider: form.provider, model: String(form.model || "").trim(),
      overrides: defaultsFromForm(form.overrides, kindOfProvider(form.provider, providers, configProvider), baseDefaults(form.provider, providers)),
    };
  }

  function profileChanged(saved, edited) {
    return stable(storedProfile(Object.assign({}, saved, { id: "" }))) !== stable(storedProfile(Object.assign({}, edited, { id: "" })));
  }

  // What Save does with an edited entry: "create" (new), "unchanged", or
  // "confirm" with the overwrite question. `used` is how many profiles use a provider.
  function saveChoice(kind, saved, edited, used, isActive) {
    if (!saved) return { action: "create", message: "" };
    if (!(kind === "provider" ? providerChanged(saved, edited) : profileChanged(saved, edited))) return { action: "unchanged", message: "" };
    let message = "Overwrite " + kind + " “" + saved.name + "”?";
    if (kind === "provider") message += used ? " " + used + " profile" + (used === 1 ? " uses" : "s use") + " it." : " No profile uses it.";
    else if (isActive) message += " It is the active profile.";
    return { action: "confirm", message: message };
  }

  // Saving a provider or profile. mode "update" overwrites the entry with the
  // edited one's id; "new" adds it under a fresh ID made from its name. Returns
  // { map, id }.
  function saveProviderInput(current, provider, mode) {
    const base = migrateSettings(current);
    const providers = parseProviders(base[PROVIDERS_KEY]);
    const profiles = parseProfiles(base[PROFILES_KEY]);
    if (mode === "new") {
      if (providers.length >= MAX_PROVIDERS) throw new Error("There can be at most " + MAX_PROVIDERS + " providers. Delete one first.");
      const named = nameError("provider", provider.name, providers);
      if (named) throw new Error(named);
      const id = uniqueId(provider.name, providers.map(function (entry) { return entry.id; }));
      providers.push(Object.assign({}, provider, { id: id, name: provider.name.trim() }));
      return { map: writeLists(base, providers, profiles), id: id };
    }
    const index = providers.findIndex(function (entry) { return entry.id === provider.id; });
    if (index === -1) throw new Error("That provider no longer exists.");
    const named = nameError("provider", provider.name, providers, provider.id);
    if (named) throw new Error(named);
    providers[index] = Object.assign({}, provider, { name: provider.name.trim() });
    return { map: writeLists(base, providers, profiles), id: provider.id };
  }

  // A provider can go only when no profile uses it.
  function deleteProviderInput(current, id) {
    const base = migrateSettings(current);
    const providers = parseProviders(base[PROVIDERS_KEY]);
    if (!providers.some(function (entry) { return entry.id === id; })) throw new Error("That provider no longer exists.");
    const using = profilesUsing(parseProfiles(base[PROFILES_KEY]), id);
    const chained = providers.filter(function (entry) { return entry.id !== id && entry.defaults.verifyProvider === id; });
    if (chained.length) throw new Error("Provider " + chained.map(function (entry) { return "“" + entry.name + "”"; }).join(", ") + " asks this provider to verify (its verify provider default). Change that first.");
    if (using.length) throw new Error(using.length + " profile" + (using.length === 1 ? " uses" : "s use") + " this provider (" + using.map(function (profile) { return profile.name; }).join(", ") + "). Delete or change " + (using.length === 1 ? "it" : "them") + " first.");
    return writeLists(base, providers.filter(function (entry) { return entry.id !== id; }), null);
  }

  function saveProfileInput(current, profile, mode, configProvider) {
    const base = migrateSettings(current);
    const providers = parseProviders(base[PROVIDERS_KEY]);
    const profiles = parseProfiles(base[PROFILES_KEY]);
    if (mode !== "new" && !profiles.some(function (entry) { return entry.id === profile.id; })) throw new Error("That profile no longer exists.");
    const problem = profileFormError(profileForm(mode === "new" ? Object.assign({}, profile, { id: "" }) : profile), providers, profiles, configProvider);
    if (problem) throw new Error(problem);
    if (mode === "new") {
      if (profiles.length >= MAX_PROFILES) throw new Error("There can be at most " + MAX_PROFILES + " profiles. Delete one first.");
      const id = uniqueId(profile.name, profiles.map(function (entry) { return entry.id; }));
      profiles.push(Object.assign({}, profile, { id: id, name: profile.name.trim() }));
      return { map: writeLists(base, null, profiles), id: id };
    }
    const index = profiles.findIndex(function (entry) { return entry.id === profile.id; });
    profiles[index] = Object.assign({}, profile, { name: profile.name.trim() });
    return { map: writeLists(base, null, profiles), id: profile.id };
  }

  // Deleting the active profile leaves none active.
  function deleteProfileInput(current, id) {
    const base = migrateSettings(current);
    const profiles = parseProfiles(base[PROFILES_KEY]);
    if (!profiles.some(function (entry) { return entry.id === id; })) throw new Error("That profile no longer exists.");
    writeLists(base, null, profiles.filter(function (entry) { return entry.id !== id; }));
    if (base[ACTIVE_KEY] === id) { delete base[ACTIVE_KEY]; delete base[AUTO_KEY]; }
    return base;
  }

  function setActiveInput(current, id) {
    const base = migrateSettings(current);
    if (!parseProfiles(base[PROFILES_KEY]).some(function (entry) { return entry.id === id; })) throw new Error("That profile no longer exists.");
    base[ACTIVE_KEY] = id;
    return base;
  }

  // The automatic-analysis switch: on needs an active profile to analyse with.
  function setAutoInput(current, on) {
    const base = migrateSettings(current);
    if (on && !activeProfileId(base)) throw new Error("Make a profile active first: automatic analysis uses it.");
    if (on) base[AUTO_KEY] = true; else delete base[AUTO_KEY];
    return base;
  }

  // "My network also uses": valid ranges only, compact; blank removes the key.
  function setNetworksInput(current, text) {
    const base = migrateSettings(current);
    const parsed = parseNetworks(text);
    if (parsed.invalid.length) throw new Error("“" + parsed.invalid[0] + "” is not an IPv4 range or address. Write each as 192.168.5.0/24 or 192.168.5.20, separated by commas.");
    const value = parsed.networks.map(function (range) { return range.text; }).join(", ");
    if (value) base[NETWORKS_KEY] = value; else delete base[NETWORKS_KEY];
    return base;
  }

  // ---------------------------------------------------------------------------
  // The request queue (pure). The page adds requests to llmRequests; the worker
  // answers each once and lists its ID in `answered`.

  // A fresh ID per request; the worker answers each ID once.
  function requestId(now, random) {
    const stamp = Math.floor(now == null ? Date.now() : now).toString(36);
    const noise = Math.floor((random == null ? Math.random() : random) * 1679616).toString(36);
    return "r" + stamp + noise;
  }

  function makeRequest(kind, fields, now, random) {
    const time = now == null ? Date.now() : now;
    return Object.assign({ id: requestId(time, random), kind: kind, at: new Date(time).toISOString() }, fields || {});
  }

  function parseRequests(value) {
    const out = [];
    parseList(value).forEach(function (entry) {
      if (!isObject(entry) || typeof entry.id !== "string" || !ENTRY_ID.test(entry.id) || REQUEST_KINDS.indexOf(entry.kind) === -1 || !validDate(entry.at)) return;
      if (out.some(function (other) { return other.id === entry.id; })) return;
      out.push(JSON.parse(JSON.stringify(entry)));
    });
    return out.slice(-MAX_REQUESTS);
  }

  // The requests the worker has not answered and that are not too old to matter:
  // the worker ignores any request but a run once it is ten minutes old, so the
  // page stops waiting for those then; a run is kept for a day.
  function pendingRequests(requests, answered, now) {
    const time = now == null ? Date.now() : now;
    const done = answered || [];
    return requests.filter(function (request) {
      return done.indexOf(request.id) === -1 && time - Date.parse(request.at) <= (LONG_REQUESTS.indexOf(request.kind) !== -1 ? REQUEST_MAX_AGE_MS : REQUEST_FRESH_MS);
    });
  }

  // Drops what the worker answered, a run older than 24 hours, and any other request older than ten minutes.
  function pruneRequests(requests, answered, now) {
    return pendingRequests(requests, answered, now);
  }

  // The map with the request added: answered and old ones dropped first, at
  // most 20 kept (the oldest go).
  function addRequest(current, request, options) {
    const opts = options || {};
    const next = Object.assign({}, current);
    const kept = pruneRequests(parseRequests(next[REQUESTS_KEY]), opts.answered, opts.now).filter(function (entry) { return entry.id !== request.id; });
    next[REQUESTS_KEY] = JSON.stringify(kept.concat([request]).slice(-MAX_REQUESTS));
    return next;
  }

  // The map with answered and old requests dropped.
  function dropRequests(current, answered, now) {
    const next = Object.assign({}, current);
    const kept = pruneRequests(parseRequests(next[REQUESTS_KEY]), answered, now);
    if (kept.length) next[REQUESTS_KEY] = JSON.stringify(kept); else delete next[REQUESTS_KEY];
    return next;
  }

  // The map without one request, by id (a draft check's, once it is answered or no longer wanted).
  function removeRequest(current, id) {
    const next = Object.assign({}, current);
    const kept = parseRequests(next[REQUESTS_KEY]).filter(function (entry) { return entry.id !== id; });
    if (kept.length) next[REQUESTS_KEY] = JSON.stringify(kept); else delete next[REQUESTS_KEY];
    return next;
  }

  // The form of a run request. `scope` says what to analyse: { type: "library" }
  // now, { type: "scenes", sceneIds } for a list view. options: profile (ID),
  // limit (scenes to send to the model; blank is no limit), tagIds (blank or
  // empty is every candidate tag), mode (new, secondOpinion or force).
  function runRequest(scope, options, now, random) {
    const opts = options || {};
    if (typeof opts.profile !== "string" || !opts.profile) throw new Error("Choose a profile.");
    const target = isObject(scope) ? scope : {};
    let cleanScope;
    if (target.type === "library") cleanScope = { type: "library" };
    else if (target.type === "scenes") {
      const ids = (Array.isArray(target.sceneIds) ? target.sceneIds : []).map(String).filter(function (id, index, list) { return /^\d+$/.test(id) && list.indexOf(id) === index; });
      if (!ids.length || ids.length > MAX_SCENE_IDS) throw new Error("Choose from 1 to " + MAX_SCENE_IDS + " scenes.");
      cleanScope = { type: "scenes", sceneIds: ids };
    } else throw new Error("That kind of selection can't be analysed here yet.");
    const fields = { profile: opts.profile, scope: cleanScope };
    const limit = String(opts.limit == null ? "" : opts.limit).trim();
    if (limit) {
      if (!/^\d+$/.test(limit) || Number(limit) < 1 || Number(limit) > MAX_RUN_LIMIT) throw new Error("The scene limit must be a whole number from 1 to 1,000,000, or blank for no limit.");
      fields.limit = Number(limit);
    }
    const tagIds = (Array.isArray(opts.tagIds) ? opts.tagIds : []).map(String).filter(function (id, index, list) { return /^\d+$/.test(id) && list.indexOf(id) === index; });
    if (tagIds.length) fields.tagIds = tagIds;
    const mode = opts.mode == null || opts.mode === "" ? "new" : opts.mode;
    if (!MODES.some(function (entry) { return entry.id === mode; })) throw new Error("Choose which scenes to analyse.");
    fields.mode = mode;
    return makeRequest("run", fields, now, random);
  }

  // ---------------------------------------------------------------------------
  // The worker's answers (pure, defensive). Values may be JSON text or the
  // value itself.

  const cut = function (item, max) { return typeof item === "string" ? item.slice(0, max) : ""; };
  // A number that may have come back as text.
  const numberOf = function (item) { return typeof item === "number" ? item : typeof item === "string" && item.trim() ? Number(item) : NaN; };
  const count = function (item) { const n = numberOf(item); return isFinite(n) && n >= 0 ? n : 0; };

  // The worker's answers, defensively: { "<address>": { at, request?, models, error? } }.
  function parseModelLists(value) {
    let data;
    try { data = typeof value === "string" ? JSON.parse(value || "null") : value; } catch (_) { return {}; }
    const lists = {};
    if (!isObject(data)) return lists;
    Object.keys(data).forEach(function (address) {
      const entry = data[address];
      if (!isObject(entry) || typeof entry.at !== "string") return;
      const models = (Array.isArray(entry.models) ? entry.models : []).filter(function (model) { return isObject(model) && typeof model.id === "string" && model.id; }).map(function (model) {
        const out = { id: model.id };
        if (typeof model.name === "string" && model.name) out.name = model.name;
        if (Number(model.context) > 0) out.context = Number(model.context);
        if (isFinite(model.priceIn) && isFinite(model.priceOut) && model.priceIn !== null && model.priceOut !== null && Number(model.priceIn) >= 0 && Number(model.priceOut) >= 0) { out.priceIn = Number(model.priceIn); out.priceOut = Number(model.priceOut); }
        return out;
      });
      lists[address] = { at: entry.at, request: typeof entry.request === "string" ? entry.request : "", models: models, error: typeof entry.error === "string" ? entry.error : "" };
    });
    return lists;
  }

  // Whether the panel should ask the worker again: no list, or one older than 10 minutes.
  function listIsStale(entry, now) {
    const at = entry ? Date.parse(entry.at) : NaN;
    return isNaN(at) || (now == null ? Date.now() : now) - at > WORKER_LIST_FRESH_MS;
  }

  // One check answer, stored under its request's ID: { at, running, ok, steps, settings, error }.
  function parseCheckEntry(id, entry) {
    if (!isObject(entry) || typeof entry.at !== "string") return null;
    const steps = (Array.isArray(entry.steps) ? entry.steps : []).filter(isObject).slice(0, 20).map(function (step) {
      return { name: cut(step.name, 80), ok: step.ok === true, warn: step.warn === true, detail: cut(step.detail, 600) };
    });
    let rows = entry.settings;
    // The settings the check used, as a list of { name, value, source } or a map of name to value.
    if (isObject(rows)) rows = Object.keys(rows).map(function (name) { return { name: name, value: isObject(rows[name]) ? rows[name].value : rows[name], source: isObject(rows[name]) ? rows[name].source : "" }; });
    const settings = (Array.isArray(rows) ? rows : []).filter(isObject).slice(0, 30).map(function (row) {
      return { name: cut(row.name, 80), value: row.value != null && typeof row.value !== "object" ? String(row.value).slice(0, 400) : "", source: cut(row.source, 80) };
    });
    return { request: id, at: entry.at, running: entry.running === true, ok: entry.ok === true, steps: steps, settings: settings, error: cut(entry.error, 600) };
  }

  // The tags the worker can analyse: { at, hash, ids }, or null when it has not published them (an older worker, or none yet).
  function parseCandidates(value) {
    const data = jsonValue(value);
    if (!isObject(data) || !Array.isArray(data.ids)) return null;
    return { at: cut(data.at, 40), hash: cut(data.hash, 40), ids: data.ids.filter(function (id) { return typeof id === "string" && /^\d{1,12}$/.test(id); }).slice(0, 50000) };
  }

  const NO_ELIGIBLE_TEXT = "No tag is eligible. A tag needs a description; tags with a Quick Tagger role, tags set to off and tags marked \u201cignore auto tag\u201d are left out.";

  // The tags a picker offers: with the worker's list, only the tags it can analyse (a description, and not a role tag,
  // not set to off, not marked ignore auto tag); without one, every tag with a description, as before.
  // `tags` is { status, list } and the result adds `filtered`, `all` (every tag with a description) and `key`.
  function eligibleView(tags, candidates) {
    if (!tags || tags.status !== "ready") return tags;
    if (!candidates) return Object.assign({}, tags, { filtered: false, all: tags.list, key: "" });
    const ok = {};
    candidates.ids.forEach(function (id) { ok[id] = true; });
    return Object.assign({}, tags, { filtered: true, all: tags.list, key: candidates.hash + ":" + candidates.ids.length, list: tags.list.filter(function (tag) { return ok[String(tag.id)] === true; }) });
  }

  // The chosen tag IDs that are still eligible (all of them when the worker has not said).
  function usableChoices(chosen, view) {
    if (!view || view.status !== "ready" || !view.filtered) return chosen;
    const ok = {};
    view.list.forEach(function (tag) { ok[String(tag.id)] = true; });
    return chosen.filter(function (id) { return ok[id] === true; });
  }

  function droppedNote(count) {
    return count + (count === 1 ? " chosen tag is" : " chosen tags are") + " no longer eligible and " + (count === 1 ? "was" : "were") + " taken out of your choice.";
  }

  function parseChecks(value) {
    const data = jsonValue(value), out = {};
    if (!isObject(data)) return out;
    Object.keys(data).slice(0, 20).forEach(function (id) { const entry = parseCheckEntry(id, data[id]); if (entry) out[id] = entry; });
    return out;
  }

  function parseJob(entry) {
    if (!isObject(entry) || typeof entry.id !== "string" || !entry.id || JOB_STATES.indexOf(entry.state) === -1) return null;
    const profile = isObject(entry.profile) ? entry.profile : {};
    const source = isObject(entry.source) ? entry.source : {};
    const request = isObject(entry.request) ? entry.request : {};
    const counts = isObject(entry.counts) ? entry.counts : {};
    const out = {
      id: entry.id, state: entry.state, type: entry.type === "eval" ? "eval" : "run", profile: { id: cut(profile.id, 40), name: cut(profile.name, 80) }, source: { key: cut(source.key, 40), label: cut(source.label, 120) },
      request: { limit: isFinite(numberOf(request.limit)) && numberOf(request.limit) > 0 ? numberOf(request.limit) : null, tagIds: (Array.isArray(request.tagIds) ? request.tagIds : []).map(String).filter(function (id) { return /^\d+$/.test(id); }),
        mode: MODES.some(function (mode) { return mode.id === request.mode; }) ? request.mode : "new", scope: { type: cut(isObject(request.scope) ? request.scope.type : "", 20) } },
      counts: { seen: count(counts.seen), analysed: count(counts.analysed), proposals: count(counts.proposals), withProposals: count(counts.withProposals), skipped: count(counts.skipped), unchanged: count(counts.unchanged), failed: count(counts.failed) },
      cost: isFinite(numberOf(entry.cost)) && numberOf(entry.cost) >= 0 ? numberOf(entry.cost) : null, published: count(entry.published), message: cut(entry.message, 600),
    };
    ["queuedAt", "startedAt", "finishedAt", "updatedAt"].forEach(function (key) { out[key] = validDate(entry[key]); });
    if (out.type === "eval") {
      out.request.method = request.method === "decisions" ? "decisions" : "profile";
      out.request.half = EVAL_HALVES.indexOf(request.half) !== -1 ? request.half : "tuning";
    }
    return out;
  }

  // The worker's map, whatever it holds: { status, modelLists, checks, jobs, answered }.
  function parseWorker(map) {
    const source = isObject(map) ? map : {};
    const status = jsonValue(source.status);
    let parsed = null;
    if (isObject(status) && validDate(status.at)) {
      const configProvider = isObject(status.configProvider) && typeof status.configProvider.url === "string" ? { url: status.configProvider.url.trim() } : null;
      if (configProvider && typeof status.configProvider.model === "string" && status.configProvider.model) configProvider.model = status.configProvider.model.trim();
      parsed = {
        at: status.at, request: cut(status.request, 40), version: cut(status.version, 40), protocol: isFinite(numberOf(status.protocol)) ? numberOf(status.protocol) : 0,
        pluginId: cut(status.pluginId, 80), auto: status.auto === true, answersOnly: status.answersOnly === true, configProvider: configProvider, job: cut(status.job, 40), llmError: cut(status.llmError, 600),
      };
    }
    const jobs = jsonValue(source.jobs);
    const answered = jsonValue(source.answered);
    return {
      status: parsed,
      modelLists: parseModelLists(jsonValue(source.modelLists)),
      checks: parseChecks(source.checks),
      candidates: parseCandidates(source.candidates),
      jobs: (Array.isArray(jobs) ? jobs : []).map(parseJob).filter(Boolean).slice(0, 10),
      answered: (Array.isArray(answered) ? answered : []).filter(function (id) { return typeof id === "string" && id; }).slice(0, 40),
      evalAcks: parseEvalAcks(source.evalAcks), evalCounts: parseEvalCounts(source.evalCounts), evalBySource: parseEvalBySource(source.evalBySource), evalAnswersFor: parseEvalAnswersFor(source.evalAnswersFor),
      evalQueues: parseEvalQueues(source.evalQueues), evalClaims: parseEvalClaims(source.evalClaims), evalRuns: parseEvalRuns(source.evalRuns),
      evalDetail: parseEvalDetail(source.evalDetail), evalScenes: parseEvalScenes(source.evalScenes),
    };
  }

  const WORKER_PROTOCOL = 1;

  // How the worker answers the status request this page sent ({ id, at (ms) }).
  // state: waiting (not yet), connected, silent (nothing within 15 seconds), or
  // mismatch (another protocol or plugin).
  function workerConnection(worker, sent, now) {
    const time = now == null ? Date.now() : now;
    const status = worker.status;
    const answered = !!(sent && (worker.answered.indexOf(sent.id) !== -1 || (status && status.request === sent.id)));
    if (status && answered) {
      if (status.protocol !== WORKER_PROTOCOL) return { state: "mismatch", text: "The worker speaks protocol " + status.protocol + ", this page protocol " + WORKER_PROTOCOL + ". Update the plugin and the worker together." };
      if (status.pluginId && status.pluginId !== ID) return { state: "mismatch", text: "The worker is set up for the plugin “" + status.pluginId + "”, not this one. Set stash.pluginId in its config file." };
      return { state: "connected", text: "Worker connected (version " + (status.version || "unknown") + ", answered " + listAge(status.at, time) + ")." };
    }
    if (sent && time - sent.at < CONNECT_WAIT_MS) return { state: "waiting", text: "Looking for the worker…" };
    return { state: "silent", text: "Worker has not answered: start it with `npm run semantic -- serve`." + (status ? " It was last seen " + listAge(status.at, time) + "." : "") };
  }

  // Whether the page should read the worker's map: a request is unanswered, a
  // job is queued or running, or a check still says it is running.
  function needsPolling(requests, worker, now) {
    const time = now == null ? Date.now() : now;
    if (pendingRequests(requests, worker.answered, time).length) return true;
    if (worker.jobs.some(function (job) { return job.state === "queued" || job.state === "running"; })) return true;
    return Object.keys(worker.checks).some(function (id) { return worker.checks[id].running && time - Date.parse(worker.checks[id].at) < REQUEST_FRESH_MS; });
  }

  // A request unanswered for ten minutes (a worker that is not running) is
  // asked about less often.
  function pollDelay(requests, worker, now) {
    const time = now == null ? Date.now() : now;
    const waiting = pendingRequests(requests, worker.answered, time);
    const busy = worker.jobs.some(function (job) { return job.state === "queued" || job.state === "running"; });
    return !busy && waiting.length && waiting.every(function (request) { return time - Date.parse(request.at) > REQUEST_FRESH_MS; }) ? SLOW_POLL_MS : POLL_MS;
  }

  // Where a check this page asked for stands: sent is { id, startedAt (ms) }.
  // waiting: nothing yet; running: the worker took it; done: answered;
  // noanswer: nothing within CHECK_WAIT_MS (a late answer still counts).
  function checkPhase(worker, sent, now, waitMs) {
    const result = worker.checks[sent.id];
    if (result) return { phase: result.running ? "running" : "done", result: result };
    const limit = waitMs == null ? CHECK_WAIT_MS : waitMs;
    return { phase: (now == null ? Date.now() : now) - sent.startedAt >= limit ? "noanswer" : "waiting", result: null };
  }

  // One line for the outcome of an answered check.
  function checkSummary(result) {
    const failed = result.steps.filter(function (step) { return !step.ok; })[0];
    if (failed) return "Failed at \u201c" + failed.name + "\u201d.";
    if (!result.steps.length) return "The worker gave no steps.";
    return result.steps.some(function (step) { return step.warn; }) ? "Passed, with a note." : "Passed.";
  }

  // Where scene text goes for a profile: the provider's host, and whether it is
  // on the user's network. The worker's config-file server is judged by the
  // address the worker reports; local is null when that is not known.
  function runDestination(profile, providers, configProvider, networks) {
    if (!profile) return null;
    let url = "", name = "";
    if (profile.provider === CONFIG_PROVIDER) { url = configProvider ? configProvider.url : ""; name = "Worker config file"; }
    else {
      const provider = providers.find(function (entry) { return entry.id === profile.provider; });
      if (!provider) return null;
      url = provider.url; name = provider.name;
    }
    const host = url ? hostOf(url) : null;
    return { provider: name, url: url, host: host, local: host ? isLocalAddress(url, networks) : null };
  }

  // The worker's model list for a provider, and how fresh it is.
  function listState(worker, providerId, now) {
    const entry = worker.modelLists[providerId] || null;
    return { entry: entry, stale: listIsStale(entry, now) };
  }

  // "N scenes", "5 credits": a job's progress in words.
  function jobProgress(job) {
    const counts = job.counts;
    const parts = [counts.analysed + " analysed"];
    if (counts.seen && counts.seen !== counts.analysed) parts.push(counts.seen + " seen");
    if (counts.withProposals || counts.proposals) parts.push(counts.proposals + " proposal" + (counts.proposals === 1 ? "" : "s") + " on " + counts.withProposals + " scene" + (counts.withProposals === 1 ? "" : "s"));
    if (counts.unchanged) parts.push(counts.unchanged + " unchanged");
    if (counts.skipped) parts.push(counts.skipped + " skipped");
    if (counts.failed) parts.push(counts.failed + " failed");
    return parts.join(", ");
  }

  // "just now", "2 minutes ago", "3 hours ago".
  function listAge(at, now) {
    const time = typeof at === "number" ? at : Date.parse(at);
    if (isNaN(time)) return "";
    const seconds = Math.max(0, Math.round(((now == null ? Date.now() : now) - time) / 1000));
    if (seconds < 45) return "just now";
    const unit = function (n, word) { return n + " " + word + (n === 1 ? "" : "s") + " ago"; };
    if (seconds < 3600) return unit(Math.max(1, Math.round(seconds / 60)), "minute");
    if (seconds < 86400) return unit(Math.round(seconds / 3600), "hour");
    return unit(Math.round(seconds / 86400), "day");
  }

  // The search behind the model field: every word typed must occur in the ID
  // or the name (any case); models whose ID holds all of them come before
  // those matched only through the name; the list's order is kept within each
  // group. At most `limit` are returned, with how many more matched.
  function filterModels(models, query, limit) {
    const max = limit == null ? MODEL_OPTION_LIMIT : limit;
    const words = String(query == null ? "" : query).toLowerCase().split(/\s+/).filter(Boolean);
    const byId = [], byName = [];
    (models || []).forEach(function (model) {
      const id = String(model.id).toLowerCase(), both = id + " " + String(model.name || "").toLowerCase();
      if (words.every(function (word) { return id.indexOf(word) !== -1; })) byId.push(model);
      else if (words.every(function (word) { return both.indexOf(word) !== -1; })) byName.push(model);
    });
    const all = byId.concat(byName);
    return { shown: all.slice(0, max), total: all.length, more: Math.max(0, all.length - max) };
  }

  // "41k context", "$0.10 in, $0.30 out per million tokens"; only what is known.
  function modelFacts(model) {
    const parts = [];
    if (Number(model.context) > 0) parts.push(Math.round(Number(model.context) / 1000) + "k context");
    const priceIn = model.priceIn == null ? null : perMillion(model.priceIn), priceOut = model.priceOut == null ? null : perMillion(model.priceOut);
    if (priceIn && priceOut) parts.push(priceIn + " in, " + priceOut + " out per million tokens");
    return parts.join(" \u00b7 ");
  }

  function perMillion(value) {
    const number = Number(value);
    if (!isFinite(number) || number < 0 || value === "" || value == null) return null;
    const dollars = number * 1e6;
    return "$" + (dollars > 0 && dollars < 0.01 ? dollars.toPrecision(2) : dollars.toFixed(2));
  }

  // OpenRouter's model list as choices for the model field.
  function modelChoices(json) {
    const list = json && Array.isArray(json.data) ? json.data : [];
    return list.filter(function (model) { return model && typeof model.id === "string" && model.id; }).map(function (model) {
      const parts = [model.id];
      if (Number(model.context_length) > 0) parts.push(Math.round(Number(model.context_length) / 1000) + "k context");
      const pricing = model.pricing || {};
      const prompt = perMillion(pricing.prompt), completion = perMillion(pricing.completion);
      if (prompt && completion) parts.push(prompt + " in, " + completion + " out per million tokens");
      const choice = { id: model.id, label: parts.join(" · ") };
      // What the search shows too, only when the list says it.
      if (typeof model.name === "string" && model.name && model.name !== model.id) choice.name = model.name;
      if (Number(model.context_length) > 0) choice.context = Number(model.context_length);
      if (prompt && completion) { choice.priceIn = Number(pricing.prompt); choice.priceOut = Number(pricing.completion); }
      return choice;
    }).sort(function (a, b) { return a.id < b.id ? -1 : a.id > b.id ? 1 : 0; });
  }

  // ---------------------------------------------------------------------------
  // Tabs (pure): kept in the URL as ?tab=

  const TAB_IDS = Object.freeze(["review", "run", "profiles", "providers", "evaluate"]);

  function tabOf(search) {
    const value = new URLSearchParams(search || "").get("tab");
    return TAB_IDS.indexOf(value) !== -1 ? value : "review";
  }

  function tabUrl(tab) {
    return tab === "review" || TAB_IDS.indexOf(tab) === -1 ? ROUTE : ROUTE + "?tab=" + tab;
  }



  // ---------------------------------------------------------------------------
  // Evaluation: the owner's own answers (pure). Answers are NOT kept in Stash:
  // the page sends them to the worker as `evalAnswers` requests, which the
  // worker saves in its own file, and keeps an outbox in the browser until the
  // worker acknowledges them (worker map key `evalAcks`). No scene custom field
  // is written for evaluation. See docs/development/semantic-tagger-evaluation-plan.md.

  const EVAL_ANSWERS = Object.freeze(["yes", "no", "unclear"]);
  // review (0.7.3): a decision made on a proposal, or a report that an applied tag is wrong.
  const EVAL_SOURCES = Object.freeze(["tagged", "claims", "picks", "scene", "browser", "review"]);
  const EVAL_QUEUE_SOURCES = Object.freeze(["tagged", "picks"]);
  const EVAL_QUOTE_FIELDS = Object.freeze(["title", "details", "file"]);
  const EVAL_METHODS = Object.freeze([{ id: "profile", label: "The profile as it is" }, { id: "decisions", label: "Decision model alone" }]);
  const EVAL_HALVES = Object.freeze(["tuning", "test", "both"]);
  const EVAL_OUTCOMES = Object.freeze(["found", "missed", "wrong", "guessed", "silent", "unclear", "waiting"]);
  const EVAL_LIMITS = Object.freeze({ quotes: 3, quote: 200, batch: 50, queue: 200, queueDefault: 100, outbox: 5000, detailRows: 50 });
  const OUTBOX_KEY = "semanticTagger.outbox";
  // A request the worker handled but never acknowledged is sent again, but not sooner than this.
  const RESEND_MS = TIMING.RESEND_MS;
  // The worker answers an invalid evalAnswers request without acknowledging it. The answer and the
  // acknowledgement may be written a moment apart, so a request counts as refused only when it has
  // been answered and still not acknowledged this long afterwards.
  const REFUSE_MS = TIMING.REFUSE_MS;
  const OUTBOX_POLL_MS = TIMING.OUTBOX_POLL_MS;

  // FNV-1a, 32 bits, over the UTF-8 bytes of "st-eval:" + the scene ID. An even
  // hash is the tuning half, an odd one the test half; a scene flagged seen
  // (Check now) is always tuning. The worker computes the same.
  function evalHash(sceneId) {
    let hash = 0x811c9dc5;
    Array.from(new TextEncoder().encode("st-eval:" + String(sceneId))).forEach(function (byte) { hash = Math.imul(hash ^ byte, 0x01000193) >>> 0; });
    return hash >>> 0;
  }

  function evalHalf(sceneId, seen) {
    return seen === true || evalHash(sceneId) % 2 === 0 ? "tuning" : "test";
  }

  function evalTime(now) {
    return new Date(now == null ? Date.now() : now).toISOString().replace(/\.\d{3}Z$/, "Z");
  }

  // The words marked as evidence: at most 3, each from the title, description
  // or file name, at most 200 characters.
  function cleanQuotes(list) {
    const out = [];
    (Array.isArray(list) ? list : []).forEach(function (entry) {
      if (out.length >= EVAL_LIMITS.quotes || !isObject(entry) || EVAL_QUOTE_FIELDS.indexOf(entry.f) === -1) return;
      const t = String(entry.t == null ? "" : entry.t).replace(/\s+/g, " ").trim().slice(0, EVAL_LIMITS.quote);
      if (t) out.push({ f: entry.f, t: t });
    });
    return out;
  }

  // The sources that proposed a tag, as an answer keeps them: at most 6 of { s, label (80 characters at
  // most), c? } with c one of high, medium, low when it is known.
  function cleanBy(list) {
    const out = [];
    (Array.isArray(list) ? list : []).forEach(function (entry) {
      if (out.length >= LIMITS.sources || !isObject(entry) || typeof entry.s !== "string" || !SOURCE_KEY.test(entry.s)) return;
      if (out.some(function (other) { return other.s === entry.s; })) return;
      const clean = { s: entry.s, label: clip(entry.label, LIMITS.sourceLabel) || entry.s };
      if (CONFIDENCES.indexOf(entry.c) !== -1) clean.c = entry.c;
      out.push(clean);
    });
    return out;
  }

  // The sources a proposal lists as having proposed it, for an answer's `by`: key, label and that source's
  // confidence. A version 1 proposal (one unnamed source) has none.
  function answerSources(item) {
    return cleanBy(((item && item.by) || []).filter(function (entry) { return entry.source; }).map(function (entry) { return { s: entry.source, label: entry.label, c: entry.confidence }; }));
  }

  // One answer as `evalAnswers` carries it. answer null clears. Evidence is kept
  // only with a yes; `by` only with src review and an answer. options: quotes, src, had, by, now.
  function evalItem(sceneId, tagId, answer, options) {
    const scene = String(sceneId), tag = String(tagId), opts = options || {};
    if (!/^\d+$/.test(scene) || !/^\d+$/.test(tag)) throw new Error("That is not a scene or a tag.");
    if (answer !== null && EVAL_ANSWERS.indexOf(answer) === -1) throw new Error("Choose Yes, No or Unclear.");
    const item = { sceneId: scene, tagId: tag, a: answer };
    const quotes = answer === "yes" ? cleanQuotes(opts.quotes) : [];
    if (quotes.length) item.q = quotes;
    item.at = evalTime(opts.now);
    if (EVAL_SOURCES.indexOf(opts.src) !== -1) item.src = opts.src;
    if (typeof opts.had === "boolean") item.had = opts.had;
    const by = opts.src === "review" && answer !== null ? cleanBy(opts.by) : [];
    if (by.length) item.by = by;
    return item;
  }

  // An item read back defensively (from storage); null when it is not one.
  function cleanEvalItem(raw) {
    if (!isObject(raw) || !/^\d+$/.test(String(raw.sceneId)) || !/^\d+$/.test(String(raw.tagId))) return null;
    if (raw.a !== null && EVAL_ANSWERS.indexOf(raw.a) === -1) return null;
    if (!validDate(raw.at)) return null;
    try { return evalItem(raw.sceneId, raw.tagId, raw.a, { quotes: raw.q, src: raw.src, had: raw.had, by: raw.by, now: Date.parse(raw.at) }); } catch (_) { return null; }
  }

  const pairKey = function (sceneId, tagId) { return String(sceneId) + ":" + String(tagId); };

  // ---- The outbox: what the worker has not acknowledged yet.
  // { v, rev, answers: { "scene:tag": { rev, item } }, seen: { scene: rev },
  //   picks: { "scene:tag": { rev, op: "add"|"remove" } },
  //   sent: [{ id, answers: { key: rev }, seen: {...}, picks: {...}, answeredAt }], lastSentAt,
  //   refused: how many items the worker refused (answered the request, saved nothing) }
  // A change made after a request was built has a higher rev, so the
  // acknowledgement of that request removes only what it carried.

  function emptyOutbox() { return { v: 1, rev: 0, answers: {}, seen: {}, picks: {}, sent: [], lastSentAt: 0, refused: 0 }; }

  function revMap(value, valid) {
    const out = {};
    if (!isObject(value)) return out;
    Object.keys(value).forEach(function (key) { if (valid(key) && Number.isInteger(value[key]) && value[key] > 0) out[key] = value[key]; });
    return out;
  }

  const PAIR = /^\d+:\d+$/;

  function parseOutbox(value) {
    let data = value;
    if (typeof value === "string") { try { data = JSON.parse(value); } catch (_) { return emptyOutbox(); } }
    const box = emptyOutbox();
    if (!isObject(data) || data.v !== 1) return box;
    let top = 0;
    const note = function (rev) { if (rev > top) top = rev; };
    if (isObject(data.answers)) {
      Object.keys(data.answers).forEach(function (key) {
        const entry = data.answers[key], item = isObject(entry) ? cleanEvalItem(entry.item) : null;
        if (!item || !PAIR.test(key) || pairKey(item.sceneId, item.tagId) !== key || !Number.isInteger(entry.rev) || entry.rev < 1) return;
        box.answers[key] = { rev: entry.rev, item: item };
        note(entry.rev);
      });
    }
    if (isObject(data.seen)) Object.keys(data.seen).forEach(function (id) { if (/^\d+$/.test(id) && Number.isInteger(data.seen[id]) && data.seen[id] > 0) { box.seen[id] = data.seen[id]; note(data.seen[id]); } });
    if (isObject(data.picks)) {
      Object.keys(data.picks).forEach(function (key) {
        const entry = data.picks[key];
        if (!PAIR.test(key) || !isObject(entry) || (entry.op !== "add" && entry.op !== "remove") || !Number.isInteger(entry.rev) || entry.rev < 1) return;
        box.picks[key] = { rev: entry.rev, op: entry.op };
        note(entry.rev);
      });
    }
    box.sent = (Array.isArray(data.sent) ? data.sent : []).filter(function (entry) { return isObject(entry) && typeof entry.id === "string" && ENTRY_ID.test(entry.id); }).slice(-4).map(function (entry) {
      const sent = { id: entry.id, answers: revMap(entry.answers, function (key) { return PAIR.test(key); }), seen: revMap(entry.seen, function (id) { return /^\d+$/.test(id); }), picks: revMap(entry.picks, function (key) { return PAIR.test(key); }) };
      [sent.answers, sent.seen, sent.picks].forEach(function (map) { Object.keys(map).forEach(function (key) { note(map[key]); }); });
      if (Number.isFinite(entry.answeredAt) && entry.answeredAt > 0) sent.answeredAt = entry.answeredAt;
      return sent;
    });
    box.lastSentAt = Number.isFinite(data.lastSentAt) && data.lastSentAt > 0 ? data.lastSentAt : 0;
    box.refused = Number.isInteger(data.refused) && data.refused > 0 ? data.refused : 0;
    box.rev = Math.max(Number.isInteger(data.rev) ? data.rev : 0, top);
    return box;
  }

  function outboxCount(box) {
    return Object.keys(box.answers).length + Object.keys(box.seen).length + Object.keys(box.picks).length;
  }

  // "3 answers waiting for the worker", "2 answers and 1 pick waiting for the worker"; "" when none.
  function outboxText(box) {
    const answers = Object.keys(box.answers).length, picks = Object.keys(box.picks).length, seen = Object.keys(box.seen).length;
    const parts = [];
    if (answers) parts.push(answers + " answer" + (answers === 1 ? "" : "s"));
    if (picks) parts.push(picks + " pick" + (picks === 1 ? "" : "s"));
    if (seen) parts.push(seen + " scene flag" + (seen === 1 ? "" : "s"));
    return parts.length ? parts.join(" and ").replace(/, ([^,]*)$/, " and $1") + " waiting for the worker" : "";
  }

  // The outbox with a change added. change: { items: [evalItem...], seen: [sceneId],
  // picks: { add: [{ sceneId, tagId }], remove: [...] } }. A later change to the
  // same pair replaces the earlier one. An answer settles its pair's pending pick.
  function outboxAdd(box, change) {
    const next = parseOutbox(JSON.stringify(box)), input = change || {};
    (input.items || []).forEach(function (item) {
      const clean = cleanEvalItem(item);
      if (!clean) throw new Error("That answer is not valid.");
      const key = pairKey(clean.sceneId, clean.tagId);
      next.rev += 1;
      next.answers[key] = { rev: next.rev, item: clean };
      if (next.picks[key] && next.picks[key].op === "add") delete next.picks[key];
    });
    (input.seen || []).forEach(function (id) {
      if (!/^\d+$/.test(String(id))) throw new Error("That is not a scene.");
      next.rev += 1;
      next.seen[String(id)] = next.rev;
    });
    ["add", "remove"].forEach(function (op) {
      ((input.picks && input.picks[op]) || []).forEach(function (pair) {
        if (!/^\d+$/.test(String(pair.sceneId)) || !/^\d+$/.test(String(pair.tagId))) throw new Error("That is not a scene or a tag.");
        next.rev += 1;
        next.picks[pairKey(pair.sceneId, pair.tagId)] = { rev: next.rev, op: op };
      });
    });
    if (outboxCount(next) > EVAL_LIMITS.outbox) throw new Error("Too many answers are waiting for the worker (" + EVAL_LIMITS.outbox + "). Wait until it has saved them.");
    return next;
  }

  const byRev = function (map) { return function (a, b) { const x = map[a], y = map[b]; return (typeof x === "object" ? x.rev : x) - (typeof y === "object" ? y.rev : y); }; };

  // The next `evalAnswers` request: the oldest waiting items, at most 50 of each
  // kind. Returns { request, sent } or null when nothing waits.
  function outboxRequest(box, now, random) {
    const answers = Object.keys(box.answers).sort(byRev(box.answers)).slice(0, EVAL_LIMITS.batch);
    const seen = Object.keys(box.seen).sort(byRev(box.seen)).slice(0, EVAL_LIMITS.batch);
    const picksOf = function (op) { return Object.keys(box.picks).filter(function (key) { return box.picks[key].op === op; }).sort(byRev(box.picks)).slice(0, EVAL_LIMITS.batch); };
    const add = picksOf("add"), remove = picksOf("remove");
    if (!answers.length && !seen.length && !add.length && !remove.length) return null;
    const fields = {};
    if (answers.length) fields.items = answers.map(function (key) { return box.answers[key].item; });
    if (seen.length) fields.seen = seen;
    const pair = function (key) { const parts = key.split(":"); return { sceneId: parts[0], tagId: parts[1] }; };
    if (add.length || remove.length) {
      fields.picks = {};
      if (add.length) fields.picks.add = add.map(pair);
      if (remove.length) fields.picks.remove = remove.map(pair);
    }
    const request = makeRequest("evalAnswers", fields, now, random);
    const record = function (keys, map) { const out = {}; keys.forEach(function (key) { out[key] = typeof map[key] === "object" ? map[key].rev : map[key]; }); return out; };
    return { request: request, sent: { id: request.id, answers: record(answers, box.answers), seen: record(seen, box.seen), picks: record(add.concat(remove), box.picks) } };
  }

  // Takes what a sent request carried out of the outbox, but not an item changed since;
  // returns how many items that was.
  function dropSent(next, entry) {
    let dropped = 0;
    Object.keys(entry.answers).forEach(function (key) { if (next.answers[key] && next.answers[key].rev === entry.answers[key]) { delete next.answers[key]; dropped += 1; } });
    Object.keys(entry.seen).forEach(function (id) { if (next.seen[id] === entry.seen[id]) { delete next.seen[id]; dropped += 1; } });
    Object.keys(entry.picks).forEach(function (key) { if (next.picks[key] && next.picks[key].rev === entry.picks[key]) { delete next.picks[key]; dropped += 1; } });
    return dropped;
  }

  // What the worker acknowledged leaves the outbox: exactly what that request
  // carried, and not an answer changed since.
  function outboxAck(box, ackIds) {
    const next = parseOutbox(JSON.stringify(box));
    next.sent = next.sent.filter(function (entry) {
      if (ackIds.indexOf(entry.id) === -1) return true;
      dropSent(next, entry);
      return false;
    });
    return next;
  }

  function outboxDismissRefused(box) {
    const next = parseOutbox(JSON.stringify(box));
    next.refused = 0;
    return next;
  }

  function outboxMarkSent(box, sent, now) {
    const next = parseOutbox(JSON.stringify(box));
    next.sent = next.sent.concat([sent]).slice(-4);
    next.lastSentAt = now == null ? Date.now() : now;
    return next;
  }

  // One step of the pump. view: { acks: [request ids the worker saved],
  // pending: [ids of requests still in the queue and not answered],
  // answered: [ids the worker has answered] }. Returns { box, request, sent };
  // request is null when nothing should be sent now. At most one unacknowledged
  // request is out at a time. A request that was answered but never
  // acknowledged was refused (the worker saved nothing): its items are dropped and
  // counted in `refused`, never sent again. A request that vanished without an
  // answer (dropped after a day) is dead: its items are sent again, but not sooner
  // than RESEND_MS after the last send.
  function outboxStep(box, view, now, random) {
    const acked = view.acks || [], pending = view.pending || [], answered = view.answered || [], time = now == null ? Date.now() : now;
    let next = outboxAck(box, acked);
    let dead = false;
    next.sent = next.sent.filter(function (entry) {
      if (pending.indexOf(entry.id) !== -1) return true;
      if (answered.indexOf(entry.id) === -1) { dead = true; return false; }
      if (!entry.answeredAt) { entry.answeredAt = time; return true; }
      if (time - entry.answeredAt < REFUSE_MS) return true;
      next.refused += dropSent(next, entry);
      return false;
    });
    if (next.sent.length) return { box: next, request: null, sent: null };
    if (!outboxCount(next) || (dead && time - next.lastSentAt < RESEND_MS)) return { box: next, request: null, sent: null };
    const built = outboxRequest(next, time, random);
    return built ? { box: next, request: built.request, sent: built.sent } : { box: next, request: null, sent: null };
  }

  // The outbox in the browser: local storage, every call wrapped in try/catch.
  // When storage is missing or refuses writes it keeps the box in memory and
  // says so (`persistent` is false), so the page can warn that closing it loses
  // what is not yet saved.
  function createOutboxStore(getStorage) {
    let memory = emptyOutbox(), persistent = true;
    const storage = function () { try { return getStorage(); } catch (_) { return null; } };
    (function probe() {
      const area = storage();
      if (!area) { persistent = false; return; }
      try { area.setItem(OUTBOX_KEY + ".probe", "1"); area.removeItem(OUTBOX_KEY + ".probe"); } catch (_) { persistent = false; }
    })();
    return {
      isPersistent: function () { return persistent; },
      load: function () {
        if (persistent) {
          try { const raw = storage().getItem(OUTBOX_KEY); memory = raw ? parseOutbox(raw) : emptyOutbox(); } catch (_) { persistent = false; }
        }
        return memory;
      },
      save: function (box) {
        memory = box;
        if (persistent) {
          try {
            if (outboxCount(box) || box.sent.length || box.refused) storage().setItem(OUTBOX_KEY, JSON.stringify(box)); else storage().removeItem(OUTBOX_KEY);
          } catch (_) { persistent = false; }
        }
        return box;
      },
    };
  }

  // ---- A scene's answers as the page shows them: what the worker said
  // (evalAnswersFor), then what is still in the outbox, then what was given
  // since (the same shape, never sent). { seen, tags: { tagId: { a, q, at, src, had } }, picks: [tagId] }.
  function mergeSceneAnswers(fetched, box, sceneId) {
    const id = String(sceneId);
    const out = { seen: !!(fetched && fetched.seen), tags: {}, picks: fetched ? fetched.picks.slice() : [] };
    if (fetched) Object.keys(fetched.tags).forEach(function (tagId) { out.tags[tagId] = fetched.tags[tagId]; });
    const waiting = box || emptyOutbox();
    Object.keys(waiting.answers).sort(byRev(waiting.answers)).forEach(function (key) {
      const item = waiting.answers[key].item;
      if (item.sceneId !== id) return;
      if (item.a === null) delete out.tags[item.tagId];
      else out.tags[item.tagId] = { a: item.a, q: item.q || [], at: item.at, src: item.src || "", had: typeof item.had === "boolean" ? item.had : null };
      out.picks = out.picks.filter(function (tagId) { return tagId !== item.tagId; });
    });
    if (waiting.seen[id]) out.seen = true;
    Object.keys(waiting.picks).sort(byRev(waiting.picks)).forEach(function (key) {
      const parts = key.split(":");
      if (parts[0] !== id) return;
      out.picks = out.picks.filter(function (tagId) { return tagId !== parts[1]; });
      if (waiting.picks[key].op === "add") out.picks.push(parts[1]);
    });
    return out;
  }

  // ---- Who carries a tag. A scene carries a tag when it has the tag, a
  // descendant of it, or one of its Quick Tagger role tags. `related` holds
  // the IDs of the tag's descendants (or, from the scene's side, of the
  // ancestors of the scene's tags); sceneTags are { id, name, custom_fields }.
  function isRoleTag(tag, conceptName) {
    const role = tag && tag.custom_fields && tag.custom_fields.quickTagger_role;
    return (role === "user" || role === "marker") && (String(tag.name) === conceptName + " (user)" || String(tag.name) === conceptName + " (marker)");
  }

  function carriedBy(tag, sceneTags, ancestorIds) {
    const ids = sceneTagIds(sceneTags);
    return ids.indexOf(String(tag.id)) !== -1 || (ancestorIds || []).indexOf(String(tag.id)) !== -1 || (sceneTags || []).some(function (entry) { return isRoleTag(entry, String(tag.name)); });
  }

  // ---- Keys, evidence and the pieces of the answering screen (pure).

  // 1 Yes, 2 No, 3 Unclear, 4 Skip: never with a modifier, while a key is held
  // down, after the key was handled, or while focus is in a field.
  function answerKey(event) {
    if (!event || event.defaultPrevented || event.repeat || event.ctrlKey || event.metaKey || event.altKey) return null;
    const target = event.target, name = target && target.tagName ? String(target.tagName).toUpperCase() : "";
    if (name === "INPUT" || name === "SELECT" || name === "TEXTAREA" || (target && target.isContentEditable)) return null;
    return ({ "1": "yes", "2": "no", "3": "unclear", "4": "skip" })[event.key] || null;
  }

  const FIELD_WORDS = { title: "title", details: "description", file: "file name" };

  // Text selected inside one field becomes evidence: { list, message }. At most 3,
  // 200 characters each; the same words in the same field once.
  function evidenceFrom(field, text, current) {
    const list = current || [];
    if (EVAL_QUOTE_FIELDS.indexOf(field) === -1) return { list: list, message: "Select words in the title, the description or the file name." };
    const t = String(text == null ? "" : text).replace(/\s+/g, " ").trim();
    if (!t) return { list: list, message: "" };
    if (t.length > EVAL_LIMITS.quote) return { list: list, message: "Select at most " + EVAL_LIMITS.quote + " characters for one piece of evidence." };
    if (list.some(function (entry) { return entry.f === field && entry.t === t; })) return { list: list, message: "Those words are already marked." };
    if (list.length >= EVAL_LIMITS.quotes) return { list: list, message: "At most " + EVAL_LIMITS.quotes + " pieces of evidence. Remove one first." };
    return { list: list.concat([{ f: field, t: t }]), message: "Marked “" + t + "” in the " + FIELD_WORDS[field] + " as evidence." };
  }

  // The Evaluate tab's address: the tag stays in it, and the source of "More ways to add answers" when it is the
  // scenes that have the tag or the owner's picks (waiting claims are the default and are not named).
  function evaluateUrl(tagId, source) {
    const params = [];
    if (tagId && /^\d+$/.test(String(tagId))) params.push("tag=" + tagId);
    if (source && ["tagged", "picks"].indexOf(source) !== -1) params.push("source=" + source);
    return ROUTE + "?tab=evaluate" + (params.length ? "&" + params.join("&") : "");
  }

  // ---- Requests (page to worker) for the evaluation.

  const digits = function (value) { return /^\d+$/.test(String(value)); };
  const uniqueDigits = function (list) { return (Array.isArray(list) ? list : []).map(String).filter(function (id, index, all) { return digits(id) && all.indexOf(id) === index; }); };

  function evalAnswersRequest(fields, now, random) {
    const input = fields || {};
    const out = {};
    const items = (Array.isArray(input.items) ? input.items : []).map(cleanEvalItem).filter(Boolean);
    if (items.length) out.items = items.slice(0, EVAL_LIMITS.batch);
    const seen = uniqueDigits(input.seen);
    if (seen.length) out.seen = seen.slice(0, EVAL_LIMITS.batch);
    const picks = {};
    ["add", "remove"].forEach(function (op) {
      const list = ((input.picks && input.picks[op]) || []).filter(function (pair) { return pair && digits(pair.sceneId) && digits(pair.tagId); }).map(function (pair) { return { sceneId: String(pair.sceneId), tagId: String(pair.tagId) }; });
      if (list.length) picks[op] = list.slice(0, EVAL_LIMITS.batch);
    });
    if (Object.keys(picks).length) out.picks = picks;
    if (!Object.keys(out).length) throw new Error("There is nothing to send.");
    return makeRequest("evalAnswers", out, now, random);
  }

  function evalAnswersForRequest(sceneIds, now, random) {
    const ids = uniqueDigits(sceneIds);
    if (!ids.length || ids.length > EVAL_LIMITS.batch) throw new Error("Ask about 1 to " + EVAL_LIMITS.batch + " scenes.");
    return makeRequest("evalAnswersFor", { sceneIds: ids }, now, random);
  }

  // options.includeNamed (true for "Scenes that have this tag" only) asks for the scenes whose text names the tag too;
  // the worker leaves them out otherwise, as they are trivially Yes.
  function evalQueueRequest(tagId, source, limit, now, random, options) {
    if (!digits(tagId)) throw new Error("Choose a tag.");
    if (EVAL_QUEUE_SOURCES.indexOf(source) === -1) throw new Error("Choose which scenes to answer.");
    const n = limit == null || limit === "" ? EVAL_LIMITS.queueDefault : Number(limit);
    if (!Number.isInteger(n) || n < 1 || n > EVAL_LIMITS.queue) throw new Error("Ask for 1 to " + EVAL_LIMITS.queue + " scenes.");
    const fields = { tagId: String(tagId), source: source, limit: n };
    if (source === "tagged" && options && options.includeNamed === true) fields.includeNamed = true;
    return makeRequest("evalQueue", fields, now, random);
  }

  // options: profile (ID), method (profile or decisions), half (tuning, test or
  // both), tagIds (blank: all), limit (scenes, blank: no limit).
  function evalRunRequest(options, now, random) {
    const opts = options || {};
    if (typeof opts.profile !== "string" || !opts.profile) throw new Error("Choose a profile.");
    const method = opts.method == null || opts.method === "" ? "profile" : opts.method;
    if (!EVAL_METHODS.some(function (entry) { return entry.id === method; })) throw new Error("Choose a method.");
    const half = opts.half == null || opts.half === "" ? "tuning" : opts.half;
    if (EVAL_HALVES.indexOf(half) === -1) throw new Error("Choose a half.");
    const fields = { profile: opts.profile, method: method, half: half };
    const tagIds = uniqueDigits(opts.tagIds);
    if (tagIds.length) fields.tagIds = tagIds;
    const limit = String(opts.limit == null ? "" : opts.limit).trim();
    if (limit) {
      if (!/^\d+$/.test(limit) || Number(limit) < 1 || Number(limit) > MAX_RUN_LIMIT) throw new Error("The scene limit must be a whole number from 1 to 1,000,000, or blank for no limit.");
      fields.limit = Number(limit);
    }
    return makeRequest("evalRun", fields, now, random);
  }

  function evalScoreRequest(runId, now, random) {
    const fields = {};
    if (runId != null && runId !== "") {
      if (typeof runId !== "string" || !ENTRY_ID.test(runId)) throw new Error("That is not a run.");
      fields.runId = runId;
    }
    return makeRequest("evalScore", fields, now, random);
  }

  // options: runId, tagId (optional), outcome (optional), page (0-based).
  function evalDetailRequest(options, now, random) {
    const opts = options || {};
    if (typeof opts.runId !== "string" || !ENTRY_ID.test(opts.runId)) throw new Error("Choose a run.");
    const page = opts.page == null ? 0 : Number(opts.page);
    if (!Number.isInteger(page) || page < 0) throw new Error("That is not a page.");
    const fields = { runId: opts.runId };
    if (opts.tagId != null && opts.tagId !== "") { if (!digits(opts.tagId)) throw new Error("That is not a tag."); fields.tagId = String(opts.tagId); }
    if (opts.outcome != null && opts.outcome !== "") { if (EVAL_OUTCOMES.indexOf(opts.outcome) === -1) throw new Error("That is not an outcome."); fields.outcome = opts.outcome; }
    fields.page = page;
    return makeRequest("evalDetail", fields, now, random);
  }

  function evalSceneRequest(sceneId, profile, now, random) {
    if (!digits(sceneId)) throw new Error("That is not a scene.");
    if (typeof profile !== "string" || !profile) throw new Error("Choose a profile.");
    return makeRequest("evalScene", { sceneId: String(sceneId), profile: profile }, now, random);
  }

  // ---- The worker's evaluation answers, read defensively.

  const ratioOf = function (item) { const n = numberOf(item); return isFinite(n) && n >= 0 && n <= 1 ? n : null; };
  // A count that may be a number or an object of numbers (yes, no, unclear).
  const countOf = function (item) {
    if (isObject(item)) return Object.keys(item).reduce(function (sum, key) { return sum + count(item[key]); }, 0);
    return count(item);
  };

  function parseEvalAcks(value) {
    const data = jsonValue(value);
    return (Array.isArray(data) ? data : []).filter(function (id) { return typeof id === "string" && id; }).slice(-200);
  }

  // { at, total, tuning, test, picks, byTag: { tagId: { yes, no, unclear } } }
  function parseEvalCounts(value) {
    const data = jsonValue(value), byTag = {};
    const source = isObject(data) ? data : {};
    if (isObject(source.byTag)) Object.keys(source.byTag).filter(digits).slice(0, 5000).forEach(function (id) {
      const entry = source.byTag[id];
      if (isObject(entry)) byTag[id] = { yes: count(entry.yes), no: count(entry.no), unclear: count(entry.unclear) };
    });
    return { at: validDate(source.at), total: countOf(source.total), tuning: countOf(source.tuning), test: countOf(source.test), picks: countOf(source.picks), byTag: byTag };
  }

  // The owner's Review decisions by the source that proposed the tag (worker 0.7.3):
  // { at, sources: [{ s, label, yes, no, byConfidence: { high, medium, low: { yes, no } } }] }, at most 20, or an empty list.
  function parseEvalBySource(value) {
    const data = jsonValue(value), sources = [];
    if (isObject(data) && Array.isArray(data.sources)) data.sources.forEach(function (entry) {
      if (sources.length >= 20 || !isObject(entry) || typeof entry.s !== "string" || !SOURCE_KEY.test(entry.s)) return;
      const by = {};
      CONFIDENCES.forEach(function (level) { const one = isObject(entry.byConfidence) && isObject(entry.byConfidence[level]) ? entry.byConfidence[level] : {}; by[level] = { yes: count(one.yes), no: count(one.no) }; });
      sources.push({ s: entry.s, label: clip(entry.label, LIMITS.sourceLabel) || entry.s, yes: count(entry.yes), no: count(entry.no), byConfidence: by });
    });
    return { at: isObject(data) ? validDate(data.at) : "", sources: sources };
  }

  function cleanAnswerEntry(raw) {
    if (!isObject(raw) || EVAL_ANSWERS.indexOf(raw.a) === -1) return null;
    return { a: raw.a, q: cleanQuotes(raw.q), at: validDate(raw.at), src: EVAL_SOURCES.indexOf(raw.src) !== -1 ? raw.src : "", had: typeof raw.had === "boolean" ? raw.had : null };
  }

  // The one slot: { request, at, scenes: { sceneId: { seen, tags, picks } } }, or null.
  function parseEvalAnswersFor(value) {
    const data = jsonValue(value);
    if (!isObject(data)) return null;
    const scenes = {};
    if (isObject(data.scenes)) Object.keys(data.scenes).filter(digits).slice(0, EVAL_LIMITS.batch).forEach(function (id) {
      const entry = data.scenes[id];
      if (!isObject(entry)) return;
      const tags = {};
      if (isObject(entry.tags)) Object.keys(entry.tags).filter(digits).slice(0, 5000).forEach(function (tagId) { const clean = cleanAnswerEntry(entry.tags[tagId]); if (clean) tags[tagId] = clean; });
      scenes[id] = { seen: entry.seen === true, tags: tags, picks: uniqueDigits(entry.picks).slice(0, 5000) };
    });
    return { request: cut(data.request, 40), at: validDate(data.at), scenes: scenes };
  }

  // { "<tagId>:<source>": { at, request, source, sceneIds, scanned, more, includeNamed, named } }
  function parseEvalQueues(value) {
    const data = jsonValue(value), out = {};
    if (!isObject(data)) return out;
    Object.keys(data).slice(0, 10).forEach(function (key) {
      const match = /^(\d+):(tagged|picks)$/.exec(key), entry = data[key];
      if (!match || !isObject(entry)) return;
      out[key] = { tagId: match[1], source: match[2], at: validDate(entry.at), request: cut(entry.request, 40), sceneIds: uniqueDigits(entry.sceneIds).slice(0, 1000), scanned: count(entry.scanned), more: entry.more === true, includeNamed: entry.includeNamed === true, named: count(entry.named), error: cut(entry.error, 300) };
    });
    return out;
  }

  const queueKey = function (tagId, source) { return String(tagId) + ":" + source; };

  // { at, total, byTag: { tagId: [sceneId] } }, at most 2,000 pairs.
  function parseEvalClaims(value) {
    const data = jsonValue(value), byTag = {};
    const source = isObject(data) ? data : {};
    let pairs = 0;
    if (isObject(source.byTag)) Object.keys(source.byTag).filter(digits).forEach(function (id) {
      const ids = uniqueDigits(source.byTag[id]).slice(0, Math.max(0, 2000 - pairs));
      pairs += ids.length;
      if (ids.length) byTag[id] = ids;
    });
    return { at: validDate(source.at), total: isFinite(numberOf(source.total)) && numberOf(source.total) >= 0 ? numberOf(source.total) : pairs, byTag: byTag };
  }

  function parseRatio(value, keys) {
    const source = isObject(value) ? value : {}, out = {};
    keys.forEach(function (key) { out[key] = count(source[key]); });
    out.value = ratioOf(source.value);
    out.lo = ratioOf(source.lo);
    out.hi = ratioOf(source.hi);
    return out;
  }

  const PRECISION_KEYS = ["right", "wrong", "unclear", "waiting"], RECALL_KEYS = ["found", "missed"];

  // Precision adds the range while claims wait (worker 0.7.3): all waiting wrong, all waiting right. Recall adds
  // the figures for the yes answers a model's claims gave (fromModels) and for the owner's own (independent);
  // those are null from a worker that does not send them.
  function parsePair(value) {
    const source = isObject(value) ? value : {};
    const precision = parseRatio(source.precision, PRECISION_KEYS), recall = parseRatio(source.recall, RECALL_KEYS);
    const raw = isObject(source.precision) ? source.precision : {}, rawRecall = isObject(source.recall) ? source.recall : {};
    precision.ifWaitingWrong = ratioOf(raw.ifWaitingWrong);
    precision.ifWaitingRight = ratioOf(raw.ifWaitingRight);
    recall.fromModels = isObject(rawRecall.fromModels) ? parseRatio(rawRecall.fromModels, RECALL_KEYS) : null;
    recall.independent = isObject(rawRecall.independent) ? parseRatio(rawRecall.independent, RECALL_KEYS) : null;
    return { precision: precision, recall: recall };
  }

  // One half's figures. For the decisions method `atKeep` holds the same
  // precision and recall at keep thresholds (an object keyed by the threshold,
  // or a list of { keep, precision, recall }).
  function parseFigures(value) {
    if (!isObject(value)) return null;
    const guess = isObject(value.guess) ? value.guess : {}, evidence = isObject(value.evidence) ? value.evidence : {};
    const atKeep = [];
    if (Array.isArray(value.atKeep)) value.atKeep.forEach(function (entry) { if (isObject(entry) && isFinite(numberOf(entry.keep))) atKeep.push(Object.assign({ keep: numberOf(entry.keep) }, parsePair(entry))); });
    else if (isObject(value.atKeep)) Object.keys(value.atKeep).forEach(function (key) { if (isFinite(Number(key))) atKeep.push(Object.assign({ keep: Number(key) }, parsePair(value.atKeep[key]))); });
    atKeep.sort(function (a, b) { return a.keep - b.keep; });
    return Object.assign(parsePair(value), {
      guess: { guessed: count(guess.guessed), wrong: count(guess.wrong), silent: count(guess.silent) },
      evidence: { same: count(evidence.same), different: count(evidence.different) },
      nameInText: parsePair(value.nameInText), nameNotInText: parsePair(value.nameNotInText),
      tags: (Array.isArray(value.tags) ? value.tags : []).filter(function (entry) { return isObject(entry) && digits(entry.tagId); }).slice(0, 60).map(function (entry) { return Object.assign({ tagId: String(entry.tagId) }, parsePair(entry)); }),
      atKeep: atKeep,
    });
  }

  // The kept runs, newest first, at most 8.
  function parseEvalRuns(value) {
    const data = jsonValue(value), out = [];
    (Array.isArray(data) ? data : []).forEach(function (entry) {
      if (out.length >= 8 || !isObject(entry) || typeof entry.id !== "string" || !entry.id) return;
      const scenes = isObject(entry.scenes) ? entry.scenes : {}, thresholds = isObject(entry.thresholds) ? entry.thresholds : {};
      out.push({
        id: cut(entry.id, 40), at: validDate(entry.at), scoredAt: validDate(entry.scoredAt), profile: cut(entry.profile, 80),
        method: entry.method === "decisions" ? "decisions" : "profile", half: EVAL_HALVES.indexOf(entry.half) !== -1 ? entry.half : "",
        models: (Array.isArray(entry.models) ? entry.models : []).filter(function (model) { return typeof model === "string"; }).slice(0, 6).map(function (model) { return model.slice(0, 120); }),
        thresholds: { keep: ratioOf(thresholds.keep), high: ratioOf(thresholds.high) },
        scenes: { total: count(scenes.total), sample: count(scenes.sample), answered: count(scenes.answered), noText: count(scenes.noText), failed: count(scenes.failed), notHere: count(scenes.notHere) },
        cost: isFinite(numberOf(entry.cost)) && numberOf(entry.cost) >= 0 ? numberOf(entry.cost) : null,
        tuning: parseFigures(entry.tuning), test: parseFigures(entry.test),
      });
    });
    return out;
  }

  // The one slot of mistakes: rows from the tuning half only.
  function parseEvalDetail(value) {
    const data = jsonValue(value);
    if (!isObject(data)) return null;
    const rows = (Array.isArray(data.rows) ? data.rows : []).filter(function (row) { return isObject(row) && digits(row.sceneId) && digits(row.tagId); }).slice(0, EVAL_LIMITS.detailRows).map(function (row) {
      return {
        sceneId: String(row.sceneId), tagId: String(row.tagId), outcome: EVAL_OUTCOMES.indexOf(row.outcome) !== -1 ? row.outcome : "", answer: EVAL_ANSWERS.indexOf(row.answer) !== -1 ? row.answer : "",
        confidence: CONFIDENCES.indexOf(row.confidence) !== -1 ? row.confidence : "", p: ratioOf(row.p), field: cut(row.field, 20), quote: cut(row.quote, 300), reason: cut(row.reason, 300),
      };
    });
    return { request: cut(data.request, 40), runId: cut(data.runId, 40), page: count(data.page), total: count(data.total), rows: rows, refused: cut(data.refused, 200) };
  }

  // { "<request id>": { sceneId, at, profile, claims, error } }, the ten most recent.
  function parseEvalScenes(value) {
    const data = jsonValue(value), out = {};
    if (!isObject(data)) return out;
    Object.keys(data).slice(0, 10).forEach(function (id) {
      const entry = data[id];
      if (!isObject(entry) || !digits(entry.sceneId)) return;
      out[id] = {
        sceneId: String(entry.sceneId), at: validDate(entry.at), profile: cut(entry.profile, 80), error: cut(entry.error, 600),
        claims: (Array.isArray(entry.claims) ? entry.claims : []).filter(function (claim) { return isObject(claim) && digits(claim.tagId); }).slice(0, 200).map(function (claim) {
          return { tagId: String(claim.tagId), confidence: CONFIDENCES.indexOf(claim.confidence) !== -1 ? claim.confidence : "", p: ratioOf(claim.p), field: cut(claim.field, 20), quote: cut(claim.quote, 300), reason: cut(claim.reason, 300) };
        }),
      };
    });
    return out;
  }

  // ---- Figures in words.

  // 0.923 -> "92.3%", 0.92 -> "92%"; "" when there is no number.
  function percentText(value) {
    return typeof value === "number" && isFinite(value) ? Math.round(value * 1000) / 10 + "%" : "";
  }

  // "92% (95% interval 85% to 96%)", or "nothing to count yet" when there is no value.
  function ratioText(figure) {
    if (!figure || figure.value == null) return "nothing to count yet";
    const interval = figure.lo != null && figure.hi != null ? " (95% interval " + percentText(figure.lo) + " to " + percentText(figure.hi) + ")" : "";
    return percentText(figure.value) + interval;
  }

  const plural = function (n, word) { return n + " " + word + (n === 1 ? "" : "s"); };

  // "46 right, 4 wrong, 3 unclear, 12 waiting": the counts behind the precision.
  function precisionCounts(figure) {
    const f = figure || {};
    return (f.right || 0) + " right, " + (f.wrong || 0) + " wrong, " + (f.unclear || 0) + " unclear, " + (f.waiting || 0) + " waiting";
  }

  function recallCounts(figure) {
    const f = figure || {};
    return (f.found || 0) + " found, " + (f.missed || 0) + " missed";
  }

  // Precision while claims wait for an answer is a range: "71% to 93%" is what it would be if every waiting claim
  // were wrong, and if every one were right. "" when none wait or the worker did not send the range.
  function precisionRange(figure) {
    const f = figure || {};
    return f.waiting > 0 && f.ifWaitingWrong != null && f.ifWaitingRight != null ? percentText(f.ifWaitingWrong) + " to " + percentText(f.ifWaitingRight) : "";
  }

  // The headline: the range while claims wait, else the figure with its interval.
  function precisionHeadline(figure) {
    return precisionRange(figure) || ratioText(figure);
  }

  const RECALL_NOTE = "Recall counts only tags a model found or you marked yourself, so it reads higher than the truth.";

  // The two parts of recall, as lines: [{ id, label, text }]. Empty when the worker does not send them.
  function recallParts(figure) {
    const f = figure || {}, out = [];
    if (f.fromModels) out.push({ id: "models", label: "Tags a model found (your Review decisions and answers to claims)", text: ratioText(f.fromModels) + " (" + recallCounts(f.fromModels) + ")" });
    if (f.independent) out.push({ id: "own", label: "Tags you added yourself (the scene page, the scenes list, your own queues)", text: ratioText(f.independent) + " (" + recallCounts(f.independent) + ")" });
    return out;
  }

  // "Qwen: accepted 12, rejected 3 (80%)": one source's Review decisions; the share accepted of those decided.
  function decidedShare(entry) {
    const total = (entry.yes || 0) + (entry.no || 0);
    return total ? percentText((entry.yes || 0) / total) : "";
  }

  // The no answers a method claimed: "7 of 30 were claimed (4 on scenes that already have the tag, 3 on scenes that do not)".
  function guessText(guess) {
    const g = guess || {}, claimed = (g.guessed || 0) + (g.wrong || 0), total = claimed + (g.silent || 0);
    if (!total) return "no No answers yet";
    return claimed + " of " + plural(total, "No answer") + " claimed (" + (g.guessed || 0) + " on scenes that already have the tag, " + (g.wrong || 0) + " on scenes that do not)";
  }

  function evidenceText(evidence) {
    const e = evidence || {}, total = (e.same || 0) + (e.different || 0);
    return total ? (e.same || 0) + " of " + plural(total, "quote") + " share words with what you marked" : "no marked words to compare yet";
  }

  // Check now's claims set against the answers: [{ tagId, claimed, confidence, p,
  // field, quote, reason, answer, verdict }]. Verdicts: matches (a yes it claimed),
  // missed (a yes it did not claim), wrong (a no it claimed), unclear, unanswered
  // (claimed, no answer). A no it did not claim says nothing and is left out.
  function compareCheck(claims, tags) {
    const answers = tags || {}, rows = [], seen = {};
    (claims || []).forEach(function (claim) {
      if (seen[claim.tagId]) return;
      seen[claim.tagId] = true;
      const entry = answers[claim.tagId], answer = entry ? entry.a : "";
      rows.push(Object.assign({ claimed: true, answer: answer }, claim, { verdict: !answer ? "unanswered" : answer === "yes" ? "matches" : answer === "no" ? "wrong" : "unclear" }));
    });
    Object.keys(answers).forEach(function (tagId) {
      if (seen[tagId] || answers[tagId].a !== "yes") return;
      rows.push({ tagId: tagId, claimed: false, confidence: "", p: null, field: "", quote: "", reason: "", answer: "yes", verdict: "missed" });
    });
    return rows;
  }

  // Where scene text goes for an evaluation run: the profile's provider, or for the
  // decision model alone its verify provider (the profile's own when none is set).
  function evalDestination(profile, method, providers, configProvider, networks) {
    if (!profile) return null;
    if (method !== "decisions") return runDestination(profile, providers, configProvider, networks);
    const base = providers.find(function (entry) { return entry.id === profile.provider; });
    const via = (profile.overrides && profile.overrides.verifyProvider) || (base && base.defaults && base.defaults.verifyProvider) || profile.provider;
    return runDestination(Object.assign({}, profile, { provider: via }), providers, configProvider, networks);
  }

  // ---------------------------------------------------------------------------
  // GraphQL

  function fetchTransport(document, variables) {
    return fetch("/graphql", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: document, variables: variables || {} }),
    }).then(function (response) {
      if (!response.ok) throw new Error("Stash returned HTTP " + response.status + ".");
      return response.json();
    }).then(function (json) {
      if (json.errors && json.errors.length) throw new Error(json.errors[0].message || "GraphQL error");
      return json.data;
    });
  }

  // Everything a review row shows about a scene.
  const CARD_FIELDS = "id title details date studio { id name } performers { id name } tags { id name } custom_fields paths { screenshot preview vtt sprite } files { path duration width height }";
  const INDEX_PAGE = 1000;

  const QUERIES = {
    scenes: "query SemanticTaggerScenes($ids: [ID!]) { findScenes(ids: $ids, filter: { per_page: -1 }) { scenes { id title tags { id name } custom_fields files { path } } } }",
    definedTags: "query SemanticTaggerDefinedTags { findTags(filter: { per_page: -1, sort: \"name\", direction: ASC }) { tags { id name description } } }",
    pendingTotal: "query SemanticTaggerPendingTotal($f: SceneFilterType) { findScenes(scene_filter: $f, filter: { per_page: 0 }) { count } }",
    // One request per page: everything a row shows about the scene.
    tagScenes: "query SemanticTaggerTagScenes($f: SceneFilterType, $page: Int!, $per: Int!) { findScenes(scene_filter: $f, filter: { page: $page, per_page: $per, sort: \"id\", direction: ASC }) { count scenes { " + CARD_FIELDS + " } } }",
    // The confidence sort: every pending scene's ID and proposals, a thousand at a time...
    indexScenes: "query SemanticTaggerIndex($f: SceneFilterType, $page: Int!, $per: Int!) { findScenes(scene_filter: $f, filter: { page: $page, per_page: $per, sort: \"id\", direction: ASC }) { count scenes { id custom_fields } } }",
    // ...then one page of cards by ID.
    cardScenes: "query SemanticTaggerCards($ids: [ID!]) { findScenes(ids: $ids, filter: { per_page: -1 }) { scenes { " + CARD_FIELDS + " } } }",
    // Evaluation: the text of a scene and nothing else (no preview, no tags shown, no model output). Its tag IDs
    // are read only to tell whether it carries the tag; no custom field is read or written.
    evalCards: "query SemanticTaggerEvalCards($ids: [ID!]) { findScenes(ids: $ids, filter: { per_page: -1 }) { scenes { id title details files { path } performers { id name } studio { id name } tags { id } } } }",
    evalSceneTags: "query SemanticTaggerEvalSceneTags($ids: [ID!]) { findScenes(ids: $ids, filter: { per_page: -1 }) { scenes { id title details files { path } tags { id name custom_fields } } } }",
    // The tags a scene carries for a tag: its descendants, and tags named like its Quick Tagger role tags.
    evalCarry: "query SemanticTaggerEvalCarry($id: ID!, $name: String!) { d: findTags(tag_filter: { parents: { value: [$id], modifier: INCLUDES, depth: -1 } }, filter: { per_page: -1 }) { tags { id } } r: findTags(tag_filter: { name: { value: $name, modifier: INCLUDES } }, filter: { per_page: -1 }) { tags { id name custom_fields } } }",
    evalAncestors: "query SemanticTaggerEvalAncestors($ids: [ID!]) { findTags(tag_filter: { children: { value: $ids, modifier: INCLUDES, depth: -1 } }, filter: { per_page: -1 }) { tags { id name description } } }",
    evalTagNames: "query SemanticTaggerEvalTagNames($ids: [ID!]) { findTags(ids: $ids, filter: { per_page: -1 }) { tags { id name description } } }",
  };
  const WRITES = {
    addTag: "mutation SemanticTaggerAccept($ids: [ID!], $tag: [ID!]) { bulkSceneUpdate(input: { ids: $ids, tag_ids: { ids: $tag, mode: ADD } }) { id tags { id } } }",
  };
  const CONFIG_QUERY = "query SemanticTaggerConfig($include: [ID!]) { configuration { plugins(include: $include) } }";
  const CONFIGURE = "mutation SemanticTaggerConfigure($input: Map!) { configurePlugin(plugin_id: \"" + ID + "\", input: $input) }";

  function pendingFilter(tagId) {
    return { custom_fields: [tagId == null
      ? { field: FIELDS.pending, modifier: "NOT_NULL" }
      : { field: FIELDS.pending, modifier: "INCLUDES", value: ["|" + tagId + "|"] }] };
  }

  // One request that sets each scene's own field values.
  function updateFields(transport, changes) {
    const entries = changes.filter(function (change) { return change.change; });
    if (!entries.length) return Promise.resolve([]);
    const params = [], calls = [], variables = {};
    entries.forEach(function (entry, index) {
      const input = { id: String(entry.id), custom_fields: {} };
      if (Object.keys(entry.change.set).length) input.custom_fields.partial = entry.change.set;
      if (entry.change.remove.length) input.custom_fields.remove = entry.change.remove;
      // The scene's whole tag list, only when the same update changes its tags.
      if (entry.tagIds) input.tag_ids = entry.tagIds.map(String);
      params.push("$i" + index + ": SceneUpdateInput!");
      calls.push("u" + index + ": sceneUpdate(input: $i" + index + ") { id" + (entry.tagIds ? " tags { id }" : "") + " }");
      variables["i" + index] = input;
    });
    return transport("mutation SemanticTaggerFields(" + params.join(", ") + ") { " + calls.join(" ") + " }", variables);
  }

  // Reads the scenes' current fields first, so a decision never overwrites a
  // newer publish or another tab's decision.
  function loadScenes(transport, sceneIds) {
    return transport(QUERIES.scenes, { ids: sceneIds.map(String) }).then(function (data) { return data.findScenes.scenes; });
  }

  // ---- Review decisions as answers (0.7.3). Each decision on a proposal, and each report that an applied tag is
  // wrong, is also an answer for the evaluation: accept yes, reject no, report no, all with src "review". The
  // functions below return the answers with the scene write's result; the caller puts them in the outbox once
  // the write succeeded, and the write never waits for the worker.

  // The proposal item of a tag on a scene, as the scene's fields list it (null when it is gone).
  function proposalOf(customFields, tagId) {
    return parseProposals((customFields || {})[FIELDS.proposals]).items.find(function (entry) { return entry.tagId === String(tagId); }) || null;
  }

  // The answer for a decision made on a proposal: had false (the scene did not carry the tag yet), by the sources the
  // proposal lists. `at` is the time of the scene write.
  function reviewAnswer(scene, tagId, answer, at) {
    return evalItem(scene.id, tagId, answer, { src: "review", had: false, by: answerSources(proposalOf(scene.custom_fields, tagId)), now: Date.parse(at) });
  }

  // The answer for a report: no. `had` is false when the scene's applied record shows the tag came from an accepted
  // proposal (the usual case: only such a tag can be reported), else true. `by` is the sources the record kept.
  function reportAnswer(scene, tagId, at) {
    const record = parseApplied((scene.custom_fields || {})[FIELDS.applied])[String(tagId)] || null;
    return evalItem(scene.id, tagId, "no", { src: "review", had: !record, by: record ? record.by : [], now: Date.parse(at) });
  }

  // options.at: the time of the decision (tests). Resolves with { answers }: one answer per scene, "yes".
  function accept(transport, sceneIds, tagId, options) {
    const ids = sceneIds.map(String);
    return transport(WRITES.addTag, { ids: ids, tag: [String(tagId)] }).then(function (data) {
      const updated = data.bulkSceneUpdate || [];
      const confirmed = updated.filter(function (scene) { return (scene.tags || []).some(function (tag) { return String(tag.id) === String(tagId); }); });
      if (confirmed.length !== ids.length) throw new Error("Stash did not confirm the tag on every scene.");
      return loadScenes(transport, ids);
    }).then(function (scenes) {
      const at = (options && options.at) || new Date().toISOString();
      const answers = scenes.map(function (scene) { return reviewAnswer(scene, tagId, "yes", at); });
      return updateFields(transport, scenes.map(function (scene) {
        return { id: scene.id, change: resolveChange(scene.custom_fields, [tagId], false, { applied: true, sceneTags: scene.tags, at: at }) };
      })).then(function () { return { answers: answers }; });
    });
  }

  // reason: optional { category, note }. A reject with none still records a
  // feedback entry, so the worker keeps the proposal that was turned down.
  // Resolves with { answers }: one answer per scene whose proposal this reject took off the pending list, "no"; a
  // repeated click or a tag another tab already decided is not a new decision.
  function reject(transport, sceneIds, tagId, reason, tagName, options) {
    const at = (options && options.at) || new Date().toISOString();
    const names = {};
    if (tagName) names[String(tagId)] = tagName;
    return loadScenes(transport, sceneIds).then(function (scenes) {
      const answers = scenes.filter(function (scene) { return decodeIds((scene.custom_fields || {})[FIELDS.pending]).indexOf(String(tagId)) !== -1; }).map(function (scene) { return reviewAnswer(scene, tagId, "no", at); });
      return updateFields(transport, scenes.map(function (scene) {
        return { id: scene.id, change: resolveChange(scene.custom_fields, [tagId], true, { reason: reason || {}, tagNames: names, at: at }) };
      })).then(function () { return { answers: answers }; });
    });
  }

  // Removes an applied tag from one scene and records why, in one sceneUpdate. Resolves with { answers: [the report's answer, "no"] }.
  function reportWrong(transport, sceneId, tagId, reason, tagName, options) {
    return loadScenes(transport, [sceneId]).then(function (scenes) {
      const scene = scenes[0];
      if (!scene) throw new Error("The scene no longer exists.");
      const at = (options && options.at) || new Date().toISOString();
      const report = resolveReport(scene.custom_fields, scene.tags, tagId, reason, { tagName: tagName, at: at });
      return updateFields(transport, [{ id: scene.id, change: report.change, tagIds: report.tagIds }]).then(function (data) {
        const updated = data && data.u0;
        if (updated && updated.tags && updated.tags.some(function (tag) { return String(tag.id) === String(tagId); })) throw new Error("Stash did not remove the tag.");
        return { answers: [reportAnswer(scene, tagId, at)] };
      });
    });
  }

  // Adds a tag to a scene by hand: the owner added it, so it gets no applied record ("A model missed a tag…").
  // A record left over from an earlier AI accept of a tag that has since left the scene is dropped, so the tag
  // is not shown as AI-added again. Resolves when Stash confirmed the tag.
  function addByHand(transport, sceneId, tagId) {
    return transport(WRITES.addTag, { ids: [String(sceneId)], tag: [String(tagId)] }).then(function (data) {
      const updated = (data.bulkSceneUpdate || []).find(function (scene) { return String(scene.id) === String(sceneId); });
      if (!updated || !(updated.tags || []).some(function (tag) { return String(tag.id) === String(tagId); })) throw new Error("Stash did not confirm the tag on the scene.");
      return loadScenes(transport, [sceneId]);
    }).then(function (scenes) {
      const scene = scenes[0];
      if (!scene) return null;
      const applied = parseApplied((scene.custom_fields || {})[FIELDS.applied]);
      if (!applied[String(tagId)]) return null;
      delete applied[String(tagId)];
      const set = {}, remove = [];
      setApplied(scene.custom_fields || {}, applied, set, remove);
      return updateFields(transport, [{ id: scene.id, change: { set: set, remove: remove } }]);
    });
  }

  function requestAnalysis(transport, sceneId) {
    const set = {};
    set[FIELDS.request] = new Date().toISOString();
    return updateFields(transport, [{ id: sceneId, change: { set: set, remove: [] } }]);
  }

  function definedTags(transport) {
    return transport(QUERIES.definedTags).then(function (data) {
      return data.findTags.tags.filter(function (tag) { return String(tag.description || "").trim(); });
    });
  }

  // Pending counts for many tags in a few requests, as aliased count queries.
  function pendingCounts(transport, tagIds) {
    const counts = {};
    const chunks = [];
    for (let i = 0; i < tagIds.length; i += 40) chunks.push(tagIds.slice(i, i + 40));
    return chunks.reduce(function (previous, chunk) {
      return previous.then(function () {
        const params = [], calls = [], variables = {};
        chunk.forEach(function (id, index) {
          params.push("$f" + index + ": SceneFilterType");
          calls.push("c" + index + ": findScenes(scene_filter: $f" + index + ", filter: { per_page: 0 }) { count }");
          variables["f" + index] = pendingFilter(id);
        });
        return transport("query SemanticTaggerCounts(" + params.join(", ") + ") { " + calls.join(" ") + " }", variables).then(function (data) {
          chunk.forEach(function (id, index) { counts[id] = data["c" + index].count; });
        });
      });
    }, Promise.resolve()).then(function () { return counts; });
  }

  function pendingTotal(transport) {
    return transport(QUERIES.pendingTotal, { f: pendingFilter(null) }).then(function (data) { return data.findScenes.count; });
  }

  function tagScenes(transport, tagId, page) {
    return transport(QUERIES.tagScenes, { f: pendingFilter(tagId), page: page, per: PAGE_SIZE }).then(function (data) { return data.findScenes; });
  }

  // ---------------------------------------------------------------------------
  // Sort by confidence (pure, then the index that feeds it)

  const SORTS = Object.freeze([
    { id: "scene", label: "Scene order" },
    { id: "high", label: "Confidence: high first" },
    { id: "low", label: "Confidence: low first" },
    { id: "disagree", label: "Disagreements first" },
  ]);
  // The Agreement filter: which proposals to list by how the sources that looked agree.
  const AGREEMENTS = Object.freeze([
    { id: "all", label: "All" },
    { id: "agree", label: "Models agree" },
    { id: "disagree", label: "Models disagree" },
    { id: "single", label: "Only one model looked" },
  ]);
  const SORT_STORAGE_KEY = "semanticTagger.sort";
  const CONFIDENCE_RANK = { high: 3, medium: 2, low: 1 };

  function sortId(value) {
    return SORTS.some(function (entry) { return entry.id === value; }) ? String(value) : "scene";
  }

  // What a confidence sort compares: a numeric `s` (0 to 100) on the
  // proposal item when the worker publishes one, else high 3, medium 2, low 1.
  function sortKey(entry) {
    const score = entry && entry.score != null && entry.score !== "" ? Number(entry.score) : NaN;
    if (isFinite(score) && score >= 0 && score <= 100) return score;
    return CONFIDENCE_RANK[entry && entry.confidence] || 0;
  }

  // The index's entries in a sort's order: { id, confidence, score, literal, by, no }.
  // Confidence sorts: ties go to the number of sources that proposed it (more
  // first when high first, fewer first when low first), then a literal match
  // of the tag's name, then the scene ID. "disagree": proposals the sources
  // disagree on first, then as "high". "scene" is the order Stash gives: by ID.
  function sortEntries(entries, mode) {
    const direction = mode === "high" || mode === "disagree" ? -1 : mode === "low" ? 1 : 0;
    const agreeing = function (entry) { return (entry.by || []).length || 1; };
    return (entries || []).slice().sort(function (a, b) {
      if (mode === "disagree") {
        const split = (agreementOf(a) === "disagree" ? 0 : 1) - (agreementOf(b) === "disagree" ? 0 : 1);
        if (split) return split;
      }
      if (direction) {
        const difference = sortKey(a) - sortKey(b);
        if (difference) return difference * direction;
        const more = agreeing(a) - agreeing(b);
        if (more) return more * direction;
        if (!!a.literal !== !!b.literal) return a.literal ? -1 : 1;
      }
      return Number(a.id) - Number(b.id);
    });
  }

  function agreementId(value) {
    return AGREEMENTS.some(function (entry) { return entry.id === value; }) ? String(value) : "all";
  }

  // The filters on the review page: { by: source key or "", agreement }.
  // highOnly keeps only high confidence.
  function filtersActive(filters) {
    return !!(filters && (filters.by || agreementId(filters.agreement) !== "all" || filters.highOnly));
  }

  function filterEntries(entries, filters) {
    const f = filters || {};
    const agreement = agreementId(f.agreement);
    return (entries || []).filter(function (entry) {
      if (f.highOnly && entry.confidence !== "high") return false;
      if (f.by && (entry.by || []).indexOf(f.by) === -1) return false;
      if (agreement !== "all" && agreementOf(entry) !== agreement) return false;
      return true;
    });
  }

  // The sources the index names, for the Proposed by filter: [{ key, label, count }],
  // most proposals first. The unnamed source of version 1 fields is left out.
  function indexSources(entries) {
    const found = {};
    (entries || []).forEach(function (entry) {
      (entry.by || []).forEach(function (key) {
        if (!key) return;
        if (!found[key]) found[key] = { key: key, label: (entry.labels && entry.labels[key]) || key, count: 0 };
        found[key].count += 1;
      });
    });
    return Object.keys(found).map(function (key) { return found[key]; }).sort(function (a, b) { return b.count - a.count || (a.label < b.label ? -1 : a.label > b.label ? 1 : 0); });
  }

  // One scene's entry for a tag, from its custom fields (the tag must be pending
  // and have a proposal), or null.
  function indexEntry(scene, tagId) {
    const fields = (scene && scene.custom_fields) || {};
    if (decodeIds(fields[FIELDS.pending]).indexOf(String(tagId)) === -1) return null;
    let data;
    try { data = JSON.parse(fields[FIELDS.proposals] || "null"); } catch (_) { return null; }
    const raw = data && Array.isArray(data.items) ? data.items.find(function (entry) { return entry && String(entry.t) === String(tagId); }) : null;
    if (!raw) return null;
    const score = raw.s != null && raw.s !== "" ? Number(raw.s) : NaN;
    const item = parseProposals(JSON.stringify({ v: data.v, model: data.model, sources: data.sources, items: [raw] })).items[0];
    const labels = {};
    item.by.concat(item.no).forEach(function (entry) { if (entry.source) labels[entry.source] = entry.label; });
    return {
      id: String(scene.id), confidence: String(raw.c || ""), score: isFinite(score) && score >= 0 && score <= 100 ? score : null, literal: !!raw.l,
      by: item.by.map(function (entry) { return entry.source; }), no: item.no.map(function (entry) { return entry.source; }), labels: labels,
    };
  }

  // Every pending scene for the tag, a thousand at a time. options.onProgress
  // gets (loaded, total); options.cancelled() stops the reading early.
  function loadIndex(transport, tagId, options) {
    const opts = options || {};
    const entries = [];
    function next(page) {
      return transport(QUERIES.indexScenes, { f: pendingFilter(tagId), page: page, per: INDEX_PAGE }).then(function (data) {
        const result = data.findScenes;
        result.scenes.forEach(function (scene) { const entry = indexEntry(scene, tagId); if (entry) entries.push(entry); });
        if (opts.onProgress) opts.onProgress(Math.min(page * INDEX_PAGE, result.count), result.count);
        if (result.scenes.length && page * INDEX_PAGE < result.count && !(opts.cancelled && opts.cancelled())) return next(page + 1);
        return entries;
      });
    }
    return next(1);
  }

  // The cards for some scenes, in the order of the IDs given.
  function cardScenes(transport, ids) {
    if (!ids.length) return Promise.resolve([]);
    const list = ids.map(String);
    return transport(QUERIES.cardScenes, { ids: list }).then(function (data) {
      return data.findScenes.scenes.slice().sort(function (a, b) { return list.indexOf(String(a.id)) - list.indexOf(String(b.id)); });
    });
  }

  // The text cards of scenes, in the order of the IDs given. Scenes that no longer exist are missing.
  function evalCards(transport, ids) {
    if (!ids.length) return Promise.resolve([]);
    const list = ids.map(String);
    return transport(QUERIES.evalCards, { ids: list }).then(function (data) {
      return data.findScenes.scenes.slice().sort(function (a, b) { return list.indexOf(String(a.id)) - list.indexOf(String(b.id)); });
    });
  }

  // The IDs whose presence on a scene means it carries the tag: the tag, its descendants
  // and its role tags (as { ids }).
  function loadCarry(transport, tag) {
    return transport(QUERIES.evalCarry, { id: String(tag.id), name: String(tag.name) + " (" }).then(function (data) {
      const ids = [String(tag.id)];
      (data.d.tags || []).forEach(function (entry) { ids.push(String(entry.id)); });
      (data.r.tags || []).forEach(function (entry) { if (isRoleTag(entry, String(tag.name))) ids.push(String(entry.id)); });
      return ids.filter(function (id, index, all) { return all.indexOf(id) === index; });
    });
  }

  // Whether a scene (its tag IDs) carries a tag, given the IDs that count.
  function sceneCarries(tagIds, carry, tagId) {
    const own = sceneTagIds(tagIds);
    return (carry && carry.length ? carry : [String(tagId)]).some(function (id) { return own.indexOf(id) !== -1; });
  }

  // Both maps in one read: the page's own and the worker's.
  function readMaps(transport) {
    return transport(CONFIG_QUERY, { include: [ID, WORKER_ID] }).then(function (data) {
      const plugins = data && data.configuration && data.configuration.plugins;
      if (!plugins || typeof plugins !== "object") throw new Error("Couldn't read the plugin settings.");
      return { page: isObject(plugins[ID]) ? plugins[ID] : {}, worker: isObject(plugins[WORKER_ID]) ? plugins[WORKER_ID] : {} };
    });
  }

  // This page's map only; writes start from it.
  function settingsMap(transport) {
    return transport(CONFIG_QUERY, { include: [ID] }).then(function (data) {
      const plugins = data && data.configuration && data.configuration.plugins;
      if (!plugins || typeof plugins !== "object") throw new Error("Couldn't read the plugin settings.");
      return plugins[ID] && typeof plugins[ID] === "object" ? plugins[ID] : {};
    });
  }

  // Reads the page's map again just before writing, so a key saved elsewhere in
  // the meantime survives, builds the new map from it (`build` returns the
  // whole map, or throws a message for the user), and checks Stash's reply.
  // Returns the map Stash stored. Only the map named ID is ever written: the
  // worker's map has one writer, the worker.
  // The writes of one page run one after the other, so two of them (a request from a tab and the
  // outbox pump) cannot read the same map and lose one of the changes.
  let settingsQueue = Promise.resolve();
  function updateSettings(transport, build) {
    const run = function () {
      return Promise.resolve().then(function () { return settingsMap(transport); }).then(function (current) {
        const next = build(current);
        return transport(CONFIGURE, { input: next }).then(function (result) {
          const saved = result && result.configurePlugin;
          const same = saved && typeof saved === "object" && Object.keys(next).every(function (key) { return String(saved[key]) === String(next[key]); })
            && Object.keys(saved).every(function (key) { return Object.prototype.hasOwnProperty.call(next, key); });
          if (!same) throw new Error("Stash did not confirm the settings.");
          return saved;
        });
      });
    };
    const result = settingsQueue.then(run, run);
    settingsQueue = result.catch(function () {});
    return result;
  }

  // Adds one request to the queue (see addRequest) in a read-modify-write.
  // `answered` is the worker's list, so what it has handled is dropped.
  function enqueueRequest(transport, request, answered) {
    return updateSettings(transport, function (current) { return addRequest(migrateSettings(current), request, { answered: answered }); });
  }

  // OpenRouter's public list, with no key, cookies or referrer. By default
  // only models that support structured outputs, which the worker needs.
  function loadModels(fetchImpl, structuredOnly) {
    return (fetchImpl || fetch)(structuredOnly === false ? OPENROUTER_ALL : OPENROUTER_MODELS, { method: "GET", credentials: "omit", referrerPolicy: "no-referrer", cache: "no-store" }).then(function (response) {
      if (!response.ok) throw new Error("OpenRouter returned HTTP " + response.status + ".");
      return response.json();
    }).then(modelChoices);
  }

  function fileName(scene) {
    const path = scene.files && scene.files[0] && scene.files[0].path;
    return path ? String(path).replace(/^.*[\\/]/, "") : "";
  }

  // ---------------------------------------------------------------------------
  // What a review row shows about a scene (pure)

  // A row lists this many of the scene's own tags before "+N more".
  const TAG_LIMIT = 15;

  function formatDuration(seconds) {
    const total = Math.round(Number(seconds));
    if (!isFinite(total) || total <= 0) return "";
    const hours = Math.floor(total / 3600), minutes = Math.floor(total % 3600 / 60), rest = total % 60;
    const two = function (n) { return (n < 10 ? "0" : "") + n; };
    return hours ? hours + ":" + two(minutes) + ":" + two(rest) : minutes + ":" + two(rest);
  }

  // The usual name for a video's size, from its shorter side.
  function resolutionLabel(width, height) {
    const side = Math.min(Number(width), Number(height));
    if (!(side > 0)) return "";
    if (side >= 4320) return "8K";
    if (side >= 2160) return "4K";
    if (side >= 1440) return "1440p";
    if (side >= 1080) return "1080p";
    if (side >= 720) return "720p";
    if (side >= 480) return "480p";
    return side + "p";
  }

  // The scene as a row shows it. Everything is optional: a scene may have no
  // title, no file, no previews.
  function sceneView(scene) {
    const source = scene || {};
    const file = source.files && source.files[0] ? source.files[0] : null;
    const paths = source.paths || {};
    const named = function (list) {
      return (list || []).filter(function (entry) { return entry && entry.id != null; }).map(function (entry) { return { id: String(entry.id), name: String(entry.name || "") }; });
    };
    const title = String(source.title || "").trim();
    return {
      id: String(source.id),
      title: title || fileName(source) || "Scene " + source.id,
      hasTitle: !!title,
      path: file && file.path ? String(file.path) : "",
      date: String(source.date || ""),
      studio: source.studio && source.studio.id != null ? { id: String(source.studio.id), name: String(source.studio.name || "") } : null,
      duration: file ? formatDuration(file.duration) : "",
      resolution: file ? resolutionLabel(file.width, file.height) : "",
      size: file && file.width && file.height ? file.width + "\u00d7" + file.height : "",
      details: String(source.details || "").trim(),
      performers: named(source.performers),
      tags: named(source.tags),
      image: paths.screenshot || "",
      video: paths.preview || "",
      vtt: paths.vtt || "",
      portrait: !!(file && Number(file.height) > Number(file.width)),
    };
  }

  // The first place `piece` occurs in `source` as whole words, as the worker's
  // quote check reads text: case, punctuation and spacing between words do
  // not matter, so "Toyota Corolla" is found in "Dad's Toyota_Corolla.mp4".
  function findWords(source, piece) {
    const words = String(piece).split(/[^\p{L}\p{N}]+/u).filter(Boolean).map(function (word) { return word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); });
    if (!words.length) return null;
    // Scripts written without spaces match inside a longer run, as in the worker.
    const edge = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}\p{Script=Thai}]/u.test(piece);
    const match = new RegExp((edge ? "" : "(?<![\\p{L}\\p{N}])") + words.join("[^\\p{L}\\p{N}]+") + (edge ? "" : "(?![\\p{L}\\p{N}])"), "iu").exec(source);
    return match ? { start: match.index, end: match.index + match[0].length } : null;
  }

  // Splits text around where the quote occurs, so it can be highlighted in the
  // field it came from: [{ text, mark }]. A quote joined with an ellipsis is
  // marked piece by piece. Text with no match comes back as one unmarked piece.
  function highlightSegments(text, quote) {
    const source = String(text == null ? "" : text);
    if (!source) return [];
    const whole = findWords(source, quote);
    let ranges = whole ? [whole] : [];
    if (!ranges.length) {
      ranges = String(quote == null ? "" : quote).split(/\u2026|\.{3}/).map(function (piece) { return findWords(source, piece); }).filter(Boolean)
        .sort(function (a, b) { return a.start - b.start; })
        .filter(function (range, index, list) { return index === 0 || range.start >= list[index - 1].end; });
    }
    if (!ranges.length) return [{ text: source, mark: false }];
    const out = [];
    let at = 0;
    ranges.forEach(function (range) {
      if (range.start > at) out.push({ text: source.slice(at, range.start), mark: false });
      out.push({ text: source.slice(range.start, range.end), mark: true });
      at = range.end;
    });
    if (at < source.length) out.push({ text: source.slice(at), mark: false });
    return out;
  }

  // The scene's tags a row lists: the first TAG_LIMIT, or all when expanded.
  // `extra` is how many the collapsed list leaves out (0: no toggle needed).
  function limitTags(tags, expanded, limit) {
    const list = tags || [];
    const max = limit == null ? TAG_LIMIT : limit;
    const extra = Math.max(0, list.length - max);
    return { shown: expanded || !extra ? list : list.slice(0, max), extra: extra };
  }

  // ---------------------------------------------------------------------------
  // UI

  function createComponents(PluginApi) {
    const React = PluginApi.React, h = React.createElement;
    const Router = (PluginApi.libraries && PluginApi.libraries.ReactRouterDOM) || {};
    const transport = fetchTransport;
    const memo = React.memo || function (component) { return component; };
    // OpenRouter's list per filter, kept in memory for an hour.
    const openrouterCache = {};

    function refreshStash() {
      const service = PluginApi.utils && PluginApi.utils.StashService;
      const client = service && service.getClient ? service.getClient() : null;
      if (client && client.refetchQueries) Promise.resolve(client.refetchQueries({ include: ["FindScene"] })).catch(function () {});
    }

    function Link(props) {
      const extra = { className: props.className, "aria-label": props["aria-label"], title: props.title };
      return Router.Link ? h(Router.Link, Object.assign({ to: props.to }, extra), props.children) : h("a", Object.assign({ href: props.to }, extra), props.children);
    }

    function Evidence(props) {
      const item = props.item;
      return h("span", { className: "st-evidence" },
        h("span", { className: "st-field text-muted" }, item.field === "details" ? "description" : item.field === "file" ? "file name" : item.field),
        " “", h("mark", null, item.quote), "”",
        h("span", { className: "st-confidence", "data-confidence": item.confidence }, item.confidence),
        item.literal ? h("span", { className: "st-literal", title: "The tag's name or an alias appears in the text" }, "literal") : null,
        typeof item.p === "number" ? h("span", { className: "st-verified", title: "The probability a decision model gave this proposal" + (item.verifier ? " (" + item.verifier + ")" : "") }, "verified " + item.p.toFixed(2)) : null,
        item.reason ? h("span", { className: "st-reason text-muted" }, item.reason) : null);
    }

    // Which model set-ups (sources) proposed the tag and which looked and
    // declined it, one chip each. A proposal the sources disagree on is marked.
    // Each source's own quote and reason, where they differ from the one shown,
    // open with a toggle. Nothing is shown for a version 1 field (one unnamed source).
    function SourceChips(props) {
      const item = props.item;
      const pair = React.useState(false), expanded = pair[0], setExpanded = pair[1];
      const named = (item.by || []).concat(item.no || []).some(function (entry) { return entry.source; });
      if (!named) return null;
      const agreement = agreementOf(item);
      const differing = (item.by || []).filter(function (entry) { return entry.quote !== item.quote || entry.field !== item.field || (entry.reason && entry.reason !== item.reason); });
      const id = "st-src-" + props.idKey;
      const where = function (field) { return field === "details" ? "description" : field === "file" ? "file name" : field; };
      return h("div", { className: "st-sources", "data-agreement": agreement },
        agreement === "disagree" ? h("span", { className: "st-disagree" }, "Models disagree") : null,
        h("ul", { className: "st-chips", "aria-label": "Models" },
          (item.by || []).map(function (entry) {
            return h("li", { key: "by-" + entry.source, className: "st-chip st-chip-yes", "data-source": entry.source },
              h("span", { className: "st-chip-label" }, entry.label || "Model"), " ",
              h("span", { className: "st-chip-state" }, "proposed, " + entry.confidence));
          }),
          (item.no || []).map(function (entry) {
            return h("li", { key: "no-" + entry.source, className: "st-chip st-chip-no", "data-source": entry.source },
              h("span", { className: "st-chip-label" }, entry.label || "Model"), " ",
              h("span", { className: "st-chip-state" }, "declined: " + (DECLINES[entry.why] || DECLINES.not_proposed)));
          })),
        differing.length ? h("button", {
          type: "button", className: "btn btn-link btn-sm st-toggle st-sources-toggle", "aria-expanded": expanded, "aria-controls": id,
          onClick: function () { setExpanded(!expanded); },
        }, expanded ? "Hide each model’s evidence" : "Show each model’s evidence") : null,
        expanded && differing.length ? h("ul", { id: id, className: "st-source-evidence" }, differing.map(function (entry) {
          return h("li", { key: entry.source },
            h("span", { className: "st-chip-label" }, entry.label || "Model"), ": ",
            h("span", { className: "st-field text-muted" }, where(entry.field)), " “", entry.quote, "”",
            entry.reason ? h("span", { className: "st-reason text-muted" }, entry.reason) : null);
        })) : null);
    }

    function formatDate(value) {
      const time = Date.parse(value);
      if (isNaN(time)) return "";
      try { return new Date(time).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }); } catch (_) { return String(value).slice(0, 10); }
    }

    // A category and an optional note, for a rejection or a report. Nothing
    // is saved until it is submitted; Cancel only closes it.
    function FeedbackForm(props) {
      const pair = React.useState({ category: "", note: "" }), value = pair[0], setValue = pair[1];
      const id = "st-fb-" + props.idKey;
      function change(key, next) { setValue(function (previous) { const copy = Object.assign({}, previous); copy[key] = next; return copy; }); }
      return h("form", {
        className: "st-feedback-form", "aria-label": props.label, noValidate: true,
        onSubmit: function (event) { event.preventDefault(); props.onSubmit({ category: value.category, note: value.note }); },
      },
        h("div", { className: "st-feedback-field" },
          h("label", { htmlFor: id + "-category" }, "What was wrong?"),
          h("select", { id: id + "-category", className: "form-control form-control-sm st-feedback-category", value: value.category, onChange: function (event) { change("category", event.target.value); } },
            h("option", { value: "" }, "Not specified"),
            CATEGORIES.map(function (entry) { return h("option", { key: entry.id, value: entry.id }, entry.label); }))),
        h("div", { className: "st-feedback-field" },
          h("label", { htmlFor: id + "-note" }, "Note (optional)"),
          h("textarea", { id: id + "-note", className: "form-control form-control-sm st-feedback-note", rows: 2, maxLength: LIMITS.note, value: value.note, onChange: function (event) { change("note", event.target.value); } })),
        h("div", { className: "st-feedback-actions" },
          h("button", { type: "submit", className: "btn btn-primary btn-sm st-feedback-submit", disabled: !!props.busy }, props.busy ? "Saving\u2026" : props.submitLabel),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-feedback-cancel", disabled: !!props.busy, onClick: props.onCancel }, "Cancel")));
    }

    // The navbar count, shared by both copies of the button, and refreshed
    // after every decision.
    let totalCache = null;
    function sharedTotal(force) {
      if (force || !totalCache || Date.now() - totalCache.at > 30000) {
        totalCache = { at: Date.now(), promise: pendingTotal(transport) };
        totalCache.promise.catch(function () { totalCache = null; });
      }
      return totalCache.promise;
    }
    const listeners = [];
    function announceChange() {
      totalCache = null;
      listeners.slice().forEach(function (listener) { listener(); });
    }

    function useStates() {
      const pair = React.useState({});
      const mounted = React.useRef(true);
      React.useEffect(function () { mounted.current = true; return function () { mounted.current = false; }; }, []);
      return [pair[0], function (key, value) {
        if (!mounted.current) return;
        pair[1](function (previous) { const next = Object.assign({}, previous); next[key] = value; return next; });
      }];
    }


    // ---- The outbox of evaluation answers. An answer is added to the outbox at
    // once (the next card shows without waiting); a pump sends the outbox to the
    // worker as `evalAnswers` requests, one unacknowledged request at a time,
    // and drops what the worker acknowledges in `evalAcks`.

    const outboxStore = createOutboxStore(function () { return window.localStorage; });
    const outboxListeners = [];
    const outboxState = { error: "", worker: null, maps: null };
    let pumpTimer = null, pumpBusy = false, pumpKick = false, pumpSettle = 0;

    function notifyOutbox() { outboxListeners.slice().forEach(function (listener) { listener(); }); }

    function pumpOnce() {
      return readMaps(transport).then(function (maps) {
        const worker = parseWorker(maps.worker);
        const pending = pendingRequests(parseRequests(maps.page[REQUESTS_KEY]), worker.answered).map(function (request) { return request.id; });
        // No await between reading the box and saving it, so a change made meanwhile is not lost.
        const step = outboxStep(outboxStore.load(), { acks: worker.evalAcks, pending: pending, answered: worker.answered }, Date.now());
        outboxStore.save(step.box);
        outboxState.worker = worker;
        outboxState.maps = maps;
        notifyOutbox();
        if (!step.request) return null;
        return enqueueRequest(transport, step.request, worker.answered).then(function () {
          outboxStore.save(outboxMarkSent(outboxStore.load(), step.sent, Date.now()));
          notifyOutbox();
        });
      });
    }

    function pumpTick() {
      pumpTimer = null;
      pumpBusy = true;
      pumpKick = false;
      pumpOnce().then(function () { outboxState.error = ""; return false; }, function (error) { outboxState.error = error.message; return true; }).then(function (failed) {
        pumpBusy = false;
        notifyOutbox();
        const box = outboxStore.load();
        if (outboxCount(box) || box.sent.length || pumpKick) { pumpSettle = 1; pumpTimer = setTimeout(pumpTick, failed ? SLOW_POLL_MS : OUTBOX_POLL_MS); }
        // One more read after the last acknowledgement, for the counts the worker rewrites then.
        else if (pumpSettle > 0) { pumpSettle -= 1; pumpTimer = setTimeout(pumpTick, OUTBOX_POLL_MS); }
      });
    }

    function startPump() {
      if (pumpBusy) pumpKick = true;
      else if (!pumpTimer) pumpTimer = setTimeout(pumpTick, 0);
    }

    // Adds a change to the outbox (see outboxAdd) and starts sending. Throws a message for the user.
    function submitOutbox(change) {
      const next = outboxAdd(outboxStore.load(), change);
      outboxStore.save(next);
      notifyOutbox();
      startPump();
      return next;
    }

    // The answers a Review decision made (see reviewAnswer): put in the outbox once the scene write succeeded, so the
    // write never waits for the worker. Returns "" or what went wrong, to show beside the decision's own message.
    function sendDecisionAnswers(result) {
      const answers = (result && result.answers) || [];
      if (!answers.length) return "";
      try { submitOutbox({ items: answers }); return ""; } catch (error) { return "Your decision was saved on the scene, but it could not be queued as an answer for the evaluation: " + error.message; }
    }

    function useOutbox() {
      const pair = React.useState(0), setTick = pair[1];
      React.useEffect(function () {
        const listener = function () { setTick(function (n) { return n + 1; }); };
        outboxListeners.push(listener);
        return function () { const index = outboxListeners.indexOf(listener); if (index !== -1) outboxListeners.splice(index, 1); };
      }, []);
      return { box: outboxStore.load(), persistent: outboxStore.isPersistent(), error: outboxState.error };
    }

    // What is waiting for the worker, and the warning when the browser cannot keep it.
    function OutboxLine(props) {
      const outbox = props.outbox, text = outboxText(outbox.box);
      const warn = !outbox.persistent && (text || props.always);
      const refused = outbox.box.refused;
      if (!text && !warn && !outbox.error && !refused) return null;
      return h("div", { className: "st-outbox" },
        refused ? h("p", { className: "st-outbox-refused tps-error", role: "alert" }, plural(refused, "item") + " not saved: the worker answered the request but did not accept it, so nothing was kept. Answer " + (refused === 1 ? "it" : "them") + " again. ",
          h("button", { type: "button", className: "btn btn-link btn-sm st-outbox-dismiss", onClick: function () { outboxStore.save(outboxDismissRefused(outboxStore.load())); notifyOutbox(); } }, "Dismiss")) : null,
        text ? h("p", { className: "st-outbox-line", role: "status", "aria-live": "polite" }, text + (props.saved ? ". They are saved only when the worker confirms." : ".")) : null,
        warn ? h("p", { className: "st-outbox-warning", role: "status" }, "This browser does not allow local storage, so answers waiting for the worker are kept in this tab only. Closing the tab loses them.") : null,
        text && outbox.error ? h("p", { className: "tps-error", role: "alert" }, "Couldn’t reach Stash to send them: " + outbox.error) : null);
    }

    // Polls the worker's map while `active`; returns what it last read (or null).
    function useWorkerPoll(active) {
      const pair = React.useState(null), worker = pair[0], setWorker = pair[1];
      React.useEffect(function () {
        if (!active) return undefined;
        let live = true, timer = null;
        function loop() {
          readMaps(transport).then(function (maps) { if (live) setWorker(parseWorker(maps.worker)); }).catch(function () {}).then(function () { if (live) timer = setTimeout(loop, POLL_MS); });
        }
        loop();
        return function () { live = false; clearTimeout(timer); };
      }, [active]);
      return worker;
    }

    // Drops the requests the worker has answered from the page's map (the page's own queue).
    function dropAnswered(worker) {
      if (!worker || !worker.answered.length) return Promise.resolve();
      return updateSettings(transport, function (map) { return dropRequests(map, worker.answered); }).catch(function () {});
    }

    // Starts sending what an earlier visit left in the outbox.
    function resumeOutbox() {
      const box = outboxStore.load();
      if (outboxCount(box) || box.sent.length) startPump();
    }

    // Becomes true `ms` after `startedAt` (a time in ms; null: never).
    function useExpiry(startedAt, ms) {
      const pair = React.useState(false), expired = pair[0], setExpired = pair[1];
      React.useEffect(function () {
        setExpired(false);
        if (!startedAt) return undefined;
        const timer = setTimeout(function () { setExpired(true); }, Math.max(0, ms - (Date.now() - startedAt)) + 20);
        return function () { clearTimeout(timer); };
      }, [startedAt]);
      return !!startedAt && expired;
    }

    // Words the owner selected inside one text field of a scene card become evidence: { list, message } for the
    // chosen words added to `current`, or null when nothing is selected. The fields are the cards' elements with
    // data-evidence-field (title, details, file).
    function readSelection(current) {
      const selection = window.getSelection ? window.getSelection() : null;
      if (!selection || selection.isCollapsed || !selection.rangeCount) return null;
      const range = selection.getRangeAt(0);
      const fieldOf = function (node) { const el = node && node.nodeType === 1 ? node : node && node.parentElement; return el && el.closest ? el.closest("[data-evidence-field]") : null; };
      const first = fieldOf(range.startContainer), last = fieldOf(range.endContainer);
      if (!first || first !== last) return { list: current, message: "Select words inside one field: the title, the description or the file name." };
      return evidenceFrom(first.getAttribute("data-evidence-field"), selection.toString(), current);
    }

    const ANSWER_LABELS = { yes: "Yes", no: "No", unclear: "Unclear" };
    const QUESTION = function (name) { return "From this text alone, would you add " + name + "?"; };

    // "A model missed a tag…": choose a tag, optionally select the words that show it, and save. The tag can be added to the
    // scene in the same action (on by default; not offered when the scene already carries the tag).
    function MissedTagForm(props) {
      const tagPair = React.useState(""), tagId = tagPair[0], setTagId = tagPair[1];
      const quotePair = React.useState([]), quotes = quotePair[0], setQuotes = quotePair[1];
      const alsoPair = React.useState(true), also = alsoPair[0], setAlso = alsoPair[1];
      const messagePair = React.useState(""), message = messagePair[0], setMessage = messagePair[1];
      const busyPair = React.useState(false), busy = busyPair[0], setBusy = busyPair[1];
      const mounted = React.useRef(true);
      React.useEffect(function () { mounted.current = true; return function () { mounted.current = false; }; }, []);
      const scene = props.scene, id = props.idKey + "-missed";
      const tag = props.tags.find(function (entry) { return String(entry.id) === tagId; }) || null;
      const carried = tag ? props.carried(tag) : false;
      const title = String(scene.title || "").trim(), details = String(scene.details || "").trim(), file = fileName(scene);
      const empty = function (text) { return h("span", { className: "st-eval-none text-muted" }, text); };
      function select() {
        const result = readSelection(quotes);
        if (!result) return;
        setQuotes(result.list);
        if (result.message) setMessage(result.message);
      }
      function save(event) {
        event.preventDefault();
        if (!tag) { setMessage("Choose the tag a model missed."); return; }
        setBusy(true);
        setMessage("");
        props.onSave({ tag: tag, quotes: quotes, add: also }).then(function () { if (mounted.current) setBusy(false); }, function (error) { if (mounted.current) { setBusy(false); setMessage("Nothing was recorded: " + error.message); } });
      }
      return h("form", { className: "st-eval-missed-form", "aria-label": "A model missed a tag", noValidate: true, onSubmit: save },
        h("p", { className: "st-settings-help text-muted" }, "Use this when a tag belongs on this scene and no model proposed it. It records a Yes that does not come from any model, which the evaluation needs to measure what models miss."),
        h(TagSelect, { idKey: id, label: "Tag a model missed", tags: props.tags, filtered: props.filtered, value: tagId, onChange: function (value) { setTagId(value); setMessage(""); } }),
        h("dl", { className: "st-eval-text st-eval-missed-text", onMouseUp: select, onKeyUp: select },
          h("dt", null, "Title"), h("dd", { "data-evidence-field": "title" }, title || empty("(no title)")),
          h("dt", null, "Description"), h("dd", { "data-evidence-field": "details", className: "st-eval-details" }, details || empty("(no description)")),
          h("dt", null, "File name"), h("dd", { "data-evidence-field": "file" }, file || empty("(no file)"))),
        h("p", { className: "st-eval-hint st-settings-help text-muted" }, "Optional: select the words that show the tag in the title, description or file name. They are saved as evidence."),
        quotes.length ? h("ul", { className: "st-eval-chips", "aria-label": "Evidence" }, quotes.map(function (entry, index) {
          return h("li", { key: index, className: "st-eval-chip" },
            h("span", { className: "st-chip-label" }, "Evidence"), " ", h("span", { className: "st-field text-muted" }, FIELD_WORDS[entry.f]), " “" + entry.t + "”",
            h("button", { type: "button", className: "btn btn-link btn-sm st-eval-chip-remove", "aria-label": "Remove evidence “" + entry.t + "”", onClick: function () { setQuotes(quotes.filter(function (other, at) { return at !== index; })); } }, "×"));
        })) : null,
        tag && !carried ? h("label", { className: "st-check st-eval-missed-add" },
          h("input", { id: id + "-add", type: "checkbox", checked: also, onChange: function (event) { setAlso(event.target.checked); } }), " Also add the tag to this scene") : null,
        tag && carried ? h("p", { className: "st-settings-help text-muted st-eval-missed-carried" }, "This scene already has " + tag.name + ", so only your answer is recorded.") : null,
        h("div", { className: "st-settings-actions" },
          h("button", { type: "submit", className: "btn btn-primary btn-sm st-eval-missed-save", disabled: busy || !tag }, busy ? "Saving…" : "Save"),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-missed-cancel", disabled: busy, onClick: props.onCancel }, "Cancel")),
        message ? h("p", { className: "st-eval-missed-message tps-error", role: "alert" }, message) : null);
    }

    // The Evaluate group on the scene page, inside "From the text (AI)": the
    // defined tags the scene carries and the tags with an answer, each with Yes,
    // No, Unclear and Clear; A model missed a tag…; and Check now. Answers go
    // through the outbox to the worker, which keeps them; this group reads the
    // scene's own answers with an `evalAnswersFor` request, and merges what is
    // still in the outbox so a just-given answer shows at once.
    function EvalGroup(props) {
      const sceneId = String(props.sceneId), answersOnly = !!props.answersOnly;
      const openPair = React.useState(false), open = openPair[0], setOpen = openPair[1];
      const dataPair = React.useState({ status: "idle" }), data = dataPair[0], setData = dataPair[1];
      const askedPair = React.useState(null), asked = askedPair[0], setAsked = askedPair[1];
      const sessionPair = React.useState(emptyOutbox), session = sessionPair[0], setSession = sessionPair[1];
      const extraPair = React.useState([]), extra = extraPair[0], setExtra = extraPair[1];
      const missedPair = React.useState(false), missedOpen = missedPair[0], setMissedOpen = missedPair[1];
      const messagePair = React.useState(""), message = messagePair[0], setMessage = messagePair[1];
      const checkPair = React.useState(null), check = checkPair[0], setCheck = checkPair[1];
      const dialogPair = React.useState(null), dialog = dialogPair[0], setDialog = dialogPair[1];
      const profilePair = React.useState(""), pickedProfile = profilePair[0], setPickedProfile = profilePair[1];
      const outbox = useOutbox();
      const ready = data.status === "ready";
      const waitingAnswers = open && ready && !!asked;
      const phase = check ? check.phase : "";
      const worker = useWorkerPoll(open && (waitingAnswers || phase === "asking"));
      const slowAnswers = useExpiry(asked && asked.at, 30000);
      const slowCheck = useExpiry(check && check.at, check && check.phase === "flagging" ? 30000 : 150000);
      const groupId = "st-eval-group-" + sceneId;

      // On first opening: the scene, the defined tags, the tags above the scene's own, the settings; then ask for the answers.
      React.useEffect(function () {
        if (!open || data.status !== "idle") return undefined;
        let live = true;
        setData({ status: "loading" });
        Promise.all([transport(QUERIES.evalSceneTags, { ids: [sceneId] }), definedTags(transport), readMaps(transport)]).then(function (all) {
          const scene = all[0].findScenes.scenes[0];
          if (!scene) throw new Error("The scene no longer exists.");
          const ids = sceneTagIds(scene.tags);
          return (ids.length ? transport(QUERIES.evalAncestors, { ids: ids }) : Promise.resolve({ findTags: { tags: [] } })).then(function (above) {
            const worker0 = parseWorker(all[2].worker), request = evalAnswersForRequest([sceneId]);
            return enqueueRequest(transport, request, worker0.answered).then(function () { return { scene: scene, defined: all[1], above: above.findTags.tags, settings: settingsOf(all[2].page), worker0: worker0, request: request }; });
          });
        }).then(function (loaded) {
          if (!live) return;
          setData({ status: "ready", scene: loaded.scene, defined: loaded.defined, ancestorIds: loaded.above.map(function (entry) { return String(entry.id); }), settings: loaded.settings, status0: loaded.worker0.status, candidates: loaded.worker0.candidates });
          setAsked({ id: loaded.request.id, at: Date.now() });
        }, function (error) { if (live) setData({ status: "error", error: error.message }); });
        return function () { live = false; };
      }, [open]);

      const answeredFetch = worker && worker.evalAnswersFor && asked && worker.evalAnswersFor.request === asked.id ? worker.evalAnswersFor : null;
      const fetchedScene = answeredFetch ? answeredFetch.scenes[sceneId] || { seen: false, tags: {}, picks: [] } : null;
      React.useEffect(function () { if (answeredFetch) dropAnswered(worker); }, [answeredFetch && answeredFetch.request]);
      const base = mergeSceneAnswers(fetchedScene, outbox.box, sceneId);
      const effective = mergeSceneAnswers(base, session, sceneId);
      const only = answersOnly || !!(worker && worker.status && worker.status.answersOnly) || !!(ready && data.status0 && data.status0.answersOnly);

      // Check now: the scene's flag is sent first and acknowledged, then the model is asked.
      React.useEffect(function () {
        if (!check || check.phase !== "flagging") return;
        if (outbox.box.seen[sceneId]) return;
        const profile = check.profile;
        let request;
        try { request = evalSceneRequest(sceneId, profile); } catch (error) { setCheck({ phase: "error", error: error.message }); return; }
        enqueueRequest(transport, request, (worker && worker.answered) || []).then(function () {
          setCheck({ phase: "asking", at: Date.now(), profile: profile, request: request.id });
        }, function (error) { setCheck({ phase: "error", error: error.message }); });
      }, [phase, !!outbox.box.seen[sceneId]]);

      if (!open) {
        return h("div", { className: "st-eval-group" }, h("button", { type: "button", className: "btn btn-link btn-sm st-eval-toggle", "aria-expanded": false, "aria-controls": groupId, onClick: function () { setOpen(true); } }, "Evaluate"));
      }
      const toggle = h("button", { type: "button", className: "btn btn-link btn-sm st-eval-toggle", "aria-expanded": true, "aria-controls": groupId, onClick: function () { setOpen(false); } }, "Evaluate");
      if (!ready) {
        return h("div", { className: "st-eval-group" }, toggle, h("div", { id: groupId },
          data.status === "error" ? h("p", { className: "tps-error", role: "alert" }, "Couldn’t load the evaluation: " + data.error) : h("p", { className: "tps-status text-muted", role: "status" }, "Loading…")));
      }

      const scene = data.scene, sceneTags = scene.tags;
      const defined = data.defined;
      const byId = {};
      defined.forEach(function (tag) { byId[String(tag.id)] = tag; });
      const ids = [];
      const add = function (id) { id = String(id); if (ids.indexOf(id) === -1) ids.push(id); };
      sceneTagIds(sceneTags).concat(data.ancestorIds).forEach(function (id) { if (byId[id]) add(id); });
      Object.keys(effective.tags).forEach(add);
      extra.forEach(add);
      const rows = ids.map(function (id) { return { tag: byId[id] || { id: id, name: "Tag " + id, description: "" }, carried: byId[id] ? carriedBy(byId[id], sceneTags, data.ancestorIds) : false }; });
      // The tags a model could have missed: every tag the worker can analyse (every tag with a description until it says).
      const eligible = eligibleView({ status: "ready", list: defined }, data.candidates).list;
      const carriedNow = function (tag) { return carriedBy(tag, sceneTags, data.ancestorIds); };

      // The scene's tags after the tag was added by hand, so the rows and the "on this scene" marks follow.
      function reloadSceneTags() {
        return transport(QUERIES.evalSceneTags, { ids: [sceneId] }).then(function (loaded) {
          const fresh = loaded.findScenes.scenes[0];
          if (!fresh) return null;
          const freshIds = sceneTagIds(fresh.tags);
          return (freshIds.length ? transport(QUERIES.evalAncestors, { ids: freshIds }) : Promise.resolve({ findTags: { tags: [] } })).then(function (above) {
            setData(function (previous) { return Object.assign({}, previous, { scene: fresh, ancestorIds: above.findTags.tags.map(function (entry) { return String(entry.id); }) }); });
          });
        });
      }

      // "A model missed a tag…": a Yes with src scene, which the worker keeps outside Stash, and, when asked, the tag
      // added to the scene by hand (no applied record: the owner added it, not an AI proposal). The answer is queued
      // once Stash has the tag, so a refused add records nothing.
      function saveMissed(entry) {
        const carried = carriedNow(entry.tag);
        const add = entry.add && !carried;
        return (add ? addByHand(transport, sceneId, entry.tag.id) : Promise.resolve()).then(function () {
          const item = evalItem(sceneId, entry.tag.id, "yes", { src: "scene", had: carried, quotes: entry.quotes });
          submitOutbox({ items: [item] });
          setSession(function (previous) { return outboxAdd(previous, { items: [item] }); });
          if (extra.indexOf(String(entry.tag.id)) === -1) setExtra(extra.concat([String(entry.tag.id)]));
          setMissedOpen(false);
          setMessage("Recorded that a model missed " + entry.tag.name + (add ? " and added the tag to this scene." : "."));
          if (add) { refreshStash(); return reloadSceneTags().catch(function () {}); }
          return null;
        });
      }

      function give(row, kind) {
        try {
          const item = evalItem(sceneId, row.tag.id, kind, { src: "scene", had: row.carried });
          submitOutbox({ items: [item] });
          setSession(function (previous) { return outboxAdd(previous, { items: [item] }); });
          // The row stays after a clear, so the answer can be given again.
          if (extra.indexOf(String(row.tag.id)) === -1) setExtra(extra.concat([String(row.tag.id)]));
          setMessage(kind === null ? "Cleared your answer for " + row.tag.name + "." : "Answered " + ANSWER_LABELS[kind] + " for " + row.tag.name + ".");
        } catch (error) { setMessage(error.message); }
      }
      const profiles = data.settings.profiles;
      const profile = profiles.find(function (entry) { return entry.id === pickedProfile; }) || profiles.find(function (entry) { return entry.id === data.settings.active; }) || profiles[0] || null;
      const half = evalHalf(sceneId, effective.seen);
      const destination = profile ? runDestination(profile, data.settings.providers, null, data.settings.networks) : null;
      function startCheck() {
        setDialog(null);
        setMessage("");
        try { submitOutbox({ seen: [sceneId] }); } catch (error) { setMessage(error.message); return; }
        setSession(function (previous) { return outboxAdd(previous, { seen: [sceneId] }); });
        setCheck({ phase: "flagging", at: Date.now(), profile: profile.id });
      }
      function askCheck() {
        if (!profile) { setMessage("Make a profile active on the Profiles tab first: the check uses it."); return; }
        const parts = [];
        if (half === "test" && !effective.seen) parts.push("This scene is in the final set (the test half). Checking it moves it to the practice set (the tuning half) for good, so the answers you gave for it no longer count in the final figures.");
        if (destination && destination.local === false) parts.push("Scene text will be sent to " + destination.host + ", outside your network, and the model there is billed.");
        if (parts.length) setDialog({ text: parts.join(" ") }); else startCheck();
      }
      const result = check && check.phase === "asking" && worker && worker.evalScenes[check.request] ? worker.evalScenes[check.request] : null;
      const compared = result ? compareCheck(result.claims, effective.tags) : [];
      const nameOf = function (id) { return byId[id] ? byId[id].name : "Tag " + id; };
      let checkLine = "";
      if (check && check.phase === "flagging") checkLine = slowCheck ? "The worker has not saved the flag yet, so nothing was sent to the model. Start it with `npm run semantic -- serve`." : "Saving the flag that keeps this scene in the practice set…";
      else if (check && check.phase === "asking" && !result) checkLine = slowCheck ? "No answer from the worker yet. It may be busy; the result shows here when it arrives." : "Asking the model…";
      else if (check && check.phase === "error") checkLine = "Couldn’t send the check: " + check.error;
      else if (result) checkLine = result.error ? "The check failed: " + result.error : "Checked " + listAge(result.at) + " with “" + (result.profile || (profile && profile.name) || "the profile") + "”. " + (result.claims.length ? plural(result.claims.length, "tag") + " claimed." : "No tag claimed.");

      return h("div", { className: "st-eval-group", "data-open": "true" }, toggle,
        h("div", { id: groupId, className: "st-eval-body" },
          h("p", { className: "st-eval-help text-muted" }, "Answer from the title, description and file name alone, before you look at what the model proposed. The worker keeps your answers outside Stash."),
          rows.length ? h("ul", { className: "st-eval-rows", "aria-label": "Tags to answer" }, rows.map(function (row) {
            const entry = effective.tags[String(row.tag.id)], current = entry ? entry.a : "";
            return h("li", { key: row.tag.id, className: "st-eval-row", "data-tag": row.tag.id, "data-answer": current },
              h("div", { className: "st-eval-row-main" },
                h(Link, { to: "/tags/" + row.tag.id, className: "st-eval-name" }, row.tag.name),
                row.carried ? h("span", { className: "st-eval-carried text-muted" }, "on this scene") : null,
                h("span", { className: "st-eval-current", role: "status" }, current ? "Your answer: " + ANSWER_LABELS[current] : "No answer yet")),
              h("div", { className: "st-eval-buttons", role: "group", "aria-label": QUESTION(row.tag.name) },
                EVAL_ANSWERS.map(function (kind) {
                  return h("button", { key: kind, type: "button", className: "btn btn-sm st-eval-answer st-eval-" + kind + " " + (current === kind ? "btn-primary" : "btn-secondary"), "aria-pressed": current === kind, onClick: function () { give(row, kind); } }, ANSWER_LABELS[kind]);
                }),
                h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-clear", disabled: !current, "aria-label": "Clear your answer for " + row.tag.name, onClick: function () { give(row, null); } }, "Clear")));
          })) : h("p", { className: "tps-empty text-muted" }, "No defined tag is on this scene yet."),
          h("div", { className: "st-eval-missed" },
            missedOpen
              ? h(MissedTagForm, { idKey: groupId, scene: scene, tags: eligible, filtered: !!data.candidates, carried: carriedNow, onSave: saveMissed, onCancel: function () { setMissedOpen(false); } })
              : h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-missed-button", "aria-expanded": false, title: "A tag belongs on this scene and no model proposed it", onClick: function () { setMissedOpen(true); } }, "A model missed a tag…")),
          h("div", { className: "st-eval-check" },
            profiles.length > 1 ? h("div", { className: "st-settings-field" },
              h("label", { htmlFor: groupId + "-profile" }, "Profile for Check now"),
              h("select", { id: groupId + "-profile", className: "form-control form-control-sm st-settings-budget st-eval-profile", value: profile ? profile.id : "", onChange: function (event) { setPickedProfile(event.target.value); } },
                profiles.map(function (entry) { return h("option", { key: entry.id, value: entry.id }, entry.name); }))) : null,
            h("div", { className: "st-settings-actions" },
              h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-check-now", disabled: only || !!dialog || phase === "flagging" || (phase === "asking" && !result && !slowCheck), title: "Ask the model about this scene now. The scene stays in the practice set for good.", onClick: askCheck }, "Check now"),
              only ? h("span", { className: "st-settings-help text-muted st-answers-only" }, "This worker only records answers, so it cannot check a scene.") : null),
            dialog ? h(ConfirmForm, { label: "Check this scene now", text: dialog.text, confirmLabel: "Check now", onConfirm: startCheck, onCancel: function () { setDialog(null); } }) : null,
            checkLine ? h("p", { className: "st-eval-check-line" + (check && check.phase === "error" ? " tps-error" : ""), role: "status", "aria-live": "polite" }, withCode(checkLine)) : null,
            result && !result.error ? (compared.length
              ? h("ul", { className: "st-eval-compared", "aria-label": "What the model claimed against your answers" }, compared.map(function (row) {
                return h("li", { key: row.tagId, className: "st-eval-compared-row", "data-verdict": row.verdict },
                  h("strong", null, nameOf(row.tagId)), " ",
                  row.claimed ? h("span", { className: "st-eval-claim" }, "claimed" + (row.confidence ? ", " + row.confidence : "") + (typeof row.p === "number" ? ", " + row.p.toFixed(2) : "")) : null,
                  row.quote ? h("span", { className: "st-eval-claim-quote" }, " " + (row.field ? FIELD_WORDS[row.field] || row.field : "") + " “" + row.quote + "”") : null,
                  h("span", { className: "st-eval-verdict" }, " " + ({ matches: "You said Yes: they agree.", wrong: "You said No: it is wrong.", unclear: "You said Unclear.", unanswered: "You have not answered this tag.", missed: "You said Yes; the model did not claim it." })[row.verdict]),
                  row.reason ? h("span", { className: "st-reason text-muted" }, row.reason) : null);
              }))
              : h("p", { className: "text-muted" }, "Nothing to compare: the model claimed no tag and you have no Yes answer.")) : null),
          waitingAnswers && !answeredFetch ? h("p", { className: "st-settings-help text-muted", role: "status" }, withCode(slowAnswers ? "Worker has not answered: your earlier answers for this scene are not shown. Start it with `npm run semantic -- serve`." : "Asking the worker for your earlier answers…")) : null,
          h(OutboxLine, { outbox: outbox, always: true }),
          h("p", { className: "st-eval-status text-muted", role: "status", "aria-live": "polite" }, message)));
    }

    // ---- Evaluate tab: the owner's own answers, a run that scores a method
    // against them, and the figures.

    // Where scenes to answer come from. Waiting claims are the main queue (0.7.3); the other two sit under "More ways to add answers".
    const CLAIMS_SOURCES = Object.freeze([{ id: "claims", label: "Scenes a method claimed it for" }]);
    const MORE_SOURCES = Object.freeze([
      { id: "tagged", label: "Scenes that have this tag" },
      { id: "picks", label: "My picks" },
    ]);
    const INCLUDE_NAMED_LABEL = "Include scenes whose text names the tag";
    const TEST_HALF_TEXT = "The test half is the final set. Its figures are for reporting, not for tuning: each time you run it and then change a prompt or a definition because of what it says, it stops being a fair check. Run it only when the prompt and the definitions are settled.";
    const HALF_NAMES = { tuning: "Tuning half (practice set)", test: "Test half (final set)" };
    const MISTAKES = Object.freeze([
      { id: "wrong", label: "Claimed, but you said No" },
      { id: "missed", label: "You said Yes, not claimed" },
      { id: "guessed", label: "Claimed on a scene that already has the tag, you said No" },
    ]);

    function queueFresh(entry) {
      return !!entry && !!entry.at && Date.now() - Date.parse(entry.at) < REQUEST_FRESH_MS;
    }

    // The tag to answer for, with a search box over the tags the worker can analyse (else those with a definition).
    // `also` holds every tag with a description, so a tag chosen earlier stays shown if it stopped being eligible.
    function TagSelect(props) {
      const searchPair = React.useState(""), search = searchPair[0], setSearch = searchPair[1];
      const words = search.toLowerCase().split(/\s+/).filter(Boolean);
      const matching = props.tags.filter(function (tag) { return words.every(function (word) { return tag.name.toLowerCase().indexOf(word) !== -1; }); });
      const shown = matching.slice(0, 200);
      if (props.value && !shown.some(function (tag) { return String(tag.id) === props.value; })) {
        const chosen = (props.also || props.tags).find(function (tag) { return String(tag.id) === props.value; });
        if (chosen) shown.unshift(chosen);
      }
      // idKey keeps the ids apart when two pickers are on one page; label names the choice.
      const key = props.idKey || "st-eval";
      return h("div", { className: "st-eval-tagselect" },
        field(key + "-tagsearch", "Search tags", h("input", { id: key + "-tagsearch", type: "search", className: "form-control form-control-sm", value: search, autoComplete: "off", placeholder: "Type part of a name", onChange: function (event) { setSearch(event.target.value); } })),
        field(key + "-tag", props.label || "Tag to answer for", h("select", { id: key + "-tag", className: "form-control form-control-sm st-eval-tag-select", value: props.value, onChange: function (event) { props.onChange(event.target.value); } },
          h("option", { value: "" }, "Choose a tag"),
          shown.map(function (tag) { return h("option", { key: tag.id, value: String(tag.id) }, tag.name); })),
        !props.tags.length ? NO_ELIGIBLE_TEXT
          : matching.length > shown.length ? (matching.length - shown.length) + " more match; keep typing to narrow the list." : props.tags.length + (props.filtered ? " tags are eligible." : " tags have a definition.")));
    }

    // Counts from the worker: answers in total and per half, picks, claims waiting, and the chosen tag's.
    function EvalCounts(props) {
      const worker = props.console.worker, counts = worker.evalCounts, waiting = outboxText(props.outbox.box) ? Object.keys(props.outbox.box.answers).length : 0;
      const tag = props.tagId ? counts.byTag[props.tagId] : null;
      let line;
      if (!counts.at && !counts.total) line = "The worker has not reported any answers yet.";
      else line = plural(counts.total, "answer") + " in all: " + counts.tuning + " in the tuning half (practice set) and " + counts.test + " in the test half (final set). " + plural(counts.picks, "pick") + " waiting in your queues.";
      return h("div", { className: "st-eval-counts" },
        h("p", { className: "st-eval-counts-line", role: "status", "aria-live": "polite" }, line, " ", plural(worker.evalClaims.total, "claim") + " waiting for your decision.", waiting ? " Plus " + plural(waiting, "answer") + " not yet saved by the worker." : ""),
        tag ? h("p", { className: "st-eval-counts-tag" }, "For " + props.tagName + ": " + tag.yes + " Yes, " + tag.no + " No, " + tag.unclear + " Unclear.") : null);
    }

    // "Your Review decisions, by model": for each model set-up (source) that proposed tags you decided on, how many you
    // accepted and rejected, the share accepted, and the same for the confidence it gave. It needs no evaluation run.
    function EvalBySource(props) {
      const list = props.console.worker.evalBySource.sources;
      const pair = React.useState(false), details = pair[0], setDetails = pair[1];
      return h("section", { className: "st-eval-bysource", "aria-labelledby": "st-eval-bysource-title" },
        h("h4", { id: "st-eval-bysource-title", className: "st-subheading" }, "Your Review decisions, by model"),
        h("p", { className: "st-settings-help text-muted st-eval-bysource-note" }, "Only proposals you decided on in Review count here, so this says how often a model was right when it was shown to you, not how often it is right overall. Your decisions are saved when the worker confirms them."),
        !list.length ? h("p", { className: "tps-empty text-muted st-eval-bysource-empty" }, "No Review decision has been saved yet. Accept or reject proposals in Review, or run `npm run semantic -- eval gold import-review` to bring in the decisions you made before.")
          : h(React.Fragment, null,
            h("div", { className: "st-eval-table-wrap" }, h("table", { className: "st-eval-table st-eval-bysource-table" },
              h("caption", { className: "st-sr-only" }, "Your Review decisions by the model that proposed the tag"),
              h("thead", null, h("tr", null, h("th", { scope: "col" }, "Model"), h("th", { scope: "col" }, "Accepted"), h("th", { scope: "col" }, "Rejected"), h("th", { scope: "col" }, "Accepted of decided"))),
              h("tbody", null, list.map(function (entry) {
                return h("tr", { key: entry.s, "data-source": entry.s },
                  h("th", { scope: "row" }, entry.label), h("td", null, entry.yes), h("td", null, entry.no), h("td", null, decidedShare(entry) || "–"));
              })))),
            h("button", { type: "button", className: "btn btn-link btn-sm st-eval-bysource-toggle", "aria-expanded": details, onClick: function () { setDetails(!details); } }, details ? "Hide the split by confidence" : "Show the split by confidence"),
            details ? h("div", { className: "st-eval-table-wrap" }, h("table", { className: "st-eval-table st-eval-bysource-confidence" },
              h("caption", { className: "st-sr-only" }, "Your Review decisions by model and the confidence it gave"),
              h("thead", null, h("tr", null, h("th", { scope: "col" }, "Model"), CONFIDENCES.map(function (level) { return h("th", { key: level, scope: "col" }, level + ": accepted, rejected"); }))),
              h("tbody", null, list.map(function (entry) {
                return h("tr", { key: entry.s }, h("th", { scope: "row" }, entry.label), CONFIDENCES.map(function (level) { return h("td", { key: level }, entry.byConfidence[level].yes + ", " + entry.byConfidence[level].no); }));
              })))) : null));
    }

    // One scene at a time: its text, the question, Yes / No / Unclear / Skip.
    function EvalAnswering(props) {
      const c = props.console, worker = c.worker, tagId = props.tagId, source = props.source, outbox = props.outbox, tags = props.tags;
      const online = c.connection.state === "connected";
      const tag = tags.status === "ready" ? tags.list.find(function (entry) { return String(entry.id) === tagId; }) || null : null;
      const askPair = React.useState(null), ask = askPair[0], setAsk = askPair[1];
      const refreshPair = React.useState(0), refresh = refreshPair[0], setRefresh = refreshPair[1];
      const cardsPair = React.useState({}), cards = cardsPair[0], setCards = cardsPair[1];
      const donePair = React.useState({}), done = donePair[0], setDone = donePair[1];
      const skippedPair = React.useState({}), skipped = skippedPair[0], setSkipped = skippedPair[1];
      const undoPair = React.useState([]), undoStack = undoPair[0], setUndo = undoPair[1];
      const evidencePair = React.useState([]), evidence = evidencePair[0], setEvidence = evidencePair[1];
      const messagePair = React.useState(""), message = messagePair[0], setMessage = messagePair[1];
      const carryPair = React.useState({ tagId: "", ids: null }), carry = carryPair[0], setCarry = carryPair[1];
      const verifyPair = React.useState(null), verify = verifyPair[0], setVerify = verifyPair[1];
      const checkedPair = React.useState({}), checked = checkedPair[0], setChecked = checkedPair[1];
      const namedPair = React.useState(false), includeNamed = namedPair[0], setIncludeNamed = namedPair[1];
      const askedRef = React.useRef({});
      const mounted = React.useRef(true);
      React.useEffect(function () { mounted.current = true; return function () { mounted.current = false; }; }, []);
      const slow = useExpiry(ask && ask.at, 60000);
      const verifySlow = useExpiry(verify && verify.at, 45000);
      const key = EVAL_QUEUE_SOURCES.indexOf(source) !== -1 ? queueKey(tagId, source) : "";
      // Only the scenes that have the tag can name it; the worker leaves those out unless asked.
      const wantNamed = source === "tagged" && includeNamed;

      // Which scenes count as the tag: the tag, its descendants and role tags.
      React.useEffect(function () {
        if (!tag) return undefined;
        let live = true;
        loadCarry(transport, tag).then(function (ids) { if (live) setCarry({ tagId: String(tag.id), ids: ids }); }, function () {});
        return function () { live = false; };
      }, [tagId, tag && tag.name]);

      // The worker lists the scenes for "that have this tag" and "my picks". A list it wrote earlier may hold
      // scenes answered since, so it is asked afresh each time (and again on request).
      React.useEffect(function () {
        if (!online || !tag || !key) return;
        const marker = key + ":" + refresh + ":" + (wantNamed ? "named" : "");
        if (askedRef.current[marker]) return;
        askedRef.current[marker] = true;
        let request;
        try { request = evalQueueRequest(tagId, source, EVAL_LIMITS.queueDefault, undefined, undefined, { includeNamed: wantNamed }); } catch (error) { setMessage(error.message); return; }
        c.enqueue(request).then(function () { if (mounted.current) setAsk({ key: key, id: request.id, at: Date.now(), includeNamed: wantNamed }); }, function (error) { if (mounted.current) setMessage(error.message); });
      }, [online, tagId, source, refresh, wantNamed, !!tag]);

      let ids = [], status = "ready", more = false, scanned = 0, leftOut = 0;
      const doneKey = function (id) { return tagId + ":" + id; };
      if (!tag) status = "choose";
      else if (!online) status = "offline";
      else if (source === "claims") {
        // The worker rewrites the claims only when it scores, so a claim may have been answered since:
        // ask for the answers on the scenes about to be shown (50 at a time) and leave those out.
        const open = (worker.evalClaims.byTag[tagId] || []).filter(function (id) { return !done[doneKey(id)] && !skipped[doneKey(id)]; });
        ids = open.filter(function (id) { return checked[doneKey(id)] === "ok"; });
        if (!ids.length && open.some(function (id) { return checked[doneKey(id)] === undefined; })) status = verifySlow ? "slow" : "asking";
      } else {
        const entry = worker.evalQueues[key] || null, mine = ask && ask.key === key && ask.includeNamed === wantNamed ? ask : null;
        if (!mine) status = "asking";
        else if (!(entry && entry.request === mine.id)) status = worker.answered.indexOf(mine.id) !== -1 ? "failed" : slow ? "slow" : "asking";
        else { ids = entry.sceneIds; more = entry.more; scanned = entry.scanned; leftOut = wantNamed ? 0 : entry.named; }
      }
      const waitingItem = function (id) { const entry = outbox.box.answers[pairKey(id, tagId)]; return !!entry && entry.item.a !== null; };
      const candidates = ids.filter(function (id) { return !done[doneKey(id)] && !skipped[doneKey(id)] && cards[id] !== false && !waitingItem(id); });
      const head = candidates.slice(0, 6), headKey = head.join(",");
      const currentId = status === "ready" ? candidates[0] : undefined;
      const card = currentId ? cards[currentId] : undefined;

      React.useEffect(function () {
        const need = head.filter(function (id) { return cards[id] === undefined; });
        if (!need.length) return;
        evalCards(transport, need).then(function (scenes) {
          if (!mounted.current) return;
          setCards(function (previous) {
            const next = Object.assign({}, previous);
            need.forEach(function (id) { next[id] = scenes.find(function (entry) { return String(entry.id) === id; }) || false; });
            return next;
          });
        }, function (error) { if (mounted.current) setMessage("Couldn’t load scenes: " + error.message); });
      }, [headKey]);
      React.useEffect(function () { setEvidence([]); }, [currentId]);

      // Claims: the first scenes not yet checked are asked about (evalAnswersFor, 50 at a time).
      const unchecked = source === "claims" && tag && online ? (worker.evalClaims.byTag[tagId] || []).filter(function (id) { return !done[doneKey(id)] && !skipped[doneKey(id)] && checked[doneKey(id)] === undefined; }).slice(0, EVAL_LIMITS.batch) : [];
      React.useEffect(function () {
        if (!unchecked.length || (verify && verify.tagId === tagId)) return;
        let request;
        try { request = evalAnswersForRequest(unchecked); } catch (_) { return; }
        setVerify({ id: request.id, tagId: tagId, ids: unchecked, at: Date.now() });
        c.enqueue(request).catch(function (error) { if (mounted.current) { setVerify(null); setMessage(error.message); } });
      }, [unchecked.join(","), !!verify]);
      const slot = verify && worker.evalAnswersFor && worker.evalAnswersFor.request === verify.id ? worker.evalAnswersFor : null;
      React.useEffect(function () {
        if (!slot || !verify) return;
        setChecked(function (previous) {
          const next = Object.assign({}, previous);
          verify.ids.forEach(function (id) { const known = slot.scenes[id]; next[verify.tagId + ":" + id] = known && known.tags[verify.tagId] ? "answered" : "ok"; });
          return next;
        });
        setVerify(null);
      }, [slot && slot.request]);

      const titleOf = function (scene) { return String(scene.title || "").trim() || fileName(scene) || "Scene " + scene.id; };
      function answer(kind) {
        if (!card || !tag) return;
        try {
          const had = sceneCarries((card.tags || []).map(function (entry) { return entry.id; }), carry.tagId === tagId ? carry.ids : null, tagId);
          submitOutbox({ items: [evalItem(card.id, tagId, kind, { quotes: evidence, src: source, had: had })] });
        } catch (error) { setMessage(error.message); return; }
        setDone(function (previous) { const next = Object.assign({}, previous); next[doneKey(card.id)] = true; return next; });
        setUndo(function (previous) { return previous.concat([{ sceneId: String(card.id), tagId: tagId, src: source, title: titleOf(card), tagName: tag.name }]).slice(-20); });
        setMessage("Answered " + ANSWER_LABELS[kind] + " for " + tag.name + " on “" + titleOf(card) + "”." + (kind === "yes" && evidence.length ? " Evidence: " + plural(evidence.length, "piece") + "." : ""));
        setEvidence([]);
      }
      function skip() {
        if (!card) return;
        setSkipped(function (previous) { const next = Object.assign({}, previous); next[doneKey(card.id)] = true; return next; });
        setMessage("Skipped “" + titleOf(card) + "”. Nothing was recorded.");
        setEvidence([]);
      }
      function undo() {
        const last = undoStack[undoStack.length - 1];
        if (!last) return;
        try {
          // The answer is cleared; a pick that the answer settled comes back.
          submitOutbox({ items: [evalItem(last.sceneId, last.tagId, null, { src: last.src })], picks: last.src === "picks" ? { add: [{ sceneId: last.sceneId, tagId: last.tagId }] } : undefined });
        } catch (error) { setMessage(error.message); return; }
        setUndo(undoStack.slice(0, -1));
        setDone(function (previous) { const next = Object.assign({}, previous); delete next[last.tagId + ":" + last.sceneId]; return next; });
        setMessage("Undid your answer for " + last.tagName + " on “" + last.title + "”. The scene is back in the queue.");
      }
      const latest = React.useRef(null);
      latest.current = { answer: answer, skip: skip, active: !!card && !props.keysOff };
      React.useEffect(function () {
        function onKey(event) {
          const action = answerKey(event);
          if (!action || !latest.current.active) return;
          event.preventDefault();
          if (action === "skip") latest.current.skip(); else latest.current.answer(action);
        }
        document.addEventListener("keydown", onKey);
        return function () { document.removeEventListener("keydown", onKey); };
      }, []);

      // Words selected inside one field become evidence.
      function captureSelection() {
        const result = readSelection(evidence);
        if (!result) return;
        setEvidence(result.list);
        if (result.message) setMessage(result.message);
      }

      let body;
      if (status === "choose") body = h("p", { className: "tps-empty text-muted" }, "Choose a tag to start.");
      else if (status === "offline") body = h("p", { className: "st-eval-offline tps-error", role: "status" }, withCode(c.connection.text + " Every list of scenes to answer comes from the worker, so there is nothing to answer until it runs."));
      else if (status === "asking") body = h("p", { className: "tps-status text-muted", role: "status" }, "Asking the worker for scenes…");
      else if (status === "slow" || status === "failed") body = h("div", null,
        h("p", { className: "tps-error", role: "alert" }, status === "slow" ? "The worker has not answered yet. It may be busy, or not running." : "The worker answered but gave no list for this tag and source."),
        h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-ask-again", onClick: function () { setVerify(null); setRefresh(refresh + 1); } }, "Ask again"));
      else if (!candidates.length && key && worker.evalQueues[key] && worker.evalQueues[key].error) body = h("p", { className: "tps-error st-eval-queue-error", role: "alert" }, "The worker could not list scenes: " + worker.evalQueues[key].error);
      else if (!candidates.length && !ids.length && leftOut) body = h("div", { className: "st-eval-empty" },
        h("p", { className: "tps-empty text-muted st-eval-empty-named", role: "status" }, "Every scene the worker found for " + tag.name + " names the tag in its text, so " + (leftOut === 1 ? "it was" : "all " + leftOut + " were") + " left out. Tick “" + INCLUDE_NAMED_LABEL + "” to answer " + (leftOut === 1 ? "it" : "them") + " anyway." + (more ? " The worker stopped after " + scanned + " scenes." : "")));
      else if (!candidates.length) body = h("div", { className: "st-eval-empty" },
        h("p", { className: "tps-empty text-muted", role: "status" }, source === "claims" ? "No method claims for " + tag.name + " are waiting for your answer." : source === "picks" ? "You have no picks left for " + tag.name + "." : "No more scenes to answer for " + tag.name + " in this list." + (scanned ? " The worker looked at " + scanned + " scenes." : "")),
        key && (more || ids.length) ? h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-more", onClick: function () { setRefresh(refresh + 1); } }, more ? "Ask the worker for more scenes" : "Ask the worker again") : null);
      else if (card === undefined) body = h("p", { className: "tps-status text-muted", role: "status" }, "Loading the scene…");
      else body = h(EvalCard, { card: card, tag: tag, evidence: evidence, onSelect: captureSelection, onRemove: function (index) { setEvidence(evidence.filter(function (entry, at) { return at !== index; })); }, onAnswer: answer, onSkip: skip });

      const waitingTotal = worker.evalClaims.total;
      const titleId = (props.idKey || "st-eval") + "-answer-title";
      return h("section", { className: "st-eval-answering st-eval-answering-" + (props.variant || "claims"), "aria-labelledby": titleId },
        props.heading ? h("h4", { id: titleId, className: "st-subheading" }, props.heading, props.variant === "claims" ? h("span", { className: "st-eval-waiting-total text-muted" }, " " + plural(waitingTotal, "claim") + " waiting") : null) : h("h5", { id: titleId, className: "st-eval-h5" }, "Answer"),
        h("p", { className: "st-settings-help text-muted" }, props.help),
        h(TagSelect, { idKey: props.idKey, tags: tags.status === "ready" ? eligibleView(tags, worker.candidates).list : [], filtered: !!worker.candidates, also: tags.status === "ready" ? tags.list : undefined, value: tagId, onChange: props.onTag }),
        tags.status === "error" ? h("p", { className: "tps-error", role: "alert" }, "Couldn’t load the tags: " + tags.error) : null,
        props.sources.length > 1 ? h("div", { className: "st-eval-sources", role: "group", "aria-label": "Which scenes to answer" },
          props.sources.map(function (choice) {
            const on = source === choice.id;
            return h("button", { key: choice.id, type: "button", className: "btn btn-sm st-eval-source " + (on ? "btn-primary" : "btn-secondary"), "data-source": choice.id, "aria-pressed": on, onClick: function () { props.onSource(choice.id); } }, choice.label);
          })) : null,
        source === "claims" && tagId ? h("p", { className: "st-eval-claims-count st-settings-help text-muted", role: "status" }, plural((worker.evalClaims.byTag[tagId] || []).length, "claim") + " waiting for " + (tag ? tag.name : "this tag") + ".") : null,
        source === "tagged" ? h("label", { className: "st-check st-eval-named-check" },
          h("input", { id: "st-eval-includenamed", type: "checkbox", checked: includeNamed, onChange: function (event) { setIncludeNamed(event.target.checked); setRefresh(refresh + 1); } }),
          " " + INCLUDE_NAMED_LABEL) : null,
        leftOut && status === "ready" && ids.length ? h("p", { className: "st-eval-named-note st-settings-help text-muted", role: "status" }, "Left out " + plural(leftOut, "scene") + " whose text names the tag.") : null,
        body,
        h("div", { className: "st-settings-actions st-eval-undo" },
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-undo-button", disabled: !undoStack.length, onClick: undo }, "Undo last answer")),
        h("p", { className: "st-eval-status", role: "status", "aria-live": "polite" }, message));
    }

    // The scene as text only: no preview, no tags, no model output, no half.
    function EvalCard(props) {
      const scene = props.card, tag = props.tag;
      const title = String(scene.title || "").trim(), details = String(scene.details || "").trim(), file = fileName(scene);
      const performers = (scene.performers || []).map(function (entry) { return String(entry.name || ""); }).filter(Boolean);
      const studio = scene.studio && scene.studio.name ? String(scene.studio.name) : "";
      const empty = function (text) { return h("span", { className: "st-eval-none text-muted" }, text); };
      const button = function (kind, label, number, primary) {
        return h("button", { key: kind, type: "button", className: "btn btn-sm st-eval-answer st-eval-" + kind + " " + (primary ? "btn-primary" : "btn-secondary"), "aria-keyshortcuts": String(number), onClick: function () { kind === "skip" ? props.onSkip() : props.onAnswer(kind); } },
          label, h("span", { className: "st-key", "aria-hidden": "true" }, number));
      };
      return h("article", { className: "st-eval-card", "data-scene": scene.id, "aria-label": "Scene to answer for" },
        h("p", { className: "st-eval-question", id: "st-eval-question" }, "From this text alone, would you add ", h("strong", null, tag.name), "?"),
        tag.description ? h("p", { className: "st-eval-definition text-muted" }, h("span", { className: "st-eval-definition-label" }, "Definition: "), tag.description) : null,
        h("dl", { className: "st-eval-text", onMouseUp: props.onSelect, onKeyUp: props.onSelect },
          h("dt", null, "Title"), h("dd", { "data-evidence-field": "title" }, title || empty("(no title)")),
          h("dt", null, "Description"), h("dd", { "data-evidence-field": "details", className: "st-eval-details" }, details || empty("(no description)")),
          h("dt", null, "File name"), h("dd", { "data-evidence-field": "file" }, file || empty("(no file)")),
          performers.length || studio ? h("dt", { className: "st-eval-context-label" }, "Context") : null,
          performers.length || studio ? h("dd", { className: "st-eval-context" }, (performers.length ? "Performers: " + performers.join(", ") : "") + (performers.length && studio ? ". " : "") + (studio ? "Studio: " + studio : "")) : null),
        h("p", { className: "st-eval-hint st-settings-help text-muted" }, "Select words in the title, description or file name to mark them as evidence; they are saved with a Yes."),
        props.evidence.length ? h("ul", { className: "st-eval-chips", "aria-label": "Evidence" }, props.evidence.map(function (entry, index) {
          return h("li", { key: index, className: "st-eval-chip" },
            h("span", { className: "st-chip-label" }, "Evidence"), " ", h("span", { className: "st-field text-muted" }, FIELD_WORDS[entry.f]), " “" + entry.t + "”",
            h("button", { type: "button", className: "btn btn-link btn-sm st-eval-chip-remove", "aria-label": "Remove evidence “" + entry.t + "”", onClick: function () { props.onRemove(index); } }, "×"));
        })) : null,
        h("div", { className: "st-eval-buttons", role: "group", "aria-label": "Your answer" },
          button("yes", "Yes", 1, true), button("no", "No", 2), button("unclear", "Unclear", 3), button("skip", "Skip", 4)),
        h("div", { className: "st-eval-card-links" }, h(Link, { to: "/scenes/" + scene.id, className: "st-eval-open" }, "Open the scene")),
        h("p", { className: "st-settings-help text-muted" }, "Keys 1 to 4 answer when no text box has focus."));
    }

    // Starts an evaluation run: the profile, the method, the half, optional tags and a scene limit.
    function EvalRun(props) {
      const c = props.console, s = c.settings, only = c.answersOnly;
      const profilePair = React.useState(""), picked = profilePair[0], setProfileId = profilePair[1];
      const profileId = s.profiles.some(function (entry) { return entry.id === picked; }) ? picked : s.active || (s.profiles[0] && s.profiles[0].id) || "";
      const methodPair = React.useState("profile"), method = methodPair[0], setMethod = methodPair[1];
      const halfPair = React.useState("tuning"), half = halfPair[0], setHalf = halfPair[1];
      const limitPair = React.useState(""), limit = limitPair[0], setLimit = limitPair[1];
      const allPair = React.useState(true), all = allPair[0], setAll = allPair[1];
      const chosenPair = React.useState([]), chosen = chosenPair[0], setChosen = chosenPair[1];
      const askPair = React.useState(null), asking = askPair[0], setAsking = askPair[1];
      const messagePair = React.useState(null), message = messagePair[0], setMessage = messagePair[1];
      const busyPair = React.useState(false), busy = busyPair[0], setBusy = busyPair[1];
      const profile = s.profiles.find(function (entry) { return entry.id === profileId; }) || null;
      const configProvider = c.worker.status && c.worker.status.configProvider;
      const destination = evalDestination(profile, method, s.providers, configProvider, s.networks);
      const connected = c.connection.state === "connected";
      const reset = function (setter) { return function (value) { setAsking(null); props.onDialog(false); setter(value); }; };
      const picker = useEligibleChoice(props.tags, c.worker.candidates, chosen, setChosen);

      function start() {
        setMessage(null);
        let request;
        try {
          if (!all && !usableChoices(chosen, picker.view).length) throw new Error("Choose at least one tag, or tick All tags.");
          request = evalRunRequest({ profile: profileId, method: method, half: half, tagIds: all ? [] : usableChoices(chosen, picker.view), limit: limit });
        } catch (error) { setMessage({ kind: "error", text: error.message }); return; }
        const parts = [];
        if (half !== "tuning") parts.push(TEST_HALF_TEXT);
        if (destination && destination.local === false) parts.push("Scene text will be sent to " + destination.host + ", outside your network. The model there is billed for every request.");
        if (parts.length && !asking) { setAsking({ request: request, parts: parts }); props.onDialog(true); return; }
        send(request);
      }
      function send(request) {
        setBusy(true);
        setAsking(null);
        props.onDialog(false);
        c.enqueue(request).then(function () { setBusy(false); setMessage({ kind: "info", text: "Sent. The worker starts the evaluation when it is free; its progress shows below." }); }, function (error) { setBusy(false); setMessage({ kind: "error", text: error.message }); });
      }
      if (!s.profiles.length) return h("p", { className: "tps-empty text-muted" }, "Add a provider and a profile first (Providers and Profiles tabs): an evaluation runs a profile against your answers.");
      return h(React.Fragment, null,
        h("form", { className: "st-run-form st-eval-run-form", noValidate: true, onSubmit: function (event) { event.preventDefault(); start(); } },
          field("st-eval-profile", "Profile", h("select", { id: "st-eval-profile", className: "form-control form-control-sm", value: profileId, onChange: function (event) { reset(setProfileId)(event.target.value); } },
            s.profiles.map(function (entry) { return h("option", { key: entry.id, value: entry.id }, entry.name + (s.active === entry.id ? " (active)" : "")); }))),
          field("st-eval-method", "Method", h("select", { id: "st-eval-method", className: "form-control form-control-sm", value: method, onChange: function (event) { reset(setMethod)(event.target.value); } },
            EVAL_METHODS.map(function (entry) { return h("option", { key: entry.id, value: entry.id }, entry.label); })),
          method === "decisions" ? "The decision model answers a question per candidate tag through the profile’s verify provider and verify model. It gives a probability and no quote." : "Runs the profile with its verify pass, as real analysis would, and scores what it would publish."),
          field("st-eval-half", "Half", h("select", { id: "st-eval-half", className: "form-control form-control-sm", value: half, onChange: function (event) { reset(setHalf)(event.target.value); } },
            h("option", { value: "tuning" }, "Tuning half (practice set)"), h("option", { value: "test" }, "Test half (final set)"), h("option", { value: "both" }, "Both halves")),
          "Use the tuning half while you change prompts and definitions. The test half is for reporting once they are settled; use it sparingly."),
          field("st-eval-limit", "Scene limit", h("input", { id: "st-eval-limit", type: "number", min: "1", max: String(MAX_RUN_LIMIT), step: "1", inputMode: "numeric", className: "form-control form-control-sm st-settings-budget", value: limit, placeholder: "No limit", onChange: function (event) { reset(setLimit)(event.target.value); } }),
          "At most this many scenes are sent to the model. Blank sends every scene in the set."),
          h("div", { className: "st-settings-field" }, h("span", { className: "st-label" }, "Tags"),
            props.tags.status === "ready"
              ? h(TagPicker, { tags: picker.view.list, filtered: picker.view.filtered, note: picker.note, all: all, chosen: chosen, onAll: function (on) { picker.clearNote(); reset(setAll)(on); },
                onChoose: function (ids, on) { picker.clearNote(); setAsking(null); props.onDialog(false); setChosen(function (previous) { return on ? previous.concat(ids.filter(function (id) { return previous.indexOf(id) === -1; })) : previous.filter(function (id) { return ids.indexOf(id) === -1; }); }); } })
              : h("p", { className: "tps-status text-muted", role: "status" }, "Loading tags…")),
          h("p", { className: "st-run-where", role: "status", "aria-live": "polite" }, !destination ? "Choose a profile." : destination.local === false ? "Scene text goes to " + destination.host + ", outside your network." : destination.local === true ? "Scene text goes to " + destination.host + ", on your network." : "Scene text goes to the address in the worker’s config file."),
          h("div", { className: "st-settings-actions" },
            h("button", { type: "submit", className: "btn btn-primary btn-sm st-eval-start", disabled: !connected || busy || !!asking || only, title: connected ? undefined : "The worker has not answered" }, busy ? "Sending…" : "Run evaluation"),
            only ? h("span", { className: "st-settings-help text-muted st-answers-only" }, "This worker only records answers, so it cannot run an evaluation.") : null,
            connected || only ? null : h("span", { className: "st-settings-help text-muted" }, "Run evaluation is available once the worker answers.")),
          h("p", { className: "st-settings-message" + (message && message.kind === "error" ? " tps-error" : ""), role: "status", "aria-live": "polite" }, message ? message.text : "")),
        asking ? h(ConfirmForm, { label: half === "tuning" ? "Send scene text outside your network" : "Run on the test half", busy: busy, confirmLabel: "Run evaluation", onConfirm: function () { send(asking.request); }, onCancel: function () { setAsking(null); props.onDialog(false); },
          text: asking.parts.join(" ") + " Run the evaluation?" }) : null);
    }

    // The tuning half's details for one run: the per-tag table, the name-in-text split and the mistakes.
    function EvalRunDetails(props) {
      const c = props.console, run = props.run, figures = run.tuning, worker = c.worker;
      const tagPair = React.useState(""), tagFilter = tagPair[0], setTagFilter = tagPair[1];
      const outcomePair = React.useState("wrong"), outcome = outcomePair[0], setOutcome = outcomePair[1];
      const pagePair = React.useState(0), page = pagePair[0], setPage = pagePair[1];
      const askPair = React.useState(null), ask = askPair[0], setAsk = askPair[1];
      const mounted = React.useRef(true);
      React.useEffect(function () { mounted.current = true; return function () { mounted.current = false; }; }, []);
      const online = c.connection.state === "connected";
      const slow = useExpiry(ask && ask.at, 45000);
      React.useEffect(function () {
        if (!online) return;
        let request;
        try { request = evalDetailRequest({ runId: run.id, tagId: tagFilter, outcome: outcome, page: page }); } catch (_) { return; }
        c.enqueue(request).then(function () { if (mounted.current) setAsk({ id: request.id, at: Date.now() }); }, function () {});
      }, [run.id, tagFilter, outcome, page, online]);
      const detail = worker.evalDetail && ask && worker.evalDetail.request === ask.id ? worker.evalDetail : null;
      const pages = detail ? Math.max(1, Math.ceil(detail.total / EVAL_LIMITS.detailRows)) : 1;
      const split = function (label, pair) {
        return h("tr", { key: label }, h("th", { scope: "row" }, label), h("td", null, precisionHeadline(pair.precision), h("small", { className: "text-muted st-eval-sub" }, precisionCounts(pair.precision))), h("td", null, ratioText(pair.recall), h("small", { className: "text-muted st-eval-sub" }, recallCounts(pair.recall))));
      };
      const rowText = { wrong: "Claimed; you said No.", missed: "You said Yes; not claimed.", guessed: "Claimed on a scene that already has the tag; you said No." };
      return h("div", { className: "st-eval-details-body" },
        h("h5", { className: "st-eval-h5" }, "By tag"),
        figures.tags.length ? h("div", { className: "st-eval-table-wrap" }, h("table", { className: "st-eval-table" },
          h("caption", { className: "st-sr-only" }, "Tuning half figures per tag"),
          h("thead", null, h("tr", null, h("th", { scope: "col" }, "Tag"), h("th", { scope: "col" }, "Precision"), h("th", { scope: "col" }, "Recall"))),
          h("tbody", null, figures.tags.map(function (entry) {
            return h("tr", { key: entry.tagId, "data-tag": entry.tagId }, h("th", { scope: "row" }, props.tagName(entry.tagId)),
              h("td", null, precisionHeadline(entry.precision), h("small", { className: "text-muted st-eval-sub" }, precisionCounts(entry.precision))),
              h("td", null, ratioText(entry.recall), h("small", { className: "text-muted st-eval-sub" }, recallCounts(entry.recall))));
          })))) : h("p", { className: "text-muted" }, "No per-tag figures yet."),
        h("h5", { className: "st-eval-h5" }, "Is the tag’s name in the text?"),
        h("div", { className: "st-eval-table-wrap" }, h("table", { className: "st-eval-table st-eval-split" },
          h("caption", { className: "st-sr-only" }, "Tuning half figures by whether the tag’s name or an alias appears in the text sent"),
          h("thead", null, h("tr", null, h("th", { scope: "col" }, "Pairs where"), h("th", { scope: "col" }, "Precision"), h("th", { scope: "col" }, "Recall"))),
          h("tbody", null, split("the name appears", figures.nameInText), split("the name does not appear", figures.nameNotInText)))),
        h("h5", { className: "st-eval-h5" }, "Mistakes"),
        h("div", { className: "st-eval-filters" },
          field("st-eval-detail-outcome-" + run.id, "Show", h("select", { id: "st-eval-detail-outcome-" + run.id, className: "form-control form-control-sm", value: outcome, onChange: function (event) { setOutcome(event.target.value); setPage(0); } },
            MISTAKES.map(function (entry) { return h("option", { key: entry.id, value: entry.id }, entry.label); }))),
          field("st-eval-detail-tag-" + run.id, "Tag", h("select", { id: "st-eval-detail-tag-" + run.id, className: "form-control form-control-sm", value: tagFilter, onChange: function (event) { setTagFilter(event.target.value); setPage(0); } },
            h("option", { value: "" }, "Every tag"), figures.tags.map(function (entry) { return h("option", { key: entry.tagId, value: entry.tagId }, props.tagName(entry.tagId)); })))),
        !online ? h("p", { className: "tps-error", role: "status" }, withCode("Worker has not answered: start it with `npm run semantic -- serve`.")) : null,
        online && !detail ? h("p", { className: "tps-status text-muted", role: "status" }, slow ? "The worker has not answered yet." : "Asking the worker…") : null,
        detail && detail.refused ? h("p", { className: "tps-error", role: "alert" }, detail.refused) : null,
        detail && !detail.refused && !detail.rows.length ? h("p", { className: "tps-empty text-muted", role: "status" }, "No mistakes of this kind.") : null,
        detail && detail.rows.length ? h("ul", { className: "st-eval-mistakes", "aria-label": "Mistakes in the tuning half" }, detail.rows.map(function (row, index) {
          return h("li", { key: row.sceneId + ":" + row.tagId + ":" + index, className: "st-eval-mistake", "data-scene": row.sceneId, "data-outcome": row.outcome },
            h(Link, { to: "/scenes/" + row.sceneId, className: "st-eval-mistake-link" }, "Scene " + row.sceneId), " · ", h("strong", null, props.tagName(row.tagId)), " · ", rowText[row.outcome] || row.outcome,
            row.confidence || row.p != null ? h("span", { className: "st-confidence", "data-confidence": row.confidence }, (row.confidence || "") + (row.p != null ? (row.confidence ? " " : "") + row.p.toFixed(2) : "")) : null,
            row.quote ? h("span", { className: "st-eval-claim-quote" }, " " + (FIELD_WORDS[row.field] || row.field) + " “" + row.quote + "”") : null,
            row.reason ? h("span", { className: "st-reason text-muted" }, row.reason) : null);
        })) : null,
        detail && detail.total > EVAL_LIMITS.detailRows ? h("div", { className: "st-pager" },
          h("button", { type: "button", className: "btn btn-secondary btn-sm", disabled: page <= 0, onClick: function () { setPage(page - 1); } }, "Previous"),
          h("span", null, "Page " + (page + 1) + " of " + pages),
          h("button", { type: "button", className: "btn btn-secondary btn-sm", disabled: page + 1 >= pages, onClick: function () { setPage(page + 1); } }, "Next")) : null);
    }

    // One half's figures as a list.
    function Figures(props) {
      const f = props.figures;
      return h("dl", { className: "st-eval-figures" },
        h("dt", null, "Precision"), h("dd", { className: "st-eval-precision" }, h("strong", null, precisionHeadline(f.precision)), h("small", { className: "text-muted st-eval-sub" }, precisionCounts(f.precision)),
          precisionRange(f.precision) ? h("small", { className: "text-muted st-eval-sub st-eval-precision-note" }, "A range while claims wait: if every waiting claim were wrong, to if every one were right. Counting only the answered claims: " + ratioText(f.precision) + ".") : null),
        h("dt", null, "Recall"), h("dd", { className: "st-eval-recall" }, h("strong", null, ratioText(f.recall)), h("small", { className: "text-muted st-eval-sub" }, recallCounts(f.recall)),
          recallParts(f.recall).map(function (part) { return h("small", { key: part.id, className: "text-muted st-eval-sub st-eval-recall-part", "data-part": part.id }, part.label + ": " + part.text); }),
          h("small", { className: "text-muted st-eval-sub st-eval-recall-note" }, RECALL_NOTE)),
        h("dt", null, "Guess"), h("dd", { className: "st-eval-guess" }, guessText(f.guess)),
        h("dt", null, "Evidence"), h("dd", { className: "st-eval-evidence" }, evidenceText(f.evidence)),
        f.atKeep.length ? h("dt", null, "At each keep threshold") : null,
        f.atKeep.length ? h("dd", { className: "st-eval-atkeep" }, f.atKeep.map(function (entry) {
          return h("span", { key: entry.keep, className: "st-eval-atkeep-row" }, "Keep " + entry.keep + ": precision " + ratioText(entry.precision) + ", recall " + ratioText(entry.recall));
        })) : null);
    }

    // The kept runs with their figures, and Refresh figures.
    function EvalResults(props) {
      const c = props.console, runs = c.worker.evalRuns, online = c.connection.state === "connected";
      const openPair = React.useState(""), open = openPair[0], setOpen = openPair[1];
      const scorePair = React.useState(null), score = scorePair[0], setScore = scorePair[1];
      const messagePair = React.useState(""), message = messagePair[0], setMessage = messagePair[1];
      const tagName = function (id) { const tag = props.tags.status === "ready" ? props.tags.list.find(function (entry) { return String(entry.id) === String(id); }) : null; return tag ? tag.name : "Tag " + id; };
      function refresh() {
        setMessage("");
        let request;
        try { request = evalScoreRequest(); } catch (error) { setMessage(error.message); return; }
        c.enqueue(request).then(function () { setScore({ id: request.id }); }, function (error) { setMessage(error.message); });
      }
      const scoring = score && c.worker.answered.indexOf(score.id) === -1;
      const line = message || (scoring ? "Asking the worker to score the runs again from your answers…" : score ? "Figures refreshed from your latest answers." : "");
      return h("section", { className: "st-eval-results", "aria-labelledby": "st-eval-results-title" },
        h("div", { className: "st-heading-row" },
          h("h4", { id: "st-eval-results-title", className: "st-subheading" }, "Results"),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-refresh", disabled: !online || !!scoring, title: online ? "Score the kept runs again against your latest answers; no model is asked" : "The worker has not answered", onClick: refresh }, scoring ? "Refreshing…" : "Refresh figures")),
        h("p", { className: "st-eval-score-line st-settings-help text-muted", role: "status", "aria-live": "polite" }, line),
        runs.length ? h("p", { className: "st-eval-rescore-note st-settings-help text-muted" }, "Refresh figures scores your latest answers against the results a run already has. An answer for a tag a scene already carries is scored only after that scene is run again, so run the evaluation again to include it. Answering the claims that wait changes the range at once." + (c.worker.evalCounts.at && runs[0].scoredAt && Date.parse(c.worker.evalCounts.at) > Date.parse(runs[0].scoredAt) + 1000 ? " You have answered since the newest figures were made." : "")) : null,
        !runs.length ? h("p", { className: "tps-empty text-muted st-eval-no-runs" }, "No evaluation runs yet. Decide on some proposals in Review, then run an evaluation.") : h("ul", { className: "st-eval-runs", "aria-label": "Evaluation runs" }, runs.map(function (run) {
          const halves = ["tuning", "test"].filter(function (half) { return run[half]; });
          const expanded = open === run.id;
          return h("li", { key: run.id, className: "st-eval-result", "data-run": run.id },
            h("div", { className: "st-job-head" },
              h("strong", null, run.profile || "Profile"),
              h("span", { className: "badge badge-secondary" }, (EVAL_METHODS.find(function (entry) { return entry.id === run.method; }) || EVAL_METHODS[0]).label),
              run.half ? h("span", { className: "badge badge-secondary" }, run.half === "both" ? "both halves" : run.half + " half") : null),
            h("p", { className: "st-eval-run-meta text-muted" },
              (run.at ? "Run " + listAge(run.at) : "") + (run.scoredAt ? ", scored " + listAge(run.scoredAt) : "") + ". " + plural(run.scenes.total, "scene") + " (" + run.scenes.answered + " with answers" + (run.scenes.sample ? ", " + run.scenes.sample + " in the fixed sample" : "") + (run.scenes.noText ? ", " + run.scenes.noText + " without usable text" : "") + (run.scenes.failed ? ", " + run.scenes.failed + " failed" : "") + (run.scenes.notHere ? ", " + run.scenes.notHere + " not in this Stash" : "") + ")."
              + (run.models.length ? " Models: " + run.models.join(", ") + "." : "") + (run.thresholds.keep != null ? " Keep " + run.thresholds.keep + (run.thresholds.high != null ? ", high " + run.thresholds.high : "") + "." : "") + (run.cost != null ? " Cost " + run.cost + " credits." : "")),
            halves.map(function (half) {
              return h("div", { key: half, className: "st-eval-half", "data-half": half },
                h("h5", { className: "st-eval-h5" }, HALF_NAMES[half], half === "test" ? h("span", { className: "text-muted st-eval-sub" }, " Totals only: no per-tag or per-scene figures, so the final set is not tuned against.") : null),
                h(Figures, { figures: run[half] }));
            }),
            !halves.length ? h("p", { className: "text-muted" }, "No figures yet: the worker scores this run when it finishes.") : null,
            run.tuning ? h("div", { className: "st-settings-actions" }, h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-details-toggle", "aria-expanded": expanded, onClick: function () { setOpen(expanded ? "" : run.id); } }, expanded ? "Hide tuning details" : "Show tuning details")) : null,
            expanded && run.tuning ? h(EvalRunDetails, { console: c, run: run, tagName: tagName }) : null);
        })));
    }

    // The Evaluate tab (0.7.3), top to bottom: what you have decided (counts and your Review decisions by model), the
    // evaluation run, its results, the claims that wait for your decision, and, closed, the other ways to answer.
    function EvaluateTab(props) {
      const c = props.console, s = c.settings;
      const location = Router.useLocation ? Router.useLocation() : window.location;
      const history = Router.useHistory ? Router.useHistory() : null;
      const params = new URLSearchParams(location.search || "");
      const urlSource = ["tagged", "picks"].indexOf(params.get("source")) !== -1 ? params.get("source") : "";
      const tagPair = React.useState(function () { return /^\d+$/.test(params.get("tag") || "") ? params.get("tag") : ""; }), tagId = tagPair[0], setTagId = tagPair[1];
      // The source under "More ways to add answers", which opens by itself only when the address names one.
      const sourcePair = React.useState(urlSource || "tagged"), source = sourcePair[0], setSource = sourcePair[1];
      const morePair = React.useState(!!urlSource), moreOpen = morePair[0], setMoreOpen = morePair[1];
      const tagsPair = React.useState({ status: "loading" }), tags = tagsPair[0], setTags = tagsPair[1];
      const dialogPair = React.useState(false), dialog = dialogPair[0], setDialog = dialogPair[1];
      const outbox = useOutbox();
      React.useEffect(function () {
        let live = true;
        definedTags(transport).then(function (list) { if (live) setTags({ status: "ready", list: list }); }, function (error) { if (live) setTags({ status: "error", error: error.message }); });
        return function () { live = false; };
      }, []);
      // The worker's map may have changed since the page opened (counts, claims, figures).
      React.useEffect(function () { if (c.status === "ready") c.reload().catch(function () {}); }, [c.status]);
      // A finished evaluation run: its figures are written a moment after the job says done, so read again.
      const finished = c.worker.jobs.filter(function (job) { return job.type === "eval" && job.state !== "queued" && job.state !== "running"; }).map(function (job) { return job.id + job.state; }).join(",");
      React.useEffect(function () {
        if (!finished || c.status !== "ready") return undefined;
        const timer = setTimeout(function () { c.reload().catch(function () {}); }, 1500);
        return function () { clearTimeout(timer); };
      }, [finished]);
      // With no tag chosen, the waiting claims start with the tag that has the most.
      const claimsByTag = c.worker.evalClaims.byTag;
      const busiest = Object.keys(claimsByTag).sort(function (a, b) { return claimsByTag[b].length - claimsByTag[a].length || Number(a) - Number(b); })[0] || "";
      React.useEffect(function () { if (!tagId && busiest) setTagId(busiest); }, [busiest]);
      // The address keeps the tag, and the source while "More ways to add answers" is open.
      function remember(nextTag, nextSource, open) {
        const url = evaluateUrl(nextTag, open ? nextSource : "");
        if (history && history.replace) history.replace(url); else if (window.history && window.history.replaceState) window.history.replaceState(null, "", url);
      }
      function choose(nextTag, nextSource) {
        setTagId(nextTag);
        setSource(nextSource);
        remember(nextTag, nextSource, moreOpen);
      }
      function toggleMore() {
        const next = !moreOpen;
        setMoreOpen(next);
        remember(tagId, source, next);
      }
      if (c.status === "loading") return h("section", { className: "st-settings st-eval" }, h("p", { className: "tps-status text-muted", role: "status" }, "Loading settings…"));
      const tag = tags.status === "ready" ? tags.list.find(function (entry) { return String(entry.id) === tagId; }) : null;
      return h("section", { className: "st-eval", "aria-labelledby": "st-eval-title" },
        h("h3", { id: "st-eval-title" }, "Evaluate"),
        h("p", { className: "st-settings-help text-muted st-eval-intro" }, "Your decisions measure how good the proposals are. Each proposal you accept in Review counts as a Yes and each one you reject as a No. An evaluation run asks a model about the scenes you have decided on and scores what it claims against those decisions. What it claims that you have not decided on waits for you below, and each round adds answers. Half of the scenes (the test half, the final set) are kept back so that the headline figures are not tuned against; the other half (the tuning half, the practice set) is for improving prompts and definitions."),
        h(EvalCounts, { console: c, tagId: tagId, tagName: tag ? tag.name : "", outbox: outbox }),
        h(OutboxLine, { outbox: outbox, always: true, saved: true }),
        h(EvalBySource, { console: c }),
        h("section", { className: "st-eval-run", "aria-labelledby": "st-eval-run-title" },
          h("h4", { id: "st-eval-run-title", className: "st-subheading" }, "Run an evaluation"),
          h("p", { className: "st-settings-help text-muted st-eval-run-help" }, "Runs over the scenes you have decided on: your Review decisions and every answer you have given. Nothing is written to any scene."),
          h(EvalRun, { console: c, tags: tags, onDialog: setDialog }),
          h(JobList, { console: c, kind: "eval" })),
        h(EvalResults, { console: c, tags: tags }),
        // With no claim waiting there is nothing to pick a tag for, so the section only says so.
        c.worker.evalClaims.total > 0 ? h(EvalAnswering, {
          key: "claims", console: c, tags: tags, tagId: tagId, source: "claims", sources: CLAIMS_SOURCES, variant: "claims", idKey: "st-eval", heading: "Waiting for your decision", outbox: outbox, keysOff: dialog || moreOpen,
          help: "A method claimed these tags and you have not decided on them yet. Answer from the text alone, before you look at anything a model proposed. An answer is about what you mean by the tag, not whether its name appears in the text. The worker keeps your answers in its own file, outside Stash.",
          onTag: function (value) { choose(value, source); }, onSource: function () {},
        }) : h("section", { className: "st-eval-answering st-eval-answering-claims st-eval-waiting-none", "aria-labelledby": "st-eval-waiting-title" },
          h("h4", { id: "st-eval-waiting-title", className: "st-subheading" }, "Waiting for your decision", h("span", { className: "st-eval-waiting-total text-muted" }, " 0 claims waiting")),
          h("p", { className: "tps-empty text-muted" }, "No claim is waiting. Run an evaluation: what a model claims on the scenes you have decided on, and you have not, waits here.")),
        h("section", { className: "st-eval-more-section" },
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-eval-more-toggle", "aria-expanded": moreOpen, "aria-controls": "st-eval-more-panel", onClick: toggleMore }, "More ways to add answers"),
          moreOpen ? h("div", { id: "st-eval-more-panel", className: "st-eval-more-panel" },
            h(EvalAnswering, {
              key: "more", console: c, tags: tags, tagId: tagId, source: source, sources: MORE_SOURCES, variant: "more", idKey: "st-eval-more", outbox: outbox, keysOff: dialog,
              help: "Answer for scenes that have the tag, or for scenes you queued from the scenes list. Answer from the text alone. The worker keeps your answers in its own file, outside Stash.",
              onTag: function (value) { choose(value, source); }, onSource: function (value) { choose(tagId, value); },
            })) : null));
    }

    // The scenes list's selection: an Evaluate… action. Choose a tag, then add the
    // scenes to your queue (picks) or record a Yes for each ("From the text, I
    // would add this tag", src browser). Both go through the outbox, which sends
    // 50 at a time; at most MAX_SCENE_IDS scenes are handled in one go.
    function ListEvaluate(props) {
      const ids = Array.from(props.selectedIds || []).map(String).filter(function (id, index, all) { return /^\d+$/.test(id) && all.indexOf(id) === index; });
      const openPair = React.useState(false), open = openPair[0], setOpen = openPair[1];
      const tagsPair = React.useState({ status: "idle" }), tags = tagsPair[0], setTags = tagsPair[1];
      const tagPair = React.useState(""), tagId = tagPair[0], setTagId = tagPair[1];
      const messagePair = React.useState(null), message = messagePair[0], setMessage = messagePair[1];
      const busyPair = React.useState(false), busy = busyPair[0], setBusy = busyPair[1];
      const dialogPair = React.useState(false), dialog = dialogPair[0], setDialog = dialogPair[1];
      const outbox = useOutbox();
      React.useEffect(function () {
        if (!open || tags.status !== "idle") return undefined;
        let live = true;
        setTags({ status: "loading" });
        // The worker's list of tags it can analyse, when it has published one; the list still works without it.
        Promise.all([definedTags(transport), readMaps(transport).then(function (maps) { return parseWorker(maps.worker).candidates; }, function () { return null; })]).then(function (all) {
          if (live) setTags({ status: "ready", list: all[0], candidates: all[1] });
        }, function (error) { if (live) setTags({ status: "error", error: error.message }); });
        return function () { live = false; };
      }, [open]);
      if (!ids.length) return null;
      const over = ids.length > MAX_SCENE_IDS;
      const tag = tags.status === "ready" ? tags.list.find(function (entry) { return String(entry.id) === tagId; }) || null : null;
      const scenes = plural(ids.length, "scene");

      function queue() {
        setMessage(null);
        try {
          submitOutbox({ picks: { add: ids.map(function (id) { return { sceneId: id, tagId: tagId }; }) } });
          setMessage({ kind: "info", text: "Added " + scenes + " to your queue for " + tag.name + ". They are saved once the worker confirms." });
        } catch (error) { setMessage({ kind: "error", text: error.message }); }
      }
      function yes() {
        setDialog(false);
        setBusy(true);
        setMessage(null);
        Promise.all([transport(QUERIES.evalSceneTags, { ids: ids }), loadCarry(transport, tag).catch(function () { return null; })]).then(function (all) {
          const found = all[0].findScenes.scenes;
          const items = found.map(function (scene) {
            return evalItem(scene.id, tagId, "yes", { src: "browser", had: sceneCarries((scene.tags || []).map(function (entry) { return entry.id; }), all[1], tagId) });
          });
          submitOutbox({ items: items });
          const missing = ids.length - found.length;
          setMessage({ kind: missing ? "error" : "info", text: "Recorded Yes for " + tag.name + " on " + plural(items.length, "scene") + ". They are saved once the worker confirms." + (missing ? " " + plural(missing, "selected scene") + " could not be read and " + (missing === 1 ? "was" : "were") + " skipped." : "") });
          setBusy(false);
        }, function (error) { setBusy(false); setMessage({ kind: "error", text: "Nothing was recorded: " + error.message }); });
      }
      return h("div", { className: "st-list-bar", role: "region", "aria-label": "Evaluate the selected scenes" },
        h("div", { className: "st-list-head" },
          h("span", { className: "st-list-count" }, scenes + " selected"),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-list-evaluate", "aria-expanded": open, onClick: function () { setOpen(!open); } }, "Evaluate…")),
        open ? h("div", { className: "st-list-panel" },
          h("p", { className: "st-settings-help text-muted" }, "Answers are about the text alone. A queued scene waits for you on the Evaluate tab; the second choice records the answer now."),
          tags.status === "ready" ? h(TagSelect, { tags: eligibleView(tags, tags.candidates).list, filtered: !!tags.candidates, also: tags.list, value: tagId, onChange: function (value) { setTagId(value); setMessage(null); setDialog(false); } })
            : tags.status === "error" ? h("p", { className: "tps-error", role: "alert" }, "Couldn’t load the tags: " + tags.error) : h("p", { className: "tps-status text-muted", role: "status" }, "Loading tags…"),
          over ? h("p", { className: "tps-error", role: "alert" }, "Select at most " + MAX_SCENE_IDS + " scenes at a time; " + scenes + " are selected.") : null,
          h("div", { className: "st-settings-actions" },
            h("button", { type: "button", className: "btn btn-secondary btn-sm st-list-queue", disabled: !tag || over || busy, onClick: queue }, "Add to my queue"),
            h("button", { type: "button", className: "btn btn-primary btn-sm st-list-yes", disabled: !tag || over || busy, onClick: function () { setDialog(true); setMessage(null); } }, "From the text, I would add this tag")),
          tag && !over ? h("p", { className: "st-list-count-note st-settings-help text-muted", role: "status" }, scenes + " will be written for " + tag.name + ".") : null,
          dialog && tag ? h(ConfirmForm, { label: "Record Yes for the selected scenes", confirmLabel: "Record Yes for " + scenes, onConfirm: yes, onCancel: function () { setDialog(false); },
            text: "Record “From this text alone, I would add " + tag.name + "” as a Yes for " + scenes + "? It replaces any answer you gave before for " + tag.name + " on them." }) : null,
          h("p", { className: "st-list-status" + (message && message.kind === "error" ? " tps-error" : ""), role: "status", "aria-live": "polite" }, busy ? "Reading the scenes…" : message ? message.text : ""),
          h(OutboxLine, { outbox: outbox })) : null);
    }

    // Section in the Suggestions tab (Tag & Performer Suggestions).
    function SceneSection(props) {
      const target = props.target;
      const resultPair = React.useState({ status: "loading" }), result = resultPair[0], setResult = resultPair[1];
      const statesPair = useStates(), states = statesPair[0], setState = statesPair[1];
      const requestPair = React.useState(null), request = requestPair[0], setRequest = requestPair[1];
      // Which inline form is open ("reject:<tag>" or "report:<tag>"), and the
      // last outcome, announced to screen readers.
      const formPair = React.useState(null), formOpen = formPair[0], setFormOpen = formPair[1];
      const messagePair = React.useState(""), message = messagePair[0], setMessage = messagePair[1];
      // A worker that only records answers never analyses, so Re-analyse is off.
      const onlyPair = React.useState(false), answersOnly = onlyPair[0], setAnswersOnly = onlyPair[1];
      React.useEffect(function () {
        if (target.type !== "scene") return undefined;
        let live = true;
        readMaps(transport).then(function (maps) { const worker = parseWorker(maps.worker); if (live) setAnswersOnly(!!(worker.status && worker.status.answersOnly)); }).catch(function () {});
        return function () { live = false; };
      }, [target.type, target.id]);
      React.useEffect(function () {
        if (target.type !== "scene") return undefined;
        let live = true;
        setResult({ status: "loading" });
        loadScenes(transport, [target.id]).then(function (scenes) {
          if (!live) return;
          const scene = scenes[0];
          setResult({ status: "ready", scene: scene, proposals: scene ? sceneProposals(scene.custom_fields, scene.tags) : { items: [] } });
        }, function (error) { if (live) setResult({ status: "error", error: error.message }); });
        return function () { live = false; };
      }, [target.type, target.id, props.refreshKey]);
      if (target.type !== "scene") return null;

      // Reads the scene again so the applied list follows a decision; the
      // proposal rows keep the status of the decisions made on this page.
      function reloadScene() {
        loadScenes(transport, [target.id]).then(function (scenes) {
          setResult(function (previous) { return previous.status === "ready" && scenes[0] ? Object.assign({}, previous, { scene: scenes[0] }) : previous; });
        }, function () {});
      }
      function act(kind, item, reason) {
        const key = item.tagId;
        setFormOpen(null);
        setState(key, { status: kind === "accept" ? "accepting" : "rejecting" });
        (kind === "accept" ? accept(transport, [target.id], item.tagId) : reject(transport, [target.id], item.tagId, reason, item.tagName)).then(function (result) {
          const queued = sendDecisionAnswers(result);
          setState(key, { status: kind === "accept" ? "accepted" : "rejected" });
          if (kind === "accept") setMessage("Added " + item.tagName + ". The reasoning is listed below." + (queued ? " " + queued : ""));
          else if (reason && (reason.category || reason.note)) setMessage("Rejected " + item.tagName + " and recorded your reason." + (queued ? " " + queued : ""));
          else if (queued) setMessage(queued);
          announceChange();
          if (kind === "accept") { refreshStash(); reloadScene(); }
        }, function (error) { setState(key, { status: "error", error: error.message }); });
      }
      function report(entry, reason) {
        const key = "report:" + entry.tagId;
        setState(key, { status: "reporting" });
        reportWrong(transport, target.id, entry.tagId, reason, entry.tagName).then(function (result) {
          const queued = sendDecisionAnswers(result);
          setState(key, { status: "reported" });
          setFormOpen(null);
          setMessage("Removed " + (entry.tagName || "the tag") + " from this scene and recorded your report." + (queued ? " " + queued : ""));
          refreshStash();
          reloadScene();
        }, function (error) { setState(key, { status: "error", error: error.message }); });
      }
      function reanalyse() {
        setRequest({ status: "sending" });
        requestAnalysis(transport, target.id).then(function () { setRequest({ status: "sent" }); }, function (error) { setRequest({ status: "error", error: error.message }); });
      }

      let body;
      if (result.status === "loading") body = h("p", { className: "tps-status text-muted", role: "status" }, "Loading AI proposals…");
      else if (result.status === "error") body = h("p", { className: "tps-error", role: "alert" }, "Couldn't load AI proposals: " + result.error);
      else if (!result.proposals.items.length) body = h("p", { className: "tps-empty text-muted" }, "No AI proposals for this scene.");
      else {
        body = h("ul", { className: "tps-list" }, result.proposals.items.map(function (item) {
          const state = states[item.tagId] || {};
          const busy = state.status === "accepting" || state.status === "rejecting";
          const done = state.status === "accepted" || state.status === "rejected";
          return h("li", { key: item.tagId, className: "tps-row st-row", "data-tag": item.tagId },
            h("div", { className: "tps-main" },
              h(Link, { to: "/tags/" + item.tagId, className: "tps-name" }, item.tagName),
              h(Evidence, { item: item }),
              h(SourceChips, { item: item, idKey: "scene-" + item.tagId })),
            done
              ? h("span", { className: "tps-added", role: "status" }, state.status === "accepted" ? "Added" : "Rejected")
              : h("div", { className: "tps-actions" },
                h("button", { type: "button", className: "btn btn-primary btn-sm st-accept", disabled: busy, "aria-label": "Add tag " + item.tagName, onClick: function () { act("accept", item); } }, state.status === "accepting" ? "Adding…" : "Add"),
                h("button", { type: "button", className: "btn btn-secondary btn-sm st-reject", disabled: busy, "aria-label": "Reject tag " + item.tagName + " for this scene", title: "Never propose this tag for this scene again", onClick: function () { act("reject", item); } }, state.status === "rejecting" ? "Rejecting…" : "Reject"),
                h("button", {
                  type: "button", className: "btn btn-link btn-sm st-reject-reason", disabled: busy, "aria-expanded": formOpen === "reject:" + item.tagId,
                  "aria-label": "Reject tag " + item.tagName + " with a reason", title: "Say why this proposal is wrong, then reject it",
                  onClick: function () { setFormOpen(formOpen === "reject:" + item.tagId ? null : "reject:" + item.tagId); },
                }, "Reject with reason\u2026")),
            formOpen === "reject:" + item.tagId && !done ? h(FeedbackForm, {
              idKey: "reject-" + item.tagId, label: "Reject " + item.tagName + " with a reason", submitLabel: "Reject with reason", busy: busy,
              onSubmit: function (reason) { act("reject", item, reason); }, onCancel: function () { setFormOpen(null); },
            }) : null,
            state.status === "error" ? h("p", { className: "tps-error", role: "alert" }, state.error) : null);
        }));
      }
      const applied = result.status === "ready" && result.scene ? sceneApplied(result.scene.custom_fields, result.scene.tags) : [];
      const appliedList = applied.length ? h("div", { className: "st-applied" },
        h("h6", { className: "tps-heading st-applied-heading" }, "Applied from the text (AI)"),
        h("ul", { className: "tps-list st-applied-list" }, applied.map(function (entry) {
          const key = "report:" + entry.tagId, state = states[key] || {}, open = formOpen === key, busy = state.status === "reporting";
          const name = entry.tagName || "tag " + entry.tagId;
          return h("li", { key: entry.tagId, className: "tps-row st-applied-row", "data-tag": entry.tagId },
            h("div", { className: "tps-main" },
              h(Link, { to: "/tags/" + entry.tagId, className: "tps-name" }, name),
              entry.record.quote ? h(Evidence, { item: entry.record }) : h("span", { className: "st-evidence st-evidence-gone text-muted" }, "Added from an AI proposal; its evidence was not kept."),
              entry.record.at ? h("time", { className: "st-applied-date text-muted", dateTime: entry.record.at, title: entry.record.model ? "Model: " + entry.record.model : undefined }, "Added " + formatDate(entry.record.at)) : null),
            h("div", { className: "tps-actions" },
              h("button", {
                type: "button", className: "btn btn-secondary btn-sm st-report", disabled: busy, "aria-expanded": open,
                "aria-label": "Report tag " + name + " as wrong", title: "Remove this tag, never propose it here again, and tell the worker why it was wrong",
                onClick: function () { setFormOpen(open ? null : key); },
              }, "Report as wrong")),
            open ? h(FeedbackForm, {
              idKey: "report-" + entry.tagId, label: "Report " + name + " as wrong", submitLabel: "Report and remove tag", busy: busy,
              onSubmit: function (reason) { report(entry, reason); }, onCancel: function () { setFormOpen(null); },
            }) : null,
            state.status === "error" ? h("p", { className: "tps-error", role: "alert" }, state.error) : null);
        }))) : null;
      const requested = request && request.status === "sent" || (result.scene && result.scene.custom_fields && result.scene.custom_fields[FIELDS.request] != null);
      return h("section", { className: "tps-section st-section", "data-kind": "semantic" },
        h("div", { className: "st-heading-row" },
          h("h6", { className: "tps-heading" }, "From the text (AI)"),
          h("button", {
            type: "button", className: "btn btn-link btn-sm st-reanalyse", disabled: !!requested || (request && request.status === "sending") || answersOnly,
            title: answersOnly ? "This worker only records answers" : "Ask the semantic tagger to read this scene again at its next check",
            onClick: reanalyse,
          }, requested ? "Re-analysis requested" : "Re-analyse"),
          answersOnly ? h("span", { className: "st-answers-only text-muted" }, "This worker only records answers.") : null,
          h(Link, { to: ROUTE, className: "st-review-link" }, "Review all")),
        body,
        appliedList,
        h(EvalGroup, { sceneId: target.id, answersOnly: answersOnly }),
        h("p", { className: "st-feedback-status tps-status text-muted", role: "status", "aria-live": "polite" }, message),
        request && request.status === "error" ? h("p", { className: "tps-error", role: "alert" }, request.error) : null);
    }
    // The model field: a text box with a listbox of matching models, as in
    // the ARIA editable combobox pattern. Typing filters over ID and name; the
    // arrow keys move through the options (Home and End jump once one is
    // highlighted), Enter takes the highlighted one, Escape closes. Text that
    // matches nothing is kept as typed.
    function ModelCombobox(props) {
      const openPair = React.useState(false), open = openPair[0], setOpen = openPair[1];
      const activePair = React.useState(-1), active = activePair[0], setActive = activePair[1];
      const pickedPair = React.useState(""), picked = pickedPair[0], setPicked = pickedPair[1];
      const result = filterModels(props.models, props.value);
      const shown = result.shown;
      const visible = open && shown.length > 0;
      const listId = props.id + "-list";
      const optionId = function (index) { return props.id + "-option-" + index; };

      React.useEffect(function () {
        const el = active >= 0 && typeof document !== "undefined" ? document.getElementById(optionId(active)) : null;
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest" });
      }, [active, visible]);

      function choose(model) {
        props.onChange(model.id);
        setOpen(false);
        setActive(-1);
        setPicked("Selected " + model.id);
      }
      function keyDown(event) {
        const last = shown.length - 1;
        if (event.key === "ArrowDown" && shown.length) {
          event.preventDefault();
          if (!open) { setOpen(true); setActive(0); } else setActive(Math.min(last, active + 1));
        } else if (event.key === "ArrowUp" && shown.length) {
          event.preventDefault();
          if (!open) { setOpen(true); setActive(last); } else setActive(active < 0 ? last : Math.max(0, active - 1));
        } else if ((event.key === "Home" || event.key === "End") && visible && active >= 0) {
          event.preventDefault();
          setActive(event.key === "Home" ? 0 : last);
        } else if (event.key === "Enter" && open) {
          // A list that is open takes Enter; the form is not submitted by it.
          event.preventDefault();
          if (visible && active >= 0) choose(shown[active]); else setOpen(false);
        } else if (event.key === "Escape" && open) {
          event.preventDefault();
          event.stopPropagation();
          setOpen(false);
          setActive(-1);
        }
      }
      const status = picked || (open && props.models.length ? (result.total ? result.total + (result.total === 1 ? " model matches." : " models match.") + " Use the up and down arrow keys to choose." : "No model matches. Your text is kept.") : "");
      return h("div", { className: "st-combobox" },
        h("input", {
          id: props.id, type: "text", className: "form-control form-control-sm", value: props.value, placeholder: props.placeholder, autoComplete: "off", spellCheck: false,
          role: "combobox", "aria-expanded": visible, "aria-controls": listId, "aria-autocomplete": "list", "aria-activedescendant": visible && active >= 0 ? optionId(active) : undefined,
          onChange: function (event) { props.onChange(event.target.value); setOpen(true); setActive(-1); setPicked(""); },
          onClick: function () { if (props.models.length) setOpen(true); },
          onKeyDown: keyDown,
          onBlur: function () { setOpen(false); setActive(-1); },
        }),
        visible ? h("div", { className: "st-combobox-popup" },
          h("ul", { id: listId, role: "listbox", "aria-label": "Models", className: "st-combobox-list" }, shown.map(function (model, index) {
            const facts = modelFacts(model);
            return h("li", {
              key: model.id, id: optionId(index), role: "option", "aria-selected": index === active, className: "st-combobox-option" + (index === active ? " active" : ""),
              // The box keeps the focus while the pointer chooses.
              onMouseDown: function (event) { event.preventDefault(); },
              onClick: function () { choose(model); },
            }, h("span", { className: "st-option-id" }, model.id),
              model.name ? h("span", { className: "st-option-name" }, model.name) : null,
              facts ? h("span", { className: "st-option-facts" }, facts) : null);
          })),
          result.more ? h("p", { className: "st-combobox-more" }, result.more + " more match" + (result.more === 1 ? "es" : "") + ". Keep typing to narrow the list.") : null) : null,
        h("span", { className: "st-sr-only", role: "status", "aria-live": "polite" }, status));
    }

    // ---- Shared pieces of the Run, Profiles and Providers tabs.

    function field(id, label, input, help) {
      return h("div", { className: "st-settings-field" }, h("label", { htmlFor: id }, label), input, help ? h("small", { className: "st-settings-help text-muted" }, help) : null);
    }

    // Text with `code` marked between backticks.
    function withCode(value) {
      return String(value).split("`").map(function (part, index) { return index % 2 ? h("code", { key: index }, part) : part; });
    }

    // A small form that asks before something is done: a question, an optional
    // name field (children), an error, and Confirm and Cancel.
    function ConfirmForm(props) {
      return h("form", { className: "st-profile-dialog st-dialog", "aria-label": props.label, noValidate: true, onSubmit: function (event) { event.preventDefault(); props.onConfirm(); } },
        props.children,
        props.text ? h("p", { className: "st-profile-text" }, props.text) : null,
        props.error ? h("p", { className: "tps-error st-profile-error", role: "alert" }, props.error) : null,
        h("div", { className: "st-settings-actions" },
          h("button", { type: "submit", className: "btn btn-sm st-dialog-confirm " + (props.secondary ? "btn-secondary" : "btn-primary"), disabled: !!props.busy }, props.busy ? "Working…" : props.confirmLabel),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-dialog-cancel", disabled: !!props.busy, onClick: props.onCancel }, "Cancel")));
    }

    // What a check shows: a status line, the worker's steps with a pass or fail
    // mark, and the settings it used. phase: idle, saving, asking, waiting,
    // running, done or noanswer.
    function CheckResult(props) {
      const phase = props.phase, result = props.result;
      const status = {
        saving: "Saving, then asking the worker…",
        asking: "Asking the worker…",
        waiting: "Waiting for the worker…",
        running: "The worker is running the check…",
        noanswer: "No answer from the worker. Start it with `npm run semantic -- serve`.",
      }[phase];
      const shown = phase === "done" || phase === "running" ? result : null;
      let line = status || "";
      const tooOld = phase === "done" && oldWorkerCheck(result);
      if (tooOld) line = "This worker is too old to check values that are not saved. Update it and restart it with `npm run semantic -- serve`, then check again.";
      else if (phase === "done" && result) {
        const when = new Date(result.at);
        const clock = isNaN(when.getTime()) ? "" : " (" + when.toLocaleTimeString() + ")";
        line = "Check ran " + listAge(result.at) + clock + ". " + checkSummary(result) + (result.error ? " " + result.error : "");
      }
      if (!line) return null;
      const mark = function (step) {
        return step.ok ? (step.warn ? h("span", { className: "st-probe-mark st-probe-warn" }, "! Note") : h("span", { className: "st-probe-mark st-probe-pass" }, "✓ Passed"))
          : h("span", { className: "st-probe-mark st-probe-fail" }, "✗ Failed");
      };
      return h("div", { className: "st-probe", id: props.id },
        h("p", { className: "st-probe-line" + (phase === "noanswer" || tooOld ? " tps-error" : ""), role: "status", "aria-live": "polite" }, withCode(line)),
        props.note && !tooOld ? h("p", { className: "st-probe-note" }, props.note) : null,
        shown && !tooOld && shown.steps.length ? h("ol", { className: "st-probe-steps" }, shown.steps.map(function (step, index) {
          return h("li", { key: index, className: "st-probe-step" }, mark(step), h("span", { className: "st-probe-name" }, " " + step.name + ": "), h("span", { className: "st-probe-detail" }, step.detail));
        })) : null,
        shown && !tooOld && shown.settings.length ? h("dl", { className: "st-probe-settings", "aria-label": "Settings the worker used" }, shown.settings.map(function (entry, index) {
          return [h("dt", { key: "t" + index }, entry.name), h("dd", { key: "d" + index }, entry.value + (entry.source ? " (" + entry.source + ")" : ""))];
        })) : null);
    }

    // The state of a check this editor asked for: the request it sent and what
    // the worker has answered. Returns [phase, result, start(request)].
    function useCheck(c, busyPhase) {
      const sentPair = React.useState(null), sent = sentPair[0], setSent = sentPair[1];
      const tickPair = React.useState(0), setTick = tickPair[1];
      React.useEffect(function () {
        if (!sent) return undefined;
        const timer = setTimeout(function () { setTick(function (n) { return n + 1; }); }, Math.max(0, CHECK_WAIT_MS - (Date.now() - sent.startedAt)) + 50);
        return function () { clearTimeout(timer); };
      }, [sent && sent.id]);
      const progress = sent ? checkPhase(c.worker, sent, Date.now()) : { phase: "idle", result: null };
      return {
        phase: busyPhase || progress.phase, result: progress.result, note: sent && sent.note || "",
        start: function (id, note) { setSent({ id: id, startedAt: Date.now(), note: note || "" }); }, clear: function () { setSent(null); },
      };
    }

    // The six optional settings, as a provider's defaults (mode "defaults") or a
    // profile's overrides (mode "overrides"). With overrides, a setting the
    // profile leaves alone shows the provider's default marked "(default)".
    function SettingFields(props) {
      const values = props.values, prefix = props.prefix, defaults = props.defaults || {}, overrides = props.mode === "overrides";
      const openrouter = props.kind === "openrouter";
      const worker = "Worker’s default";
      const change = function (key) { return function (event) { props.onChange(key, event.target.value); }; };
      const number = function (key, label, id, extra, help, placeholder) {
        const known = overrides && defaults[key] != null;
        // The decision model's thresholds have built-in defaults the page knows; the others only the worker does.
        const builtin = overrides && (key === "verifyKeep" || key === "verifyHigh") ? BUILTIN[key] + " (default)" : null;
        return field(prefix + "-" + id, label, h("input", Object.assign({
          id: prefix + "-" + id, type: "number", className: "form-control form-control-sm st-settings-budget", value: values[key], inputMode: "numeric",
          placeholder: known ? defaults[key] + " (default)" : builtin || (overrides ? worker : placeholder), onChange: change(key),
        }, extra)), help);
      };
      const tri = function (key, label, id, help) {
        const known = overrides && typeof defaults[key] === "boolean";
        return field(prefix + "-" + id, label, h("select", { id: prefix + "-" + id, className: "form-control form-control-sm st-settings-budget st-" + id, value: values[key], onChange: change(key) },
          h("option", { value: "" }, known ? "Default: " + (defaults[key] ? "on" : "off") : overrides ? "Default (worker’s setting)" : "Not set"),
          h("option", { value: "on" }, "On"), h("option", { value: "off" }, "Off")), help);
      };
      const routingDefault = overrides && defaults.routing ? JSON.stringify(defaults.routing) : "";
      const replyKnown = overrides && replyFormatOf(defaults.responseFormat) ? REPLY_FORMATS.find(function (entry) { return entry.value === defaults.responseFormat; }) : null;
      // The verify pass is off, the same model, or a decision model; the decision
      // model's own settings show while it is in effect.
      const verifyKnown = overrides && defaults.verify != null;
      const verifyChoice = VERIFY_CHOICES.find(function (choice) { return choice.value === (defaults.verify === true ? "on" : defaults.verify === false ? "off" : defaults.verify); });
      const decisions = decisionsOn(values, overrides ? defaults : null);
      const choices = props.providers || [];
      const providerDefault = overrides && defaults.verifyProvider ? choices.find(function (choice) { return choice.id === defaults.verifyProvider; }) : null;
      const verifyField = field(prefix + "-verify", "Verify pass", h("select", { id: prefix + "-verify", className: "form-control form-control-sm st-settings-budget st-verify", value: values.verify, onChange: change("verify") },
        h("option", { value: "" }, verifyKnown && verifyChoice ? "Default: " + verifyChoice.label : overrides ? "Default (worker’s setting)" : "Not set"),
        VERIFY_CHOICES.map(function (choice) { return h("option", { key: choice.value, value: choice.value }, choice.label); })),
        "Asks a second question about each proposal. Same model: the chat model answers yes or no, which costs one request per proposal. Decisions model: a decision model on OpenRouter gives each proposal a probability, one request per scene.");
      const decisionFields = decisions ? h("div", { className: "st-decisions" },
        field(prefix + "-verifyprovider", "Verify provider", h("select", { id: prefix + "-verifyprovider", className: "form-control form-control-sm st-settings-budget st-verifyprovider", value: values.verifyProvider, onChange: change("verifyProvider") },
          h("option", { value: "" }, providerDefault ? "Default: " + providerDefault.name : overrides ? "Same as the profile’s provider (default)" : "Same as the profile’s provider"),
          choices.map(function (choice) { return h("option", { key: choice.id, value: choice.id }, choice.name); })),
          "The decisions model works only through an OpenRouter provider. Scene text, with the tag definitions it is asked about, goes to it; the key of that provider is used, and data collection is always denied."),
        field(prefix + "-verifymodel", "Verify model", h("input", {
          id: prefix + "-verifymodel", type: "text", className: "form-control form-control-sm st-settings-budget st-verifymodel", value: values.verifyModel, autoComplete: "off", spellCheck: false,
          placeholder: (overrides && defaults.verifyModel ? defaults.verifyModel : DECISIONS_MODEL) + (overrides ? " (default)" : ""), onChange: change("verifyModel"),
        }), "Keep the model id pinned: the thresholds below are tuned to a version, and a newer one can answer differently."),
        number("verifyKeep", "Keep at or above", "verifykeep", { min: "0.01", max: "1", step: "0.01", inputMode: "decimal" },
          "Proposals the decision model rates below this probability are not shown. From here up they are shown with medium confidence. Applied when the worker publishes, so changing it needs no new analysis.", "0.7"),
        number("verifyHigh", "High at or above", "verifyhigh", { min: "0.01", max: "1", step: "0.01", inputMode: "decimal" },
          "From this probability up a proposal is shown with high confidence.", "0.9")) : null;
      return h(React.Fragment, null,
        number("dailyBudget", "Daily spending limit (credits)", "budget", { min: "0", step: "0.01", inputMode: "decimal" },
          "The worker stops for the day, by UTC date, when the day’s requests reach it. One total across all providers. It works only with servers that report cost, such as OpenRouter.", "No limit"),
        tri("thinking", "Thinking", "thinking", "Lets the model reason before it answers: finds more, slower, costs more."),
        verifyField,
        decisionFields,
        number("concurrency", "Parallel requests", "concurrency", { min: "1", max: String(MAX_CONCURRENCY), step: "1" },
          "How many scenes the worker sends at once, 1 to " + MAX_CONCURRENCY + ". Match your server’s slots.", "Worker’s default"),
        field(prefix + "-replyformat", "Reply format", h("select", { id: prefix + "-replyformat", className: "form-control form-control-sm st-settings-budget st-replyformat", value: values.responseFormat || "", onChange: change("responseFormat") },
          h("option", { value: "" }, replyKnown ? "Default: " + replyKnown.label : overrides ? "Default (worker’s setting)" : "Not set"),
          REPLY_FORMATS.map(function (entry) { return h("option", { key: entry.value, value: entry.value }, entry.label); })),
          "How the model is asked to reply. “Enforced by the server” sends a JSON schema, which most servers follow. “JSON mode” asks for any JSON object. “Described in the prompt only” sends no reply format and explains the shape in the prompt; choose it when a server ignores the reply format and answers in prose, which shows as “reply is not JSON”."),
        openrouter ? field(prefix + "-routing", "Provider routing", h("textarea", {
          id: prefix + "-routing", className: "form-control form-control-sm st-settings-routing", rows: 2, value: values.routing, spellCheck: false, autoComplete: "off",
          placeholder: routingDefault ? routingDefault + " (default)" : overrides ? worker : "{\"only\": [\"River\", \"Morph\"]}", onChange: change("routing"),
        }), "Optional, a JSON object for OpenRouter’s provider field. Routing to a few providers makes answers more repeatable.") : null,
        openrouter ? h("div", { className: "st-zdr" },
          tri("zdr", "Zero data retention only", "zdr", null),
          h("p", { id: prefix + "-zdr-help", className: "st-settings-help text-muted" }, "OpenRouter then routes only to providers that keep no prompts or replies. This is stricter than the data-collection filter the worker always sends. If no provider of the model qualifies, requests fail instead of falling back.")) : null);
    }

    // ---- The page's shared state: both settings maps, the request queue, and
    // the worker's answers.

    function migrationNotice(settings) {
      const providers = settings.providers.length, profiles = settings.profiles.length;
      return "Your model settings from earlier versions moved to the new Providers and Profiles tabs: " + providers + " provider" + (providers === 1 ? "" : "s")
        + " and " + profiles + " profile" + (profiles === 1 ? "" : "s") + ". Nothing was lost; check them there.";
    }

    function useConsole() {
      const pair = React.useState({ status: "loading", error: "", map: {}, worker: parseWorker({}), notice: "", sent: null, tick: 0 });
      const state = pair[0], setState = pair[1];
      const latest = React.useRef(state);
      latest.current = state;
      const mounted = React.useRef(true);
      React.useEffect(function () { mounted.current = true; return function () { mounted.current = false; }; }, []);
      function merge(patch) {
        if (!mounted.current) return;
        setState(function (previous) {
          const change = typeof patch === "function" ? patch(previous) : patch;
          return change ? Object.assign({}, previous, change) : previous;
        });
      }

      // On open: migrate old settings if needed and ask the worker for its status,
      // in one write.
      React.useEffect(function () {
        let live = true;
        readMaps(transport).then(function (maps) {
          const worker = parseWorker(maps.worker);
          const legacy = needsMigration(maps.page) && hasLegacySettings(maps.page);
          const request = makeRequest("status", {});
          return enqueueRequest(transport, request, worker.answered).then(function (saved) {
            if (live) merge({ status: "ready", map: saved, worker: worker, sent: { id: request.id, at: Date.parse(request.at) }, notice: legacy ? migrationNotice(settingsOf(saved)) : "" });
          }, function (error) {
            if (live) merge({ status: "ready", map: maps.page, worker: worker, error: "Couldn’t save to Stash: " + error.message });
          });
        }, function (error) { if (live) merge({ status: "error", error: error.message }); });
        return function () { live = false; };
      }, []);

      const settings = React.useMemo(function () { return settingsOf(migrateSettings(state.map)); }, [state.map]);
      const polling = state.status === "ready" && needsPolling(settings.requests, state.worker, Date.now());

      // Reads the maps and keeps what the worker says; drops the requests it has answered.
      function readWorkerOnce() {
        return readMaps(transport).then(function (maps) {
          const worker = parseWorker(maps.worker);
          merge(function (previous) { return stable(previous.worker) === stable(worker) ? null : { worker: worker }; });
          const requests = parseRequests(maps.page[REQUESTS_KEY]);
          if (pruneRequests(requests, worker.answered).length === requests.length) return null;
          return updateSettings(transport, function (map) { return dropRequests(map, worker.answered); }).then(function (saved) { merge({ map: saved }); });
        });
      }

      // Reads the worker's map every few seconds, only while something is
      // waiting for it, and drops the requests it has answered.
      React.useEffect(function () {
        if (!polling) return undefined;
        let live = true, timer = null;
        function schedule() {
          const current = latest.current;
          timer = setTimeout(function () {
            readWorkerOnce().catch(function () {}).then(function () { if (live) schedule(); });
          }, pollDelay(settingsOf(current.map).requests, current.worker, Date.now()));
        }
        schedule();
        return function () { live = false; clearTimeout(timer); };
      }, [polling]);

      // The outbox pump reads both maps while answers wait; the page follows what it read
      // (the worker's acknowledgements and counts, and the requests it queued).
      React.useEffect(function () {
        const listener = function () {
          const worker = outboxState.worker, maps = outboxState.maps;
          if (!worker || !maps) return;
          merge(function (previous) {
            const change = {};
            if (stable(previous.worker) !== stable(worker)) change.worker = worker;
            if (stable(previous.map) !== stable(maps.page)) change.map = maps.page;
            return Object.keys(change).length ? change : null;
          });
        };
        outboxListeners.push(listener);
        return function () { const index = outboxListeners.indexOf(listener); if (index !== -1) outboxListeners.splice(index, 1); };
      }, []);

      // The status line turns from "looking" to "has not answered" by itself.
      React.useEffect(function () {
        if (!state.sent) return undefined;
        const timer = setTimeout(function () { merge(function (previous) { return { tick: previous.tick + 1 }; }); }, Math.max(0, CONNECT_WAIT_MS - (Date.now() - state.sent.at)) + 50);
        return function () { clearTimeout(timer); };
      }, [state.sent && state.sent.id]);

      return {
        status: state.status, error: state.error, notice: state.notice, map: state.map, settings: settings, worker: state.worker, sent: state.sent,
        connection: workerConnection(state.worker, state.sent, Date.now()),
        answersOnly: !!(state.worker.status && state.worker.status.answersOnly),
        // Reads the worker's map again (counts, queues, figures).
        reload: function () { return readWorkerOnce(); },
        dismissNotice: function () { merge({ notice: "" }); },
        clearError: function () { merge({ error: "" }); },
        // A read-modify-write of this page's map; resolves with the stored map.
        update: function (build) {
          return updateSettings(transport, build).then(function (saved) { merge({ map: saved }); return saved; });
        },
        // Removes one request from the queue by id, at once (a draft check carries a typed key).
        dropRequest: function (id) {
          if (!settingsOf(latest.current.map).requests.some(function (entry) { return entry.id === id; })) return Promise.resolve();
          return updateSettings(transport, function (map) { return removeRequest(map, id); }).then(function (saved) { merge({ map: saved }); });
        },
        // Adds a request to the queue; resolves with it.
        enqueue: function (request) {
          return enqueueRequest(transport, request, latest.current.worker.answered).then(function (saved) {
            merge(Object.assign({ map: saved }, request.kind === "status" ? { sent: { id: request.id, at: Date.parse(request.at) } } : {}));
            return request;
          });
        },
      };
    }

    // "Worker connected (version 0.5.0, answered 4 seconds ago)", or why not,
    // and the running job.
    function WorkerStatus(props) {
      const c = props.console;
      const tickPair = React.useState(0), setTick = tickPair[1];
      React.useEffect(function () {
        const timer = setInterval(function () { setTick(function (n) { return n + 1; }); }, 10000);
        return function () { clearInterval(timer); };
      }, []);
      const job = c.worker.jobs.find(function (entry) { return entry.state === "running"; });
      const status = c.worker.status;
      return h("div", { className: "st-worker", "data-state": c.status === "loading" ? "loading" : c.connection.state },
        h("p", { className: "st-worker-line" + (c.connection.state === "silent" || c.connection.state === "mismatch" ? " st-worker-bad" : ""), role: "status", "aria-live": "polite" },
          c.status === "loading" ? "Looking for the worker…" : withCode(c.connection.text)),
        c.status === "ready" && (c.connection.state === "silent" || c.connection.state === "mismatch")
          ? h("button", { type: "button", className: "btn btn-secondary btn-sm st-worker-again", onClick: function () { c.enqueue(makeRequest("status", {})).catch(function () {}); } }, "Ask again") : null,
        job ? h("p", { className: "st-worker-job" }, (job.type === "eval" ? "Evaluating with “" : "Running “") + (job.profile.name || job.profile.id) + "”: " + jobProgress(job) + ".") : null,
        c.connection.state === "connected" && c.answersOnly ? h("p", { className: "st-worker-line st-answers-only" }, "This worker only records answers: it does not analyse, publish or evaluate.") : null,
        c.connection.state === "connected" && status && status.llmError ? h("p", { className: "st-worker-line tps-error" }, "The worker’s set-up has a problem: " + status.llmError) : null,
        c.error ? h("p", { className: "tps-error st-worker-error", role: "alert" }, c.error) : null,
        c.notice ? h("p", { className: "st-notice", role: "status" }, c.notice, " ",
          h("button", { type: "button", className: "btn btn-link btn-sm st-notice-dismiss", onClick: c.dismissNotice }, "Dismiss")) : null);
    }

    // ---- Providers tab

    function ProviderEditor(props) {
      const c = props.console, s = c.settings, saved = props.saved;
      const configProvider = c.worker.status && c.worker.status.configProvider;
      const formPair = React.useState(function () { return providerForm(saved); }), form = formPair[0], setForm = formPair[1];
      const showPair = React.useState(false), showKey = showPair[0], setShowKey = showPair[1];
      const replacePair = React.useState(false), replacing = replacePair[0], setReplacing = replacePair[1];
      const messagePair = React.useState(null), message = messagePair[0], setMessage = messagePair[1];
      const dialogPair = React.useState(null), dialog = dialogPair[0], setDialog = dialogPair[1];
      const busyPair = React.useState(""), busy = busyPair[0], setBusy = busyPair[1];
      const check = useCheck(c, busy === "check" ? "asking" : "");
      const used = saved ? profilesUsing(s.profiles, saved.id).length : 0;
      const url = formAddress(form);
      const local = !url || isLocalAddress(url, s.networks);
      const addressChanged = !!(saved && saved.apiKey && !form.newKey.trim() && addressKey(saved.url) !== addressKey(url) && !form.removeKey);

      // The check of the form is independent of saving. Its request carries the form's values, maybe a typed
      // key, so it is taken out of the queue as soon as it is answered, when it times out, when the form
      // changes and when the editor closes.
      const draftRequest = React.useRef(null), checkToken = React.useRef(0), consoleRef = React.useRef(c);
      consoleRef.current = c;
      function dropDraft() {
        const id = draftRequest.current;
        if (!id) return;
        draftRequest.current = null;
        consoleRef.current.dropRequest(id).catch(function () {});
      }
      function forgetCheck() { checkToken.current += 1; check.clear(); dropDraft(); }
      React.useEffect(function () { return function () { checkToken.current += 1; dropDraft(); }; }, []);
      React.useEffect(function () { if (check.phase === "done" || check.phase === "noanswer") dropDraft(); }, [check.phase]);

      function set(key, value) { setMessage(null); forgetCheck(); setForm(function (previous) { const next = Object.assign({}, previous); next[key] = value; return next; }); }
      function setDefault(key, value) {
        setMessage(null);
        forgetCheck();
        setForm(function (previous) { return Object.assign({}, previous, { defaults: Object.assign({}, previous.defaults, { [key]: value }) }); });
      }
      function fail(error) { setBusy(""); setDialog(function (previous) { return previous ? Object.assign({}, previous, { error: error.message }) : previous; }); setMessage({ kind: "error", text: error.message }); }

      // Checks the form's values as they are: never saves, never changes the form.
      function checkForm() {
        const problem = providerAddressError(form);
        if (problem) { setMessage({ kind: "error", text: problem }); return; }
        setMessage(null);
        forgetCheck();
        const token = checkToken.current;
        const request = makeRequest("check", { draft: providerCheckDraft(form, saved, s.networks) });
        const note = checkedNote(form, saved, s.networks);
        draftRequest.current = request.id;
        setBusy("check");
        c.enqueue(request).then(function () {
          setBusy("");
          if (checkToken.current === token) check.start(request.id, note);
        }, function (error) {
          if (draftRequest.current === request.id) draftRequest.current = null;
          fail(error);
        });
      }
      // Saves the form: "update" overwrites the provider being edited, "new" adds one.
      function commit(mode, name) {
        setBusy("save");
        setMessage(null);
        let edited, newId = "";
        try {
          edited = providerFromForm(form, saved, s.networks);
          if (mode === "new") edited = Object.assign({}, edited, { id: "", name: name == null ? edited.name : name });
        } catch (error) { fail(error); return; }
        c.update(function (current) {
          const result = saveProviderInput(current, edited, mode);
          newId = result.id;
          return result.map;
        }).then(function (map) {
          setBusy("");
          setDialog(null);
          setReplacing(false);
          const stored = parseProviders(map[PROVIDERS_KEY]).find(function (entry) { return entry.id === newId; });
          setForm(providerForm(stored));
          setMessage({ kind: "saved", text: mode === "new" && saved ? "Saved as a new provider “" + stored.name + "”." : "Saved." });
          forgetCheck();
          props.onSaved(newId);
        }, fail);
      }
      // Validates, then decides: save at once, ask about overwriting, or nothing to do.
      function decide() {
        const problem = providerFormError(form, s.networks, s.providers, form.id, configProvider);
        if (problem) { setMessage({ kind: "error", text: problem }); return; }
        let edited;
        try { edited = providerFromForm(form, saved, s.networks); } catch (error) { setMessage({ kind: "error", text: error.message }); return; }
        const choice = saveChoice("provider", saved, edited, used);
        if (choice.action === "unchanged") setMessage({ kind: "info", text: "Nothing has changed." });
        else if (choice.action === "create") commit("new", edited.name);
        else setDialog({ kind: "overwrite", text: choice.message, error: "" });
      }
      function submitDialog() {
        if (!dialog || busy) return;
        if (dialog.kind === "overwrite") commit("update", null);
        else if (dialog.kind === "asnew") {
          const problem = nameError("provider", dialog.name, s.providers);
          if (problem) { setDialog(Object.assign({}, dialog, { error: problem })); return; }
          const invalid = providerFormError(Object.assign({}, form, { name: dialog.name }), s.networks, s.providers, "", configProvider);
          if (invalid) { setDialog(Object.assign({}, dialog, { error: invalid })); return; }
          commit("new", dialog.name.trim());
        } else if (dialog.kind === "delete") {
          setBusy("delete");
          c.update(function (current) { return deleteProviderInput(current, saved.id); }).then(function () { setBusy(""); props.onClose("Deleted provider “" + saved.name + "”."); }, fail);
        }
      }

      let dialogView = null;
      if (dialog && dialog.kind === "overwrite") {
        dialogView = h(ConfirmForm, { label: "Overwrite provider", text: dialog.text, error: dialog.error, busy: busy === "save", confirmLabel: "Overwrite", onConfirm: submitDialog, onCancel: function () { setDialog(null); } });
      } else if (dialog && dialog.kind === "asnew") {
        dialogView = h(ConfirmForm, { label: "Save as new provider", error: dialog.error, busy: busy === "save", confirmLabel: "Save as new", onConfirm: submitDialog, onCancel: function () { setDialog(null); } },
          field("st-provider-newname", "Name of the new provider", h("input", {
            id: "st-provider-newname", type: "text", className: "form-control form-control-sm", value: dialog.name, maxLength: MAX_PROFILE_NAME, autoComplete: "off", autoFocus: true,
            onChange: function (event) { setDialog(Object.assign({}, dialog, { name: event.target.value, error: "" })); },
          }), "The current form is saved under this name; the provider you are editing stays as it was."));
      } else if (dialog && dialog.kind === "delete") {
        dialogView = h(ConfirmForm, { label: "Delete provider", text: "Delete provider “" + saved.name + "”? Its saved key goes with it.", error: dialog.error, busy: busy === "delete", secondary: true, confirmLabel: "Delete provider", onConfirm: submitDialog, onCancel: function () { setDialog(null); } });
      }

      let addressField;
      if (form.kind === "openrouter") addressField = h("p", { className: "st-settings-help text-muted" }, "Address: " + OPENROUTER_URL);
      else addressField = field("st-provider-url", "Address", h("input", {
        id: "st-provider-url", type: "url", className: "form-control form-control-sm", value: form.url, placeholder: "http://192.168.1.20:8000/v1",
        autoComplete: "off", spellCheck: false, onChange: function (event) { set("url", event.target.value); },
      }), "The server’s OpenAI-compatible address, ending in /v1: oMLX, LM Studio, llama.cpp, vLLM or a hosted API.");

      // A saved key is never put into the page: only that one is saved.
      let keyField;
      if (form.keySaved && !replacing && !form.removeKey) {
        keyField = field("st-provider-key-saved", "API key", h("div", { className: "st-settings-inline st-key-saved" },
          h("span", { className: "st-key-state", id: "st-provider-key-saved" }, "Key saved"),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-key-replace", onClick: function () { setReplacing(true); } }, "Replace"),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-key-remove", onClick: function () { set("removeKey", true); } }, "Remove key")),
        "Stored in Stash’s configuration file in plain text, like other plugin settings; anyone signed in to Stash can read it. It is sent only to this address.");
      } else if (form.removeKey) {
        keyField = field("st-provider-key-saved", "API key", h("div", { className: "st-settings-inline st-key-saved" },
          h("span", { className: "st-key-state", id: "st-provider-key-saved" }, "The saved key is removed when you save."),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-key-keep", onClick: function () { set("removeKey", false); } }, "Keep it")));
      } else {
        keyField = field("st-provider-key", "API key", h("div", { className: "st-settings-inline" },
          h("input", {
            id: "st-provider-key", type: showKey ? "text" : "password", className: "form-control form-control-sm", value: form.newKey, autoComplete: "off", spellCheck: false,
            placeholder: form.kind === "openrouter" ? "sk-or-…" : "Optional", onChange: function (event) { set("newKey", event.target.value); },
          }),
          h("button", { type: "button", className: "btn btn-secondary btn-sm", "aria-pressed": showKey, onClick: function () { setShowKey(!showKey); } }, showKey ? "Hide" : "Show"),
          replacing ? h("button", { type: "button", className: "btn btn-secondary btn-sm st-key-keep", onClick: function () { setReplacing(false); set("newKey", ""); } }, "Keep the saved key") : null),
        "Stored in Stash’s configuration file in plain text, like other plugin settings; anyone signed in to Stash can read it. It is sent only to this address. Every profile on this provider uses it.");
      }

      const working = !!busy || check.phase === "saving" || check.phase === "asking";
      return h("section", { className: "st-editor", "aria-labelledby": "st-provider-title", "data-provider": saved ? saved.id : "new" },
        h("h4", { id: "st-provider-title" }, saved ? "Provider “" + saved.name + "”" : "New provider"),
        h("form", { noValidate: true, onSubmit: function (event) { event.preventDefault(); decide(); } },
          field("st-provider-name", "Name", h("input", { id: "st-provider-name", type: "text", className: "form-control form-control-sm", value: form.name, maxLength: MAX_PROFILE_NAME, autoComplete: "off", onChange: function (event) { set("name", event.target.value); } })),
          field("st-provider-kind", "Kind", h("select", {
            id: "st-provider-kind", className: "form-control form-control-sm", value: form.kind,
            onChange: function (event) { setMessage(null); forgetCheck(); setForm(function (previous) { return Object.assign({}, previous, { kind: event.target.value, url: event.target.value === "compatible" && previous.kind !== "compatible" ? "" : previous.url }); }); },
          }, h("option", { value: "openrouter" }, "OpenRouter"), h("option", { value: "compatible" }, "OpenAI-compatible server (local or hosted)"))),
          addressField,
          addressChanged ? h("p", { className: "st-settings-help st-key-warning", role: "status" }, "The saved key was entered for the old address, so saving removes it. Type the key for the new address if it needs one.") : null,
          keyField,
          url && !local ? h("label", { className: "st-check st-consent" },
            h("input", { id: "st-provider-consent", type: "checkbox", checked: !!form.allowHosted, onChange: function (event) { set("allowHosted", event.target.checked); } }),
            " Send scene text to " + (hostOf(url) || url) + ". Titles, descriptions, file and folder names, and performer and studio names leave your network.") : null,
          h("fieldset", { className: "st-defaults" },
            h("legend", null, "Defaults for its profiles (optional)"),
            h("p", { className: "st-settings-help text-muted" }, "A profile on this provider uses these unless it sets its own."),
            h(SettingFields, { prefix: "st-provider", mode: "defaults", values: form.defaults, kind: form.kind, providers: s.providers.filter(function (entry) { return !saved || entry.id !== saved.id; }).map(function (entry) { return { id: entry.id, name: entry.name }; }).concat(configProvider ? [{ id: CONFIG_PROVIDER, name: "Worker config file" }] : []), onChange: setDefault })),
          h("div", { className: "st-settings-actions" },
            h("button", { type: "submit", className: "btn btn-primary btn-sm st-save", disabled: working }, busy === "save" ? "Saving…" : "Save"),
            saved ? h("button", { type: "button", className: "btn btn-secondary btn-sm st-save-new", disabled: working, onClick: function () { setDialog({ kind: "asnew", name: "", error: "" }); } }, "Save as new…") : null,
            h("button", { type: "button", id: "st-provider-check", className: "btn btn-secondary btn-sm st-check-button", disabled: working || c.connection.state !== "connected", title: c.connection.state === "connected" ? undefined : "The worker has not answered", onClick: checkForm }, "Check connection"),
            h("button", { type: "button", className: "btn btn-secondary btn-sm st-close", onClick: function () { props.onClose(""); } }, "Cancel"),
            saved ? h("button", { type: "button", className: "btn btn-secondary btn-sm st-delete", disabled: working || used > 0, onClick: function () { setDialog({ kind: "delete", error: "" }); } }, "Delete") : null),
          saved && used ? h("p", { className: "st-settings-help text-muted st-delete-note" }, used + " profile" + (used === 1 ? " uses" : "s use") + " this provider. Delete or change " + (used === 1 ? "it" : "them") + " first.") : null),
        dialogView,
        h("p", { className: "st-settings-message" + (message && message.kind === "error" ? " tps-error" : ""), role: "status", "aria-live": "polite" }, message ? message.text : ""),
        h(CheckResult, { id: "st-provider-check-result", phase: check.phase, result: check.result, note: check.note }));
    }

    function ProvidersTab(props) {
      const c = props.console, s = c.settings;
      const editPair = React.useState(null), editing = editPair[0], setEditing = editPair[1];
      const messagePair = React.useState(""), message = messagePair[0], setMessage = messagePair[1];
      const netPair = React.useState(null), networkText = netPair[0], setNetworkText = netPair[1];
      const netMessagePair = React.useState(null), netMessage = netMessagePair[0], setNetMessage = netMessagePair[1];
      const countPair = React.useState(0), counter = countPair[0], setCounter = countPair[1];
      const configProvider = c.worker.status && c.worker.status.configProvider;
      const configCheck = useCheck(c, "");
      if (c.status === "loading") return h("section", { className: "st-settings" }, h("p", { className: "tps-status text-muted", role: "status" }, "Loading settings…"));
      const selected = editing && editing.id ? s.providers.find(function (entry) { return entry.id === editing.id; }) || null : null;
      const networks = networkText == null ? s.networks : networkText;

      function saveNetworks(event) {
        event.preventDefault();
        setNetMessage(null);
        c.update(function (current) { return setNetworksInput(current, networks); }).then(function () { setNetworkText(null); setNetMessage({ kind: "saved", text: "Saved." }); }, function (error) { setNetMessage({ kind: "error", text: error.message }); });
      }
      function askConfigCheck() {
        c.enqueue(makeRequest("check", { provider: CONFIG_PROVIDER })).then(function (request) { configCheck.start(request.id); }, function (error) { setMessage(error.message); });
      }
      const row = function (provider) {
        const count = profilesUsing(s.profiles, provider.id).length;
        const host = hostOf(provider.url) || provider.url;
        return h("li", { key: provider.id, className: "st-entry", "data-provider": provider.id },
          h("div", { className: "st-entry-main" },
            h("strong", { className: "st-entry-name" }, provider.name),
            h("span", { className: "st-entry-detail text-muted" }, provider.url),
            h("span", { className: "st-entry-detail text-muted" }, (provider.apiKey ? "Key saved" : "No key") + " · " + count + " profile" + (count === 1 ? "" : "s") + (host && !isLocalAddress(provider.url, s.networks) ? " · outside your network" : ""))),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-entry-edit", "aria-label": "Edit provider " + provider.name, "aria-expanded": !!(editing && editing.id === provider.id), onClick: function () { setMessage(""); setEditing({ id: provider.id, key: provider.id + counter }); } }, "Edit"));
      };
      return h("section", { className: "st-settings st-providers", "aria-labelledby": "st-providers-title" },
        h("h3", { id: "st-providers-title" }, "Providers"),
        h("p", { className: "st-settings-help text-muted" }, "A provider is a server: its address, API key, consent to send scene text outside your network, and optional defaults. A profile on the Profiles tab picks a provider and a model."),
        message ? h("p", { className: "st-profile-message", role: "status", "aria-live": "polite" }, message) : null,
        h("ul", { className: "st-entries" },
          configProvider ? h("li", { className: "st-entry st-entry-config", "data-provider": CONFIG_PROVIDER },
            h("div", { className: "st-entry-main" },
              h("strong", { className: "st-entry-name" }, "Worker config file"),
              h("span", { className: "st-entry-detail text-muted" }, configProvider.url + (configProvider.model ? " · model " + configProvider.model : "")),
              h("span", { className: "st-entry-detail text-muted" }, "Read-only · its key stays in the worker’s secrets.env · " + profilesUsing(s.profiles, CONFIG_PROVIDER).length + " profile" + (profilesUsing(s.profiles, CONFIG_PROVIDER).length === 1 ? "" : "s"))),
            h("button", { type: "button", className: "btn btn-secondary btn-sm st-entry-check", "aria-label": "Check the worker config file server", disabled: c.connection.state !== "connected", onClick: askConfigCheck }, "Check connection")) : null,
          s.providers.map(row)),
        configProvider ? h(CheckResult, { id: "st-config-check-result", phase: configCheck.phase, result: configCheck.result }) : null,
        !s.providers.length && !configProvider ? h("p", { className: "tps-empty text-muted" }, "No providers yet.") : null,
        h("div", { className: "st-settings-actions st-entries-actions" },
          h("button", { type: "button", className: "btn btn-primary btn-sm st-add", disabled: s.providers.length >= MAX_PROVIDERS, onClick: function () { setMessage(""); setCounter(counter + 1); setEditing({ id: "", key: "new" + counter }); } }, "Add provider")),
        editing && (!editing.id || selected)
          ? h(ProviderEditor, {
            key: editing.key, console: c, saved: selected,
            onSaved: function (id) { setEditing({ id: id, key: editing.key }); },
            onClose: function (text) { setEditing(null); setMessage(text || ""); },
          }) : null,
        h("form", { className: "st-networks", onSubmit: saveNetworks, noValidate: true },
          field("st-networks", "My network also uses", h("input", {
            id: "st-networks", type: "text", className: "form-control form-control-sm", value: networks, placeholder: "9.9.9.0/24", autoComplete: "off", spellCheck: false,
            onChange: function (event) { setNetMessage(null); setNetworkText(event.target.value); },
          }), "Only if your home network uses addresses outside the usual private ranges: list them as ranges or addresses, separated by commas, and the worker treats them as local. Applies to every provider."),
          h("div", { className: "st-settings-actions" }, h("button", { type: "submit", className: "btn btn-secondary btn-sm st-networks-save", disabled: networkText == null || networkText.trim() === s.networks }, "Save network ranges")),
          h("p", { className: "st-settings-message" + (netMessage && netMessage.kind === "error" ? " tps-error" : ""), role: "status", "aria-live": "polite" }, netMessage ? netMessage.text : "")));
    }

    // ---- Profiles tab

    function ProfileEditor(props) {
      const c = props.console, s = c.settings, saved = props.saved, worker = c.worker;
      const configProvider = worker.status && worker.status.configProvider;
      const formPair = React.useState(function () { return profileForm(saved || { id: "", name: "", provider: props.defaultProvider, model: "", overrides: {} }); }), form = formPair[0], setForm = formPair[1];
      const messagePair = React.useState(null), message = messagePair[0], setMessage = messagePair[1];
      const dialogPair = React.useState(null), dialog = dialogPair[0], setDialog = dialogPair[1];
      const busyPair = React.useState(""), busy = busyPair[0], setBusy = busyPair[1];
      const structuredPair = React.useState(true), structured = structuredPair[0], setStructured = structuredPair[1];
      const refreshPair = React.useState(0), refresh = refreshPair[0], setRefresh = refreshPair[1];
      const browserPair = React.useState({ status: "idle", models: [], at: 0, error: "" }), browser = browserPair[0], setBrowser = browserPair[1];
      const check = useCheck(c, busy === "check" ? "asking" : "");
      const force = React.useRef(false);
      const forceBrowser = React.useRef(false);
      const asked = React.useRef({});
      const providerId = form.provider;
      const provider = s.providers.find(function (entry) { return entry.id === providerId; }) || null;
      const kind = kindOfProvider(providerId, s.providers, configProvider);
      const defaults = provider ? provider.defaults : {};
      const entry = providerId ? worker.modelLists[providerId] || null : null;
      const workerModels = entry ? entry.models : [];
      const fallback = kind === "openrouter" && workerModels.length === 0;
      const connected = c.connection.state === "connected";
      const waiting = !!providerId && pendingRequests(s.requests, worker.answered).some(function (request) { return request.kind === "models" && request.provider === providerId; });

      // The worker lists a provider's models; ask when there is no list or it is older than ten minutes.
      React.useEffect(function () {
        if (!providerId || !connected || (providerId === CONFIG_PROVIDER && !configProvider)) return;
        const key = providerId + ":" + refresh;
        if (asked.current[key]) return;
        if (!force.current && entry && !listIsStale(entry)) return;
        asked.current[key] = true;
        force.current = false;
        c.enqueue(makeRequest("models", { provider: providerId })).catch(function () {});
      }, [providerId, connected, refresh, entry && entry.at]);

      // OpenRouter's public list stands in until the worker has listed models: the
      // browser may fetch it (no key, cookie or referrer), and keeps it for an hour.
      React.useEffect(function () {
        if (!fallback) return undefined;
        const which = structured ? "structured" : "all";
        const cached = openrouterCache[which];
        const refetch = forceBrowser.current;
        forceBrowser.current = false;
        if (cached && Date.now() - cached.at < OPENROUTER_LIST_FRESH_MS && !refetch) {
          setBrowser({ status: "ready", models: cached.models, at: cached.at, error: "" });
          return undefined;
        }
        let live = true;
        setBrowser(function (previous) { return { status: "loading", models: previous.models, at: 0, error: "" }; });
        loadModels(null, structured).then(function (models) {
          openrouterCache[which] = { at: Date.now(), models: models };
          if (live) setBrowser({ status: "ready", models: models, at: Date.now(), error: "" });
        }, function (error) { if (live) setBrowser({ status: "error", models: [], at: 0, error: error.message }); });
        return function () { live = false; };
      }, [fallback, structured, refresh]);

      function set(key, value) { setMessage(null); setForm(function (previous) { const next = Object.assign({}, previous); next[key] = value; return next; }); }
      function setOverride(key, value) {
        setMessage(null);
        setForm(function (previous) { return Object.assign({}, previous, { overrides: Object.assign({}, previous.overrides, { [key]: value }) }); });
      }
      function fail(error) { setBusy(""); setDialog(function (previous) { return previous ? Object.assign({}, previous, { error: error.message }) : previous; }); setMessage({ kind: "error", text: error.message }); }
      function refreshList() { force.current = true; forceBrowser.current = true; setRefresh(function (n) { return n + 1; }); }

      function startCheck(id) {
        setBusy("check");
        c.enqueue(makeRequest("check", { profile: id })).then(function (request) { setBusy(""); check.start(request.id); }, fail);
      }
      function edited() { return profileFromForm(form, s.providers, configProvider); }
      function commit(mode, name, then) {
        setBusy("save");
        setMessage(null);
        let profile, newId = "";
        try { profile = edited(); profile = Object.assign({}, profile, mode === "new" ? { id: "", name: name == null ? profile.name : name } : { id: saved.id }); } catch (error) { fail(error); return; }
        c.update(function (current) {
          const result = saveProfileInput(current, profile, mode, configProvider);
          newId = result.id;
          return result.map;
        }).then(function (map) {
          setBusy("");
          setDialog(null);
          const stored = parseProfiles(map[PROFILES_KEY]).find(function (item) { return item.id === newId; });
          setForm(profileForm(stored));
          setMessage({ kind: "saved", text: mode === "new" && saved ? "Saved as a new profile “" + stored.name + "”." : "Saved." });
          if (newId !== (saved && saved.id)) check.clear();
          props.onSaved(newId);
          if (then === "check") startCheck(newId);
        }, fail);
      }
      function decide(then) {
        const problem = profileFormError(form, s.providers, s.profiles, configProvider);
        if (problem) { setMessage({ kind: "error", text: problem }); return; }
        const choice = saveChoice("profile", saved, edited(), 0, !!(saved && s.active === saved.id));
        if (choice.action === "unchanged") {
          if (then === "check") startCheck(saved.id); else setMessage({ kind: "info", text: "Nothing has changed." });
        } else if (choice.action === "create") commit("new", null, then);
        else setDialog({ kind: "overwrite", text: choice.message, then: then, error: "" });
      }
      function submitDialog() {
        if (!dialog || busy) return;
        if (dialog.kind === "overwrite") commit("update", null, dialog.then);
        else if (dialog.kind === "asnew") {
          const problem = nameError("profile", dialog.name, s.profiles);
          if (problem) { setDialog(Object.assign({}, dialog, { error: problem })); return; }
          commit("new", dialog.name.trim(), "");
        } else if (dialog.kind === "delete") {
          setBusy("delete");
          c.update(function (current) { return deleteProfileInput(current, saved.id); }).then(function () { setBusy(""); props.onClose("Deleted profile “" + saved.name + "”."); }, fail);
        }
      }

      let dialogView = null;
      if (dialog && dialog.kind === "overwrite") {
        dialogView = h(ConfirmForm, { label: "Overwrite profile", text: dialog.text, error: dialog.error, busy: busy === "save", confirmLabel: "Overwrite", onConfirm: submitDialog, onCancel: function () { setDialog(null); } });
      } else if (dialog && dialog.kind === "asnew") {
        dialogView = h(ConfirmForm, { label: "Save as new profile", error: dialog.error, busy: busy === "save", confirmLabel: "Save as new", onConfirm: submitDialog, onCancel: function () { setDialog(null); } },
          field("st-profile-newname", "Name of the new profile", h("input", {
            id: "st-profile-newname", type: "text", className: "form-control form-control-sm", value: dialog.name, maxLength: MAX_PROFILE_NAME, autoComplete: "off", autoFocus: true,
            onChange: function (event) { setDialog(Object.assign({}, dialog, { name: event.target.value, error: "" })); },
          }), "The current form is saved under this name; the profile you are editing stays as it was."));
      } else if (dialog && dialog.kind === "delete") {
        dialogView = h(ConfirmForm, { label: "Delete profile", text: "Delete profile “" + saved.name + "”?" + (s.active === saved.id ? " It is the active profile, so automatic analysis stops until you make another one active." : ""), error: dialog.error, busy: busy === "delete", secondary: true, confirmLabel: "Delete profile", onConfirm: submitDialog, onCancel: function () { setDialog(null); } });
      }

      // Which models the field offers, and where they came from.
      const models = workerModels.length ? workerModels : browser.models;
      const chosen = models.find(function (model) { return model.id === form.model; });
      let note = "";
      if (!providerId) note = "Choose a provider to see its models.";
      else if (waiting) note = "Asking the worker for this server’s models…" + (entry ? " Showing the list from " + listAge(entry.at) + " meanwhile." : "");
      else if (entry && entry.error && !workerModels.length) note = "The worker couldn’t list this server’s models (" + entry.error + "). You can still type a model ID.";
      else if (workerModels.length) note = workerModels.length + " model" + (workerModels.length === 1 ? "" : "s") + ", from the worker, " + listAge(entry.at) + ". Type to search.";
      else if (fallback && browser.status === "loading") note = "Loading OpenRouter’s model list…";
      else if (fallback && browser.status === "ready") note = browser.models.length + " model" + (browser.models.length === 1 ? "" : "s") + (structured ? " with structured outputs" : "") + ", from OpenRouter, " + listAge(browser.at) + ". Type to search.";
      else if (fallback && browser.status === "error") note = "Couldn’t load the model list (" + browser.error + "). You can still type a model ID.";
      else if (!connected) note = "The worker has not answered, so it cannot list this server’s models. You can still type a model ID.";
      else note = "No model list yet. You can type a model ID.";

      const providerChoices = s.providers.map(function (item) { return { id: item.id, name: item.name }; });
      if (configProvider || providerId === CONFIG_PROVIDER) providerChoices.push({ id: CONFIG_PROVIDER, name: "Worker config file" });
      const working = !!busy;
      const checkLabel = !saved || saveChoice("profile", saved, safeEdited(), 0).action !== "unchanged" ? "Save and check" : "Check";
      function safeEdited() { try { return edited(); } catch (_) { return saved; } }
      return h("section", { className: "st-editor", "aria-labelledby": "st-profile-title", "data-profile": saved ? saved.id : "new" },
        h("h4", { id: "st-profile-title" }, saved ? "Profile “" + saved.name + "”" : "New profile"),
        h("form", { noValidate: true, onSubmit: function (event) { event.preventDefault(); decide(""); } },
          field("st-profile-name", "Name", h("input", { id: "st-profile-name", type: "text", className: "form-control form-control-sm", value: form.name, maxLength: MAX_PROFILE_NAME, autoComplete: "off", onChange: function (event) { set("name", event.target.value); } })),
          field("st-profile-provider", "Provider", h("select", { id: "st-profile-provider", className: "form-control form-control-sm", value: form.provider, onChange: function (event) { set("provider", event.target.value); } },
            h("option", { value: "" }, "Choose a provider"),
            providerChoices.map(function (choice) { return h("option", { key: choice.id, value: choice.id }, choice.name); }))),
          field("st-profile-model", "Model", h("div", { className: "st-settings-inline" },
            h(ModelCombobox, { id: "st-profile-model", value: form.model, models: models, placeholder: kind === "openrouter" ? "qwen/qwen3-32b" : providerId === CONFIG_PROVIDER ? "Blank uses the config file’s model" : "", onChange: function (value) { set("model", value); } }),
            providerId ? h("button", { type: "button", className: "btn btn-secondary btn-sm st-refresh-models", disabled: waiting || browser.status === "loading", onClick: refreshList }, waiting || browser.status === "loading" ? "Loading…" : "Refresh") : null),
          chosen && modelFacts(chosen) ? chosen.id + " · " + modelFacts(chosen) : null),
          h("p", { className: "st-settings-help text-muted st-list-note", role: "status", "aria-live": "polite" }, note),
          fallback ? h("label", { className: "st-check st-structured" },
            h("input", { type: "checkbox", checked: structured, onChange: function (event) { setStructured(event.target.checked); } }),
            " Structured outputs only: the worker needs a model that can enforce its reply format") : null,
          h("fieldset", { className: "st-defaults" },
            h("legend", null, "Settings for this profile (optional)"),
            h("p", { className: "st-settings-help text-muted" }, "Leave a setting alone to use the provider’s default, marked “(default)”. Typing or choosing a value overrides it; clearing it goes back to the default."),
            h(SettingFields, { prefix: "st-profile", mode: "overrides", values: form.overrides, kind: kind, defaults: defaults, providers: providerChoices, onChange: setOverride })),
          h("div", { className: "st-settings-actions" },
            h("button", { type: "submit", className: "btn btn-primary btn-sm st-save", disabled: working }, busy === "save" ? "Saving…" : "Save"),
            saved ? h("button", { type: "button", className: "btn btn-secondary btn-sm st-save-new", disabled: working, onClick: function () { setDialog({ kind: "asnew", name: "", error: "" }); } }, "Save as new…") : null,
            h("button", { type: "button", id: "st-profile-check", className: "btn btn-secondary btn-sm st-check-button", disabled: working || !connected, title: connected ? undefined : "The worker has not answered", onClick: function () { decide("check"); } }, checkLabel),
            h("button", { type: "button", className: "btn btn-secondary btn-sm st-close", onClick: function () { props.onClose(""); } }, "Cancel"),
            saved ? h("button", { type: "button", className: "btn btn-secondary btn-sm st-delete", disabled: working, onClick: function () { setDialog({ kind: "delete", error: "" }); } }, "Delete") : null)),
        dialogView,
        h("p", { className: "st-settings-message" + (message && message.kind === "error" ? " tps-error" : ""), role: "status", "aria-live": "polite" }, message ? message.text : ""),
        h(CheckResult, { id: "st-profile-check-result", phase: check.phase, result: check.result }));
    }

    function ProfilesTab(props) {
      const c = props.console, s = c.settings;
      const editPair = React.useState(null), editing = editPair[0], setEditing = editPair[1];
      const messagePair = React.useState(""), message = messagePair[0], setMessage = messagePair[1];
      const countPair = React.useState(0), counter = countPair[0], setCounter = countPair[1];
      if (c.status === "loading") return h("section", { className: "st-settings" }, h("p", { className: "tps-status text-muted", role: "status" }, "Loading settings…"));
      const configProvider = c.worker.status && c.worker.status.configProvider;
      const selected = editing && editing.id ? s.profiles.find(function (entry) { return entry.id === editing.id; }) || null : null;
      const providerName = function (id) {
        if (id === CONFIG_PROVIDER) return "Worker config file";
        const provider = s.providers.find(function (entry) { return entry.id === id; });
        return provider ? provider.name : id + " (missing)";
      };
      const defaultProvider = s.providers.length ? s.providers[0].id : configProvider ? CONFIG_PROVIDER : "";
      function makeActive(profile) {
        setMessage("");
        c.update(function (current) { return setActiveInput(current, profile.id); }).then(function () { setMessage("“" + profile.name + "” is the active profile: automatic analysis and the Re-analyse buttons use it."); }, function (error) { setMessage(error.message); });
      }
      return h("section", { className: "st-settings st-profiles-tab", "aria-labelledby": "st-profiles-title" },
        h("h3", { id: "st-profiles-title" }, "Profiles"),
        h("p", { className: "st-settings-help text-muted" }, "A profile names a provider and a model, and may override the provider’s defaults. Each profile keeps its own results: a new one analyses the scenes it has not analysed yet, and earlier proposals stay. The active profile is used for automatic analysis and the Re-analyse buttons."),
        message ? h("p", { className: "st-profile-message", role: "status", "aria-live": "polite" }, message) : null,
        s.profiles.length ? h("ul", { className: "st-entries" }, s.profiles.map(function (profile) {
          const active = s.active === profile.id;
          return h("li", { key: profile.id, className: "st-entry", "data-profile": profile.id, "data-active": active ? "true" : "false" },
            h("div", { className: "st-entry-main" },
              h("strong", { className: "st-entry-name" }, profile.name, active ? h("span", { className: "badge badge-secondary st-active-badge" }, "Active") : null),
              h("span", { className: "st-entry-detail text-muted" }, providerName(profile.provider) + " · " + (profile.model || "the config file’s model"))),
            h("div", { className: "st-entry-buttons" },
              active ? null : h("button", { type: "button", className: "btn btn-secondary btn-sm st-make-active", "aria-label": "Make " + profile.name + " active", onClick: function () { makeActive(profile); } }, "Make active"),
              h("button", { type: "button", className: "btn btn-secondary btn-sm st-entry-edit", "aria-label": "Edit profile " + profile.name, "aria-expanded": !!(editing && editing.id === profile.id), onClick: function () { setMessage(""); setEditing({ id: profile.id, key: profile.id + counter }); } }, "Edit")));
        })) : h("p", { className: "tps-empty text-muted" }, "No profiles yet."),
        h("div", { className: "st-settings-actions st-entries-actions" },
          h("button", { type: "button", className: "btn btn-primary btn-sm st-add", disabled: !defaultProvider || s.profiles.length >= MAX_PROFILES, onClick: function () { setMessage(""); setCounter(counter + 1); setEditing({ id: "", key: "new" + counter }); } }, "Add profile"),
          !defaultProvider ? h("span", { className: "st-settings-help text-muted" }, "Add a provider first.") : null),
        editing && (!editing.id || selected)
          ? h(ProfileEditor, {
            key: editing.key, console: c, saved: selected, defaultProvider: defaultProvider,
            onSaved: function (id) { setEditing({ id: id, key: editing.key }); },
            onClose: function (text) { setEditing(null); setMessage(text || ""); },
          }) : null);
    }

    // ---- Run tab

    // Which tags the model is asked about: every candidate tag, or a chosen few.
    // `tags` are the candidates: the tags the worker says it can analyse, else those that have a definition.
    function TagPicker(props) {
      const searchPair = React.useState(""), search = searchPair[0], setSearch = searchPair[1];
      const tags = props.tags, chosen = props.chosen;
      const words = search.toLowerCase().split(/\s+/).filter(Boolean);
      const matching = tags.filter(function (tag) { return words.every(function (word) { return tag.name.toLowerCase().indexOf(word) !== -1; }); });
      const shown = matching.slice(0, 100);
      return h("div", { className: "st-tag-picker" },
        h("label", { className: "st-check" },
          h("input", { id: "st-run-alltags", type: "checkbox", checked: props.all, onChange: function (event) { props.onAll(event.target.checked); } }),
          " All tags (" + tags.length + (props.filtered ? " eligible)" : " with a definition)")),
        !tags.length ? h("p", { className: "st-settings-help text-muted st-picker-empty", role: "status" }, NO_ELIGIBLE_TEXT) : null,
        props.note ? h("p", { className: "st-settings-help st-picker-note", role: "status", "aria-live": "polite" }, props.note) : null,
        props.all ? null : h("div", { className: "st-picker" },
          field("st-run-tagsearch", "Search tags", h("input", {
            id: "st-run-tagsearch", type: "search", className: "form-control form-control-sm", value: search, autoComplete: "off", placeholder: "Type part of a name", onChange: function (event) { setSearch(event.target.value); },
          })),
          h("div", { className: "st-settings-actions st-picker-actions" },
            h("button", { type: "button", className: "btn btn-secondary btn-sm st-picker-all", disabled: !shown.length, onClick: function () { props.onChoose(shown.map(function (tag) { return String(tag.id); }), true); } }, "Choose these " + shown.length),
            h("button", { type: "button", className: "btn btn-secondary btn-sm st-picker-none", disabled: !chosen.length, onClick: function () { props.onChoose(chosen, false); } }, "Clear all")),
          h("p", { className: "st-settings-help text-muted", role: "status", "aria-live": "polite" },
            chosen.length + " chosen. " + (matching.length > shown.length ? matching.length - shown.length + " more match; keep typing to narrow the list." : matching.length + (matching.length === 1 ? " tag matches." : " tags match."))),
          h("ul", { className: "st-picker-list", "aria-label": "Tags" }, shown.map(function (tag) {
            const id = String(tag.id);
            return h("li", { key: id }, h("label", { className: "st-check" },
              h("input", { type: "checkbox", "data-tag": id, checked: chosen.indexOf(id) !== -1, onChange: function (event) { props.onChoose([id], event.target.checked); } }),
              " " + tag.name));
          }))));
    }

    // A picker's tags and choice: the eligible tags (see eligibleView), with the chosen ones that stopped being
    // eligible taken out and a note saying so. Returns { view, note, clearNote }.
    function useEligibleChoice(tags, candidates, chosen, setChosen) {
      const view = eligibleView(tags, candidates);
      const notePair = React.useState(""), note = notePair[0], setNote = notePair[1];
      React.useEffect(function () {
        if (!view || view.status !== "ready" || !view.filtered) return;
        const kept = usableChoices(chosen, view);
        if (kept.length !== chosen.length) { setNote(droppedNote(chosen.length - kept.length)); setChosen(kept); }
      }, [view && view.key, view && view.status === "ready" ? view.list.length : -1, chosen]);
      return { view: view, note: note, clearNote: function () { setNote(""); } };
    }

    // The form that starts an analysis. `scope` says what to analyse
    // ({ type: "library" } here; a list view could pass { type: "scenes", sceneIds }),
    // and runRequest(scope, options) builds the request.
    function RunForm(props) {
      const c = props.console, s = c.settings, scope = props.scope;
      const profilePair = React.useState(""), picked = profilePair[0], setProfileId = profilePair[1];
      // The profile picked, else the active one, else the first.
      const profileId = s.profiles.some(function (entry) { return entry.id === picked; }) ? picked : s.active || (s.profiles[0] && s.profiles[0].id) || "";
      const limitPair = React.useState(""), limit = limitPair[0], setLimit = limitPair[1];
      const allPair = React.useState(true), all = allPair[0], setAll = allPair[1];
      const chosenPair = React.useState([]), chosen = chosenPair[0], setChosen = chosenPair[1];
      const modePair = React.useState("new"), mode = modePair[0], setMode = modePair[1];
      const askPair = React.useState(null), asking = askPair[0], setAsking = askPair[1];
      const messagePair = React.useState(null), message = messagePair[0], setMessage = messagePair[1];
      const busyPair = React.useState(false), busy = busyPair[0], setBusy = busyPair[1];
      const configProvider = c.worker.status && c.worker.status.configProvider;
      const profile = s.profiles.find(function (entry) { return entry.id === profileId; }) || null;
      const provider = profile ? s.providers.find(function (entry) { return entry.id === profile.provider; }) || null : null;
      const destination = runDestination(profile, s.providers, configProvider, s.networks);
      const budget = profile ? effectiveSetting("dailyBudget", profile.overrides, provider ? provider.defaults : null, null) : null;
      const connected = c.connection.state === "connected";
      const picker = useEligibleChoice(props.tags, c.worker.candidates, chosen, setChosen);

      function build() {
        return runRequest(scope, { profile: profileId, limit: limit, tagIds: all ? [] : usableChoices(chosen, picker.view), mode: mode });
      }
      function start() {
        setMessage(null);
        let request;
        try {
          request = build();
          if (!all && !usableChoices(chosen, picker.view).length) throw new Error("Choose at least one tag, or tick All tags.");
        } catch (error) { setMessage({ kind: "error", text: error.message }); return; }
        if (destination && destination.local === false && !asking) { setAsking(request); return; }
        send(request);
      }
      function send(request) {
        setBusy(true);
        setAsking(null);
        c.enqueue(request).then(function () {
          setBusy(false);
          setMessage({ kind: "info", text: "Sent. The worker starts the analysis when it is free; its progress shows below." });
        }, function (error) { setBusy(false); setMessage({ kind: "error", text: error.message }); });
      }

      const limitText = budget && budget.source !== "default"
        ? "Daily spending limit in effect: " + settingText("dailyBudget", budget.value) + " (" + (budget.source === "profile" ? "this profile’s" : "the provider’s default") + ")."
        : "No daily spending limit is set here; the worker’s config file may set one.";
      let where;
      if (!destination) where = "Choose a profile.";
      else if (destination.local === false) where = "Scene text goes to " + destination.host + ", outside your network: titles, descriptions, file and folder names, and performer and studio names leave it.";
      else if (destination.local === true) where = "Scene text goes to " + destination.host + ", on your network.";
      else where = "Scene text goes to the address in the worker’s config file.";

      if (!s.profiles.length) return h("p", { className: "tps-empty text-muted" }, "Add a provider and a profile first (Providers and Profiles tabs).");
      // The question is a form of its own, so it sits beside this one, not inside it.
      return h(React.Fragment, null, h("form", { className: "st-run-form", noValidate: true, onSubmit: function (event) { event.preventDefault(); start(); } },
        field("st-run-profile", "Profile", h("select", { id: "st-run-profile", className: "form-control form-control-sm", value: profileId, onChange: function (event) { setProfileId(event.target.value); setAsking(null); } },
          s.profiles.map(function (entry) { return h("option", { key: entry.id, value: entry.id }, entry.name + (s.active === entry.id ? " (active)" : "")); })),
          profile ? "Model: " + (profile.model || "the config file’s model") + "." : null),
        field("st-run-limit", "Scene limit", h("input", {
          id: "st-run-limit", type: "number", min: "1", max: String(MAX_RUN_LIMIT), step: "1", inputMode: "numeric", className: "form-control form-control-sm st-settings-budget",
          value: limit, placeholder: "No limit", onChange: function (event) { setLimit(event.target.value); setAsking(null); },
        }), "How many scenes to send to the model, at most. Blank sends every scene that qualifies. A small number is a cheap way to try a profile."),
        h("div", { className: "st-settings-field" }, h("span", { className: "st-label" }, "Tags"),
          props.tags.status === "ready"
            ? h(TagPicker, { tags: picker.view.list, filtered: picker.view.filtered, note: picker.note, all: all, chosen: chosen, onAll: function (on) { picker.clearNote(); setAll(on); setAsking(null); },
              onChoose: function (ids, on) { picker.clearNote(); setAsking(null); setChosen(function (previous) { const next = on ? previous.concat(ids.filter(function (id) { return previous.indexOf(id) === -1; })) : previous.filter(function (id) { return ids.indexOf(id) === -1; }); return next; }); } })
            : props.tags.status === "error" ? h("p", { className: "tps-error", role: "alert" }, "Couldn’t load the tags: " + props.tags.error)
              : h("p", { className: "tps-status text-muted", role: "status" }, "Loading tags…")),
        field("st-run-mode", "Which scenes", h("select", { id: "st-run-mode", className: "form-control form-control-sm", value: mode, onChange: function (event) { setMode(event.target.value); setAsking(null); } },
          MODES.map(function (entry) { return h("option", { key: entry.id, value: entry.id }, entry.label); }))),
        h("p", { className: "st-run-where", role: "status", "aria-live": "polite" }, where, " ", limitText),
        h("div", { className: "st-settings-actions" },
          h("button", { type: "submit", className: "btn btn-primary btn-sm st-run-start", disabled: !connected || busy || !!asking || c.answersOnly, title: connected ? undefined : "The worker has not answered" }, busy ? "Sending…" : "Start analysis"),
          connected && c.answersOnly ? h("span", { className: "st-settings-help text-muted st-answers-only" }, "This worker only records answers, so it cannot run an analysis.") : null,
          connected ? null : h("span", { className: "st-settings-help text-muted" }, "Start is available once the worker answers.")),
        h("p", { className: "st-settings-message" + (message && message.kind === "error" ? " tps-error" : ""), role: "status", "aria-live": "polite" }, message ? message.text : "")),
        asking ? h(ConfirmForm, {
          label: "Send scene text outside your network", busy: busy, confirmLabel: "Send and start", onConfirm: function () { send(asking); }, onCancel: function () { setAsking(null); },
          text: "Scene text will be sent to " + destination.host + ", outside your network. The model there is billed for every request. Start the analysis?",
        }) : null);
    }

    const STATE_LABELS = { queued: "Queued", running: "Running", done: "Done", stopped: "Stopped", cancelled: "Cancelled", failed: "Failed" };

    // The jobs the worker reports, with run requests it has not shown yet.
    function JobList(props) {
      const c = props.console, s = c.settings, worker = c.worker;
      // The Run tab lists analyses; the Evaluate tab lists evaluation runs.
      const evaluating = props.kind === "eval";
      const jobs = worker.jobs.filter(function (job) { return (job.type === "eval") === evaluating; });
      const messagePair = React.useState(""), message = messagePair[0], setMessage = messagePair[1];
      const knownIds = worker.jobs.map(function (job) { return job.id; });
      const unseen = pendingRequests(s.requests, worker.answered).filter(function (request) { return request.kind === (evaluating ? "evalRun" : "run") && knownIds.indexOf(request.id) === -1; });
      const cancelling = pendingRequests(s.requests, worker.answered).filter(function (request) { return request.kind === "cancel"; }).map(function (request) { return request.job; });
      function cancel(job) {
        setMessage("");
        c.enqueue(makeRequest("cancel", { job: job.id })).catch(function (error) { setMessage(error.message); });
      }
      const profileName = function (id) { const profile = s.profiles.find(function (entry) { return entry.id === id; }); return profile ? profile.name : id; };
      if (!jobs.length && !unseen.length) return h("p", { className: "tps-empty text-muted st-jobs-empty" }, evaluating ? "No evaluation runs yet." : "No analyses yet.");
      return h("div", { className: "st-jobs-block" },
        message ? h("p", { className: "tps-error", role: "alert" }, message) : null,
        h("ul", { className: "st-jobs", "aria-label": evaluating ? "Evaluation runs" : "Analyses" },
          unseen.map(function (request) {
            return h("li", { key: request.id, className: "st-job", "data-job": request.id, "data-state": "sent" },
              h("div", { className: "st-job-head" }, h("strong", null, profileName(request.profile)), h("span", { className: "badge badge-secondary st-job-state" }, "Sent")),
              h("p", { className: "st-job-line" }, "Waiting for the worker (sent " + listAge(request.at) + ")."));
          }),
          jobs.map(function (job) {
            const live = job.state === "queued" || job.state === "running";
            const request = job.request;
            const what = [request.limit ? "limit " + request.limit : "no limit", request.tagIds.length ? request.tagIds.length + " tag" + (request.tagIds.length === 1 ? "" : "s") : "all tags"];
            if (evaluating) what.unshift((EVAL_METHODS.find(function (method) { return method.id === request.method; }) || EVAL_METHODS[0]).label.toLowerCase(), request.half + " half");
            else what.push((MODES.find(function (mode) { return mode.id === request.mode; }) || MODES[0]).label.toLowerCase());
            return h("li", { key: job.id, className: "st-job", "data-job": job.id, "data-state": job.state },
              h("div", { className: "st-job-head" },
                h("strong", null, job.profile.name || profileName(job.profile.id)),
                h("span", { className: "badge badge-secondary st-job-state" }, STATE_LABELS[job.state])),
              h("p", { className: "st-job-line st-job-request text-muted" }, what.join(" · ")),
              job.state !== "queued" ? h("p", { className: "st-job-line st-job-progress" }, jobProgress(job) + (job.cost != null ? " · cost " + job.cost + " credits" : "") + (job.published ? " · " + job.published + " published" : "")) : null,
              job.message ? h("p", { className: "st-job-line st-job-message" + (job.state === "failed" ? " tps-error" : "") }, job.message) : null,
              h("div", { className: "st-settings-actions" },
                live ? h("button", { type: "button", className: "btn btn-secondary btn-sm st-job-cancel", "aria-label": "Cancel the analysis with " + (job.profile.name || job.profile.id), disabled: cancelling.indexOf(job.id) !== -1, onClick: function () { cancel(job); } }, cancelling.indexOf(job.id) !== -1 ? "Cancelling…" : "Cancel") : null,
                !evaluating && (job.state === "done" || job.state === "stopped" || job.state === "cancelled") ? h(Link, { to: ROUTE, className: "btn btn-link btn-sm st-job-review" }, "Review the proposals") : null));
          })));
    }

    function RunTab(props) {
      const c = props.console, s = c.settings;
      const tagsPair = React.useState({ status: "loading" }), tags = tagsPair[0], setTags = tagsPair[1];
      const autoPair = React.useState(""), autoMessage = autoPair[0], setAutoMessage = autoPair[1];
      React.useEffect(function () {
        let live = true;
        definedTags(transport).then(function (list) { if (live) setTags({ status: "ready", list: list }); }, function (error) { if (live) setTags({ status: "error", error: error.message }); });
        return function () { live = false; };
      }, []);
      if (c.status === "loading") return h("section", { className: "st-settings" }, h("p", { className: "tps-status text-muted", role: "status" }, "Loading settings…"));
      const active = s.profiles.find(function (entry) { return entry.id === s.active; }) || null;
      function toggleAuto(on) {
        setAutoMessage("");
        c.update(function (current) { return setAutoInput(current, on); }).then(function () {
          setAutoMessage(on ? "Automatic analysis is on. The worker analyses new and changed scenes with “" + active.name + "”." : "Automatic analysis is off.");
        }, function (error) { setAutoMessage(error.message); });
      }
      const status = c.worker.status;
      return h("section", { className: "st-settings st-run", "aria-labelledby": "st-run-title" },
        h("h3", { id: "st-run-title" }, "Run"),
        h(RunForm, { console: c, scope: { type: "library" }, tags: tags }),
        h("h4", { className: "st-subheading" }, "Analyses"),
        h(JobList, { console: c }),
        h("div", { className: "st-auto" },
          h("label", { className: "st-check st-auto-label" },
            h("input", { id: "st-auto", type: "checkbox", checked: s.auto, disabled: !s.auto && !active, onChange: function (event) { toggleAuto(event.target.checked); } }),
            " Analyse new and changed scenes automatically with the active profile" + (active ? " (“" + active.name + "”)" : "")),
          !active ? h("p", { className: "st-settings-help text-muted" }, "Make a profile active on the Profiles tab first.") : null,
          s.auto && status && c.connection.state === "connected" && !status.auto ? h("p", { className: "st-settings-help text-muted" }, "The worker has not picked this up yet; it reads it at its next poll.") : null,
          h("p", { className: "st-settings-help text-muted", role: "status", "aria-live": "polite" }, autoMessage)));
    }

    // ---- The AI tags page: a worker status line and four tabs kept in the URL.

    // Review proposals grouped by tag, with bulk decisions.
    const ReviewTab = memo(function ReviewTab() {
      const location = Router.useLocation ? Router.useLocation() : window.location;
      const history = Router.useHistory ? Router.useHistory() : null;
      const params = new URLSearchParams(location.search || "");
      const selectedTag = params.get("tag");
      const tagsPair = React.useState({ status: "loading" }), tags = tagsPair[0], setTags = tagsPair[1];
      const outbox = useOutbox();

      React.useEffect(function () {
        let live = true;
        definedTags(transport).then(function (list) {
          return pendingCounts(transport, list.map(function (tag) { return tag.id; })).then(function (counts) {
            if (!live) return;
            const withCounts = list.map(function (tag) { return Object.assign({}, tag, { pending: counts[tag.id] || 0 }); })
              .sort(function (a, b) { return b.pending - a.pending || a.name.localeCompare(b.name); });
            setTags({ status: "ready", list: withCounts });
          });
        }).catch(function (error) { if (live) setTags({ status: "error", error: error.message }); });
        return function () { live = false; };
      }, []);

      // A decision lowers the chosen tag's count where it is shown; the
      // counts for every tag are read again only when the page opens.
      function decided(tagId, count) {
        setTags(function (previous) {
          if (previous.status !== "ready") return previous;
          return Object.assign({}, previous, { list: previous.list.map(function (entry) {
            return String(entry.id) === String(tagId) ? Object.assign({}, entry, { pending: Math.max(0, count) }) : entry;
          }) });
        });
        announceChange();
      }

      function choose(tagId) {
        const search = tagId ? "?tag=" + encodeURIComponent(tagId) : "";
        if (history) history.push(ROUTE + search); else window.location.search = search;
      }

      let sidebar;
      if (tags.status === "loading") sidebar = h("p", { className: "tps-status text-muted", role: "status" }, "Counting proposals…");
      else if (tags.status === "error") sidebar = h("p", { className: "tps-error", role: "alert" }, tags.error);
      else {
        const withPending = tags.list.filter(function (tag) { return tag.pending > 0; });
        sidebar = h(React.Fragment, null,
          h("p", { className: "tps-summary text-muted" }, withPending.length
            ? withPending.reduce(function (sum, tag) { return sum + tag.pending; }, 0) + " proposals across " + withPending.length + " tags"
            : "No pending proposals. Proposals appear here after the worker publishes them."),
          h("ul", { className: "st-tag-list" }, withPending.map(function (tag) {
            return h("li", { key: tag.id },
              h("button", {
                type: "button", className: "btn btn-sm minimal st-tag" + (String(tag.id) === selectedTag ? " active" : ""),
                "data-tag": tag.id,
                "aria-current": String(tag.id) === selectedTag ? "true" : undefined,
                onClick: function () { choose(tag.id); },
              }, h("span", null, tag.name), h("span", { className: "badge badge-secondary" }, tag.pending)));
          })));
      }
      const tag = tags.status === "ready" && selectedTag ? tags.list.find(function (entry) { return String(entry.id) === selectedTag; }) : null;
      return h("div", { className: "st-review-layout" },
        h("nav", { className: "st-sidebar", "aria-label": "Tags with proposals" }, sidebar,
          h("p", { className: "st-review-saved st-settings-help text-muted", role: "status", "aria-live": "polite" },
            "Your decisions are saved for evaluation: an accept counts as a Yes and a reject as a No, for the model that proposed the tag." + (outboxText(outbox.box) ? " " + outboxText(outbox.box) + "." : ""))),
        h("main", { className: "st-main" }, selectedTag
          ? h(TagReview, { key: selectedTag, tagId: selectedTag, tag: tag, onDecided: decided })
          : h("p", { className: "tps-empty text-muted" }, "Choose a tag to review its proposals.")));
    });

    const TABS = Object.freeze([
      { id: "review", label: "Review" },
      { id: "run", label: "Run" },
      { id: "profiles", label: "Profiles" },
      { id: "providers", label: "Providers" },
      { id: "evaluate", label: "Evaluate" },
    ]);

    function AiTagsPage() {
      const location = Router.useLocation ? Router.useLocation() : window.location;
      const history = Router.useHistory ? Router.useHistory() : null;
      const tab = tabOf(location.search);
      const c = useConsole();
      function go(id) {
        const url = tabUrl(id);
        if (history) history.push(url); else window.location.href = url;
      }
      function keys(event) {
        const index = TABS.findIndex(function (entry) { return entry.id === tab; });
        let next = -1;
        if (event.key === "ArrowRight") next = (index + 1) % TABS.length;
        else if (event.key === "ArrowLeft") next = (index + TABS.length - 1) % TABS.length;
        else if (event.key === "Home") next = 0;
        else if (event.key === "End") next = TABS.length - 1;
        if (next < 0) return;
        event.preventDefault();
        go(TABS[next].id);
        setTimeout(function () { const el = document.getElementById("st-tab-" + TABS[next].id); if (el) el.focus(); }, 0);
      }
      let panel;
      if (tab === "run") panel = h(RunTab, { console: c });
      else if (tab === "profiles") panel = h(ProfilesTab, { console: c });
      else if (tab === "providers") panel = h(ProvidersTab, { console: c });
      else if (tab === "evaluate") panel = h(EvaluateTab, { console: c });
      else panel = h(ReviewTab, null);
      return h("div", { className: "st-review container-fluid", "data-tab": tab },
        h("div", { className: "st-heading-row st-review-heading" }, h("h2", null, "AI tag proposals")),
        h(WorkerStatus, { console: c }),
        h("div", { className: "st-tabs", role: "tablist", "aria-label": "AI tags", onKeyDown: keys },
          TABS.map(function (entry) {
            const on = entry.id === tab;
            return h("button", {
              key: entry.id, id: "st-tab-" + entry.id, type: "button", role: "tab", "aria-selected": on, "aria-controls": "st-tabpanel", tabIndex: on ? 0 : -1,
              className: "btn btn-sm minimal st-tab" + (on ? " active" : ""), "data-tab": entry.id, onClick: function () { go(entry.id); },
            }, entry.label);
          })),
        h("div", { id: "st-tabpanel", className: "st-tabpanel", role: "tabpanel", "aria-labelledby": "st-tab-" + tab }, panel));
    }


    // Stash's own scene preview: the screenshot, the preview video while the
    // pointer is over it, and the sprite scrubber along its bottom edge. It
    // lives in Stash's lazily loaded SceneCard module, which the plugin API
    // exposes as loadableComponents.SceneCard (it resolves to { SceneCard,
    // ScenePreview }). The module is loaded once, on first use.
    let previewComponent = null, previewLoad = null;
    function loadScenePreview() {
      if (!previewLoad) {
        const loadable = PluginApi.loadableComponents && PluginApi.loadableComponents.SceneCard;
        previewLoad = (loadable ? Promise.resolve().then(loadable) : Promise.resolve(null)).then(function (module) {
          previewComponent = module && typeof module.ScenePreview === "function" ? module.ScenePreview : null;
          return previewComponent;
        }, function () { return null; });
      }
      return previewLoad;
    }
    function useScenePreview() {
      const pair = React.useState(function () { return previewComponent; }), component = pair[0], setComponent = pair[1];
      React.useEffect(function () {
        if (component) return undefined;
        let live = true;
        loadScenePreview().then(function (loaded) { if (live && loaded) setComponent(function () { return loaded; }); });
        return function () { live = false; };
      }, []);
      return component;
    }

    // Segments from highlightSegments, as text and <mark>s.
    function Highlighted(props) {
      return h(React.Fragment, null, highlightSegments(props.text, props.quote).map(function (part, index) {
        return part.mark ? h("mark", { key: index }, part.text) : h(React.Fragment, { key: index }, part.text);
      }));
    }

    // Clamped to about four lines with a Show more/less toggle. A quote that
    // the clamp would hide opens the description, so it is seen where it is.
    function Description(props) {
      const ref = React.useRef(null);
      const expandedPair = React.useState(false), expanded = expandedPair[0], setExpanded = expandedPair[1];
      const overflowPair = React.useState(false), overflows = overflowPair[0], setOverflows = overflowPair[1];
      const id = "st-desc-" + props.idKey;
      React.useLayoutEffect(function () {
        const el = ref.current, mark = el && el.querySelector("mark");
        if (mark && mark.offsetTop + mark.offsetHeight > el.clientHeight + 1) setExpanded(true);
      }, []);
      React.useLayoutEffect(function () {
        const el = ref.current;
        if (!el) return undefined;
        function check() { if (!expanded) setOverflows(el.scrollHeight > el.clientHeight + 1); }
        check();
        window.addEventListener("resize", check);
        return function () { window.removeEventListener("resize", check); };
      }, [expanded, props.text]);
      return h("div", { className: "st-description-block" },
        h("p", { id: id, ref: ref, className: "st-description" + (expanded ? "" : " st-clamped") }, h(Highlighted, { text: props.text, quote: props.quote })),
        overflows || expanded ? h("button", {
          type: "button", className: "btn btn-link btn-sm st-toggle st-description-toggle", "aria-expanded": expanded, "aria-controls": id,
          onClick: function () { setExpanded(!expanded); },
        }, expanded ? "Show less" : "Show more") : null);
    }

    // The scene's own tags as Stash-style badges, the first TAG_LIMIT of them.
    function ExistingTags(props) {
      const pair = React.useState(false), expanded = pair[0], setExpanded = pair[1];
      const limited = limitTags(props.tags, expanded);
      if (!props.tags.length) return null;
      return h("div", { className: "st-existing-tags", "aria-label": "Tags on this scene", role: "group" },
        limited.shown.map(function (tag) {
          return h("span", { key: tag.id, className: "badge badge-secondary tag-item tag-link st-scene-tag" }, h(Link, { to: "/tags/" + tag.id }, tag.name));
        }),
        limited.extra ? h("button", {
          type: "button", className: "btn btn-link btn-sm st-toggle st-tags-toggle", "aria-expanded": expanded, onClick: function () { setExpanded(!expanded); },
        }, expanded ? "Show fewer" : "+" + limited.extra + " more") : null);
    }

    // One proposal, laid out like a row of Stash's scene Tagger: the scene's
    // preview, what it is, and what is proposed for it.
    function ProposalCard(props) {
      const view = sceneView(props.row.scene), item = props.row.item;
      const history = Router.useHistory ? Router.useHistory() : null;
      const Preview = useScenePreview();
      const link = "/scenes/" + view.id;
      function openAt(timestamp) {
        const target = link + "?t=" + timestamp;
        if (history) history.push(target); else window.location.assign(target);
      }
      const preview = Preview
        ? h(Preview, { image: view.image || undefined, video: view.video || undefined, vttPath: view.vtt || undefined, isPortrait: view.portrait, soundActive: false, onScrubberClick: openAt })
        : h("div", { className: "scene-card-preview" + (view.portrait ? " portrait" : "") }, view.image ? h("img", { className: "scene-card-preview-image", loading: "lazy", src: view.image, alt: "" }) : null);
      const meta = [];
      if (view.date) meta.push(h("span", { key: "date", className: "st-date" }, view.date));
      if (view.studio) meta.push(h(Link, { key: "studio", to: "/studios/" + view.studio.id, className: "st-studio" }, view.studio.name));
      if (view.duration) meta.push(h("span", { key: "duration", className: "st-duration" }, view.duration));
      if (view.resolution) meta.push(h("span", { key: "resolution", className: "st-resolution", title: view.size }, view.resolution));
      const where = item.field === "details" ? "description" : item.field === "file" ? "file name" : item.field;
      return h("li", { className: "st-row st-card", "data-scene": view.id, "data-agreement": agreementOf(item) },
        h("div", { className: "st-card-preview" },
          h("div", { className: "scene-card st-preview" },
            h(Link, { to: link, className: "st-preview-link", "aria-label": "Open scene " + view.title }, preview))),
        h("div", { className: "st-card-body" },
          h("h4", { className: "st-card-title" }, h(Link, { to: link, className: "tps-name st-title" },
            item.field === "title" && view.hasTitle ? h(Highlighted, { text: view.title, quote: item.quote }) : view.title)),
          meta.length ? h("p", { className: "st-card-meta text-muted" }, meta) : null,
          item.field === "file" || item.field === "folders" ? h("p", { className: "st-path text-muted", title: "Where the quoted words are" }, view.path ? h(Highlighted, { text: view.path, quote: item.quote }) : null) : null,
          view.details ? h(Description, { idKey: view.id, text: view.details, quote: item.field === "details" ? item.quote : "" }) : null,
          view.performers.length ? h("p", { className: "st-performers" },
            h("span", { className: "text-muted" }, "Performers: "),
            view.performers.map(function (performer, index) {
              return h(React.Fragment, { key: performer.id }, index ? ", " : "", h(Link, { to: "/performers/" + performer.id, className: "st-performer" }, performer.name));
            })) : null,
          h(ExistingTags, { tags: view.tags })),
        h("div", { className: "st-card-proposal", "aria-label": "Proposal for " + view.title, role: "group" },
          h("label", { className: "st-check" },
            h("input", { type: "checkbox", checked: !!props.selected, "aria-label": "Select scene " + view.title, onChange: function (event) { props.onSelect(event.target.checked); } }),
            " Select"),
          h(Evidence, { item: item }),
          h(SourceChips, { item: item, idKey: "card-" + view.id }),
          h("div", { className: "tps-actions" },
            h("button", { type: "button", className: "btn btn-primary btn-sm st-accept", disabled: !!props.busy, onClick: function () { props.onDecide("accept"); } }, "Add"),
            h("button", { type: "button", className: "btn btn-secondary btn-sm st-reject", disabled: !!props.busy, onClick: function () { props.onDecide("reject"); } }, "Reject"),
            h("button", {
              type: "button", className: "btn btn-link btn-sm st-reject-reason", disabled: !!props.busy, "aria-expanded": !!props.formOpen,
              "aria-label": "Reject " + view.title + " with a reason", title: "Say why this proposal is wrong, then reject it", onClick: props.onToggleForm,
            }, "Reject with reason\u2026")),
          props.formOpen ? h(FeedbackForm, {
            idKey: "scene-" + view.id, label: "Reject " + item.tagName + " for " + view.title + " with a reason", submitLabel: "Reject with reason", busy: props.busy === "reject",
            onSubmit: function (reason) { props.onDecide("reject", reason); }, onCancel: props.onToggleForm,
          }) : null));
    }

    // The remembered sort, per browser. Storage may be missing or blocked.
    function readSort() {
      try { return sortId(window.localStorage && window.localStorage.getItem(SORT_STORAGE_KEY)); } catch (_) { return "scene"; }
    }
    function rememberSort(value) {
      try { if (window.localStorage) window.localStorage.setItem(SORT_STORAGE_KEY, value); } catch (_) { /* not remembered */ }
    }

    function TagReview(props) {
      const pagePair = React.useState(1), page = pagePair[0], setPage = pagePair[1];
      const dataPair = React.useState({ status: "loading" }), data = dataPair[0], setData = dataPair[1];
      const selectedPair = React.useState({}), selected = selectedPair[0], setSelected = selectedPair[1];
      const highOnlyPair = React.useState(false), highOnly = highOnlyPair[0], setHighOnly = highOnlyPair[1];
      const busyPair = React.useState(null), busy = busyPair[0], setBusy = busyPair[1];
      const errorPair = React.useState(null), error = errorPair[0], setError = errorPair[1];
      const loadPair = React.useState(0), load = loadPair[0], setLoad = loadPair[1];
      const reasonPair = React.useState(false), reasonOpen = reasonPair[0], setReasonOpen = reasonPair[1];
      const rowFormPair = React.useState(null), rowForm = rowFormPair[0], setRowForm = rowFormPair[1];
      const sortPair = React.useState(readSort), sort = sortPair[0], setSort = sortPair[1];
      // The filters: a source that proposed it ("" for any) and how the sources agree.
      const byPair = React.useState(""), proposedBy = byPair[0], setProposedBy = byPair[1];
      const agreementPair = React.useState("all"), agreement = agreementPair[0], setAgreement = agreementPair[1];
      // Asked for before a filter is chosen, so the Proposed by list can name every source.
      const wantPair = React.useState(false), wantIndex = wantPair[0], setWantIndex = wantPair[1];
      // Every pending scene of the tag, for a confidence sort and the filters.
      const indexPair = React.useState({ status: "idle", entries: [], loaded: 0, total: null }), index = indexPair[0], setIndex = indexPair[1];
      const filtering = !!proposedBy || agreement !== "all";
      // The index decides the pages for a sort other than scene order, or a filter.
      const bySort = sort !== "scene" || filtering;
      const indexNeeded = bySort || wantIndex;
      const filters = { by: proposedBy, agreement: agreement, highOnly: highOnly };

      // Stash can neither sort by confidence nor filter by source, which live
      // inside each scene's proposals: read the IDs and proposals of all
      // pending scenes once, and sort, filter and page them here. Changing the
      // tag (this component is keyed by it) or the sort builds the index
      // again; a filter does not; decisions only remove entries.
      React.useEffect(function () {
        if (!indexNeeded) return undefined;
        let live = true;
        setIndex({ status: "loading", entries: [], loaded: 0, total: null });
        loadIndex(transport, props.tagId, {
          cancelled: function () { return !live; },
          onProgress: function (loaded, total) { if (live) setIndex(function (previous) { return Object.assign({}, previous, { loaded: loaded, total: total }); }); },
        }).then(function (entries) {
          if (live) setIndex({ status: "ready", entries: entries, loaded: entries.length, total: entries.length });
        }, function (failure) { if (live) setIndex({ status: "error", entries: [], loaded: 0, total: null, error: failure.message }); });
        return function () { live = false; };
      }, [props.tagId, indexNeeded, sort]);

      // Scene order: Stash pages the scenes.
      React.useEffect(function () {
        if (bySort) return undefined;
        let live = true;
        setData({ status: "loading" });
        tagScenes(transport, props.tagId, page).then(function (result) {
          if (!live) return;
          // After decisions empty the last page, step back to one that has rows.
          const last = Math.max(1, Math.ceil(result.count / PAGE_SIZE));
          if (page > last) { setPage(last); return; }
          const rows = result.scenes.map(function (scene) {
            const item = sceneProposals(scene.custom_fields, scene.tags).items.find(function (entry) { return entry.tagId === String(props.tagId); });
            return { scene: scene, item: item };
          }).filter(function (row) { return row.item; });
          setData({ status: "ready", count: result.count, listed: result.count, rows: rows });
          setSelected({});
          if (load && props.onDecided) props.onDecided(props.tagId, result.count);
        }, function (failure) { if (live) setData({ status: "error", error: failure.message }); });
        return function () { live = false; };
      }, [props.tagId, page, load, bySort]);

      // A sort or a filter: the page's cards are fetched by ID from the sorted, filtered index.
      const listedEntries = bySort && index.status === "ready" ? sortEntries(filterEntries(index.entries, filters), sort) : null;
      const listedKey = listedEntries ? listedEntries.map(function (entry) { return entry.id; }).join(",") : "";
      React.useEffect(function () {
        if (!bySort) return undefined;
        if (index.status === "loading" || index.status === "idle") { setData({ status: "loading" }); return undefined; }
        if (index.status === "error") { setData({ status: "error", error: index.error }); return undefined; }
        const last = Math.max(1, Math.ceil(listedEntries.length / PAGE_SIZE));
        if (page > last) { setPage(last); return undefined; }
        let live = true;
        const ids = listedEntries.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE).map(function (entry) { return entry.id; });
        cardScenes(transport, ids).then(function (scenes) {
          if (!live) return;
          const rows = scenes.map(function (scene) {
            const item = sceneProposals(scene.custom_fields, scene.tags).items.find(function (entry) { return entry.tagId === String(props.tagId); });
            return { scene: scene, item: item };
          }).filter(function (row) { return row.item; });
          setData({ status: "ready", count: index.entries.length, listed: listedEntries.length, rows: rows });
          setSelected({});
        }, function (failure) { if (live) setData({ status: "error", error: failure.message }); });
        return function () { live = false; };
      }, [props.tagId, bySort, index.status, listedKey, page]);

      const visible = data.status === "ready" ? data.rows.filter(function (row) { return bySort || !highOnly || row.item.confidence === "high"; }) : [];
      const chosen = visible.filter(function (row) { return selected[row.scene.id]; }).map(function (row) { return row.scene.id; });

      function decide(kind, sceneIds, reason) {
        if (!sceneIds.length) return;
        setBusy(kind);
        setError(null);
        (kind === "accept" ? accept(transport, sceneIds, props.tagId) : reject(transport, sceneIds, props.tagId, reason, props.tag && props.tag.name)).then(function (result) {
          const queued = sendDecisionAnswers(result);
          setBusy(null);
          setReasonOpen(false);
          setRowForm(null);
          if (queued) setError(queued);
          if (kind === "accept") refreshStash();
          // The index is not read again: the decided scenes just leave it.
          const gone = sceneIds.map(String);
          const remaining = index.entries.filter(function (entry) { return gone.indexOf(entry.id) === -1; });
          if (index.status === "ready") setIndex(Object.assign({}, index, { entries: remaining }));
          if (bySort) {
            if (props.onDecided) props.onDecided(props.tagId, remaining.length);
          } else {
            // Reload this page; the page, filter and the rest stay as they were.
            setLoad(function (n) { return n + 1; });
          }
        }, function (failure) { setBusy(null); setError(failure.message); });
      }
      function toggleAll(on) {
        const next = {};
        if (on) visible.forEach(function (row) { next[row.scene.id] = true; });
        setSelected(next);
      }
      function chooseSort(value) {
        const next = sortId(value);
        rememberSort(next);
        setSort(next);
        setPage(1);
        setSelected({});
        setError(null);
      }
      function chooseFilter(kind, value) {
        if (kind === "by") setProposedBy(value); else setAgreement(agreementId(value));
        setPage(1);
        setSelected({});
        setError(null);
      }
      // The Proposed by choices: every source the index names once it is read,
      // and until then the sources on this page.
      const sourceChoices = index.status === "ready" ? indexSources(index.entries) : indexSources((data.rows || []).map(function (row) {
        const labels = {};
        row.item.by.forEach(function (entry) { labels[entry.source] = entry.label; });
        return { by: row.item.by.map(function (entry) { return entry.source; }), labels: labels };
      }));
      if (proposedBy && !sourceChoices.some(function (entry) { return entry.key === proposedBy; })) sourceChoices.push({ key: proposedBy, label: proposedBy, count: 0 });

      const name = props.tag ? props.tag.name : "tag " + props.tagId;
      let body;
      if (bySort && index.status === "loading") {
        body = h("p", { className: "tps-status text-muted st-index-progress", role: "status" },
          (sort === "scene" ? "Filtering" : sort === "disagree" ? "Sorting by disagreement" : "Sorting by confidence") + ": reading the proposals" + (index.total != null ? " (" + index.loaded + " of " + index.total + " scenes)" : "") + "\u2026");
      } else if (data.status === "loading") body = h("p", { className: "tps-status text-muted", role: "status" }, "Loading proposals…");
      else if (data.status === "error") body = h("p", { className: "tps-error", role: "alert" }, data.error);
      else if (!visible.length) body = h("p", { className: "tps-empty text-muted" }, bySort
        ? (data.count && filtering ? "No proposals for " + name + " match the filters." : data.count && highOnly ? "No high-confidence proposals for " + name + "." : "No pending proposals for " + name + ".")
        : data.rows.length ? "No high-confidence proposals on this page." : "No pending proposals for " + name + ".");
      else {
        body = h("ul", { className: "tps-list st-scene-list" }, visible.map(function (row) {
          const id = row.scene.id;
          return h(ProposalCard, {
            key: id, row: row, selected: !!selected[id], busy: busy, formOpen: rowForm === id,
            onSelect: function (on) { const next = Object.assign({}, selected); next[id] = on; setSelected(next); },
            onDecide: function (kind, reason) { decide(kind, [id], reason); },
            onToggleForm: function () { setRowForm(rowForm === id ? null : id); },
          });
        }));
      }
      const pages = data.status === "ready" ? Math.max(1, Math.ceil(data.listed / PAGE_SIZE)) : 1;
      return h("section", { className: "st-tag-review", "data-tag": props.tagId, "data-sort": sort },
        h("h3", null, h(Link, { to: "/tags/" + props.tagId }, name), data.status === "ready" ? h("span", { className: "tps-summary text-muted st-count" },
          bySort && data.listed !== data.count ? " " + data.listed + " of " + data.count + " scenes" : " " + data.count + " scenes") : null),
        props.tag && props.tag.description ? h("p", { className: "st-definition text-muted" }, props.tag.description) : null,
        h("div", { className: "st-toolbar" },
          h("div", { className: "st-sort" },
            h("label", { htmlFor: "st-sort" }, "Sort"),
            h("select", { id: "st-sort", className: "form-control form-control-sm", value: sort, onChange: function (event) { chooseSort(event.target.value); } },
              SORTS.map(function (entry) { return h("option", { key: entry.id, value: entry.id }, entry.label); }))),
          h("div", { className: "st-sort st-filter" },
            h("label", { htmlFor: "st-filter-by" }, "Proposed by"),
            h("select", {
              id: "st-filter-by", className: "form-control form-control-sm", value: proposedBy,
              onFocus: function () { setWantIndex(true); }, onMouseDown: function () { setWantIndex(true); },
              onChange: function (event) { chooseFilter("by", event.target.value); },
            }, h("option", { value: "" }, "Any model"),
              sourceChoices.map(function (entry) { return h("option", { key: entry.key, value: entry.key }, entry.label + (index.status === "ready" ? " (" + entry.count + ")" : "")); }))),
          h("div", { className: "st-sort st-filter" },
            h("label", { htmlFor: "st-filter-agreement" }, "Agreement"),
            h("select", { id: "st-filter-agreement", className: "form-control form-control-sm", value: agreement, onChange: function (event) { chooseFilter("agreement", event.target.value); } },
              AGREEMENTS.map(function (entry) { return h("option", { key: entry.id, value: entry.id }, entry.label); }))),
          h("label", { className: "st-check" },
            h("input", { type: "checkbox", checked: visible.length > 0 && chosen.length === visible.length, disabled: !visible.length, onChange: function (event) { toggleAll(event.target.checked); } }),
            " Select all on this page"),
          h("label", { className: "st-check" },
            h("input", { type: "checkbox", checked: highOnly, onChange: function (event) { setHighOnly(event.target.checked); setSelected({}); if (bySort) setPage(1); } }),
            " High confidence only"),
          h("button", { type: "button", className: "btn btn-primary btn-sm st-accept-selected", disabled: !chosen.length || !!busy, onClick: function () { decide("accept", chosen); } },
            busy === "accept" ? "Adding…" : "Add to " + chosen.length + " selected"),
          h("button", { type: "button", className: "btn btn-secondary btn-sm st-reject-selected", disabled: !chosen.length || !!busy, onClick: function () { decide("reject", chosen); } },
            busy === "reject" ? "Rejecting…" : "Reject " + chosen.length + " selected"),
          h("button", { type: "button", className: "btn btn-link btn-sm st-reject-selected-reason", disabled: !chosen.length || !!busy, "aria-expanded": reasonOpen && chosen.length > 0,
            title: "Say why these proposals are wrong, then reject them", onClick: function () { setReasonOpen(!reasonOpen); } }, "Reject selected with reason\u2026")),
        reasonOpen && chosen.length ? h(FeedbackForm, {
          idKey: "bulk-" + props.tagId, label: "Reject the selected proposals with a reason", submitLabel: "Reject " + chosen.length + " selected with reason", busy: busy === "reject",
          onSubmit: function (reason) { decide("reject", chosen, reason); }, onCancel: function () { setReasonOpen(false); },
        }) : null,
        error ? h("p", { className: "tps-error", role: "alert" }, error) : null,
        body,
        pages > 1 ? h("div", { className: "st-pager" },
          h("button", { type: "button", className: "btn btn-secondary btn-sm", disabled: page <= 1, onClick: function () { setPage(page - 1); } }, "Previous"),
          h("span", null, "Page " + page + " of " + pages),
          h("button", { type: "button", className: "btn btn-secondary btn-sm", disabled: page >= pages, onClick: function () { setPage(page + 1); } }, "Next")) : null);
    }

    // Navbar button with the number of scenes that have proposals. Stash
    // renders utility items twice (in the bar, and in the menu that phones
    // expand) and its nav-utility class shows exactly one copy at any width.
    function NavButton() {
      const countPair = React.useState(null), count = countPair[0], setCount = countPair[1];
      React.useEffect(function () {
        let live = true;
        function load() { sharedTotal().then(function (n) { if (live) setCount(n); }, function () {}); }
        load();
        listeners.push(load);
        return function () { live = false; const index = listeners.indexOf(load); if (index !== -1) listeners.splice(index, 1); };
      }, []);
      // As Stash's own utility items: a link around a minimal Button. The
      // Button's own classes (btn-primary + minimal) are what colour its label.
      return h(Link, { to: ROUTE, className: "nav-link nav-utility st-nav-button" },
        h("button", { type: "button", tabIndex: -1, className: "btn btn-primary minimal", title: "Review AI tag proposals" },
          "AI tags", count ? h("span", { className: "badge badge-light st-nav-count", title: count + " scenes have proposals" }, count) : null));
    }

    return { SceneSection, ReviewPage: AiTagsPage, AiTagsPage, ReviewTab, TagReview, ProvidersTab, ProfilesTab, RunTab, RunForm, WorkerStatus, NavButton, EvaluateTab, EvalGroup, ListEvaluate, submitOutbox, resumeOutbox };
  }


  function install(PluginApi) {
    if (!PluginApi || !PluginApi.React) return;
    const components = createComponents(PluginApi);
    const sections = window.TagPerformerSuggestionsSections || (window.TagPerformerSuggestionsSections = []);
    if (!sections.some(function (section) { return section && section.id === ID; })) sections.push({ id: ID, component: components.SceneSection });
    if (PluginApi.register && PluginApi.register.route) PluginApi.register.route(ROUTE, components.ReviewPage);
    components.resumeOutbox();
    if (PluginApi.patch && PluginApi.patch.after) {
      // The scenes list's selection: Stash v0.31.1 patches its inner SceneList (src/components/Scenes/SceneList.tsx,
      // PatchComponent("SceneList")), which receives the selected IDs as `selectedIds` (a Set). The list's own
      // operations menu (ListOperations) is not patchable, so the Evaluate… action is a bar above the cards that
      // shows while scenes are selected.
      PluginApi.patch.after("SceneList", function () {
        const args = Array.prototype.slice.call(arguments), props = args[0], result = args[args.length - 1];
        if (!props || !props.selectedIds) return result;
        // The same wrapper whether or not scenes are selected, so the cards are not remounted when the selection starts.
        return PluginApi.React.createElement(PluginApi.React.Fragment, null, PluginApi.React.createElement(components.ListEvaluate, { key: ID + "-list-evaluate", selectedIds: props.selectedIds }), result);
      });
      PluginApi.patch.after("MainNavBar.UtilityItems", function () {
        const args = Array.prototype.slice.call(arguments), result = args[args.length - 1];
        return PluginApi.React.createElement(PluginApi.React.Fragment, null, PluginApi.React.createElement(components.NavButton, { key: ID }), result);
      });
    }
  }
  

  return {
    ID, WORKER_ID, ROUTE, FIELDS, LIMITS, CATEGORIES, PAGE_SIZE, QUERIES, WRITES, CONFIG_QUERY, CONFIGURE, OPENROUTER_URL, OPENROUTER_MODELS, OPENROUTER_ALL,
    decodeIds, encodeIds, parseProposals, sceneProposals, resolveChange, resolveReport, pendingFilter, DECLINES, AGREEMENTS, agreementOf, sourceRecord, cleanSourceList,
    agreementId, filtersActive, filterEntries, indexSources,
    parseApplied, sceneApplied, parseFeedback, cleanReason,
    normalizeSettings, parseNetworks, isLocalAddress, providerOf, modelChoices,
    updateFields, loadScenes, accept, reject, reportWrong, addByHand, proposalOf, reviewAnswer, reportAnswer, requestAnalysis, definedTags, pendingCounts, pendingTotal, tagScenes, fileName,
    TAG_LIMIT, formatDuration, resolutionLabel, sceneView, highlightSegments, limitTags,
    loadModels, readMaps, settingsMap, updateSettings, enqueueRequest,
    // settings model
    SCHEMA, PROVIDERS_KEY, PROFILES_KEY, ACTIVE_KEY, AUTO_KEY, NETWORKS_KEY, REQUESTS_KEY, SCHEMA_KEY, LEGACY_KEYS, CONFIG_PROVIDER, MAX_PROVIDERS, MAX_PROFILES, MAX_REQUESTS,
    MAX_PROFILE_NAME, MAX_CONCURRENCY, MAX_RUN_LIMIT, MAX_SCENE_IDS, REQUEST_MAX_AGE_MS, REQUEST_FRESH_MS, POLL_MS, SLOW_POLL_MS, CONNECT_WAIT_MS, CHECK_WAIT_MS, TIMING_GLOBAL, TIMING_DEFAULTS, timingOverrides, WORKER_PROTOCOL,
    OVERRIDE_KEYS, BUILTIN, REPLY_FORMATS, replyFormatOf, VERIFY_CHOICES, DECISIONS_MODEL, thresholdOf, thresholdsError, decisionsOn, decisionsProviderError, verifyText, verifyValue, MODES, REQUEST_KINDS, JOB_STATES, MODEL_OPTION_LIMIT, INDEX_PAGE, SORTS, SORT_STORAGE_KEY, TAB_IDS,
    stable, jsonValue, splitRouting, concurrencyOf, providerError, addressKey, hostOf, cleanDefaults, effectiveSetting, effectiveSettings, settingText,
    parseProviders, parseProfiles, parseLegacyProfiles, profilesUsing, activeProfileId, settingsOf, needsMigration, hasLegacySettings, migrateSettings,
    nameError, defaultsForm, defaultsError, defaultsFromForm, providerForm, formAddress, providerFormError, providerAddressError, providerFromForm, providerCheckDraft, checkedNote, oldWorkerCheck, profileForm, kindOfProvider, profileFormError, profileFromForm,
    saveChoice, saveProviderInput, deleteProviderInput, saveProfileInput, deleteProfileInput, setActiveInput, setAutoInput, setNetworksInput,
    requestId, makeRequest, parseRequests, pendingRequests, pruneRequests, addRequest, dropRequests, removeRequest, runRequest,
    parseModelLists, parseCandidates, eligibleView, usableChoices, droppedNote, NO_ELIGIBLE_TEXT, parseChecks, parseCheckEntry, parseJob, parseWorker, workerConnection, needsPolling, pollDelay, checkPhase, checkSummary, runDestination, listState, jobProgress,
    listIsStale, listAge, filterModels, modelFacts, tabOf, tabUrl,
    sortId, sortKey, sortEntries, indexEntry, loadIndex, cardScenes,
    // evaluation (0.7.0)
    EVAL_ANSWERS, EVAL_SOURCES, EVAL_QUEUE_SOURCES, EVAL_QUOTE_FIELDS, EVAL_METHODS, EVAL_HALVES, EVAL_OUTCOMES, EVAL_LIMITS, OUTBOX_KEY, RESEND_MS, OUTBOX_POLL_MS, LONG_REQUESTS,
    evalHash, evalHalf, evalTime, cleanQuotes, evalItem, cleanEvalItem, pairKey, emptyOutbox, parseOutbox, outboxCount, outboxText, outboxAdd, outboxRequest, outboxAck, outboxDismissRefused, outboxMarkSent, outboxStep, createOutboxStore, REFUSE_MS,
    mergeSceneAnswers, isRoleTag, carriedBy, answerKey, evidenceFrom, evaluateUrl,
    evalAnswersRequest, evalAnswersForRequest, evalQueueRequest, evalRunRequest, evalScoreRequest, evalDetailRequest, evalSceneRequest, queueKey,
    parseEvalAcks, parseEvalCounts, parseEvalAnswersFor, parseEvalQueues, parseEvalClaims, parseFigures, parseEvalRuns, parseEvalDetail, parseEvalScenes,
    cleanBy, answerSources, parseEvalBySource, decidedShare, precisionRange, precisionHeadline, recallParts, RECALL_NOTE,
    percentText, ratioText, precisionCounts, recallCounts, guessText, evidenceText, compareCheck, evalDestination,
    createComponents, install,
  };
});
