(function () {
    "use strict";

    var PluginApi = window.PluginApi;
    if (!PluginApi) {
        console.warn("[ratingShortcut] PluginApi not available");
        return;
    }

    var PLUGIN_ID = "ratingShortcut-testing";

    var React = PluginApi.React;
    var patch = PluginApi.patch;
    var StashService = PluginApi.utils.StashService;
    var Mousetrap = PluginApi.libraries.Mousetrap;
    var useConfiguration = StashService.useConfiguration;
    var useToast = PluginApi.hooks.useToast;

    var useSceneUpdate = StashService.useSceneUpdate;
    var usePerformerUpdate = StashService.usePerformerUpdate;
    var useEffect = React.useEffect;
    var useMemo = React.useMemo;
    var useRef = React.useRef;

    // ─── Default Settings ────────────────────────────────────────────────

    // Normalized defaults. Manifest BOOLEAN settings are named so that an
    // unset (unchecked) value means the default shown here.
    var DEFAULT_SETTINGS = {
        enableScenes: true,
        enablePerformers: true,
        coarseDecreaseShortcut: "shift+[",
        coarseIncreaseShortcut: "shift+]",
        fineDecreaseShortcut: "alt+[",
        fineIncreaseShortcut: "alt+]",
        coarseStep: 5,
        fineStep: 1,
        showSuccessToasts: true,
        ignoreEditableFields: true,
    };

    var SHORTCUT_KEYS = [
        "coarseDecreaseShortcut",
        "coarseIncreaseShortcut",
        "fineDecreaseShortcut",
        "fineIncreaseShortcut",
    ];

    // Stable fallback so an unconfigured plugin does not produce a new
    // settings object (and rebind every shortcut) on each render.
    var EMPTY_SETTINGS = {};

    // ─── Pure Helpers ────────────────────────────────────────────────────

    /**
     * Clamp a rating value between 0 and 100.
     * @param {number|null|undefined} value
     * @returns {number}
     */
    function clampRating(value) {
        var num = (value == null) ? 0 : Number(value);
        if (isNaN(num)) num = 0;
        return Math.max(0, Math.min(100, Math.floor(num)));
    }

    /**
     * Compute the next rating from a current value and delta, clamped.
     * @param {number|null|undefined} current
     * @param {number} delta
     * @returns {number}
     */
    function nextRating(current, delta) {
        return clampRating((current || 0) + delta);
    }

    var MODIFIER_PATTERN = /\b(shift|ctrl|alt|option|meta|command|mod)\b/gi;

    /**
     * Normalize a Mousetrap shortcut string. Spaces around "+" are removed
     * (Mousetrap treats spaces as key sequences) and modifier names are
     * lowercased so Mousetrap recognizes them.
     * @param {*} val
     * @param {string} fallback
     * @returns {string}
     */
    function normalizeShortcutString(val, fallback) {
        if (typeof val !== "string") return fallback;
        var normalized = val
            .trim()
            .replace(/\s*\+\s*/g, "+")
            .replace(/\s+/g, " ")
            .replace(MODIFIER_PATTERN, function (m) { return m.toLowerCase(); });
        return normalized ? normalized : fallback;
    }

    /**
     * Find shortcut setting keys whose value is used by more than one action.
     * @param {Object} s - settings containing SHORTCUT_KEYS
     * @returns {Array<string>}
     */
    function findConflictingShortcuts(s) {
        var counts = {};
        SHORTCUT_KEYS.forEach(function (key) {
            counts[s[key]] = (counts[s[key]] || 0) + 1;
        });
        return SHORTCUT_KEYS.filter(function (key) {
            return counts[s[key]] > 1;
        });
    }

    /**
     * Resolve duplicate shortcuts. Customized shortcuts involved in a
     * conflict revert to their defaults first; if that still leaves a
     * conflict, every shortcut reverts to its default.
     * @param {Object} s
     * @param {Function} warn
     */
    function resolveShortcutConflicts(s, warn) {
        var conflicts = findConflictingShortcuts(s);
        if (!conflicts.length) return;

        conflicts.forEach(function (key) {
            if (s[key] !== DEFAULT_SETTINGS[key]) {
                warn("Shortcut \"" + s[key] + "\" for " + key + " is used by another action; using default \"" + DEFAULT_SETTINGS[key] + "\".");
                s[key] = DEFAULT_SETTINGS[key];
            }
        });

        if (findConflictingShortcuts(s).length) {
            warn("Shortcut settings still conflict; using all default shortcuts.");
            SHORTCUT_KEYS.forEach(function (key) {
                s[key] = DEFAULT_SETTINGS[key];
            });
        }
    }

    /**
     * Validate a step value: must be a positive integer.
     * @param {*} val
     * @returns {number|null}
     */
    function validStep(val) {
        var n = Number(val);
        if (isNaN(n) || n <= 0 || !Number.isInteger(n)) return null;
        return n;
    }

    function isUnset(val) {
        return val == null || val === "";
    }

    /**
     * Normalize raw plugin settings, falling back to defaults for invalid values.
     * @param {Object|null|undefined} raw
     * @param {Function} [warn] - called with a message for each rejected value
     * @returns {Object}
     */
    function normalizeSettings(raw, warn) {
        raw = raw || EMPTY_SETTINGS;
        warn = warn || function () {};
        var s = {};

        s.enableScenes = raw.disableScenes !== true;
        s.enablePerformers = raw.disablePerformers !== true;
        s.showSuccessToasts = raw.hideSuccessToasts !== true;
        s.ignoreEditableFields = raw.allowInEditableFields !== true;

        SHORTCUT_KEYS.forEach(function (key) {
            s[key] = normalizeShortcutString(raw[key], DEFAULT_SETTINGS[key]);
        });
        resolveShortcutConflicts(s, warn);

        ["coarseStep", "fineStep"].forEach(function (key) {
            var step = validStep(raw[key]);
            if (step === null && !isUnset(raw[key])) {
                warn(key + " must be a positive whole number; using default " + DEFAULT_SETTINGS[key] + ".");
            }
            s[key] = step || DEFAULT_SETTINGS[key];
        });

        return s;
    }

    /**
     * Check if an event target is an editable control.
     * @param {HTMLElement} target
     * @returns {boolean}
     */
    function isEditableTarget(target) {
        if (!target) return false;
        var tag = target.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return true;
        if (target.isContentEditable) return true;
        return false;
    }

    /**
     * Check whether Stash's image lightbox is open. Stash pauses its global
     * Mousetrap while the lightbox is shown, which does not reach the
     * plugin's own instance, so the plugin checks for it directly. The
     * lightbox renders its root `.Lightbox` element only while visible.
     * @returns {boolean}
     */
    function isLightboxOpen() {
        return typeof document.querySelector === "function" && !!document.querySelector(".Lightbox");
    }

    /**
     * Create a shortcut map from settings for a given target type.
     * Returns an array of { shortcut, delta, label } objects.
     * @param {Object} settings
     * @param {string} targetType - "scene" or "performer"
     * @returns {Array}
     */
    function createShortcutMap(settings, targetType) {
        var enableKey = targetType === "scene" ? "enableScenes" : "enablePerformers";
        if (!settings[enableKey]) return [];

        return [
            { shortcut: settings.coarseDecreaseShortcut, delta: -settings.coarseStep, label: "coarse-decrease" },
            { shortcut: settings.coarseIncreaseShortcut, delta: settings.coarseStep, label: "coarse-increase" },
            { shortcut: settings.fineDecreaseShortcut, delta: -settings.fineStep, label: "fine-decrease" },
            { shortcut: settings.fineIncreaseShortcut, delta: settings.fineStep, label: "fine-increase" },
        ];
    }

    function formatNumber(n) {
        return String(Math.round(n * 100) / 100);
    }

    /**
     * Format a rating100 value in the user's Stash rating system
     * (Settings → Interface → Editing → Rating System). The raw 0–100 value
     * is appended when the display precision hides it.
     * @param {number} rating100
     * @param {Object} [ratingSystemOptions] - { type, starPrecision }
     * @returns {string}
     */
    function formatRating(rating100, ratingSystemOptions) {
        var options = ratingSystemOptions || {};
        var isDecimal = options.type === "decimal";
        var maxValue = isDecimal ? 10 : 5;
        var precision = 0.1;
        if (!isDecimal) {
            precision = { half: 0.5, quarter: 0.25, tenth: 0.1 }[options.starPrecision] || 1;
        }
        var denom = 100 / maxValue;
        // Same rounding as Stash's convertToRatingFormat.
        var inv = 1 / precision;
        var value = Math.round((rating100 / denom) * inv) / inv;

        var text = formatNumber(value) + "/" + maxValue + (isDecimal ? "" : " stars");
        if (Math.round(value * denom) !== rating100) {
            text += " (" + rating100 + "/100)";
        }
        return text;
    }

    // ─── Rating Controller ───────────────────────────────────────────────

    /**
     * Create a reusable rating controller for a scene or performer target.
     *
     * Only one update request is in flight at a time. Presses made while a
     * request is pending move a local target rating, and the latest target is
     * sent when the pending request settles, so the server always ends at the
     * last value the user asked for.
     *
     * @param {Object} options
     * @param {string} options.targetType - "scene" or "performer"
     * @param {number|string} options.id - entity id
     * @param {number} options.initialRating - current rating100
     * @param {Function} options.updateFn - GraphQL mutation function
     * @param {Object} [options.toast] - toast notification functions
     * @param {Function} [options.formatRating] - formats rating100 for messages
     * @param {Object} options.settings - normalized settings
     * @param {Object} options.mousetrapInstance - Mousetrap instance to bind on
     * @returns {Object} controller with syncRating and dispose methods
     */
    function createRatingController(options) {
        var targetType = options.targetType;
        var id = options.id;
        var updateFn = options.updateFn;
        var toast = options.toast;
        var format = options.formatRating || String;
        var settings = options.settings;
        var mousetrap = options.mousetrapInstance;

        // confirmedRating: last value the server is known to hold.
        // targetRating: value the user has asked for.
        // lastSyncedRating: last value seen from page props, so a stale
        // re-render with an unchanged prop cannot reset local state.
        var confirmedRating = clampRating(options.initialRating);
        var targetRating = confirmedRating;
        var lastSyncedRating = confirmedRating;
        var inFlight = false;

        var boundShortcuts = [];

        function errorMessage(error) {
            return (error && error.message) || String(error);
        }

        function sendLatest() {
            if (inFlight || targetRating === confirmedRating) return;

            var rating = targetRating;
            inFlight = true;

            var request;
            try {
                request = updateFn({
                    variables: {
                        input: {
                            id: id,
                            rating100: rating,
                        },
                    },
                });
            } catch (error) {
                request = Promise.reject(error);
            }

            Promise.resolve(request).then(
                function () {
                    inFlight = false;
                    confirmedRating = rating;
                    if (targetRating !== confirmedRating) {
                        sendLatest();
                        return;
                    }
                    if (settings.showSuccessToasts && toast && toast.success) {
                        var label = targetType === "scene" ? "Scene" : "Performer";
                        toast.success(label + " rating: " + format(rating));
                    }
                },
                function (error) {
                    inFlight = false;
                    targetRating = confirmedRating;
                    dispatchEvent(
                        new CustomEvent("ratingShortcut:error", {
                            detail: {
                                targetType: targetType,
                                id: id,
                                attemptedRating: rating,
                                error: errorMessage(error),
                            },
                            bubbles: true,
                        })
                    );
                    if (toast && toast.error) {
                        toast.error("Failed to update " + targetType + " rating: " + errorMessage(error));
                    }
                }
            );
        }

        /**
         * Handle a shortcut press.
         * @param {number} delta
         * @param {string} shortcut
         * @param {Event} [event]
         * @returns {boolean} true when the shortcut was handled
         */
        function handleShortcut(delta, shortcut, event) {
            if (isLightboxOpen()) return false;

            var target = (event && event.target) || document.activeElement;
            if (settings.ignoreEditableFields && isEditableTarget(target)) {
                return false;
            }

            var previousRating = targetRating;
            var newRating = clampRating(targetRating + delta);
            if (newRating === previousRating) return true;

            targetRating = newRating;

            dispatchEvent(
                new CustomEvent("ratingShortcut:changed", {
                    detail: {
                        targetType: targetType,
                        id: id,
                        previousRating: previousRating,
                        rating: newRating,
                        delta: delta,
                        shortcut: shortcut,
                    },
                    bubbles: true,
                })
            );

            sendLatest();
            return true;
        }

        var shortcuts = createShortcutMap(settings, targetType);
        shortcuts.forEach(function (sc) {
            var handler = function (event) {
                // Returning false makes Mousetrap prevent the browser default.
                if (handleShortcut(sc.delta, sc.shortcut, event)) return false;
            };
            mousetrap.bind(sc.shortcut, handler);
            boundShortcuts.push(sc.shortcut);
        });

        /**
         * Sync local state from a rating100 value in refreshed page props.
         * Ignored while an update is pending or when the value is unchanged.
         * @param {number} propRating
         */
        function syncRating(propRating) {
            var rating = clampRating(propRating);
            if (rating === lastSyncedRating) return;
            lastSyncedRating = rating;
            if (!inFlight && targetRating === confirmedRating) {
                confirmedRating = rating;
                targetRating = rating;
            }
        }

        /**
         * Unbind this controller's shortcuts. A pending update still
         * completes so the last press is not lost.
         */
        function dispose() {
            boundShortcuts.forEach(function (shortcut) {
                mousetrap.unbind(shortcut);
            });
            boundShortcuts.length = 0;
        }

        return {
            syncRating: syncRating,
            dispose: dispose,
        };
    }

    // ─── Page Wiring ─────────────────────────────────────────────────────

    // Mousetrap instances attach document listeners that cannot be removed,
    // so the plugin creates one instance and binds/unbinds on it per page.
    // It is separate from Stash's global instance, so unbinding never
    // removes Stash's or other plugins' handlers.
    var sharedMousetrap = null;

    function getSharedMousetrap() {
        if (!sharedMousetrap) {
            sharedMousetrap = new Mousetrap(document);
            // The controller applies the editable-field guard itself, so
            // Mousetrap's built-in input filter must not block events first.
            sharedMousetrap.stopCallback = function () {
                return false;
            };
        }
        return sharedMousetrap;
    }

    function readPluginSettings(config) {
        var plugins = config && config.data && config.data.configuration && config.data.configuration.plugins;
        return (plugins && plugins[PLUGIN_ID]) || EMPTY_SETTINGS;
    }

    function readRatingSystemOptions(config) {
        var ui = config && config.data && config.data.configuration && config.data.configuration.ui;
        return (ui && ui.ratingSystemOptions) || null;
    }

    function warnSetting(message) {
        console.warn("[ratingShortcut] " + message);
    }

    /**
     * Bind rating shortcuts for the mounted scene or performer page.
     * @param {string} targetType - "scene" or "performer"
     * @param {Object} entity - object with id and rating100
     * @param {Function} updateFn - GraphQL mutation function
     */
    function useRatingShortcut(targetType, entity, updateFn) {
        var config = useConfiguration();
        var rawSettings = readPluginSettings(config);
        var settingsKey = JSON.stringify(rawSettings);
        var settings = useMemo(function () {
            return normalizeSettings(rawSettings, warnSetting);
        }, [settingsKey]);
        var Toast = useToast();

        // Latest callbacks are read through a ref so the controller is only
        // recreated when the target or settings change.
        var latestRef = useRef(null);
        latestRef.current = {
            updateFn: updateFn,
            toast: Toast,
            ratingSystemOptions: readRatingSystemOptions(config),
        };

        var controllerRef = useRef(null);
        var id = entity.id;
        var rating = entity.rating100;

        useEffect(function () {
            var controller = createRatingController({
                targetType: targetType,
                id: id,
                initialRating: rating,
                updateFn: function (args) {
                    return latestRef.current.updateFn(args);
                },
                toast: {
                    success: function (message) {
                        if (latestRef.current.toast) latestRef.current.toast.success(message);
                    },
                    error: function (message) {
                        if (latestRef.current.toast) latestRef.current.toast.error(message);
                    },
                },
                formatRating: function (value) {
                    return formatRating(value, latestRef.current.ratingSystemOptions);
                },
                settings: settings,
                mousetrapInstance: getSharedMousetrap(),
            });
            controllerRef.current = controller;

            return function () {
                controller.dispose();
                if (controllerRef.current === controller) controllerRef.current = null;
            };
        }, [targetType, id, settings]);

        useEffect(function () {
            if (controllerRef.current) controllerRef.current.syncRating(rating);
        }, [rating]);
    }

    // ─── Test-Only Exports ───────────────────────────────────────────────

    if (window.__RATING_SHORTCUT_TEST__) {
        window.ratingShortcutTestApi = {
            DEFAULT_SETTINGS: DEFAULT_SETTINGS,
            clampRating: clampRating,
            nextRating: nextRating,
            normalizeShortcutString: normalizeShortcutString,
            normalizeSettings: normalizeSettings,
            createShortcutMap: createShortcutMap,
            isEditableTarget: isEditableTarget,
            isLightboxOpen: isLightboxOpen,
            formatRating: formatRating,
            createRatingController: createRatingController,
            useRatingShortcut: useRatingShortcut,
            getSharedMousetrap: getSharedMousetrap,
        };
    }

    // ─── Page Patches ────────────────────────────────────────────────────

    patch.before("ScenePage", function (props) {
        var updateScene = useSceneUpdate()[0];
        useRatingShortcut("scene", props.scene, updateScene);
        return [props];
    });

    patch.before("PerformerPage", function (props) {
        var updatePerformer = usePerformerUpdate()[0];
        useRatingShortcut("performer", props.performer, updatePerformer);
        return [props];
    });
})();
