(function (root, factory) {
  var api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root && root.PluginApi) api.install(root.PluginApi);
})(typeof window !== "undefined" ? window : globalThis, function (window) {
  "use strict";

  // Every Stash tab connects to each Stash Bridge controller plugin (Touch
  // Portal, Stream Deck), reports what it shows, and runs the commands a bridge
  // sends while it is that bridge's controlled tab. Each bridge decides which
  // tab that is.
  const ID = "touchPortalBridge-testing";
  const QUICK_TAGGER_ID = "quickTagger-testing";
  const PROTOCOL = 1;
  const DEFAULTS = Object.freeze({ bridgeUrl: "ws://127.0.0.1:47821, ws://127.0.0.1:47822", bridgeToken: "", hideIndicator: false, paletteTagPrefix: "Deck:", quietTab: false });
  // Quick Tagger's own defaults, used when its settings were never saved.
  const QUICK_TAGGER_DEFAULTS = Object.freeze({ createMissingTags: true, applyToPerformerScenes: true, scanAfterUpdate: false, waitForScan: true, markerPrerollSeconds: 5 });
  // A controller that is not running is retried every 30 seconds.
  const RECONNECT_DELAYS_MS = [1000, 2000, 5000, 10000, 10000, 30000];
  const COVER_SIZE = 144;
  const UNDO_LIMIT = 20;
  const RECENT_LIMIT = 24;
  const SUGGESTION_LIMIT = 8;
  // Holding a seek key plays at this speed (rewinding is simulated by seeking).
  const HOLD_RATE = 16;
  const REWIND_TICK_MS = 50;
  // Releasing a fast seek returns to where the video was this long ago, to
  // make up for the time it takes to react.
  const REACTION_MS = 400;
  const STORAGE = { recent: "touchPortalBridge:recentTags", session: "touchPortalBridge:session" };
  const STATE_INTERVAL_MS = 1000;
  const PLAYER_POLL_MS = 1000;
  const FLASH_MS = 2500;
  const REFRESH_QUERIES = ["FindScene", "FindSceneMarkerTags", "FindPerformer"];
  const ROUTES = Object.freeze({
    Scenes: "/scenes", Performers: "/performers", Markers: "/scenes/markers", Studios: "/studios",
    Tags: "/tags", Galleries: "/galleries", Images: "/images",
  });
  const LIST_ROOTS = ["scenes", "performers", "images", "galleries", "studios", "tags", "groups", "movies"];
  const DETAIL_LISTS = ["studios", "tags", "groups", "movies"];

  const QUERY_CONFIG = "query TouchPortalBridgeConfig { configuration { plugins general { logLevel } } }";
  const TAG_FIELDS = "tags { id name custom_fields }";
  const QUERY_SCENE = "query TouchPortalBridgeScene($id: ID!) { findScene(id: $id) { id title rating100 organized files { basename duration } paths { screenshot } performers { id name } studio { name } scene_markers { seconds } " + TAG_FIELDS + " } }";
  const QUERY_PERFORMER = "query TouchPortalBridgePerformer($id: ID!) { findPerformer(id: $id) { id name rating100 " + TAG_FIELDS + " } }";
  const QUERY_TAG_BY_NAME = "query TouchPortalBridgeTagByName($name: String!) { findTags(tag_filter: { name: { value: $name, modifier: EQUALS } }, filter: { per_page: 20 }) { tags { id name custom_fields } } }";
  const QUERY_TAG_NAMES = "query TouchPortalBridgeTagNames($ids: [ID!]) { findTags(ids: $ids) { tags { id name } } }";
  const QUERY_PALETTES = "query TouchPortalBridgePalettes($prefix: String!) { findTags(tag_filter: { name: { value: $prefix, modifier: INCLUDES } }, filter: { per_page: -1 }) { tags { id name sort_name children { id name sort_name } } } }";
  const UPDATE_SCENE = "mutation TouchPortalBridgeUpdateScene($input: SceneUpdateInput!) { sceneUpdate(input: $input) { id rating100 organized } }";
  const UPDATE_PERFORMER = "mutation TouchPortalBridgeUpdatePerformer($input: PerformerUpdateInput!) { performerUpdate(input: $input) { id rating100 } }";
  const DESTROY_MARKER = "mutation TouchPortalBridgeDestroyMarker($id: ID!) { sceneMarkerDestroy(id: $id) }";
  const REMOVE_FROM_SCENE = {
    tag: "mutation TouchPortalBridgeRemoveSceneTag($ids: [ID!], $remove: [ID!]) { bulkSceneUpdate(input: { ids: $ids, tag_ids: { ids: $remove, mode: REMOVE } }) { id } }",
    performer: "mutation TouchPortalBridgeRemoveScenePerformer($ids: [ID!], $remove: [ID!]) { bulkSceneUpdate(input: { ids: $ids, performer_ids: { ids: $remove, mode: REMOVE } }) { id } }",
  };
  const RUN_OPERATION = "mutation TouchPortalBridgeQuickTagger($plugin_id: ID!, $args: Map) { runPluginOperation(plugin_id: $plugin_id, args: $args) }";
  const QUERY_PLUGINS = "query TouchPortalBridgePlugins { plugins { id enabled } }";

  // ---- Pure helpers --------------------------------------------------------

  // Stash routes are relative to the <base href> the UI is served under.
  function routePath(pathname, base) {
    const prefix = String(base || "/").replace(/\/+$/, "");
    let path = String(pathname || "/");
    if (prefix && path.indexOf(prefix + "/") === 0) path = path.slice(prefix.length);
    else if (prefix && path === prefix) path = "/";
    return path || "/";
  }

  // `list` is true where the URL holds a list filter: list pages, and the
  // detail pages of performers, studios, tags, and groups, whose open tab
  // (scenes, images, …) reads its filter from the URL the same way.
  function pageKind(path) {
    const parts = String(path || "/").split("/").filter(Boolean);
    const detail = /^\d+$/.test(parts[1] || "");
    if (parts[0] === "scenes" && detail) return { page: "scene", sceneId: parts[1] };
    if (parts[0] === "performers" && detail) return { page: "performer", performerId: parts[1], list: true };
    if (detail && DETAIL_LISTS.indexOf(parts[0]) >= 0) return { page: "list", list: true };
    if (parts.length === 1 && LIST_ROOTS.indexOf(parts[0]) >= 0) return { page: "list", list: true };
    if (parts[0] === "scenes" && parts[1] === "markers" && parts.length === 2) return { page: "list", list: true };
    return { page: "other" };
  }

  // Next marker after `time`, or the previous one before it. The margins let
  // repeated presses step past the marker the player is sitting on.
  function markerTime(seconds, time, direction) {
    const sorted = seconds.filter(function (s) { return Number.isFinite(s); }).sort(function (a, b) { return a - b; });
    if (direction > 0) return sorted.find(function (s) { return s > time + 0.5; });
    const earlier = sorted.filter(function (s) { return s < time - 1.5; });
    return earlier.length ? earlier[earlier.length - 1] : undefined;
  }

  function formatTime(seconds) {
    const total = Math.max(0, Math.floor(Number(seconds) || 0));
    const m = Math.floor(total / 60), s = String(total % 60).padStart(2, "0");
    return m + ":" + s;
  }

  // Arguments for Quick Tagger's task, matching what its own dialogs send.
  function quickTaggerArgs(kind, context, text, create, settings, seconds) {
    const config = Object.assign({}, QUICK_TAGGER_DEFAULTS, settings || {});
    const createMissingTags = !!create && config.createMissingTags !== false;
    if (kind === "marker") {
      return { mode: "createMarker", sceneId: context.sceneId, targetType: "scene", text: text, seconds: seconds, createMissingTags: createMissingTags, markerPrerollSeconds: config.markerPrerollSeconds };
    }
    return {
      mode: "applyTag", targetType: context.targetType, targetId: context.targetId, text: text, createMissingTags: createMissingTags,
      applyToPerformerScenes: config.applyToPerformerScenes, scanAfterUpdate: config.scanAfterUpdate, waitForScan: config.waitForScan,
      markerPrerollSeconds: config.markerPrerollSeconds,
    };
  }

  // { "curly": { plain, user, marker, performer } } for a scene's or
  // performer's tags. Quick Tagger's sub-tags count toward their concept,
  // found by custom field: `conceptNames` maps concept IDs to names.
  function tagStateOf(tags, conceptNames) {
    const state = {};
    (tags || []).forEach(function (tag) {
      const fields = tag.custom_fields || {};
      const role = fields.quickTagger_role ? String(fields.quickTagger_role) : "";
      const name = role ? conceptNames[String(fields.quickTagger_concept)] : tag.name;
      if (!name) return;
      const key = String(name).toLowerCase();
      state[key] = state[key] || {};
      state[key][role || "plain"] = true;
    });
    return state;
  }

  function conceptIds(tags) {
    const ids = [];
    (tags || []).forEach(function (tag) {
      const concept = tag.custom_fields && tag.custom_fields.quickTagger_concept;
      if (concept && ids.indexOf(String(concept)) < 0) ids.push(String(concept));
    });
    return ids;
  }

  // Palettes from tags named "<prefix> <name>": each child tag is a key.
  function palettesOf(tags, prefix) {
    const start = String(prefix || "").trim().toLowerCase();
    if (!start) return [];
    const bySortName = function (a, b) { return String(a.sort_name || a.name).localeCompare(String(b.sort_name || b.name)); };
    return (tags || [])
      .filter(function (tag) { return String(tag.name).toLowerCase().indexOf(start) === 0 && (tag.children || []).length; })
      .sort(bySortName)
      .map(function (tag) {
        return { name: String(tag.name).slice(start.length).trim() || tag.name, tags: tag.children.slice().sort(bySortName).map(function (child) { return child.name; }) };
      });
  }

  function pushRecent(list, name, limit) {
    const key = String(name).toLowerCase();
    return [name].concat((list || []).filter(function (entry) { return String(entry).toLowerCase() !== key; })).slice(0, limit || RECENT_LIMIT);
  }

  // Stash's queue panel lists the loaded part of the queue; Stash loads more
  // as it plays through. `position` counts from the start of the queue.
  function queueFromDom(document) {
    const list = document && document.querySelector("#queue-content ol");
    if (!list) return null;
    const items = Array.prototype.slice.call(list.children);
    const index = items.findIndex(function (item) { return item.classList && item.classList.contains("current"); });
    if (index < 0) return null;
    const start = Number(list.getAttribute("start")) || 1;
    const more = !!(list.nextElementSibling && list.nextElementSibling.querySelector && list.nextElementSibling.querySelector("button"));
    return { position: start + index, total: start + items.length - 1, more: more };
  }

  // ---- List filters (the URL of a Stash list page) ----
  //
  // Stash keeps a list's filter in its URL and rereads it when the URL
  // changes: sortby, sortdir, p (page), and one c per criterion, a JSON object
  // with { } written as ( ) outside strings.

  // Stash's own encoding: swaps { } and ( ) outside JSON strings.
  function translateCriterion(text, decoding) {
    let inString = false, escaped = false, out = "";
    for (const c of String(text)) {
      if (escaped) { escaped = false; out += c; continue; }
      if (c === "\\" && inString) escaped = true;
      else if (c === '"') inString = !inString;
      else if (!inString && decoding && (c === "(" || c === ")")) { out += c === "(" ? "{" : "}"; continue; }
      else if (!inString && !decoding && (c === "{" || c === "}")) { out += c === "{" ? "(" : ")"; continue; }
      out += c;
    }
    return out;
  }

  function encodeCriterion(criterion) {
    let text = encodeURI(translateCriterion(JSON.stringify(criterion), false));
    ["?", "#", "&", ";", "=", "+"].forEach(function (c) { text = text.split(c).join(encodeURIComponent(c)); });
    return text;
  }

  function parseListQuery(search) {
    const query = new URLSearchParams(search || "");
    const criteria = query.getAll("c").map(function (c) {
      try { return JSON.parse(translateCriterion(c, true)); } catch (_) { return null; }
    }).filter(Boolean);
    const other = [];
    query.forEach(function (value, key) { if (["c", "sortby", "sortdir", "p"].indexOf(key) < 0) other.push([key, value]); });
    return { sortby: query.get("sortby") || "", sortdir: query.get("sortdir") || "", page: Number(query.get("p")) || 1, criteria: criteria, other: other };
  }

  function buildListQuery(list) {
    const parts = [];
    list.other.forEach(function (pair) { parts.push(pair[0] + "=" + encodeURIComponent(pair[1])); });
    list.criteria.forEach(function (criterion) { parts.push("c=" + encodeCriterion(criterion)); });
    if (list.sortby) parts.push("sortby=" + encodeURIComponent(list.sortby));
    if (list.sortdir) parts.push("sortdir=" + list.sortdir);
    if (list.page > 1) parts.push("p=" + list.page);
    return parts.length ? "?" + parts.join("&") : "";
  }

  // Stash sorts by date newest first unless told otherwise; other fields ascend.
  function sortDirection(list) {
    if (list.sortdir === "asc" || list.sortdir === "desc") return list.sortdir;
    return !list.sortby || list.sortby === "date" ? "desc" : "asc";
  }

  function tagCriterion(list) {
    return list.criteria.find(function (c) { return c.type === "tags"; }) || null;
  }

  // What the controllers show for a list's filter.
  function describeList(list) {
    const tags = tagCriterion(list);
    const value = (tags && tags.value) || {};
    const organized = list.criteria.find(function (c) { return c.type === "organized"; });
    return {
      sort: list.sortby ? (/^random/.test(list.sortby) ? "random" : list.sortby) : "default",
      direction: sortDirection(list),
      page: list.page,
      included: (value.items || []).map(function (t) { return t.label; }),
      excluded: (value.excluded || []).map(function (t) { return t.label; }),
      organized: organized ? organized.value === true || organized.value === "true" : null,
      filters: list.criteria.length,
    };
  }

  // Returns the list with `tag` ({ id, label }) toggled in or out of the tags
  // criterion: "include" requires it, "exclude" leaves it out. A new filter
  // includes sub-tags, so Quick Tagger's "A (user)" and "A (marker)" count as A.
  function toggleTagFilter(list, tag, mode) {
    const criteria = list.criteria.map(function (c) { return JSON.parse(JSON.stringify(c)); });
    let criterion = criteria.find(function (c) { return c.type === "tags"; });
    if (!criterion) {
      criterion = { type: "tags", modifier: "INCLUDES_ALL", value: { items: [], excluded: [], depth: -1 } };
      criteria.push(criterion);
    }
    const value = criterion.value = Object.assign({ items: [], excluded: [], depth: 0 }, criterion.value || {});
    const same = function (t) { return String(t.id) === String(tag.id); };
    const field = mode === "exclude" ? "excluded" : "items";
    const other = mode === "exclude" ? "items" : "excluded";
    const had = value[field].some(same);
    value[other] = value[other].filter(function (t) { return !same(t); });
    value[field] = had ? value[field].filter(function (t) { return !same(t); }) : value[field].concat([{ id: String(tag.id), label: tag.label }]);
    if (criterion.modifier !== "INCLUDES_ALL" && criterion.modifier !== "INCLUDES") criterion.modifier = "INCLUDES_ALL";
    const kept = criteria.filter(function (c) { return c !== criterion || c.value.items.length || c.value.excluded.length; });
    return Object.assign({}, list, { criteria: kept, page: 1 });
  }

  // Any → not organized → organized → any.
  function cycleOrganized(list) {
    const current = list.criteria.find(function (c) { return c.type === "organized"; });
    const rest = list.criteria.filter(function (c) { return c !== current; });
    const now = current ? current.value === true || current.value === "true" : null;
    const next = now === null ? "false" : now === false ? "true" : null;
    return Object.assign({}, list, { criteria: next === null ? rest : rest.concat([{ type: "organized", modifier: "EQUALS", value: next }]), page: 1 });
  }

  function starsText(rating100) {
    return rating100 == null ? "no rating" : (Math.round((rating100 / 20) * 10) / 10) + "★";
  }

  function reconnectDelay(attempt) {
    return RECONNECT_DELAYS_MS[Math.min(attempt, RECONNECT_DELAYS_MS.length - 1)];
  }

  function bridgeUrls(text) {
    const urls = String(text || "").split(/[\s,]+/).filter(Boolean);
    return urls.filter(function (url, index) { return urls.indexOf(url) === index; });
  }

  // "Touch Portal", "Touch Portal and Stream Deck (pinned)": the bridges whose
  // controlled tab this is.
  function indicatorText(targets) {
    const active = targets.filter(function (t) { return t.active; });
    if (!active.length) return "";
    const names = active.map(function (t) { return t.bridge || "Touch Portal"; }).sort();
    const pinned = active.some(function (t) { return t.pinned; }) ? " (pinned)" : "";
    return names.join(" and ") + pinned;
  }

  // ---- Browser runtime -----------------------------------------------------

  function install(PluginApi) {
    if (!window.document || window.__touchPortalBridgeInstalled) return;
    window.__touchPortalBridgeInstalled = true;
    const document = window.document;
    const baseHref = (document.querySelector("base") && document.querySelector("base").getAttribute("href")) || "/";
    const graphqlUrl = new URL("graphql", window.location.origin + baseHref.replace(/\/?$/, "/")).toString();

    // One link per bridge URL: { url, socket, attempt, timer, target }.
    const links = new Map();
    let settings = Object.assign({}, DEFAULTS);
    let quickTaggerSettings = {};
    // Whether Stash logs at Debug or Trace, so debug messages are worth sending.
    let logDebug = false;
    let route = pageKind(routePath(window.location.pathname, baseHref));
    let scene = null;
    let performer = null;
    let video = null;
    let savedRate = null;
    let lastStateAt = 0;
    let stateTimer = null;
    let indicator = null;
    let flashEl = null;
    let flashTimer = null;
    let detailsToken = 0;
    // Changes made through a controller, newest last: { id, label, revert }.
    const undoStack = [];
    let undoSequence = 0;
    let interest = { suggestions: false };
    let suggestions = null;
    let palettes = [];
    let hold = null;

    function gql(query, variables) {
      return fetch(graphqlUrl, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: query, variables: variables || {} }),
      }).then(function (r) { return r.json(); }).then(function (json) {
        if (json.errors && json.errors.length) throw new Error(json.errors[0].message || "GraphQL error");
        return json.data;
      });
    }

    async function loadSettings() {
      try {
        const data = await gql(QUERY_CONFIG);
        const plugins = (data && data.configuration && data.configuration.plugins) || {};
        settings = Object.assign({}, DEFAULTS, plugins[ID] || {});
        // An empty prefix means palettes are off; unset means the default.
        if (plugins[ID] && plugins[ID].paletteTagPrefix === undefined) settings.paletteTagPrefix = DEFAULTS.paletteTagPrefix;
        quickTaggerSettings = plugins[QUICK_TAGGER_ID] || {};
        const level = String((data.configuration.general && data.configuration.general.logLevel) || "").toLowerCase();
        logDebug = level === "debug" || level === "trace";
      } catch (_) { /* keep the previous settings */ }
    }

    // ---- Player ----

    // The scene player's own video; marker previews in the sidebar are videos too.
    function findVideo() {
      return route.page === "scene" ? document.querySelector(".scene-player-container video") : null;
    }

    function videoJs() {
      const utils = PluginApi.utils && PluginApi.utils.InteractiveUtils;
      try { return utils && utils.getPlayer ? utils.getPlayer() : null; } catch (_) { return null; }
    }

    // video.js handles transcoded streams' time offsets, so it is preferred.
    const player = {
      time: function () { const p = videoJs(); return p ? Number(p.currentTime()) || 0 : video ? video.currentTime || 0 : 0; },
      duration: function () {
        const p = videoJs();
        const d = p ? Number(p.duration()) : video ? video.duration : NaN;
        return Number.isFinite(d) && d > 0 ? d : (scene && scene.duration) || 0;
      },
      paused: function () { const p = videoJs(); return p ? !!p.paused() : video ? video.paused : true; },
      rate: function () { const p = videoJs(); return p ? Number(p.playbackRate()) || 1 : video ? video.playbackRate || 1 : 1; },
      seek: function (t) { const p = videoJs(); if (p) p.currentTime(t); else if (video) video.currentTime = t; },
      play: function () { const p = videoJs(); return Promise.resolve(p ? p.play() : video && video.play()).catch(function () {}); },
      pause: function () { const p = videoJs(); if (p) p.pause(); else if (video) video.pause(); },
      setRate: function (r) { const p = videoJs(); if (p) p.playbackRate(r); else if (video) video.playbackRate = r; },
    };

    const VIDEO_EVENTS = ["play", "pause", "ratechange", "seeked", "durationchange", "loadedmetadata", "emptied", "ended"];
    function onVideoEvent() { sendState(true); }
    function onTimeUpdate() { sendState(false); }

    function bindVideo() {
      const next = findVideo();
      if (next === video) return;
      if (video) {
        VIDEO_EVENTS.forEach(function (name) { video.removeEventListener(name, onVideoEvent); });
        video.removeEventListener("timeupdate", onTimeUpdate);
      }
      video = next;
      savedRate = null;
      cancelHold();
      if (video) {
        VIDEO_EVENTS.forEach(function (name) { video.addEventListener(name, onVideoEvent); });
        video.addEventListener("timeupdate", onTimeUpdate);
      }
      sendState(true);
    }

    // ---- Page details ----

    // `keep` refreshes the current page's details without clearing them first.
    async function loadDetails(keep) {
      const token = (detailsToken += 1);
      if (!keep) { scene = null; performer = null; suggestions = null; }
      try {
        if (route.page === "scene") {
          const data = await gql(QUERY_SCENE, { id: route.sceneId });
          const s = data && data.findScene;
          if (token !== detailsToken || !s) return;
          const file = s.files && s.files[0];
          const names = await conceptNames(s.tags);
          if (token !== detailsToken) return;
          scene = {
            id: String(s.id),
            rating100: s.rating100 == null ? null : Number(s.rating100),
            organized: !!s.organized,
            performerIds: (s.performers || []).map(function (p) { return String(p.id); }),
            tagState: tagStateOf(s.tags, names),
            screenshot: (s.paths && s.paths.screenshot) || "",
            title: s.title || (file && file.basename) || "",
            performers: (s.performers || []).map(function (p) { return p.name; }),
            studio: s.studio ? s.studio.name : "",
            duration: file ? Number(file.duration) || 0 : 0,
            markers: (s.scene_markers || []).map(function (m) { return Number(m.seconds); }),
          };
        } else if (route.page === "performer") {
          const data = await gql(QUERY_PERFORMER, { id: route.performerId });
          const p = data && data.findPerformer;
          if (token !== detailsToken || !p) return;
          const names = await conceptNames(p.tags);
          if (token !== detailsToken) return;
          performer = { id: String(p.id), name: p.name || "", rating100: p.rating100 == null ? null : Number(p.rating100), tagState: tagStateOf(p.tags, names) };
        }
      } catch (_) { /* the bridge still sees the page kind */ }
      if (token === detailsToken) { sendState(true); loadCover(); loadSuggestions(); }
    }

    async function conceptNames(tags) {
      const ids = conceptIds(tags);
      if (!ids.length) return {};
      const data = await gql(QUERY_TAG_NAMES, { ids: ids });
      const names = {};
      ((data && data.findTags && data.findTags.tags) || []).forEach(function (tag) { names[String(tag.id)] = tag.name; });
      return names;
    }

    // ---- Palettes, recent tags, session counts ----

    function readStorage(key, fallback) {
      try { const value = JSON.parse(window.localStorage.getItem(key)); return value == null ? fallback : value; } catch (_) { return fallback; }
    }

    function writeStorage(key, value) {
      try { window.localStorage.setItem(key, JSON.stringify(value)); } catch (_) { /* storage is optional */ }
    }

    function rememberTag(name) {
      writeStorage(STORAGE.recent, pushRecent(readStorage(STORAGE.recent, []), name));
    }

    function session() {
      return Object.assign({ since: Date.now(), scenes: 0, tags: 0, markers: 0 }, readStorage(STORAGE.session, {}));
    }

    function count(field) {
      const current = session();
      current[field] += 1;
      writeStorage(STORAGE.session, current);
    }

    async function loadPalettes() {
      const prefix = String(settings.paletteTagPrefix || "").trim();
      let next = [];
      if (prefix) {
        try {
          const data = await gql(QUERY_PALETTES, { prefix: prefix });
          next = palettesOf(data && data.findTags && data.findTags.tags, prefix);
        } catch (_) { next = palettes; }
      }
      palettes = next;
      sendPalettes();
    }

    function sendPalettes(link) {
      const message = JSON.stringify({ type: "palettes", palettes: palettes });
      (link ? [link] : Array.from(links.values())).forEach(function (l) { if (isOpen(l)) l.socket.send(message); });
    }

    // ---- Suggestions (from the Tag & Performer Suggestions plugin) ----

    function suggestionsApi() {
      const api = window.TagPerformerSuggestions;
      return api && typeof api.computeSuggestions === "function" ? api : null;
    }

    async function loadSuggestions() {
      if (!interest.suggestions || route.page !== "scene" || !scene) return;
      const api = suggestionsApi();
      const sceneId = scene.id;
      if (!api) { suggestions = { sceneId: sceneId, status: "unavailable", items: [] }; sendState(true); return; }
      if (suggestions && suggestions.sceneId === sceneId) return;
      suggestions = { sceneId: sceneId, status: "loading", items: [] };
      sendState(true);
      try {
        const result = await api.computeSuggestions(api.createReader(gql), { type: "scene", id: sceneId });
        if (!scene || scene.id !== sceneId) return;
        const items = (result.tags || []).map(function (t) { return { kind: "tag", id: String(t.id), name: t.name, why: t.support + "/" + t.total }; })
          .concat((result.performers || []).map(function (p) { return { kind: "performer", id: String(p.id), name: p.name, why: p.support + "/" + p.total }; }));
        suggestions = { sceneId: sceneId, status: items.length ? "ready" : "none", items: items };
      } catch (error) {
        suggestions = { sceneId: sceneId, status: "error", items: [], error: String(error && error.message || error) };
      }
      sendState(true);
    }

    function onInterest(message) {
      const wanted = Array.from(links.values()).some(function (l) { return l.interest && l.interest.suggestions; });
      interest = { suggestions: wanted };
      if (wanted) loadSuggestions();
    }

    // ---- Undo ----

    function pushUndo(label, revert) {
      undoStack.push({ id: "u" + (undoSequence += 1), label: label, revert: revert });
      if (undoStack.length > UNDO_LIMIT) undoStack.shift();
    }

    // The scene's cover, small enough for a Stream Deck key. The tab fetches
    // it because only the tab is signed in to Stash.
    let cover = null;
    function loadCover() {
      const current = scene;
      if (!current || !current.screenshot || (cover && cover.sceneId === current.id)) { sendCover(); return; }
      const image = new window.Image();
      image.onload = function () {
        if (scene !== current) return;
        try {
          const canvas = document.createElement("canvas");
          canvas.width = COVER_SIZE;
          canvas.height = COVER_SIZE;
          const side = Math.min(image.naturalWidth, image.naturalHeight);
          canvas.getContext("2d").drawImage(image, (image.naturalWidth - side) / 2, (image.naturalHeight - side) / 2, side, side, 0, 0, COVER_SIZE, COVER_SIZE);
          cover = { sceneId: current.id, image: canvas.toDataURL("image/jpeg", 0.8) };
        } catch (_) { cover = { sceneId: current.id, image: "" }; }
        sendCover();
      };
      image.onerror = function () { if (scene === current) { cover = { sceneId: current.id, image: "" }; sendCover(); } };
      image.src = current.screenshot;
    }

    function sendCover(link) {
      const message = JSON.stringify({ type: "cover", sceneId: cover && scene && cover.sceneId === scene.id ? cover.sceneId : "", image: cover && scene && cover.sceneId === scene.id ? cover.image : "" });
      (link ? [link] : Array.from(links.values())).forEach(function (l) { if (isOpen(l)) l.socket.send(message); });
    }

    function onLocation() {
      const next = pageKind(routePath(window.location.pathname, baseHref));
      const changed = next.page !== route.page || next.sceneId !== route.sceneId || next.performerId !== route.performerId;
      route = next;
      if (changed) { loadDetails(); bindVideo(); loadPalettes(); }
      sendState(true);
    }

    // ---- State reports ----

    function snapshot() {
      const hasPlayer = !!video;
      return {
        type: "state",
        focused: typeof document.hasFocus === "function" ? document.hasFocus() : true,
        visible: document.visibilityState !== "hidden",
        page: route.page,
        path: routePath(window.location.pathname, baseHref),
        scene: scene ? { id: scene.id, title: scene.title, performers: scene.performers, studio: scene.studio, duration: scene.duration, rating100: scene.rating100, organized: scene.organized, performerCount: scene.performerIds.length } : null,
        performer: performer ? { id: performer.id, name: performer.name, rating100: performer.rating100 } : null,
        // Tags on what quick tags apply to: the scene, or the performer.
        tagState: route.page === "scene" && scene ? scene.tagState : route.page === "performer" && performer ? performer.tagState : null,
        queue: route.page === "scene" ? queueFromDom(document) : null,
        list: route.list ? describeList(parseListQuery(window.location.search)) : null,
        undo: undoStack.length ? { id: undoStack[undoStack.length - 1].id, label: undoStack[undoStack.length - 1].label } : null,
        session: session(),
        recentTags: readStorage(STORAGE.recent, []),
        suggestions: interest.suggestions && suggestions ? { status: suggestions.status, items: suggestions.items.slice(0, SUGGESTION_LIMIT) } : null,
        hold: hold ? hold.direction : 0,
        player: hasPlayer ? { paused: player.paused(), time: player.time(), duration: player.duration(), rate: player.rate() } : null,
      };
    }

    // Discrete changes go out at once; playback time at most once a second.
    function isOpen(link) {
      return !!(link && link.socket && link.socket.readyState === 1 && link.socket.welcomed);
    }

    function sendState(immediate) {
      const open = Array.from(links.values()).filter(isOpen);
      if (!open.length) return;
      const elapsed = Date.now() - lastStateAt;
      if (!immediate && elapsed < STATE_INTERVAL_MS) {
        if (!stateTimer) stateTimer = setTimeout(function () { stateTimer = null; sendState(true); }, STATE_INTERVAL_MS - elapsed);
        return;
      }
      clearTimeout(stateTimer);
      stateTimer = null;
      lastStateAt = Date.now();
      const message = JSON.stringify(snapshot());
      open.forEach(function (link) { link.socket.send(message); });
    }

    // ---- Feedback ----

    function showIndicator() {
      const targets = Array.from(links.values()).filter(function (l) { return isOpen(l) && l.target; }).map(function (l) { return l.target; })
        .filter(function (t) { return t.tabs > 1 || t.pinned; });
      const text = indicatorText(targets);
      const visible = !!text && !settings.hideIndicator;
      if (!visible) { if (indicator) indicator.style.display = "none"; return; }
      if (!indicator) {
        indicator = document.createElement("div");
        indicator.className = "touch-portal-bridge-indicator";
        indicator.setAttribute("role", "status");
        indicator.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:1050;padding:3px 10px;border-radius:12px;font-size:12px;" +
          "background:rgba(32,120,200,.9);color:#fff;pointer-events:none;box-shadow:0 1px 4px rgba(0,0,0,.4)";
        document.body.appendChild(indicator);
      }
      indicator.textContent = text;
      indicator.style.display = "block";
    }

    function flash(text, ok) {
      if (!flashEl) {
        flashEl = document.createElement("div");
        flashEl.className = "touch-portal-bridge-flash";
        flashEl.setAttribute("role", "status");
        flashEl.style.cssText = "position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:1060;padding:6px 14px;border-radius:6px;" +
          "font-size:14px;color:#fff;pointer-events:none;box-shadow:0 2px 8px rgba(0,0,0,.5)";
        document.body.appendChild(flashEl);
      }
      flashEl.textContent = text;
      flashEl.style.background = ok === "warn" ? "rgba(190,120,20,.95)" : ok ? "rgba(40,140,70,.95)" : "rgba(180,40,40,.95)";
      flashEl.style.display = "block";
      clearTimeout(flashTimer);
      flashTimer = setTimeout(function () { flashEl.style.display = "none"; }, FLASH_MS);
    }

    function refreshStash() {
      const service = PluginApi.utils && PluginApi.utils.StashService;
      const client = service && service.getClient ? service.getClient() : null;
      if (!client || !client.refetchQueries) return Promise.resolve();
      return Promise.resolve(client.refetchQueries({ include: REFRESH_QUERIES })).catch(function () {});
    }

    // ---- Commands ----

    function requirePlayer() {
      if (!video) throw new Error("No scene is playing in this tab");
    }

    function navigate(to) {
      if (to === "Back") { window.history.back(); return "Back"; }
      if (to === "Forward") { window.history.forward(); return "Forward"; }
      const path = ROUTES[to];
      if (!path) throw new Error("Unknown page " + to);
      // react-router's history ignores pop events without its { key, state } shape.
      const state = { key: Math.random().toString(36).slice(2, 8), state: undefined };
      window.history.pushState(state, "", baseHref.replace(/\/+$/, "") + path);
      window.dispatchEvent(new PopStateEvent("popstate", { state: state }));
      return "Opened " + to;
    }

    function tagContext() {
      if (route.page === "scene") return { targetType: "scene", targetId: route.sceneId };
      if (route.page === "performer") return { targetType: "performer", targetId: route.performerId };
      throw new Error("Open a scene or performer to quick tag");
    }

    function subjectName() {
      return route.page === "scene" ? (scene && scene.title) || "scene" : (performer && performer.name) || "performer";
    }

    // Stash 0.31 crashes the request ("invalid memory address or nil pointer
    // dereference") when runPluginOperation names a plugin that is not
    // installed, so check first and say what is missing.
    async function requireQuickTagger() {
      const data = await gql(QUERY_PLUGINS);
      const plugin = ((data && data.plugins) || []).find(function (p) { return p.id === QUICK_TAGGER_ID; });
      if (!plugin) throw new Error("Quick Tagger is not installed (plugin ID " + QUICK_TAGGER_ID + "); install it from the same package source as this plugin");
      if (!plugin.enabled) throw new Error("Quick Tagger (" + QUICK_TAGGER_ID + ") is turned off in Settings → Plugins");
    }

    async function runQuickTagger(args) {
      await requireQuickTagger();
      const data = await gql(RUN_OPERATION, { plugin_id: QUICK_TAGGER_ID, args: args });
      return (data && data.runPluginOperation) || {};
    }

    async function refreshAfterEdit() {
      await refreshStash();
      await loadDetails(true);
    }

    async function quickTag(args) {
      const text = String(args.text || "").trim();
      if (!text) throw new Error("No tag text");
      const context = tagContext();
      const subject = subjectName();
      await loadSettings();
      const result = await runQuickTagger(quickTaggerArgs("tag", context, text, args.create, quickTaggerSettings, 0));
      const changedScenes = (result.updated && result.updated.scenes) || [];
      rememberTag(text);
      await refreshAfterEdit();
      if (!result.added && !changedScenes.length) return subject + " already has " + text;
      count("tags");
      // An undo takes back only what this press added.
      pushUndo("tag " + text + (context.targetType === "performer" ? " on " + subject : ""), function () {
        return runQuickTagger({
          mode: "removeTag", targetType: context.targetType, targetId: context.targetId, text: text,
          sceneIds: context.targetType === "performer" ? changedScenes : undefined, keepTarget: !result.added,
        });
      });
      return "Tagged " + subject + " with " + text;
    }

    async function removeTag(args) {
      const text = String(args.text || "").trim();
      if (!text) throw new Error("No tag text");
      const context = tagContext();
      const subject = subjectName();
      await loadSettings();
      const result = await runQuickTagger({ mode: "removeTag", targetType: context.targetType, targetId: context.targetId, text: text });
      const removed = result.removed || { scenes: [], performers: [] };
      await refreshAfterEdit();
      if (!removed.scenes.length && !removed.performers.length) return subject + " has no " + text + " of yours to remove";
      pushUndo("remove " + text + (context.targetType === "performer" ? " from " + subject : ""), function () {
        return runQuickTagger(quickTaggerArgs("tag", context, text, false, quickTaggerSettings, 0));
      });
      return "Removed " + text + " from " + subject;
    }

    async function quickMarker(args) {
      const text = String(args.text || "").trim();
      if (!text) throw new Error("No tag text");
      if (route.page !== "scene") throw new Error("Open a scene to add a marker");
      requirePlayer();
      await loadSettings();
      const seconds = player.time();
      const result = await runQuickTagger(quickTaggerArgs("marker", { sceneId: route.sceneId }, text, args.create, quickTaggerSettings, seconds));
      const marker = result.marker;
      count("markers");
      rememberTag(text);
      if (marker && marker.id) {
        pushUndo("marker " + text + " at " + formatTime(marker.seconds), function () { return gql(DESTROY_MARKER, { id: marker.id }); });
      }
      await refreshAfterEdit();
      return "Marker " + text + " at " + formatTime(seconds);
    }

    function ratingTarget() {
      if (route.page === "scene" && scene) return { kind: "scene", item: scene };
      if (route.page === "performer" && performer) return { kind: "performer", item: performer };
      throw new Error("Open a scene or performer to rate it");
    }

    function setRating(kind, id, value) {
      return gql(kind === "scene" ? UPDATE_SCENE : UPDATE_PERFORMER, { input: { id: id, rating100: value } });
    }

    // `value` sets a rating (0 clears it); `step` changes it.
    async function rate(args) {
      await loadDetails(true);
      const target = ratingTarget();
      const from = target.item.rating100;
      const hasValue = args.value !== undefined && args.value !== null && args.value !== "";
      const to = Math.max(0, Math.min(100, Math.round(hasValue ? Number(args.value) : (from || 0) + Number(args.step || 0))));
      const value = to === 0 ? null : to;
      if (value === from) return "Rating stays " + starsText(from);
      const id = target.item.id;
      await setRating(target.kind, id, value);
      pushUndo("rating " + starsText(from) + " → " + starsText(value), function () { return setRating(target.kind, id, from); });
      await refreshAfterEdit();
      return "Rated " + starsText(value);
    }

    async function organize(args) {
      await loadDetails(true);
      if (route.page !== "scene" || !scene) throw new Error("Open a scene to mark it organized");
      const id = scene.id, from = scene.organized;
      const to = args.value === undefined || args.value === null ? !from : !!args.value;
      if (to === from) return to ? "Already organized" : "Already not organized";
      await gql(UPDATE_SCENE, { input: { id: id, organized: to } });
      pushUndo(to ? "organized" : "not organized", function () { return gql(UPDATE_SCENE, { input: { id: id, organized: from } }); });
      await refreshAfterEdit();
      return to ? "Organized" : "Not organized";
    }

    // Stash's own queue shortcuts (p n, p p, p r), so Stash keeps its queue,
    // autoplay, and continue settings.
    function queueMove(direction) {
      const keys = { next: "p n", previous: "p p", random: "p r" }[direction];
      if (!keys) throw new Error("Unknown queue direction " + direction);
      if (route.page !== "scene") throw new Error("Open a scene from a list to use its queue");
      if (!queueFromDom(document) && !/[?&](qfp|qs)=/.test(window.location.search)) throw new Error("This scene was not opened from a list, so there is no queue");
      const Mousetrap = PluginApi.libraries && PluginApi.libraries.Mousetrap;
      if (!Mousetrap || typeof Mousetrap.trigger !== "function") throw new Error("Stash's queue shortcuts are unavailable");
      Mousetrap.trigger(keys);
      if (direction !== "previous") count("scenes");
      return { next: "Next scene", previous: "Previous scene", random: "Random scene" }[direction];
    }

    // Holding plays at HOLD_RATE forward, or rewinds at it by seeking back.
    // Release restores the speed and play state and, after a fast hold,
    // returns to where the video was REACTION_MS ago (never past the start).
    function startHold(direction, link) {
      requirePlayer();
      // A hold that starts during another (both seek keys, or two controllers)
      // restores what the first one found, not the first one's 16x or pause.
      const previous = cancelHold();
      const startTime = player.time();
      hold = {
        direction: direction > 0 ? 1 : -1, link: link, wasPaused: previous ? previous.wasPaused : player.paused(), rate: previous ? previous.rate : player.rate(),
        startTime: startTime, samples: [{ at: Date.now(), time: startTime }], timer: null,
      };
      if (hold.direction > 0) { player.setRate(HOLD_RATE); if (player.paused()) player.play(); } else player.pause();
      const current = hold;
      current.timer = setInterval(function () {
        if (hold !== current) return;
        if (current.direction < 0) player.seek(Math.max(0, player.time() - (HOLD_RATE * REWIND_TICK_MS) / 1000));
        current.samples.push({ at: Date.now(), time: player.time() });
        if (current.samples.length > 40) current.samples.shift();
      }, REWIND_TICK_MS);
      return current.direction > 0 ? "Fast forward " + HOLD_RATE + "x" : "Rewind " + HOLD_RATE + "x";
    }

    function cancelHold() {
      if (!hold) return null;
      const current = hold;
      hold = null;
      clearInterval(current.timer);
      return current;
    }

    function releaseHold(jumpBack) {
      const current = cancelHold();
      if (!current) return "Not seeking";
      player.setRate(current.rate || 1);
      if (jumpBack !== false) {
        const cutoff = Date.now() - REACTION_MS;
        const earlier = current.samples.filter(function (sample) { return sample.at <= cutoff; }).pop() || current.samples[0];
        const target = current.direction > 0 ? Math.max(current.startTime, earlier.time) : Math.min(current.startTime, earlier.time);
        if (Math.abs(target - player.time()) >= 0.1) player.seek(target);
      }
      if (current.wasPaused) player.pause(); else if (current.direction < 0) player.play();
      return "At " + formatTime(player.time());
    }

    async function suggestion(args) {
      if (!scene || !suggestions || suggestions.sceneId !== scene.id) throw new Error("No suggestions for this scene yet");
      const item = suggestions.items.find(function (i) { return i.kind === args.kind && i.id === String(args.id); });
      if (!item) throw new Error("That suggestion is no longer listed");
      suggestions.items = suggestions.items.filter(function (i) { return i !== item; });
      if (args.action === "dismiss") return "Dismissed " + item.name;
      const api = suggestionsApi();
      if (!api) throw new Error("Install the Tag & Performer Suggestions plugin first");
      const sceneId = scene.id;
      try {
        await api.addToItem(gql, { type: "scene", id: sceneId }, item.kind, item.id);
      } catch (error) {
        suggestions.items.unshift(item);
        throw error;
      }
      pushUndo("add " + item.kind + " " + item.name, function () { return gql(REMOVE_FROM_SCENE[item.kind], { ids: [sceneId], remove: [item.id] }); });
      if (item.kind === "tag") { count("tags"); rememberTag(item.name); }
      await refreshAfterEdit();
      return "Added " + item.kind + " " + item.name;
    }

    async function frameImage(args) {
      const api = window.SceneFramePerformerImage;
      if (!api) throw new Error("Install the Scene Frame Performer Image plugin first");
      if (route.page !== "scene" || !scene) throw new Error("Open a scene first");
      if (args.mode !== "save") { api.open(); return "Opened the frame picker"; }
      if (scene.performerIds.length !== 1) throw new Error(scene.performerIds.length ? "This scene has several performers; choose one in the frame picker" : "This scene has no performers");
      const result = await api.quickSave({ performerId: scene.performerIds[0], replaceImage: args.replaceImage });
      if (result.needsConfirmation) return { text: result.performer + " already has an image", data: { needsConfirmation: true, image: result.image, performer: result.performer } };
      return "Saved this frame as " + result.performer + "'s image";
    }

    async function findTag(name) {
      const data = await gql(QUERY_TAG_BY_NAME, { name: name });
      const tags = ((data && data.findTags && data.findTags.tags) || []).filter(function (t) { return String(t.name).toLowerCase() === String(name).toLowerCase(); });
      // The plain tag, not one of Quick Tagger's sub-tags.
      const plain = tags.find(function (t) { return !(t.custom_fields && t.custom_fields.quickTagger_role); }) || tags[0];
      if (!plain) throw new Error("No tag named " + name);
      return { id: String(plain.id), label: plain.name };
    }

    function showList(list) {
      const search = buildListQuery(list);
      const state = { key: Math.random().toString(36).slice(2, 8), state: undefined };
      window.history.pushState(state, "", window.location.pathname + search);
      window.dispatchEvent(new PopStateEvent("popstate", { state: state }));
    }

    // Changes the open list's filter through its URL, as Stash's own filter
    // dialog does.
    async function listFilter(args) {
      if (!route.list) throw new Error("Open a list (scenes, performers, a studio's scenes, …) to filter it");
      let list = parseListQuery(window.location.search);
      let text;
      switch (args.op) {
        case "sort": {
          const field = String(args.field || "").trim();
          if (!field) throw new Error("No sort field");
          const same = list.sortby === field;
          list = Object.assign({}, list, { sortby: field, sortdir: same ? (sortDirection(list) === "asc" ? "desc" : "asc") : field === "date" || field === "rating" || field === "created_at" || field === "updated_at" ? "desc" : "asc", page: 1 });
          text = "Sorted by " + field + " " + (list.sortdir === "asc" ? "↑" : "↓");
          break;
        }
        case "direction":
          list = Object.assign({}, list, { sortdir: sortDirection(list) === "asc" ? "desc" : "asc", page: 1 });
          text = list.sortdir === "asc" ? "Ascending" : "Descending";
          break;
        case "shuffle":
          list = Object.assign({}, list, { sortby: "random_" + Math.floor(Math.random() * 1e8), sortdir: "", page: 1 });
          text = "Shuffled";
          break;
        case "organized": {
          list = cycleOrganized(list);
          const organized = describeList(list).organized;
          text = organized === null ? "Any organized state" : organized ? "Organized only" : "Not organized only";
          break;
        }
        case "clear":
          list = Object.assign({}, list, { criteria: [], page: 1 });
          text = "Filters cleared";
          break;
        case "page":
          list = Object.assign({}, list, { page: Math.max(1, list.page + (Number(args.step) || 1)) });
          text = "Page " + list.page;
          break;
        case "tag": {
          const tag = await findTag(String(args.name || "").trim());
          const mode = args.mode === "exclude" ? "exclude" : "include";
          list = toggleTagFilter(list, tag, mode);
          const shown = describeList(list);
          text = shown.included.indexOf(tag.label) >= 0 ? "Showing only " + tag.label : shown.excluded.indexOf(tag.label) >= 0 ? "Hiding " + tag.label : "No longer filtering " + tag.label;
          break;
        }
        default:
          throw new Error("Unknown filter " + args.op);
      }
      showList(list);
      return text;
    }

    async function undo(args) {
      const top = undoStack[undoStack.length - 1];
      if (!top) throw new Error("Nothing to undo");
      if (args.id && args.id !== top.id) throw new Error("The undo list changed; check the key and press again");
      undoStack.pop();
      try { await top.revert(); } catch (error) { throw new Error("Could not undo " + top.label + ": " + (error && error.message ? error.message : error)); }
      await refreshAfterEdit();
      return "Undid " + top.label;
    }

    async function runCommand(name, args, link) {
      args = args || {};
      switch (name) {
        case "togglePlay":
          requirePlayer();
          if (player.paused()) { await player.play(); return "Playing"; }
          player.pause(); return "Paused";
        case "play": requirePlayer(); await player.play(); return "Playing";
        case "pause": requirePlayer(); player.pause(); return "Paused";
        case "seekBy": {
          requirePlayer();
          const duration = player.duration();
          const target = Math.max(0, Math.min(duration || Infinity, player.time() + Number(args.seconds || 0)));
          player.seek(target);
          return "At " + formatTime(target);
        }
        case "seekTo": {
          requirePlayer();
          const target = Math.max(0, Math.min(1, Number(args.fraction) || 0)) * player.duration();
          player.seek(target);
          return "At " + formatTime(target);
        }
        case "setRate":
          requirePlayer();
          if (savedRate == null) savedRate = player.rate();
          player.setRate(Number(args.rate) || 2);
          return "Speed " + player.rate() + "x";
        case "restoreRate":
          requirePlayer();
          player.setRate(savedRate == null ? 1 : savedRate);
          savedRate = null;
          return "Speed " + player.rate() + "x";
        case "toggleRate": {
          requirePlayer();
          const rate = Number(args.rate) || 2;
          player.setRate(player.rate() === rate ? 1 : rate);
          savedRate = null;
          return "Speed " + player.rate() + "x";
        }
        case "seekMarker": {
          requirePlayer();
          await loadDetails(true);
          const target = markerTime((scene && scene.markers) || [], player.time(), Number(args.direction) || 1);
          if (target === undefined) throw new Error(Number(args.direction) < 0 ? "No earlier marker" : "No later marker");
          player.seek(target);
          return "Marker at " + formatTime(target);
        }
        case "quickTag": return quickTag(args);
        case "removeTag": return removeTag(args);
        case "quickMarker": return quickMarker(args);
        case "navigate": return navigate(args.to);
        case "rating": return rate(args);
        case "organized": return organize(args);
        case "queue": return queueMove(args.direction);
        case "holdSeek": return startHold(Number(args.direction) || 1, link);
        case "releaseSeek": return releaseHold(args.jumpBack);
        case "suggestion": return suggestion(args);
        case "frameImage": return frameImage(args);
        case "undo": return undo(args);
        case "listFilter": return listFilter(args);
        case "sessionReset":
          writeStorage(STORAGE.session, { since: Date.now(), scenes: 0, tags: 0, markers: 0 });
          return "Session counts reset";
        // Controllers ask for a second press before removing anything; this
        // shows that question in the tab too.
        case "notify":
          if (!settings.quietTab) flash(String(args.text || ""), args.level === "error" ? false : "warn");
          return "";
        default: throw new Error("Unknown command " + name);
      }
    }

    // Commands whose result is also shown at the top of the tab.
    const QUIET_COMMANDS = ["notify"];
    const FLASHED = ["quickTag", "removeTag", "quickMarker", "rating", "organized", "suggestion", "frameImage", "undo", "sessionReset"];

    function onCommand(link, message) {
      const args = message.args || {};
      const feedback = FLASHED.indexOf(message.name) >= 0 && !settings.quietTab;
      // State reports, notifications, and hold ticks are too frequent to log.
      if (QUIET_COMMANDS.indexOf(message.name) < 0) stashLog("debug", "command " + message.name + " " + JSON.stringify(args) + " from " + link.url);
      Promise.resolve().then(function () { return runCommand(message.name, args, link); }).then(function (value) {
        const result = value && typeof value === "object" ? value : { text: value == null ? "" : String(value) };
        // "Then next scene": move on once the change is saved.
        if (args.then === "next") {
          try { result.text += " · " + queueMove("next"); } catch (error) { result.text += " · " + error.message; }
        }
        if (feedback && result.text) flash(result.text, true);
        reply(link, message.id, true, result.text, result.data);
      }, function (error) {
        const text = String(error && error.message ? error.message : error);
        stashLog("error", "command " + message.name + " " + JSON.stringify(args) + " failed: " + text);
        if (feedback) flash(text, false);
        reply(link, message.id, false, text);
      }).then(function () { sendState(true); });
    }

    // Writes to Stash's log (Settings → Logs) through this plugin's log
    // operation, at most LOG_BURST messages per LOG_WINDOW_MS. Debug messages
    // are sent only while Stash's log level is Debug or Trace.
    const LOG_BURST = 20, LOG_WINDOW_MS = 10000;
    let logTimes = [];
    function stashLog(level, message) {
      if (level === "debug" && !logDebug) return;
      const now = Date.now();
      logTimes = logTimes.filter(function (t) { return now - t < LOG_WINDOW_MS; });
      if (logTimes.length >= LOG_BURST) return;
      logTimes.push(now);
      gql(RUN_OPERATION, { plugin_id: ID, args: { level: level, message: String(message) } }).catch(function () { /* logging must never fail a command */ });
    }

    function reply(link, id, ok, text, data) {
      if (link.socket && link.socket.readyState === 1) link.socket.send(JSON.stringify(data ? { type: "result", id: id, ok: ok, message: text, data: data } : { type: "result", id: id, ok: ok, message: text }));
    }

    // ---- Connection ----

    function scheduleReconnect(link) {
      clearTimeout(link.timer);
      link.timer = setTimeout(function () { open(link); }, reconnectDelay(link.attempt));
      link.attempt += 1;
    }

    function open(link) {
      if (links.get(link.url) !== link) return;
      const token = String(settings.bridgeToken || "").trim();
      let ws;
      try { ws = new WebSocket(link.url); } catch (_) { scheduleReconnect(link); return; }
      link.socket = ws;
      ws.onopen = function () { ws.send(JSON.stringify(token ? { type: "hello", protocol: PROTOCOL, token: token } : { type: "hello", protocol: PROTOCOL })); };
      ws.onmessage = function (event) {
        let message;
        try { message = JSON.parse(event.data); } catch (_) { return; }
        if (message.type === "welcome") { stashLog("debug", "connected to " + link.url); ws.welcomed = true; link.attempt = 0; sendState(true); sendCover(link); sendPalettes(link); }
        else if (message.type === "interest") { link.interest = message; onInterest(); }
        else if (message.type === "command") onCommand(link, message);
        else if (message.type === "target") { link.target = message; showIndicator(); }
      };
      ws.onclose = function () {
        if (link.socket !== ws) return;
        if (ws.welcomed) stashLog("debug", "disconnected from " + link.url);
        link.socket = null;
        link.target = null;
        link.interest = null;
        // A hold whose release can no longer arrive stops here.
        if (hold && hold.link === link) releaseHold(false);
        showIndicator();
        scheduleReconnect(link);
      };
    }

    // Opens a link per configured bridge URL; links whose URL was removed close.
    async function connect() {
      await loadSettings();
      const urls = bridgeUrls(settings.bridgeUrl || DEFAULTS.bridgeUrl);
      links.forEach(function (link, url) {
        if (urls.indexOf(url) >= 0) return;
        links.delete(url);
        clearTimeout(link.timer);
        if (link.socket) link.socket.close();
      });
      loadPalettes();
      urls.forEach(function (url) {
        if (links.has(url)) return;
        const link = { url: url, socket: null, attempt: 0, timer: null, target: null };
        links.set(url, link);
        open(link);
      });
    }

    function onFocusChange() { sendState(true); }
    window.addEventListener("focus", onFocusChange);
    window.addEventListener("blur", onFocusChange);
    document.addEventListener("visibilitychange", onFocusChange);
    if (PluginApi.Event && PluginApi.Event.addEventListener) PluginApi.Event.addEventListener("stash:location", onLocation);
    window.addEventListener("popstate", onLocation);
    // Stash replaces the player element when the source changes.
    setInterval(bindVideo, PLAYER_POLL_MS);
    loadDetails();
    connect();
  }

  return {
    install: install, routePath: routePath, pageKind: pageKind, markerTime: markerTime, quickTaggerArgs: quickTaggerArgs,
    reconnectDelay: reconnectDelay, formatTime: formatTime, bridgeUrls: bridgeUrls, indicatorText: indicatorText,
    tagStateOf: tagStateOf, conceptIds: conceptIds, palettesOf: palettesOf, pushRecent: pushRecent, queueFromDom: queueFromDom, starsText: starsText,
    translateCriterion: translateCriterion, parseListQuery: parseListQuery, buildListQuery: buildListQuery, describeList: describeList, toggleTagFilter: toggleTagFilter, cycleOrganized: cycleOrganized,
  };
});
