// Writes a message from the Touch Portal Bridge tab script into Stash's log.
// The tab runs this as a plugin operation with { level, message }, so
// controller errors appear under Settings → Logs next to Stash's own entries.
// Stash prefixes each line with "[Plugin / Touch Portal Bridge]".
(function (root) {
  "use strict";

  var LEVELS = { trace: "Trace", debug: "Debug", info: "Info", warning: "Warn", warn: "Warn", error: "Error" };
  var MAX_LENGTH = 2000;

  // The Stash log method for `level`; unknown levels log as Info.
  function methodFor(level) {
    return LEVELS[String(level || "").toLowerCase()] || "Info";
  }

  function format(message) {
    var text = String(message == null ? "" : message);
    if (text.length > MAX_LENGTH) text = text.slice(0, MAX_LENGTH) + "…";
    return text;
  }

  function writeLog(logger, args) {
    var method = methodFor(args && args.level);
    logger[method](format(args && args.message));
    return { logged: true };
  }

  function main() {
    try {
      return { Output: writeLog(log, input.Args || {}) };
    } catch (err) {
      return { Error: String(err && err.message ? err.message : err) };
    }
  }

  var api = { methodFor: methodFor, format: format, writeLog: writeLog, MAX_LENGTH: MAX_LENGTH };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.TouchPortalBridgeLog = api;

  if (typeof input !== "undefined") {
    return main();
  }
})(this);
