# quickTaggerMigration

Quick Tagger Migration converts the tags that Quick Tagger 1.x, 2.x, and 3.x left in a Stash library to Quick Tagger 4's tag model (see [Quick Tagger's tag model](../quickTagger/README.md#tag-model)). Run it once, then remove the plugin. It has two tasks and no UI. It works without Quick Tagger installed, but is meant to run beside Quick Tagger 4: Quick Tagger's marker hooks run while the migration moves markers, and the migration allows for that.

Requires Stash with custom fields on tags (v0.31.1 is tested).

## What older versions left

For a tag "A":

- **1.x** added `A_USR` to a scene you quick-tagged. A quick marker had primary tag plain A and title "A", and also added `A_USR` to its scene. Quick tagging a performer added plain A to the performer and copied **all** of the performer's tags to their scenes as plain tags. Late builds also added plain A next to `A_USR` on a scene.
- **2.x** used `A` plus its `tagSuffix` setting (default `_USR`): on quick-tagged scenes and performers, and (by default) copied from a performer to all their scenes. A quick marker had primary tag `A_USR` (and `A_USR` as a secondary tag) and added nothing to its scene.
- **3.0** added `A (performer)` to a tagged performer's scenes and made sub-tags without a category parent. Because it saw an unmigrated `A_USR` as a plain tag, picking it in the dialog made `A_USR (user)`, a marker with primary tag `A_USR` made `A_USR (marker)`, and tagging a performer with it made `A_USR (performer)`.

## Running it

1. Turn off any stable Quick Tagger 3.x copy (see [Stable and testing copies](#stable-and-testing-copies)).
2. Open Settings → Logs and keep it open, then run **Migrate legacy tags (dry run)** from Settings → Tasks. Stash keeps only its 30 newest log lines, but the Logs page shows every line written while it is open; set a log file (Settings → System → Logging) to keep them all. The dry run changes nothing and writes:
   - per legacy tag: what it becomes, how many scenes, markers, and performers it is on, which scenes lose it and why (with their scene IDs), which markers move, and why a tag would be skipped;
   - the `(performer)` tags it would delete, the category tags it would create, and the sub-tags that would get their category parent;
   - how many scenes the closing marker tag resync would change, the `(marker)` tags it would create, and a warning for any it cannot create because a tag you made already uses the name;
   - last, a one-line summary: tags to migrate, scene tags to drop, markers to move, and the tags it would skip.
3. With the Logs page still open, run **Migrate legacy tags**. When there is anything to change, it first backs up the database with Stash's `backupDatabase` (to the configured backup directory; tag images are not in this backup). It then logs each legacy tag as it finishes it ("A_USR (3 of 12): …"), the task's progress bar moves with every marker it moves, and it ends with the same one-line summary. A migration should log no errors; one that does is a bug worth reporting. With nothing to change it does nothing, so running it again is safe.
4. Check the log, then remove this plugin.

If a run is interrupted (cancelled, or Stash restarted), the log shows the last legacy tag it finished. Running it again finishes the job. The legacy tag it was working on may then keep some 1.x markers on primary tag A instead of moving them to **A (marker)**; restore your own backup first if you want that tag migrated exactly.

## What it does

For each tag whose name ends in `_USR` (any case) and that Quick Tagger does not already manage (it has no `quickTagger_role` custom field):

1. It finds plain A by name or alias, and creates A if it is missing.
2. It removes `A_USR` from the scenes where it does not mean "you tagged this scene":
   - **1.x markers:** the scene has a 1.x quick marker (primary tag plain A, title equal to A's name in any case, no secondary tags; 1.x added `A_USR` with it) and no 2.x or 3.x quick marker (primary `A_USR` or one of A's sub-tags), which would show the tag was added on purpose. The scene keeps **A (marker)**. Other markers with primary tag A, such as ones made in Stash's editor with another title or with secondary tags, say nothing about `A_USR`, so it stays as **A (user)**.
   - **2.x performer copies:** one of the scene's performers also has `A_USR`. The performer becomes **A (user)**, so the Performer Tags filter (and the Stash Bridge controllers' *performer* status) still finds the scene.
3. It turns `A_USR (user)` and `A_USR (marker)` from 3.0 into A's sub-tags: renamed in place when A has none yet (keeping the tag ID), otherwise merged into A's. A user tag that 3.0 added to a scene is kept.
4. Markers move to **A (marker)**:
   - markers with primary tag `A_USR` (2.x), with `A_USR` removed from their secondary tags;
   - 1.x quick markers: primary tag plain A, title equal to A's name (any case), no secondary tags, on a scene that has `A_USR`. A marker made by hand in Stash's editor that matches all of this moves too; one with another title or with secondary tags keeps primary A.

   Moving a marker runs Quick Tagger's marker hook, which may make another `A_USR (marker)`, so step 3 runs again afterwards.
5. `A_USR` becomes **A (user)**:
   - **If A (user) does not exist,** `A_USR` is renamed to it in place. The tag ID stays, so every link (scenes, performers, galleries, images, markers), its image, aliases, parents, children, and description are kept; `A_USR` becomes an alias; and A and **Quick Tagger: user** are added to its parents.
   - **If A (user) exists** (you tagged with Quick Tagger 4 before migrating), `A_USR`'s parents are added to **A (user)**, its child tags move under **A (user)**, and it is merged into **A (user)** with Stash's tag merge, which moves every link and alias and keeps `A_USR` as an alias. A merge does not keep `A_USR`'s description, image, or favorite flag; the dry run warns when `A_USR` has an image.

Then, for the whole library:

6. Every `(performer)` sub-tag is deleted. A marker that uses one as its primary tag moves to that tag's **A (marker)** first, because Stash will not delete a marker's primary tag. Deleting a `(performer)` tag also removes it from anything else it was added to by hand.
7. Sub-tags without their category parent get it, and the marker tags are resynced on every scene with markers. This can add **X (marker)** for markers made in Stash's editor that never had one; the dry run counts them.

Moving a marker runs Quick Tagger's marker hook on that scene. The migration orders its steps so the hook never tries to make a tag whose name is taken: an `A_USR (marker)` merged into an existing **A (marker)** is merged only after all of `A_USR`'s markers have moved, and an `A_USR (marker)` alias left on **A (marker)** by an interrupted run is removed, for every legacy tag, before any markers move, and put back afterwards. Quick Tagger checks a tag name is free before creating a tag, so a name already used by a tag you made does not make it send a request Stash would refuse.

A failure in one step is logged as an error, and the remaining steps still run.

### When a legacy tag is skipped

A skipped tag is logged with the reason and left unchanged. Fix the cause and run the migration again:

- A tag that Quick Tagger does not manage already uses `A (user)`, or `A (marker)` while A's markers need it, as its name or an alias. Rename or merge that tag by hand.
- A 3.0 sub-tag (`A_USR (user)` or `A_USR (marker)`) cannot become A's for the same reason. The whole legacy tag waits, so the sub-tag is not left pointing at a converted tag.
- A is a sub-tag of `A_USR`: making A a parent of `A (user)` would be a loop. Move A out from under `A_USR` first.
- Its plain tag is itself a legacy tag, as with `A_USR_USR` (2.x tagging with a suggested `A_USR`). It is merged into **A (user)** on the next run.

While a legacy tag is skipped, the migration's resync does not make a new `A_USR (marker)` for it, and an `A_USR (performer)` that is a marker's primary tag is kept. Quick Tagger's own marker hook can still make `A_USR (marker)` when the migration moves another tag's marker on the same scene; the next run, once `A_USR` is migrated, folds it into **A (marker)**.

A `(performer)` tag whose markers have no plain tag to move to is kept and logged, and a sub-tag whose category tag cannot be created (an unmanaged tag has the category's name) is left without it. Neither counts as something to change, so a repeat run still does nothing.

### Not migrated

- Plain tags that 1.x copied from performers to scenes. They cannot be told apart from tags added by scrapers or Auto Tag.
- Plain A added next to `A_USR` by late 1.x builds stays on the scene as an ordinary tag.

## Outcome by case

What one scene, its markers, and its performer end up with, for a tag A whose `A_USR` is migrated (not skipped). These rows are produced by running each case through the task with Quick Tagger's marker hook active. "1.x marker" means primary tag plain A, title A (any case), no secondary tags.

| Scene before | Markers before | Scene after | Markers after |
|---|---|---|---|
| `A_USR` (1.x/2.x quick tag) | none | `A (user)` | |
| `A_USR`, `A` (late 1.x quick tag) | none | `A`, `A (user)` | |
| `A_USR` | 1.x marker | `A (marker)` | primary `A (marker)` |
| `A_USR`, `A` | 1.x marker | `A`, `A (marker)` | primary `A (marker)` |
| `A_USR` | made in Stash's editor: primary A, another title | `A (marker)`, `A (user)` | unchanged (primary A) |
| `A_USR` | primary A, titled A, with a secondary tag | `A (marker)`, `A (user)` | unchanged |
| `A_USR` | 2.x quick marker (primary and secondary `A_USR`) | `A (marker)`, `A (user)` | primary `A (marker)`, `A_USR` removed from secondary |
| `A_USR` | a 1.x and a 2.x quick marker | `A (marker)`, `A (user)` | both primary `A (marker)` |
| `A_USR`, `A (marker)` | 3.x/4.0 quick marker (primary `A (marker)`) | `A (marker)`, `A (user)` | unchanged |
| no `A_USR` | 2.x quick marker (2.x markers did not tag the scene) | `A (marker)` | primary `A (marker)` |
| no `A_USR` | marker that looks like 1.x's | `A (marker)` (from the resync) | unchanged (moved only on scenes with `A_USR`) |
| `A_USR`; a performer has `A_USR` (2.x copy) | none | nothing from A; performer `A (user)` | |
| `A_USR`; a performer has `A_USR` | 1.x marker | `A (marker)`; performer `A (user)` | primary `A (marker)` |
| `A_USR`; a performer has plain A (1.x performer tag) | none | `A (user)`; performer keeps A | |
| `A_USR`, `A (user)` (tagged again with 3.x/4.0) | 1.x marker | `A (marker)`, `A (user)` (A_USR merged) | primary `A (marker)` |
| `A_USR (user)` (3.0, typed `A_USR`) | none | `A (user)` | |
| `A_USR`, `A_USR (marker)` (3.0) | 3.0 marker on `A_USR (marker)` | `A (marker)`, `A (user)` | primary `A (marker)` (same tag, renamed) |
| `A (performer)` (3.0) | none | nothing from A | |
| `A (performer)` (3.0) | marker with primary `A (performer)` | `A (marker)` | primary `A (marker)`, then `A (performer)` deleted |
| `A_USR (performer)` (3.0) | none | nothing from A | |

Performers: `A_USR` on a performer (2.x) becomes **A (user)**; `A_USR (user)` (3.0) becomes **A (user)**; plain A (1.x) is unchanged. Galleries, images, studios, and groups keep their links in both the rename and the merge.

For the tag itself: renamed in place to **A (user)** when that does not exist, merged into it when it does, plain A created if missing, and skipped (everything above unchanged) for the reasons under [When a legacy tag is skipped](#when-a-legacy-tag-is-skipped).

## Stable and testing copies

A testing install is a separate plugin (`quickTagger-testing`, `quickTaggerMigration-testing`) acting on the same library as a stable one. While a stable Quick Tagger 3.x is on, its marker hook also runs, and it keeps adding `(performer)` scene tags and sub-tags without category parents. Turn it off before migrating; running the migration again cleans up anything it added.

## Other suffixes

For a different 2.x `tagSuffix`, start the task through GraphQL with `legacySuffix`. `runPluginTask` runs it as a job, like Settings → Tasks (with progress, and Cancel in the job queue), and fills in the task's other arguments:

```graphql
mutation {
  runPluginTask(plugin_id: "quickTaggerMigration", task_name: "Migrate legacy tags (dry run)", args_map: { legacySuffix: "-mine" })
}
```

Use `task_name: "Migrate legacy tags"` to apply. `runPluginOperation` also works, but it stops the migration if the request's connection closes, and must not be given `reportProgress`.

Use `quickTaggerMigration-testing` for a testing install. (`reportProgress` is for jobs only: Stash gives `runPluginOperation` no progress channel, and the task would wait forever.)

## Keeping in step with Quick Tagger

The task carries its own copy of Quick Tagger's tag model: the `quickTagger_role`, `quickTagger_concept`, and `quickTagger_category` custom fields, the sub-tag and category tag names, and how sub-tags are found and marker tags synced. A change to the tag model in `plugins/quickTagger/src/quickTagger-task.js` must be made here too.

## Test commands

- Unit (uses Quick Tagger's task and its in-memory Stash, `plugins/quickTagger/tests/unit/fake-stash.js`): `npm run stash -- test --plugin quickTaggerMigration --suite unit`
- Integration (real Stash with Quick Tagger installed; data made the way 1.x, 2.x, and 3.0 made it; dry run, apply, and a repeat run): `npm run stash -- test --plugin quickTaggerMigration --suite integration`
