(function (root) {
  // Quick Tagger Migration converts tags left by Quick Tagger 1.x, 2.x, and 3.x
  // to Quick Tagger 4's tag model. It is a separate plugin so it can be removed
  // once a library is migrated.
  //
  // The tag model below (custom fields, roles, category tags, and how sub-tags
  // are named and found) must match plugins/quickTagger/src/quickTagger-task.js.
  var DEFAULTS = { legacySuffix: "_USR" };

  var ROLE_FIELD = "quickTagger_role";
  var CONCEPT_FIELD = "quickTagger_concept";
  var ROLES = {
    user: "Added by you with Quick Tagger.",
    marker: "Kept by Quick Tagger on scenes that contain a marker of this tag.",
  };
  var CATEGORY_ROLE = "category";
  var CATEGORY_FIELD = "quickTagger_category";
  var CATEGORIES = {
    user: { name: "Quick Tagger: user", description: "Parent of every tag Quick Tagger adds when you tag a scene or performer." },
    marker: { name: "Quick Tagger: marker", description: "Parent of every tag Quick Tagger keeps on scenes that contain markers." },
  };

  var TAG_FIELDS = "id name aliases description parents{ id } custom_fields";
  var FIND_TAGS = "query QuickTaggerFindTags($filter: TagFilterType){ findTags(tag_filter:$filter, filter:{ per_page: -1 }){ tags{ " + TAG_FIELDS + " } } }";
  var FIND_TAGS_BY_ID = "query QuickTaggerFindTagsByID($ids: [ID!]){ findTags(ids:$ids){ tags{ " + TAG_FIELDS + " } } }";
  var CREATE_TAG = "mutation QuickTaggerCreateTag($input: TagCreateInput!){ tagCreate(input:$input){ " + TAG_FIELDS + " } }";
  var UPDATE_TAG = "mutation QuickTaggerUpdateTag($input: TagUpdateInput!){ tagUpdate(input:$input){ " + TAG_FIELDS + " } }";
  var MERGE_TAGS = "mutation QuickTaggerMergeTags($input: TagsMergeInput!){ tagsMerge(input:$input){ id } }";
  var DESTROY_TAGS = "mutation QuickTaggerDestroyTags($ids: [ID!]!){ tagsDestroy(ids:$ids) }";
  var FIND_SCENE = "query QuickTaggerFindScene($id: ID!){ findScene(id:$id){ id files{ path } tags{ id } } }";
  var UPDATE_SCENE = "mutation QuickTaggerUpdateScene($input: SceneUpdateInput!){ sceneUpdate(input:$input){ id tags{ id } } }";
  var COUNT_PERFORMERS = "query QuickTaggerCountPerformers($performer_filter: PerformerFilterType){ findPerformers(performer_filter:$performer_filter){ count } }";
  var FIND_MARKER_SCENES = "query QuickTaggerMarkerScenes($scene_filter: SceneFilterType, $ids: [ID!]){ findScenes(scene_filter:$scene_filter, ids:$ids, filter:{ per_page: -1 }){ scenes{ id tags{ id custom_fields } scene_markers{ id primary_tag{ " + TAG_FIELDS + " } } } } }";
  var FIND_LEGACY_SCENES = "query QuickTaggerLegacyScenes($scene_filter: SceneFilterType){ findScenes(scene_filter:$scene_filter, filter:{ per_page: -1 }){ scenes{ id performers{ tags{ id } } scene_markers{ id title primary_tag{ " + TAG_FIELDS + " } tags{ id } } } } }";
  var FIND_TAG_IMAGE = "query QuickTaggerTagImage($ids: [ID!]){ findTags(ids:$ids){ tags{ id image_path } } }";
  var FIND_MARKERS_BY_TAG = "query QuickTaggerMarkersByTag($filter: SceneMarkerFilterType){ findSceneMarkers(scene_marker_filter:$filter, filter:{ per_page: -1 }){ scene_markers{ id primary_tag{ id } tags{ id } } } }";
  var UPDATE_MARKER = "mutation QuickTaggerUpdateMarker($input: SceneMarkerUpdateInput!){ sceneMarkerUpdate(input:$input){ id } }";
  var BACKUP = "mutation QuickTaggerBackup{ backupDatabase(input:{ download: false }) }";

  function own(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
  }

  function trim(value) {
    return String(value || "").replace(/^\s+|\s+$/g, "");
  }

  function toBool(value, fallback) {
    if (value === undefined || value === null || value === "") return fallback;
    if (value === true || value === false) return value;
    if (value === "true") return true;
    if (value === "false") return false;
    return fallback;
  }

  function getGQL(options) {
    if (options && options.gql) return options.gql;
    if (typeof gql !== "undefined") return gql;
    throw new Error("gql API is not available");
  }

  function getLog(options) {
    if (options && options.log) return options.log;
    if (typeof log !== "undefined") return log;
    return { Info: function () {}, Warn: function () {}, Error: function () {}, Progress: function () {} };
  }

  function gqlDo(gqlClient, query, variables) {
    if (variables === undefined) variables = {};
    return gqlClient.Do(query, variables);
  }

  function errorMessage(err) {
    return String(err && err.message ? err.message : err);
  }

  function tagRow(row) {
    var fields = row.custom_fields || {};
    return {
      id: String(row.id),
      name: row.name,
      aliases: row.aliases || [],
      description: row.description || "",
      parents: (row.parents || []).map(function (p) { return String(p.id); }),
      role: fields[ROLE_FIELD] ? String(fields[ROLE_FIELD]) : null,
      concept: fields[CONCEPT_FIELD] ? String(fields[CONCEPT_FIELD]) : null,
    };
  }

  function findTags(gqlClient, filter) {
    var result = gqlDo(gqlClient, FIND_TAGS, { filter: filter });
    return ((result && result.findTags && result.findTags.tags) || []).map(tagRow);
  }

  function findTagByID(gqlClient, id) {
    var result = gqlDo(gqlClient, FIND_TAGS_BY_ID, { ids: [String(id)] });
    var rows = (result && result.findTags && result.findTags.tags) || [];
    return rows.length ? tagRow(rows[0]) : null;
  }

  // Stash runs EQUALS as a case-insensitive LIKE ("_" and "%" are wildcards), so
  // every name match is confirmed here.
  function sameText(a, b) {
    return String(a || "").toLowerCase() === String(b || "").toLowerCase();
  }

  // A sub-tag's concept, or null for a category tag or a sub-tag whose concept
  // is gone or is itself one of Quick Tagger's tags.
  function conceptOf(gqlClient, tag) {
    if (!tag.role) return tag;
    var concept = tag.concept ? findTagByID(gqlClient, tag.concept) : null;
    return concept && !concept.role ? concept : null;
  }

  // The concept is the plain tag "A". Typing an alias of A, or the name or alias
  // of one of A's Quick Tagger sub-tags (a migrated "A_USR" is an alias of
  // "A (user)"), resolves to A as well.
  function findConcept(gqlClient, text) {
    var byName = findTags(gqlClient, { name: { value: text, modifier: "EQUALS" } }).filter(function (t) { return sameText(t.name, text); });
    var byAlias = byName.length ? [] : findTags(gqlClient, { aliases: { value: text, modifier: "EQUALS" } }).filter(function (t) {
      return t.aliases.some(function (alias) { return sameText(alias, text); });
    });
    var tag = byName[0] || byAlias[0];
    if (!tag) return null;
    var concept = conceptOf(gqlClient, tag);
    if (!concept) throw new Error(tag.name + " is one of Quick Tagger's own tags; type the tag it belongs to instead");
    return concept;
  }

  // The tag other than `exceptID` that already uses `name` as its name or an
  // alias, if any. Stash refuses a name that clashes with either.
  function nameTaken(gqlClient, name, exceptID) {
    var match = function (t) { return t.id !== exceptID && (sameText(t.name, name) || t.aliases.some(function (a) { return sameText(a, name); })); };
    var rows = findTags(gqlClient, { name: { value: name, modifier: "EQUALS" } }).filter(match);
    if (!rows.length) rows = findTags(gqlClient, { aliases: { value: name, modifier: "EQUALS" } }).filter(match);
    return rows.length ? rows[0].name : null;
  }

  function findRoleTag(gqlClient, conceptID, role) {
    var rows = findTags(gqlClient, {
      custom_fields: [
        { field: ROLE_FIELD, value: [role], modifier: "EQUALS" },
        { field: CONCEPT_FIELD, value: [String(conceptID)], modifier: "EQUALS" },
      ],
    });
    return rows.length ? rows[0] : null;
  }

  // The name is checked first: Stash logs every failed mutation as an error,
  // and the marker hook may try this for every marker change.
  function createManagedTag(gqlClient, input) {
    var holder = nameTaken(gqlClient, input.name, null);
    if (holder) throw new Error("could not create tag " + input.name + "; the name is already used by " + holder + ", a tag Quick Tagger does not manage");
    var result;
    try {
      result = gqlDo(gqlClient, CREATE_TAG, { input: input });
    } catch (err) {
      throw new Error("could not create tag " + input.name + "; a tag with that name may already exist that Quick Tagger does not manage: " + errorMessage(err));
    }
    if (!result || !result.tagCreate) throw new Error("failed to create tag: " + input.name);
    return tagRow(result.tagCreate);
  }

  function findCategoryTag(gqlClient, role) {
    var rows = findTags(gqlClient, {
      custom_fields: [
        { field: ROLE_FIELD, value: [CATEGORY_ROLE], modifier: "EQUALS" },
        { field: CATEGORY_FIELD, value: [role], modifier: "EQUALS" },
      ],
    });
    return rows.length ? rows[0] : null;
  }

  // The role's category tag, created if needed. Categories only help filtering,
  // so a category that cannot be made (for example an unmanaged tag already has
  // its name) returns null, is remembered in `cache.categoryErrors`, and never
  // stops tagging.
  function ensureCategoryTag(gqlClient, role, cache) {
    cache = cache || {};
    var key = CATEGORY_ROLE + ":" + role;
    if (own(cache, key)) return cache[key];
    var tag = findCategoryTag(gqlClient, role);
    if (!tag) {
      var custom = {};
      custom[ROLE_FIELD] = CATEGORY_ROLE;
      custom[CATEGORY_FIELD] = role;
      try {
        tag = createManagedTag(gqlClient, { name: CATEGORIES[role].name, ignore_auto_tag: true, description: CATEGORIES[role].description, custom_fields: custom });
      } catch (err) {
        cache.categoryErrors = (cache.categoryErrors || []).concat([errorMessage(err)]);
        tag = null;
      }
    }
    cache[key] = tag ? { id: tag.id, name: tag.name } : null;
    return cache[key];
  }

  // Role sub-tags made before category tags existed get the category parent the
  // first time they are used.
  function ensureCategoryParent(gqlClient, tag, cache) {
    var category = ensureCategoryTag(gqlClient, tag.role, cache);
    if (!category || tag.parents.indexOf(category.id) >= 0) return false;
    gqlDo(gqlClient, UPDATE_TAG, { input: { id: tag.id, parent_ids: tag.parents.concat([category.id]) } });
    tag.parents.push(category.id);
    return true;
  }

  // Sub-tags are named "A (role)", ignored by Auto Tag, stamped with their role
  // and the concept's ID, and children of both A and the role's category tag.
  function ensureRoleTag(gqlClient, concept, role, cache) {
    var key = role + ":" + concept.id;
    if (cache && cache[key]) return cache[key];
    var tag = findRoleTag(gqlClient, concept.id, role);
    if (tag) {
      try { ensureCategoryParent(gqlClient, tag, cache); } catch (_err) { /* the category is only for filtering */ }
    } else {
      var category = ensureCategoryTag(gqlClient, role, cache);
      var custom = {};
      custom[ROLE_FIELD] = role;
      custom[CONCEPT_FIELD] = String(concept.id);
      tag = createManagedTag(gqlClient, {
        name: concept.name + " (" + role + ")",
        parent_ids: category ? [String(concept.id), category.id] : [String(concept.id)],
        ignore_auto_tag: true,
        description: ROLES[role],
        custom_fields: custom,
      });
    }
    var ret = { id: tag.id, name: tag.name };
    if (cache) cache[key] = ret;
    return ret;
  }

  function uniqueIDs(existing, addID) {
    var seen = {};
    var ret = [];
    for (var i = 0; i < (existing || []).length; i += 1) {
      var id = String(existing[i]);
      if (!seen[id]) {
        seen[id] = true;
        ret.push(id);
      }
    }
    if (addID && !seen[String(addID)]) ret.push(String(addID));
    return ret;
  }

  function withoutID(ids, removeID) {
    return (ids || []).map(String).filter(function (id) { return id !== String(removeID); });
  }

  function loadMarkerScenes(gqlClient, variables) {
    var result = gqlDo(gqlClient, FIND_MARKER_SCENES, variables);
    return (result && result.findScenes && result.findScenes.scenes) || [];
  }

  // The marker sub-tag "A (marker)" is derived: a scene carries it exactly when one
  // of its markers has A, or one of A's Quick Tagger sub-tags, as primary tag.
  // Only marker sub-tags are added or removed; every other scene tag is untouched.
  // scope: { sceneIds } checks those scenes, { tagged } checks scenes carrying a
  // marker sub-tag (enough after a marker is deleted), { all } also checks every
  // scene with markers.
  // options.dryRun changes nothing and reports the "(marker)" tags it would
  // create; options.noCreate lists concept IDs whose marker tag is never created
  // (only an existing one is kept).
  function syncMarkerTags(gqlClient, scope, options) {
    options = options || {};
    var scenes = {};
    function collect(rows) {
      for (var i = 0; i < rows.length; i += 1) scenes[String(rows[i].id)] = rows[i];
    }
    if (scope.sceneIds) {
      collect(loadMarkerScenes(gqlClient, { ids: scope.sceneIds }));
    } else {
      var markerTagIDs = findTags(gqlClient, { custom_fields: [{ field: ROLE_FIELD, value: ["marker"], modifier: "EQUALS" }] })
        .map(function (t) { return t.id; });
      if (markerTagIDs.length) {
        collect(loadMarkerScenes(gqlClient, { scene_filter: { tags: { value: markerTagIDs, modifier: "INCLUDES", depth: 0 } } }));
      }
      if (scope.all) collect(loadMarkerScenes(gqlClient, { scene_filter: { has_markers: "true" } }));
    }

    var roleCache = {};
    var conceptCache = {};
    // A concept whose "(marker)" tag cannot be made (an unmanaged tag has the
    // name) is reported once and skipped, so the other scenes still sync.
    var failed = {};
    var errors = [];
    var found = {};
    var wouldCreate = {};
    function markerTagFor(primary) {
      var tag = tagRow(primary);
      if (tag.role === "marker") return tag.id;
      var concept = tag;
      if (tag.role) {
        if (!tag.concept) return null;
        if (!own(conceptCache, tag.concept)) conceptCache[tag.concept] = findTagByID(gqlClient, tag.concept);
        concept = conceptCache[tag.concept];
        if (!concept || concept.role) return null;
      }
      if (own(failed, concept.id)) return null;
      var noCreate = options.noCreate && options.noCreate[concept.id];
      if (options.dryRun || noCreate) {
        if (!own(found, concept.id)) {
          var existing = findRoleTag(gqlClient, concept.id, "marker");
          found[concept.id] = existing ? existing.id : null;
        }
        if (found[concept.id] || noCreate) return found[concept.id];
        wouldCreate[concept.id] = concept.name + " (marker)";
        return "new:" + concept.id;
      }
      try {
        return ensureRoleTag(gqlClient, concept, "marker", roleCache).id;
      } catch (err) {
        failed[concept.id] = true;
        errors.push(errorMessage(err));
        return null;
      }
    }

    var ids = Object.keys(scenes);
    var updated = [];
    for (var i = 0; i < ids.length; i += 1) {
      var scene = scenes[ids[i]];
      var desired = {};
      var markers = scene.scene_markers || [];
      for (var m = 0; m < markers.length; m += 1) {
        var markerTagID = markers[m].primary_tag ? markerTagFor(markers[m].primary_tag) : null;
        if (markerTagID) desired[markerTagID] = true;
      }
      var next = [];
      var removed = [];
      var present = {};
      var tags = scene.tags || [];
      for (var t = 0; t < tags.length; t += 1) {
        var row = tagRow(tags[t]);
        present[row.id] = true;
        if (row.role === "marker" && !desired[row.id]) removed.push(row.id);
        else next.push(row.id);
      }
      var added = Object.keys(desired).filter(function (id) { return !present[id]; });
      if (!added.length && !removed.length) continue;
      if (!options.dryRun) gqlDo(gqlClient, UPDATE_SCENE, { input: { id: String(scene.id), tag_ids: next.concat(added) } });
      updated.push({ sceneId: String(scene.id), added: added, removed: removed });
    }
    var created = Object.keys(wouldCreate).map(function (id) { return wouldCreate[id]; });
    return { scenesChecked: ids.length, updated: updated, errors: errors, created: created };
  }

  function escapeRegex(value) {
    return String(value).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&");
  }

  // Quick Tagger 1.x tagged scenes with "A_USR" (2.x: "A" plus its tagSuffix
  // setting). 1.x also added "A_USR" to a scene when making an A marker there, and
  // 2.x used "A_USR" as the marker primary tag and on performers.
  function findLegacyTags(gqlClient, suffix) {
    var lower = suffix.toLowerCase();
    return findTags(gqlClient, { name: { value: "(?i)" + escapeRegex(suffix) + "$", modifier: "MATCHES_REGEX" } }).filter(function (t) {
      return !t.role && t.name.length > suffix.length && t.name.slice(-suffix.length).toLowerCase() === lower;
    });
  }

  function markersWithPrimary(gqlClient, tagID) {
    var result = gqlDo(gqlClient, FIND_MARKERS_BY_TAG, { filter: { tags: { value: [tagID], modifier: "INCLUDES", depth: 0 } } });
    var rows = (result && result.findSceneMarkers && result.findSceneMarkers.scene_markers) || [];
    return rows.filter(function (m) { return m.primary_tag && String(m.primary_tag.id) === String(tagID); }).map(function (m) {
      return { id: String(m.id), tagIDs: (m.tags || []).map(function (t) { return String(t.id); }) };
    });
  }

  // Quick Tagger 3.x treated an unmigrated "A_USR" as a plain tag, so it may have
  // made "A_USR (user)" or "A_USR (marker)". Those become A's sub-tags as well.
  // Planned again just before they are changed, because marker hooks that run
  // during the migration can make more of them.
  function planLegacySubTags(gqlClient, item, planned) {
    var rows = findTags(gqlClient, { custom_fields: [{ field: CONCEPT_FIELD, value: [item.legacy.id], modifier: "EQUALS" }] });
    var subs = [];
    for (var i = 0; i < rows.length; i += 1) {
      var role = rows[i].role;
      if (!own(ROLES, role)) continue;
      var sub = { id: rows[i].id, name: rows[i].name, role: role, parents: rows[i].parents, action: "skip", target: null, reason: null };
      var key = item.key + ":" + role;
      var target = role === "user" ? item.target : planned[key] || (item.concept.id ? findRoleTag(gqlClient, item.concept.id, role) : null);
      if (target) {
        sub.action = "merge";
        sub.target = { id: target.id, name: target.name };
      } else {
        var name = item.concept.name + " (" + role + ")";
        var clash = nameTaken(gqlClient, name, sub.id);
        if (clash) {
          sub.reason = "the name " + name + " is already used by " + clash;
        } else {
          sub.action = "convert";
          sub.target = { id: sub.id, name: name };
          planned[key] = sub.target;
        }
      }
      subs.push(sub);
    }
    return subs;
  }

  // Stash's image_path asks for a default image when a tag has none.
  function hasImage(gqlClient, tagID) {
    var result = gqlDo(gqlClient, FIND_TAG_IMAGE, { ids: [String(tagID)] });
    var rows = (result && result.findTags && result.findTags.tags) || [];
    return !!rows.length && !!rows[0].image_path && rows[0].image_path.indexOf("default=true") < 0;
  }

  // How the legacy tag got onto each of its scenes:
  // - 1.x added it when making a quick marker: primary tag plain A, titled A,
  //   no secondary tags. Such a scene loses the legacy tag, unless it also has a
  //   2.x or 3.x quick marker (primary A_USR or an A sub-tag), which never added
  //   it, so there the tag was added on purpose. Other markers with primary A
  //   (made in Stash's editor) say nothing about it, so the tag stays. 1.x
  //   markers move to A (marker).
  // - 2.x copied a performer's tag to all their scenes. A scene whose performer
  //   also has the legacy tag loses it; the performer keeps it as A (user), which
  //   the Performer Tags filter finds.
  function planLegacyScenes(gqlClient, item, legacy, concept) {
    var scenes = gqlDo(gqlClient, FIND_LEGACY_SCENES, { scene_filter: { tags: { value: [legacy.id], modifier: "INCLUDES", depth: 0 } } });
    var rows = (scenes && scenes.findScenes && scenes.findScenes.scenes) || [];
    rows.forEach(function (scene) {
      var id = String(scene.id);
      item.scenes.push(id);
      var v1Marker = false;
      var quickMarker = false;
      (scene.scene_markers || []).forEach(function (marker) {
        if (!marker.primary_tag) return;
        var primary = tagRow(marker.primary_tag);
        if (concept && primary.id === concept.id) {
          if (sameText(trim(marker.title), concept.name) && !(marker.tags || []).length) {
            v1Marker = true;
            item.v1Markers.push({ id: String(marker.id), tagIDs: [] });
          }
        } else if (primary.id === legacy.id || (primary.role && (primary.concept === legacy.id || (concept && primary.concept === concept.id)))) {
          quickMarker = true;
        }
      });
      var copied = (scene.performers || []).some(function (p) { return (p.tags || []).some(function (t) { return String(t.id) === legacy.id; }); });
      if (copied) item.droppedAsCopy.push(id);
      else if (v1Marker && !quickMarker) item.droppedForMarker.push(id);
    });
    item.dropFromScenes = item.droppedForMarker.concat(item.droppedAsCopy);
  }

  // Decides what happens to one legacy tag without changing anything. `planned`
  // maps concepts to the "A (user)" tag an earlier legacy tag will become;
  // `legacyIDs` holds every legacy tag found.
  function planLegacyTag(gqlClient, legacy, suffix, planned, legacyIDs) {
    var base = trim(legacy.name.slice(0, legacy.name.length - suffix.length));
    var item = {
      legacy: { id: legacy.id, name: legacy.name }, key: null, concept: null, action: "skip", target: null, reason: null, warnings: [],
      scenes: [], dropFromScenes: [], droppedForMarker: [], droppedAsCopy: [], markers: [], v1Markers: [], performers: 0, subTags: [],
    };
    var skip = function (reason) {
      item.action = "skip";
      item.target = null;
      item.reason = reason;
      return item;
    };
    if (!base) return skip("nothing before the suffix");
    var concept;
    try {
      concept = findConcept(gqlClient, base);
    } catch (err) {
      return skip(errorMessage(err));
    }
    if (concept && legacyIDs[concept.id]) {
      return skip(concept.id === legacy.id ? "the tag is its own plain tag" : "its plain tag " + concept.name + " is itself a legacy tag; run the migration again afterwards");
    }
    item.concept = concept ? { id: concept.id, name: concept.name, created: false } : { id: null, name: base, created: true };
    item.key = concept ? concept.id : "new:" + base.toLowerCase();
    var target = planned[item.key] || (concept ? findRoleTag(gqlClient, concept.id, "user") : null);
    var userName = item.concept.name + " (user)";
    if (target) {
      item.action = "merge";
      item.target = { id: target.id, name: target.name };
      if (hasImage(gqlClient, legacy.id)) item.warnings.push(legacy.name + "'s image is not kept by the merge; set it on " + target.name + " by hand if you want it");
    } else {
      var clash = nameTaken(gqlClient, userName, legacy.id);
      if (clash) return skip("the name " + userName + " is already used by " + clash + ", which is not Quick Tagger's user tag for " + item.concept.name);
      // Making A a parent of the legacy tag would be a loop if A is under it.
      if (concept && findTags(gqlClient, { children: { value: [concept.id], modifier: "INCLUDES", depth: -1 } }).some(function (t) { return t.id === legacy.id; })) {
        return skip(concept.name + " is a sub-tag of " + legacy.name + "; move it out from under " + legacy.name + " first");
      }
      item.action = "convert";
      item.target = { id: legacy.id, name: userName };
    }

    planLegacyScenes(gqlClient, item, legacy, concept);
    item.markers = markersWithPrimary(gqlClient, legacy.id);
    // Markers of A need "A (marker)"; an unmanaged tag with that name would stop
    // the migration half way, so it is caught here.
    var needsMarkerTag = item.markers.length || item.v1Markers.length || item.droppedForMarker.length;
    if (needsMarkerTag && !planned[item.key + ":marker"] && !(concept && findRoleTag(gqlClient, concept.id, "marker"))) {
      var markerName = item.concept.name + " (marker)";
      var markerClash = nameTaken(gqlClient, markerName, null);
      if (markerClash) return skip("the name " + markerName + " is already used by " + markerClash + ", which is not Quick Tagger's marker tag for " + item.concept.name);
    }
    item.subTags = planLegacySubTags(gqlClient, item, planned);
    // A sub-tag left behind would point at the converted tag forever, so the
    // whole legacy tag waits until it can be moved.
    var stuck = item.subTags.filter(function (sub) { return sub.action === "skip"; });
    if (stuck.length) return skip("its sub-tag " + stuck[0].name + " cannot become " + item.concept.name + "'s: " + stuck[0].reason);
    if (item.action === "convert") planned[item.key] = item.target;
    var performers = gqlDo(gqlClient, COUNT_PERFORMERS, { performer_filter: { tags: { value: [legacy.id], modifier: "INCLUDES", depth: 0 } } });
    item.performers = (performers && performers.findPerformers && performers.findPerformers.count) || 0;
    return item;
  }

  function applyLegacySubTag(gqlClient, sub, legacyID, concept, cache) {
    if (sub.action === "merge") {
      gqlDo(gqlClient, MERGE_TAGS, { input: { source: [sub.id], destination: sub.target.id } });
      return;
    }
    var category = ensureCategoryTag(gqlClient, sub.role, cache);
    var custom = {};
    custom[CONCEPT_FIELD] = concept.id;
    var parents = uniqueIDs(withoutID(sub.parents, legacyID), concept.id);
    gqlDo(gqlClient, UPDATE_TAG, {
      input: { id: sub.id, name: sub.target.name, parent_ids: category ? uniqueIDs(parents, category.id) : parents, custom_fields: { partial: custom } },
    });
  }

  // Stash's tag merge moves every link and alias but not the source's place in
  // the hierarchy, so the legacy tag's parents and children move to the target
  // first. A move Stash refuses (a loop) is reported, and the merge goes on.
  function moveHierarchy(gqlClient, legacyID, targetID, warnings) {
    var legacy = findTagByID(gqlClient, legacyID);
    var target = findTagByID(gqlClient, targetID);
    if (!legacy || !target) return;
    // Stash refuses (and logs) a change that makes a loop, so those are left out.
    var below = {};
    findTags(gqlClient, { parents: { value: [targetID], modifier: "INCLUDES", depth: -1 } }).forEach(function (t) { below[t.id] = t.name; });
    var above = {};
    findTags(gqlClient, { children: { value: [targetID], modifier: "INCLUDES", depth: -1 } }).forEach(function (t) { above[t.id] = t.name; });
    var parents = target.parents.slice();
    legacy.parents.forEach(function (id) {
      if (id === targetID || id === legacyID) return;
      if (own(below, id)) {
        warnings.push(below[id] + " stays out of " + target.name + "'s parents: it is under " + target.name);
        return;
      }
      parents = uniqueIDs(parents, id);
    });
    if (parents.length !== target.parents.length) {
      try {
        gqlDo(gqlClient, UPDATE_TAG, { input: { id: targetID, parent_ids: parents } });
      } catch (err) {
        warnings.push("could not give " + target.name + " the parents of " + legacy.name + ": " + errorMessage(err));
      }
    }
    var children = findTags(gqlClient, { parents: { value: [legacyID], modifier: "INCLUDES", depth: 0 } });
    children.forEach(function (child) {
      if (child.id === targetID) return;
      if (own(above, child.id)) {
        warnings.push(child.name + " is not moved under " + target.name + ": it is above " + target.name + ", and it loses " + legacy.name + " as a parent");
        return;
      }
      try {
        gqlDo(gqlClient, UPDATE_TAG, { input: { id: child.id, parent_ids: uniqueIDs(withoutID(child.parents, legacyID), targetID) } });
      } catch (err) {
        warnings.push("could not move " + child.name + " under " + target.name + ": " + errorMessage(err));
      }
    });
  }

  // `holdMarkerMerges` leaves an "A_USR (marker)" that merges into an existing
  // "A (marker)" for later: while markers move, Quick Tagger's hook keeps using
  // it for the A_USR markers not moved yet. Merged too early, its name becomes
  // an alias of "A (marker)", and the hook's attempt to make it again fails and
  // fills Stash's log with errors.
  function foldLegacySubTags(gqlClient, item, concept, cache, holdMarkerMerges) {
    var subs = planLegacySubTags(gqlClient, { legacy: item.legacy, key: concept.id, concept: concept, target: item.target }, {});
    for (var t = 0; t < subs.length; t += 1) {
      if (subs[t].action === "skip") continue;
      if (holdMarkerMerges && subs[t].role === "marker" && subs[t].action === "merge") continue;
      applyLegacySubTag(gqlClient, subs[t], item.legacy.id, concept, cache);
      item.subTags.push(subs[t]);
    }
  }

  // An "A_USR (marker)" merged by an earlier, interrupted run is an alias of a
  // Quick Tagger marker tag. Quick Tagger's hook makes "A_USR (marker)" again for
  // A_USR markers not moved yet, which that alias blocks, so it is removed first.
  // The closing fold puts it back.
  function releaseLegacyMarkerName(gqlClient, legacyName, released) {
    var name = legacyName + " (marker)";
    findTags(gqlClient, { aliases: { value: name, modifier: "EQUALS" } }).forEach(function (tag) {
      if (tag.role !== "marker") return;
      var aliases = tag.aliases.filter(function (a) { return !sameText(a, name); });
      if (aliases.length === tag.aliases.length) return;
      gqlDo(gqlClient, UPDATE_TAG, { input: { id: tag.id, aliases: aliases } });
      released.push({ tagID: tag.id, alias: name });
    });
  }

  // Puts back an alias released above, unless a merge already did or the name
  // is in use again.
  function restoreReleasedNames(gqlClient, released) {
    released.forEach(function (entry) {
      var tag = findTagByID(gqlClient, entry.tagID);
      if (!tag || tag.aliases.some(function (a) { return sameText(a, entry.alias); }) || nameTaken(gqlClient, entry.alias, tag.id)) return;
      gqlDo(gqlClient, UPDATE_TAG, { input: { id: tag.id, aliases: tag.aliases.concat([entry.alias]) } });
    });
  }

  // Order matters: nothing changes if a sub-tag cannot be moved; scenes are
  // cleared before sub-tags are merged into the legacy tag (so a scene keeps a
  // user tag added by 3.x); an "A_USR (marker)" is renamed to "A (marker)"
  // before markers move (so it keeps its ID) but merged into an existing one
  // only after they have; and sub-tags are folded again afterwards, because
  // Quick Tagger's marker hook may have made another.
  function applyLegacyItem(gqlClient, item, cache, onMarker) {
    var concept = item.concept;
    if (!concept.created) {
      var stuck = planLegacySubTags(gqlClient, { legacy: item.legacy, key: concept.id, concept: concept, target: item.target }, {}).filter(function (sub) { return sub.action === "skip"; });
      if (stuck.length) throw new Error("its sub-tag " + stuck[0].name + " cannot become " + concept.name + "'s: " + stuck[0].reason);
    }
    if (concept.created) {
      // An earlier legacy tag with the same name may have created it already.
      var existing = findConcept(gqlClient, concept.name);
      if (!existing) {
        var created = gqlDo(gqlClient, CREATE_TAG, { input: { name: concept.name } });
        if (!created || !created.tagCreate) throw new Error("failed to create tag: " + concept.name);
        existing = tagRow(created.tagCreate);
      }
      concept = { id: existing.id, name: existing.name, created: true };
      item.concept = concept;
    }
    // See planLegacyScenes: scenes where 1.x added the tag with a marker, or 2.x
    // copied it from a performer.
    var legacyID = item.legacy.id;
    for (var s = 0; s < item.dropFromScenes.length; s += 1) {
      var found = gqlDo(gqlClient, FIND_SCENE, { id: item.dropFromScenes[s] });
      if (!found || !found.findScene) continue;
      var tagIDs = (found.findScene.tags || []).map(function (t) { return String(t.id); });
      gqlDo(gqlClient, UPDATE_SCENE, { input: { id: item.dropFromScenes[s], tag_ids: withoutID(tagIDs, legacyID) } });
    }
    item.subTags = [];
    foldLegacySubTags(gqlClient, item, concept, cache, true);
    // Read after the fold: merging "A_USR (user)" into the legacy tag changes
    // the tags of markers that had it, and its old ID no longer exists.
    var markers = markersWithPrimary(gqlClient, legacyID).concat(item.v1Markers);
    if (markers.length) {
      var markerTag = ensureRoleTag(gqlClient, concept, "marker", cache);
      for (var m = 0; m < markers.length; m += 1) {
        gqlDo(gqlClient, UPDATE_MARKER, { input: { id: markers[m].id, primary_tag_id: markerTag.id, tag_ids: withoutID(markers[m].tagIDs, legacyID) } });
        if (onMarker) onMarker((m + 1) / markers.length);
      }
    }
    foldLegacySubTags(gqlClient, item, concept, cache);
    if (item.action === "merge") {
      moveHierarchy(gqlClient, legacyID, item.target.id, item.warnings);
      // Stash moves every scene, performer, gallery, image, and marker link to
      // the target and keeps the legacy name as one of its aliases.
      gqlDo(gqlClient, MERGE_TAGS, { input: { source: [legacyID], destination: item.target.id } });
      return;
    }
    // Converting in place keeps the tag's ID, so no links change. Re-read the
    // tag: merged sub-tags may have added aliases to it.
    var legacy = findTagByID(gqlClient, legacyID);
    var category = ensureCategoryTag(gqlClient, "user", cache);
    var custom = {};
    custom[ROLE_FIELD] = "user";
    custom[CONCEPT_FIELD] = concept.id;
    var parents = uniqueIDs(legacy.parents, concept.id);
    gqlDo(gqlClient, UPDATE_TAG, {
      input: {
        id: legacy.id,
        name: item.target.name,
        aliases: uniqueIDs(legacy.aliases, legacy.name),
        parent_ids: category ? uniqueIDs(parents, category.id) : parents,
        ignore_auto_tag: true,
        description: legacy.description || ROLES.user,
        custom_fields: { partial: custom },
      },
    });
  }

  // 3.x's "A (performer)" scene tags. A marker using one as its primary tag
  // would stop Stash deleting it, so those markers move to "A (marker)" first.
  // A tag whose markers have nowhere to go is kept (`kept` says why), so a run
  // that can do nothing else about it changes nothing.
  function planPerformerTags(gqlClient, items, legacyIDs) {
    var migrating = {};
    items.forEach(function (it) { if (it.action !== "skip") migrating[it.legacy.id] = true; });
    return findTags(gqlClient, { custom_fields: [{ field: ROLE_FIELD, value: ["performer"], modifier: "EQUALS" }] }).map(function (tag) {
      var plan = { id: tag.id, name: tag.name, concept: tag.concept, markers: markersWithPrimary(gqlClient, tag.id), kept: null };
      if (plan.markers.length) {
        if (legacyIDs[tag.concept]) {
          if (!migrating[tag.concept]) plan.kept = "its markers wait until its legacy tag is migrated";
        } else {
          var concept = tag.concept ? findTagByID(gqlClient, tag.concept) : null;
          if (concept && concept.role) concept = conceptOf(gqlClient, concept);
          if (!concept) plan.kept = "its markers have no plain tag to move to";
        }
      }
      return plan;
    });
  }

  // `migrated` maps each migrated legacy tag's ID to its plain tag, for
  // "A_USR (performer)" tags 3.x made of an unmigrated legacy tag.
  function removePerformerTag(gqlClient, plan, cache, migrated) {
    if (plan.markers.length) {
      var concept = own(migrated, plan.concept) ? migrated[plan.concept] : plan.concept ? findTagByID(gqlClient, plan.concept) : null;
      if (concept && concept.role) concept = conceptOf(gqlClient, concept);
      if (!concept) throw new Error("its markers have no plain tag to move to");
      var markerTag = ensureRoleTag(gqlClient, concept, "marker", cache);
      plan.markers.forEach(function (marker) {
        gqlDo(gqlClient, UPDATE_MARKER, { input: { id: marker.id, primary_tag_id: markerTag.id, tag_ids: withoutID(marker.tagIDs, plan.id) } });
      });
    }
    gqlDo(gqlClient, DESTROY_TAGS, { ids: [plan.id] });
  }

  // Sub-tags without their category parent. Sub-tags of a legacy tag are left
  // out: the migration turns them into A's sub-tags.
  // A category that cannot be created (an unmanaged tag has its name) leaves
  // its sub-tags out, so a repeat run does not report them again.
  function tagsNeedingCategory(gqlClient, legacyIDs) {
    var categories = {};
    var blocked = {};
    Object.keys(ROLES).forEach(function (role) {
      categories[role] = findCategoryTag(gqlClient, role);
      blocked[role] = !categories[role] && !!nameTaken(gqlClient, CATEGORIES[role].name, null);
    });
    return findTags(gqlClient, { custom_fields: [{ field: ROLE_FIELD, value: Object.keys(ROLES), modifier: "EQUALS" }] }).filter(function (t) {
      return !legacyIDs[t.concept] && !blocked[t.role] && (!categories[t.role] || t.parents.indexOf(categories[t.role].id) < 0);
    });
  }

  // "(scenes 4, 9, 12)", shortened after 20 IDs.
  function idList(ids) {
    return "(scenes " + ids.slice(0, 20).join(", ") + (ids.length > 20 ? ", and " + (ids.length - 20) + " more" : "") + ")";
  }

  function logLegacyItem(logger, item, apply, position) {
    var name = item.legacy.name + (position ? " (" + position + ")" : "");
    if (item.action === "skip") {
      logger.Warn("Quick Tagger Migration: skip " + name + ": " + item.reason);
      return;
    }
    if (item.error) {
      logger.Error("Quick Tagger Migration: " + name + " failed part way: " + item.error + ". Run the migration again to finish it.");
      return;
    }
    var verb = apply ? "" : "would ";
    var parts = [];
    if (item.concept.created) parts.push(verb + "create plain tag " + item.concept.name);
    parts.push(verb + (item.action === "merge" ? "merge into " : "become ") + item.target.name + " (" + item.scenes.length + " scenes, " + item.performers + " performers)");
    if (item.droppedForMarker.length) parts.push(verb + "drop it from " + item.droppedForMarker.length + " scenes where Quick Tagger 1.x added it with a marker " + idList(item.droppedForMarker));
    if (item.droppedAsCopy.length) parts.push(verb + "drop it from " + item.droppedAsCopy.length + " scenes where it was copied from a performer who has it " + idList(item.droppedAsCopy));
    if (item.markers.length) parts.push(verb + "move " + item.markers.length + " markers with primary tag " + item.legacy.name + " to " + item.concept.name + " (marker)");
    if (item.v1Markers.length) parts.push(verb + "move " + item.v1Markers.length + " Quick Tagger 1.x markers from " + item.concept.name + " to " + item.concept.name + " (marker)");
    item.subTags.forEach(function (sub) {
      parts.push(sub.action === "skip" ? "leave " + sub.name + ": " + sub.reason : verb + (sub.action === "merge" ? "merge " : "rename ") + sub.name + " into " + sub.target.name);
    });
    (item.warnings || []).forEach(function (w) { parts.push(w); });
    logger.Info("Quick Tagger Migration: " + name + ": " + parts.join("; "));
  }

  // Dry run unless args.apply. Applying backs up the database first. Each step
  // records its own failure, so one problem never hides the rest of the report.
  function migrateLegacyTags(gqlClient, logger, args) {
    var suffix = trim(args.legacySuffix);
    var apply = args.apply;
    var legacyTags = findLegacyTags(gqlClient, suffix);
    var legacyIDs = {};
    legacyTags.forEach(function (t) { legacyIDs[t.id] = true; });
    var planned = {};
    var items = legacyTags.map(function (legacy) { return planLegacyTag(gqlClient, legacy, suffix, planned, legacyIDs); });
    var performerTags = planPerformerTags(gqlClient, items, legacyIDs);
    var removable = performerTags.filter(function (p) { return !p.kept; });
    var needCategory = tagsNeedingCategory(gqlClient, legacyIDs);
    var skippedLegacy = {};
    items.forEach(function (it) { if (it.action === "skip") skippedLegacy[it.legacy.id] = true; });

    var backup = null;
    var errors = [];
    var cache = {};
    var hasWork = removable.length > 0 || needCategory.length > 0 || items.some(function (it) { return it.action !== "skip"; });
    var resync = null;
    var preview = null;
    var categoriesToCreate = [];
    if (!apply && hasWork) {
      // What the closing marker resync would change in the library as it is
      // now, apart from markers whose primary tag is a legacy tag, which the
      // items above move.
      preview = syncMarkerTags(gqlClient, { all: true }, { dryRun: true, noCreate: legacyIDs });
      // A "(marker)" tag whose name is taken cannot be made by the resync or by
      // Quick Tagger's hook; scenes with that tag's markers then get none.
      preview.blocked = preview.created.map(function (name) {
        var holder = nameTaken(gqlClient, name, null);
        return holder ? name + " (the name is used by " + holder + ")" : null;
      }).filter(Boolean);
      categoriesToCreate = Object.keys(ROLES).filter(function (role) { return !findCategoryTag(gqlClient, role); }).map(function (role) { return CATEGORIES[role].name; });
    }
    if (apply && hasWork) {
      var backupResult = gqlDo(gqlClient, BACKUP, {});
      backup = backupResult ? backupResult.backupDatabase || "" : "";
      logger.Info("Quick Tagger Migration: database backed up before migrating");
      var migrated = {};
      var progress = function (value) { if (args.reportProgress) logger.Progress(value); };
      var toApply = items.filter(function (it) { return it.action !== "skip"; });
      logger.Info("Quick Tagger Migration: migrating " + toApply.length + " legacy tags. Each moved marker also runs Quick Tagger's marker hook, so this can take a while; progress is logged per tag.");
      // Released for every legacy tag first: moving one tag's markers runs
      // Quick Tagger's hook on scenes that may also hold another's.
      var released = [];
      toApply.forEach(function (item) {
        try {
          releaseLegacyMarkerName(gqlClient, item.legacy.name, released);
        } catch (err) {
          errors.push(item.legacy.name + ": " + errorMessage(err));
        }
      });
      toApply.forEach(function (item, index) {
        progress(index / (toApply.length + 1));
        try {
          applyLegacyItem(gqlClient, item, cache, function (done) { progress((index + done) / (toApply.length + 1)); });
          migrated[item.legacy.id] = item.concept;
        } catch (err) {
          item.error = errorMessage(err);
          errors.push(item.legacy.name + ": " + item.error);
        }
        // Logged as it happens, so an interrupted run shows how far it got.
        logLegacyItem(logger, item, true, (index + 1) + " of " + toApply.length);
      });
      progress(toApply.length / (toApply.length + 1));
      try {
        restoreReleasedNames(gqlClient, released);
      } catch (err) {
        errors.push("restoring aliases: " + errorMessage(err));
      }
      removable.forEach(function (plan) {
        // Its legacy tag may have failed after planning.
        if (plan.markers.length && legacyIDs[plan.concept] && !own(migrated, plan.concept)) {
          plan.kept = "its markers wait until its legacy tag is migrated";
          return;
        }
        try {
          removePerformerTag(gqlClient, plan, cache, migrated);
          plan.deleted = true;
        } catch (err) {
          errors.push(plan.name + ": " + errorMessage(err));
        }
      });
      // Worked out again now that the legacy tags have changed.
      needCategory = tagsNeedingCategory(gqlClient, legacyIDs);
      needCategory = needCategory.filter(function (tag) {
        try {
          return ensureCategoryParent(gqlClient, tag, cache);
        } catch (err) {
          errors.push(tag.name + ": " + errorMessage(err));
        }
      });
      try {
        // Legacy tags left unmigrated get no new "(marker)" tag.
        resync = syncMarkerTags(gqlClient, { all: true }, { noCreate: skippedLegacy });
        resync.errors.forEach(function (message) { errors.push("marker tag resync: " + message); });
      } catch (err) {
        errors.push("marker tag resync: " + errorMessage(err));
      }
      (cache.categoryErrors || []).forEach(function (message) { errors.push("category tag: " + message); });
    }

    for (var l = 0; l < items.length; l += 1) {
      if (!apply || items[l].action === "skip") logLegacyItem(logger, items[l], apply);
    }
    var verb = apply ? "" : "would ";
    performerTags.forEach(function (plan) {
      if (plan.kept) { logger.Warn("Quick Tagger Migration: keep " + plan.name + ": " + plan.kept); return; }
      if (apply && !plan.deleted) return;
      logger.Info("Quick Tagger Migration: " + verb + "delete " + plan.name + (plan.markers.length ? " after moving its " + plan.markers.length + " markers to its (marker) tag" : ""));
    });
    if (needCategory.length) logger.Info("Quick Tagger Migration: " + verb + "add the category parent to " + needCategory.length + " sub-tags");
    if (categoriesToCreate.length) logger.Info("Quick Tagger Migration: would create " + categoriesToCreate.join(" and "));
    if (preview) {
      logger.Info("Quick Tagger Migration: the closing marker tag resync would change " + preview.updated.length + " scenes" + (preview.created.length ? " and create " + preview.created.join(", ") : ""));
      if (preview.blocked.length) {
        logger.Warn("Quick Tagger Migration: these (marker) tags cannot be created, so scenes with those markers get none; rename the tags using their names first: " + preview.blocked.join(", "));
      }
    }
    for (var e = 0; e < errors.length; e += 1) logger.Error("Quick Tagger Migration failed for " + errors[e]);
    // Stash keeps only its newest log lines, so the run ends with a summary.
    var counted = items.filter(function (it) { return it.action !== "skip" && !it.error; }).length;
    var skipped = items.filter(function (it) { return it.action === "skip"; }).map(function (it) { return it.legacy.name; });
    var dropped = items.reduce(function (n, it) { return n + it.dropFromScenes.length; }, 0);
    var moved = items.reduce(function (n, it) { return n + it.markers.length + it.v1Markers.length; }, 0);
    logger.Info("Quick Tagger Migration " + (apply ? "applied" : "dry run") + ": " + counted + " of " + items.length + " legacy tags " + (apply ? "migrated" : "to migrate") +
      "; " + dropped + " scene tags " + (apply ? "dropped" : "to drop") + ", " + moved + " markers " + (apply ? "moved" : "to move") +
      (skipped.length ? "; skipped: " + skipped.join(", ") : "") +
      (resync ? "; marker tags updated on " + resync.updated.length + " scenes" : "") +
      (errors.length ? "; " + errors.length + " errors" : "") + ". Each tag's details are in the lines above.");
    return {
      mode: "migrateLegacyTags",
      applied: apply,
      suffix: suffix,
      backup: backup,
      tags: items.map(function (it) {
        return {
          legacy: it.legacy,
          action: it.action,
          reason: it.reason,
          error: it.error || null,
          warnings: it.warnings || [],
          concept: it.concept,
          target: it.target ? it.target.name : null,
          scenes: it.scenes.length,
          droppedFromScenes: it.dropFromScenes,
          droppedForMarker: it.droppedForMarker,
          droppedAsCopy: it.droppedAsCopy,
          markers: it.markers.map(function (mk) { return mk.id; }),
          v1Markers: it.v1Markers.map(function (mk) { return mk.id; }),
          performers: it.performers,
          subTags: it.subTags.map(function (sub) { return { name: sub.name, action: sub.action, target: sub.target ? sub.target.name : null, reason: sub.reason }; }),
        };
      }),
      performerTagsDeleted: performerTags.filter(function (p) { return !p.kept && (!apply || p.deleted); }).map(function (p) { return p.name; }),
      performerTagsKept: performerTags.filter(function (p) { return p.kept; }).map(function (p) { return p.name; }),
      categoriesToCreate: categoriesToCreate,
      resyncPreview: preview ? { scenes: preview.updated.length, created: preview.created, blocked: preview.blocked } : null,
      categoryParentsAdded: needCategory.map(function (t) { return t.name; }),
      markerTagsUpdated: resync ? resync.updated.length : 0,
      errors: errors,
    };
  }

  function mergeArgs(args) {
    args = args || {};
    var merged = {
      mode: args.mode || "migrateLegacyTags",
      apply: toBool(args.apply, false),
      // Only a task run as a job (Settings → Tasks) may report progress: Stash
      // gives a plugin operation run over GraphQL no progress channel, and
      // log.Progress then blocks forever.
      reportProgress: toBool(args.reportProgress, false),
      legacySuffix: own(args, "legacySuffix") ? String(args.legacySuffix) : DEFAULTS.legacySuffix,
    };
    if (merged.mode !== "migrateLegacyTags") throw new Error("invalid mode: " + merged.mode);
    if (!trim(merged.legacySuffix)) throw new Error("legacySuffix is required");
    return merged;
  }

  function runMigration(rawArgs, options) {
    return migrateLegacyTags(getGQL(options), getLog(options), mergeArgs(rawArgs));
  }

  function main() {
    try {
      return { Output: runMigration(input.Args || {}) };
    } catch (err) {
      return { Error: String(err && err.message ? err.message : err) };
    }
  }

  var api = {
    DEFAULTS: DEFAULTS,
    ROLE_FIELD: ROLE_FIELD,
    CONCEPT_FIELD: CONCEPT_FIELD,
    CATEGORY_FIELD: CATEGORY_FIELD,
    mergeArgs: mergeArgs,
    runMigration: runMigration,
  };

  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.QuickTaggerMigrationTask = api;

  if (typeof input !== "undefined") {
    return main();
  }
})(this);
