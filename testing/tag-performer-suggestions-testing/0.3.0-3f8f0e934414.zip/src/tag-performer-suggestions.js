(function (root, factory) {
  var api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  // Other plugins (the Stash Bridge controllers) reuse the scoring and writes.
  if (root && root.PluginApi) { root.TagPerformerSuggestions = api; api.install(root.PluginApi); }
})(typeof window !== "undefined" ? window : globalThis, function (window) {
  "use strict";

  const ID = "tag-performer-suggestions-testing";
  const PANEL_KEY = ID + "-panel";
  const DEFAULTS = Object.freeze({
    excludedTags: Object.freeze([]),
    maxTagSuggestions: 5,
    maxPerformerSuggestions: 3,
    tagMinSupport: 3,
    tagMinConfidence: 50,
    tagMinLift: 2,
    performerMinSupport: 4,
    performerMinConfidence: 60,
    performerMinLift: 2,
    showTuningTools: false,
  });
  // [minimum, maximum, integer]
  const RANGES = Object.freeze({
    maxTagSuggestions: [1, 50, true],
    maxPerformerSuggestions: [1, 50, true],
    tagMinSupport: [1, 10000, true],
    tagMinConfidence: [1, 100, false],
    tagMinLift: [1, 1000, false],
    performerMinSupport: [1, 10000, true],
    performerMinConfidence: [1, 100, false],
    performerMinLift: [1, 1000, false],
  });
  // Pseudo-count that pulls the confidence of a small sample toward the
  // library-wide rate, so two-for-two never reads as certainty.
  const SMOOTHING = 2;
  // Each further source that independently qualifies a suggestion adds this
  // much to its ranking score, up to MAX_BONUS_SOURCES sources.
  const AGREEMENT_BONUS = 0.05;
  const MAX_BONUS_SOURCES = 4;
  // Related items fetched per source and item type. Larger sources are
  // sampled with a seeded random sort, which keeps the ratios unbiased.
  const SAMPLE_SIZE = 1000;
  const CONCURRENCY = 4;
  const MAX_TAG_DEPTH = 32;
  const TAG_SOURCE_KINDS = Object.freeze(["performer", "tag", "studio", "group", "gallery"]);
  const PERFORMER_SOURCE_KINDS = Object.freeze(["performer", "studio", "group", "gallery"]);
  // Studio alone is too weak to name a performer; one of these must be present.
  const PERFORMER_ANCHOR_KINDS = Object.freeze(["performer", "group", "gallery"]);

  // ---------------------------------------------------------------------------
  // Settings

  function parseExcludedTags(value) {
    if (Array.isArray(value)) value = value.join(",");
    if (typeof value !== "string") return [];
    const seen = new Set(), entries = [];
    value.split(",").forEach(function (part) {
      const name = part.trim(), key = name.toLowerCase();
      if (name && !seen.has(key)) { seen.add(key); entries.push(name); }
    });
    return entries;
  }

  // Stash shows unset NUMBER settings as 0, which falls below every range, so
  // unset, out-of-range and non-numeric values all use the default.
  function normalizeSettings(raw) {
    const source = raw && typeof raw === "object" ? raw : {};
    const settings = { excludedTags: parseExcludedTags(source.excludedTags), showTuningTools: source.showTuningTools === true || source.showTuningTools === "true" };
    Object.keys(RANGES).forEach(function (key) {
      const range = RANGES[key];
      const value = typeof source[key] === "number" ? source[key] : typeof source[key] === "string" && source[key].trim() ? Number(source[key]) : NaN;
      settings[key] = isFinite(value) && value >= range[0] && value <= range[1] ? (range[2] ? Math.floor(value) : value) : DEFAULTS[key];
    });
    return settings;
  }

  // ---------------------------------------------------------------------------
  // GraphQL access. Reads go through a guard that refuses anything but a
  // query; the only writes are the fixed documents in WRITES and CONFIGURE.

  function isId(value) { return typeof value === "string" && /^[1-9][0-9]*$/.test(value); }

  function isReadOnlyDocument(document) {
    if (typeof document !== "string") return false;
    const text = document.replace(/#[^\n\r]*/g, "").trim();
    return /^query\b/.test(text) && !/\b(?:mutation|subscription)\b/i.test(text);
  }

  function createReader(transport) {
    return function read(document, variables) {
      if (!isReadOnlyDocument(document)) return Promise.reject(new Error("Refusing to send a GraphQL document that is not a read-only query."));
      return Promise.resolve().then(function () { return transport(document, variables || {}); });
    };
  }

  function fetchTransport(document, variables) {
    return fetch("/graphql", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: document, variables: variables || {} }),
    }).then(function (response) {
      if (!response.ok) throw new Error("Stash returned HTTP " + response.status + ".");
      return response.json();
    }).then(function (json) {
      if (json.errors && json.errors.length) throw new Error(json.errors[0].message || "GraphQL error");
      return json.data;
    });
  }

  // Bulk updates in ADD mode change only the one relationship and never
  // replace the item's existing list, so a stale page cannot drop anything.
  const WRITES = Object.freeze({
    "scene:tag": "mutation TagPerformerSuggestionsAddSceneTag($ids: [ID!], $add: [ID!]) { bulkSceneUpdate(input: { ids: $ids, tag_ids: { ids: $add, mode: ADD } }) { id tags { id } } }",
    "scene:performer": "mutation TagPerformerSuggestionsAddScenePerformer($ids: [ID!], $add: [ID!]) { bulkSceneUpdate(input: { ids: $ids, performer_ids: { ids: $add, mode: ADD } }) { id performers { id } } }",
    "image:tag": "mutation TagPerformerSuggestionsAddImageTag($ids: [ID!], $add: [ID!]) { bulkImageUpdate(input: { ids: $ids, tag_ids: { ids: $add, mode: ADD } }) { id tags { id } } }",
    "image:performer": "mutation TagPerformerSuggestionsAddImagePerformer($ids: [ID!], $add: [ID!]) { bulkImageUpdate(input: { ids: $ids, performer_ids: { ids: $add, mode: ADD } }) { id performers { id } } }",
  });
  const CONFIGURE = "mutation TagPerformerSuggestionsConfigure($input: Map!) { configurePlugin(plugin_id: \"" + ID + "\", input: $input) }";
  const CONFIG_QUERY = "query TagPerformerSuggestionsConfig($include: [ID!]) { configuration { plugins(include: $include) } }";

  function addToItem(transport, target, kind, candidateId) {
    return Promise.resolve().then(function () {
      const document = target && (target.type === "scene" || target.type === "image") && (kind === "tag" || kind === "performer") ? WRITES[target.type + ":" + kind] : null;
      if (!document) throw new Error("Unsupported suggestion.");
      if (!isId(target.id) || !isId(candidateId)) throw new Error("Invalid ID.");
      return transport(document, { ids: [target.id], add: [candidateId] });
    }).then(function (data) {
      const rows = data && (target.type === "scene" ? data.bulkSceneUpdate : data.bulkImageUpdate);
      const row = Array.isArray(rows) && rows.length === 1 ? rows[0] : null;
      const list = row && row[kind === "tag" ? "tags" : "performers"];
      if (!row || String(row.id) !== target.id || !Array.isArray(list) || !list.some(function (entry) { return String(entry.id) === candidateId; })) {
        throw new Error("Stash did not confirm the change.");
      }
      return row;
    });
  }

  // configurePlugin replaces the plugin's whole settings map, so the current
  // map is read back from Stash and only excludedTags is extended.
  function excludeTag(read, transport, name) {
    const clean = typeof name === "string" ? name.trim() : "";
    return Promise.resolve().then(function () {
      if (!clean || clean.indexOf(",") !== -1) throw new Error("This tag name can't be added to the excluded list.");
      return read(CONFIG_QUERY, { include: [ID] });
    }).then(function (data) {
      const plugins = data && data.configuration && data.configuration.plugins;
      if (!plugins || typeof plugins !== "object") throw new Error("Couldn't read the plugin settings.");
      const current = plugins[ID] && typeof plugins[ID] === "object" ? plugins[ID] : {};
      const raw = typeof current.excludedTags === "string" ? current.excludedTags.replace(/[\s,]+$/, "").trim() : "";
      if (parseExcludedTags(raw).some(function (entry) { return entry.toLowerCase() === clean.toLowerCase(); })) return current;
      const next = Object.assign({}, current, { excludedTags: raw ? raw + ", " + clean : clean });
      return transport(CONFIGURE, { input: next }).then(function (result) {
        const saved = result && result.configurePlugin;
        if (!saved || saved.excludedTags !== next.excludedTags) throw new Error("Stash did not confirm the setting.");
        return saved;
      });
    });
  }

  // ---------------------------------------------------------------------------
  // Loading

  const ITEM_QUERIES = Object.freeze({
    scene: "query TagPerformerSuggestionsScene($id: ID!) { item: findScene(id: $id) { id tags { id name } performers { id name } studio { id name } groups { group { id name } } galleries { id title } } }",
    image: "query TagPerformerSuggestionsImage($id: ID!) { item: findImage(id: $id) { id tags { id name } performers { id name } studio { id name } galleries { id title } } }",
  });
  const TOTALS_QUERY = "query TagPerformerSuggestionsTotals {" +
    " taggedScenes: findScenes(scene_filter: { tag_count: { value: 0, modifier: GREATER_THAN } }, filter: { per_page: 0 }) { count }" +
    " taggedImages: findImages(image_filter: { tag_count: { value: 0, modifier: GREATER_THAN } }, filter: { per_page: 0 }) { count }" +
    " castScenes: findScenes(scene_filter: { performer_count: { value: 0, modifier: GREATER_THAN } }, filter: { per_page: 0 }) { count }" +
    " castImages: findImages(image_filter: { performer_count: { value: 0, modifier: GREATER_THAN } }, filter: { per_page: 0 }) { count } }";
  const SOURCE_QUERY = "query TagPerformerSuggestionsSource($scene_filter: SceneFilterType, $image_filter: ImageFilterType, $filter: FindFilterType, $scenes: Boolean!, $images: Boolean!) {" +
    " findScenes(scene_filter: $scene_filter, filter: $filter) @include(if: $scenes) { count scenes { id tags { id } performers { id } } }" +
    " findImages(image_filter: $image_filter, filter: $filter) @include(if: $images) { count images { id tags { id } performers { id } } } }";
  const TAGS_QUERY = "query TagPerformerSuggestionsTags($ids: [ID!]) { findTags(ids: $ids, filter: { per_page: -1 }) { tags { id name scene_count(depth: 0) image_count(depth: 0) parents { id } } } }";
  const TAG_PARENTS_QUERY = "query TagPerformerSuggestionsTagParents($ids: [ID!]) { findTags(ids: $ids, filter: { per_page: -1 }) { tags { id name parents { id } } } }";
  const PERFORMERS_QUERY = "query TagPerformerSuggestionsPerformers($ids: [ID!]) { findPerformers(ids: $ids, filter: { per_page: -1 }) { performers { id name scene_count image_count } } }";

  function ids(list) { return (list || []).map(function (entry) { return String(entry.id); }); }

  function loadSettings(read) {
    return read(CONFIG_QUERY, { include: [ID] }).then(function (data) {
      const plugins = data && data.configuration && data.configuration.plugins;
      return normalizeSettings(plugins && plugins[ID]);
    });
  }

  function loadItem(read, target) {
    if (!target || !ITEM_QUERIES[target.type] || !isId(target.id)) return Promise.reject(new Error("Invalid scene or image."));
    return read(ITEM_QUERIES[target.type], { id: target.id }).then(function (data) {
      const item = data && data.item;
      if (!item) throw new Error("The " + target.type + " was not found.");
      return {
        type: target.type,
        id: String(item.id),
        tags: (item.tags || []).map(function (tag) { return { id: String(tag.id), name: tag.name }; }),
        performers: (item.performers || []).map(function (performer) { return { id: String(performer.id), name: performer.name }; }),
        studio: item.studio ? { id: String(item.studio.id), name: item.studio.name } : null,
        groups: (item.groups || []).filter(function (entry) { return entry && entry.group; }).map(function (entry) { return { id: String(entry.group.id), name: entry.group.name }; }),
        galleries: (item.galleries || []).map(function (gallery) { return { id: String(gallery.id), name: gallery.title || "Gallery " + gallery.id }; }),
      };
    });
  }

  function loadTotals(read) {
    return read(TOTALS_QUERY, {}).then(function (data) {
      const count = function (key) { return data && data[key] && typeof data[key].count === "number" ? data[key].count : 0; };
      return { taggedItems: count("taggedScenes") + count("taggedImages"), castItems: count("castScenes") + count("castImages") };
    });
  }

  // The scenes and images that share one thing with the item.
  function evidenceSources(item) {
    const sources = [];
    const add = function (kind, entity, criterion, images) {
      sources.push({ kind, id: entity.id, label: entity.name, sceneFilter: criterion, imageFilter: images ? criterion : null });
    };
    item.performers.forEach(function (performer) { add("performer", performer, { performers: { value: [performer.id], modifier: "INCLUDES" } }, true); });
    item.tags.forEach(function (tag) { add("tag", tag, { tags: { value: [tag.id], modifier: "INCLUDES", depth: 0 } }, true); });
    if (item.studio) add("studio", item.studio, { studios: { value: [item.studio.id], modifier: "INCLUDES", depth: 0 } }, true);
    // Images can't belong to groups.
    item.groups.forEach(function (group) { add("group", group, { groups: { value: [group.id], modifier: "INCLUDES", depth: 0 } }, false); });
    item.galleries.forEach(function (gallery) { add("gallery", gallery, { galleries: { value: [gallery.id], modifier: "INCLUDES" } }, true); });
    return sources;
  }

  function sampleSeed(item) {
    const digits = Number(item.id) || 0;
    return (digits * 7919 + (item.type === "image" ? 1 : 0)) % 100000000;
  }

  function loadSource(read, item, source) {
    const filter = { per_page: SAMPLE_SIZE, sort: "random_" + sampleSeed(item) };
    return read(SOURCE_QUERY, {
      scene_filter: source.sceneFilter,
      image_filter: source.imageFilter,
      filter,
      scenes: !!source.sceneFilter,
      images: !!source.imageFilter,
    }).then(function (data) {
      const rows = [];
      let total = 0;
      const collect = function (type, result, field) {
        if (!result) return;
        total += typeof result.count === "number" ? result.count : 0;
        (result[field] || []).forEach(function (row) {
          const id = String(row.id);
          // The item's own tags and performers are what is being predicted.
          if (type === item.type && id === item.id) return;
          rows.push({ type, id, tagIds: ids(row.tags), performerIds: ids(row.performers) });
        });
      };
      collect("scene", data && data.findScenes, "scenes");
      collect("image", data && data.findImages, "images");
      // Every source matches the item itself, which is never among the rows.
      return { kind: source.kind, id: source.id, label: source.label, rows, sampled: total - 1 > rows.length };
    });
  }

  function mapLimit(items, limit, fn) {
    const results = new Array(items.length);
    let next = 0;
    const worker = function () {
      if (next >= items.length) return Promise.resolve();
      const index = next++;
      return fn(items[index]).then(function (value) { results[index] = value; return worker(); });
    };
    const workers = [];
    for (let i = 0; i < Math.min(limit, items.length); i += 1) workers.push(worker());
    return Promise.all(workers).then(function () { return results; });
  }

  function chunk(list, size) {
    const out = [];
    for (let i = 0; i < list.length; i += size) out.push(list.slice(i, i + size));
    return out;
  }

  // Counts, names and the full ancestor chain of every tag that matters.
  function loadTagMeta(read, tagIds) {
    const meta = {};
    const store = function (tags) {
      (tags || []).forEach(function (tag) {
        meta[String(tag.id)] = {
          id: String(tag.id),
          name: tag.name,
          count: (tag.scene_count || 0) + (tag.image_count || 0),
          parentIds: ids(tag.parents),
        };
      });
    };
    const fetchBatches = function (document, list) {
      return mapLimit(chunk(list, 500), CONCURRENCY, function (batch) {
        return read(document, { ids: batch }).then(function (data) { store(data && data.findTags && data.findTags.tags); });
      });
    };
    const climb = function (depth) {
      const missing = new Set();
      Object.keys(meta).forEach(function (id) { meta[id].parentIds.forEach(function (parent) { if (!meta[parent]) missing.add(parent); }); });
      if (!missing.size || depth >= MAX_TAG_DEPTH) return Promise.resolve(meta);
      const before = Object.keys(meta).length;
      return fetchBatches(TAG_PARENTS_QUERY, Array.from(missing)).then(function () {
        // A parent Stash no longer returns would otherwise loop forever.
        if (Object.keys(meta).length === before) return meta;
        return climb(depth + 1);
      });
    };
    if (!tagIds.length) return Promise.resolve(meta);
    return fetchBatches(TAGS_QUERY, tagIds).then(function () { return climb(0); });
  }

  function loadPerformerMeta(read, performerIds) {
    const meta = {};
    if (!performerIds.length) return Promise.resolve(meta);
    return mapLimit(chunk(performerIds, 500), CONCURRENCY, function (batch) {
      return read(PERFORMERS_QUERY, { ids: batch }).then(function (data) {
        ((data && data.findPerformers && data.findPerformers.performers) || []).forEach(function (performer) {
          meta[String(performer.id)] = { id: String(performer.id), name: performer.name, count: (performer.scene_count || 0) + (performer.image_count || 0) };
        });
      });
    }).then(function () { return meta; });
  }

  // ---------------------------------------------------------------------------
  // Scoring

  // Only rows that carry at least one of the field count: an untagged item
  // says nothing about which tags it should have.
  function tally(rows, field) {
    const counts = new Map();
    let total = 0;
    rows.forEach(function (row) {
      const values = row[field];
      if (!values || !values.length) return;
      total += 1;
      new Set(values).forEach(function (value) { counts.set(value, (counts.get(value) || 0) + 1); });
    });
    return { total, counts };
  }

  function smoothedConfidence(support, total, base) {
    return (support + SMOOTHING * base) / (total + SMOOTHING);
  }

  // IDs that reach the minimum support in at least one source, before any
  // metadata is loaded.
  function supportedIds(sources, kinds, field, minSupport, skip) {
    const found = new Set();
    sources.forEach(function (source) {
      if (kinds.indexOf(source.kind) === -1) return;
      tally(source.rows, field).counts.forEach(function (count, id) { if (count >= minSupport && !skip.has(id)) found.add(id); });
    });
    return Array.from(found);
  }

  function rankCandidates(sources, kinds, field, thresholds, baseRate, skip) {
    const byId = new Map();
    sources.forEach(function (source) {
      if (kinds.indexOf(source.kind) === -1) return;
      const counts = tally(source.rows, field);
      if (!counts.total) return;
      counts.counts.forEach(function (support, id) {
        if (support < thresholds.support || skip(id)) return;
        const base = baseRate(id);
        if (!(base > 0)) return;
        const confidence = smoothedConfidence(support, counts.total, base), lift = confidence / base;
        if (confidence < thresholds.confidence || lift < thresholds.lift) return;
        if (!byId.has(id)) byId.set(id, []);
        byId.get(id).push({ kind: source.kind, id: source.id, label: source.label, support, total: counts.total, base, confidence, lift, sampled: !!source.sampled });
      });
    });
    const ranked = [];
    byId.forEach(function (evidence, id) {
      evidence.sort(function (a, b) { return b.confidence - a.confidence || b.support - a.support; });
      const best = evidence[0];
      ranked.push({
        id,
        score: best.confidence + AGREEMENT_BONUS * Math.min(evidence.length - 1, MAX_BONUS_SOURCES),
        confidence: best.confidence,
        lift: best.lift,
        base: best.base,
        support: best.support,
        total: best.total,
        evidence,
      });
    });
    return ranked;
  }

  function byRank(a, b) {
    return b.score - a.score || b.support - a.support || String(a.name).localeCompare(String(b.name)) || Number(a.id) - Number(b.id);
  }

  function ancestorsOf(id, tagMeta) {
    const seen = new Set(), queue = [id];
    while (queue.length) {
      const meta = tagMeta[queue.shift()];
      if (!meta) continue;
      meta.parentIds.forEach(function (parent) { if (!seen.has(parent)) { seen.add(parent); queue.push(parent); } });
    }
    seen.delete(id);
    return seen;
  }

  function hasPerformerAnchor(item) {
    return item.performers.length > 0 || item.groups.length > 0 || item.galleries.length > 0;
  }

  function thresholdsFor(settings, kind) {
    return kind === "tag"
      ? { support: settings.tagMinSupport, confidence: settings.tagMinConfidence / 100, lift: settings.tagMinLift, max: settings.maxTagSuggestions }
      : { support: settings.performerMinSupport, confidence: settings.performerMinConfidence / 100, lift: settings.performerMinLift, max: settings.maxPerformerSuggestions };
  }

  // The share of the library carrying a tag or performer; never zero, so
  // lift stays finite for a candidate Stash has just counted as unused.
  function rateOf(meta, id, population) {
    const count = Math.max(meta[id] ? meta[id].count : 0, 1);
    return Math.min(count / Math.max(population, 1), 1);
  }

  // The whole scoring pass, keeping what was dropped along the way so the
  // tuning tools can explain any candidate the same way it was scored.
  function scoreDetails(data, rawSettings) {
    const settings = normalizeSettings(rawSettings);
    const item = data.item, sources = data.sources || [], tagMeta = data.tagMeta || {}, performerMeta = data.performerMeta || {};
    const totals = data.totals || { taggedItems: 0, castItems: 0 };

    // Tags
    const onItem = new Set(ids(item.tags));
    const blocked = new Set();
    onItem.forEach(function (id) { ancestorsOf(id, tagMeta).forEach(function (parent) { blocked.add(parent); }); });
    const excluded = new Map(settings.excludedTags.map(function (name) { return [name.toLowerCase(), name]; }));
    // The excluded-list entry that hides a tag, and the tag in its chain it matched.
    const excludedBy = function (id) {
      const chain = [id].concat(Array.from(ancestorsOf(id, tagMeta)));
      for (let i = 0; i < chain.length; i += 1) {
        const meta = tagMeta[chain[i]];
        if (meta && excluded.has(String(meta.name).toLowerCase())) return { entry: excluded.get(String(meta.name).toLowerCase()), via: meta.name };
      }
      return null;
    };
    const tagRate = function (id) { return rateOf(tagMeta, id, totals.taggedItems); };
    const tagQualified = rankCandidates(sources, TAG_SOURCE_KINDS, "tagIds", thresholdsFor(settings, "tag"), tagRate, function (id) {
      return !tagMeta[id] || onItem.has(id) || blocked.has(id) || !!excludedBy(id);
    });
    // A parent says less than its child, so suggest only the child.
    const tagParents = new Set();
    tagQualified.forEach(function (candidate) { ancestorsOf(candidate.id, tagMeta).forEach(function (parent) { tagParents.add(parent); }); });
    const tagOrdered = tagQualified
      .filter(function (candidate) { return !tagParents.has(candidate.id); })
      .map(function (candidate) { return Object.assign(candidate, { name: tagMeta[candidate.id].name }); })
      .sort(byRank);

    // Performers
    let performerOrdered = [];
    const cast = new Set(ids(item.performers));
    const performerEvidence = hasPerformerAnchor(item);
    if (performerEvidence) {
      const performerRate = function (id) { return rateOf(performerMeta, id, totals.castItems); };
      performerOrdered = rankCandidates(sources, PERFORMER_SOURCE_KINDS, "performerIds", thresholdsFor(settings, "performer"), performerRate, function (id) {
        return !performerMeta[id] || cast.has(id);
      })
        .map(function (candidate) { return Object.assign(candidate, { name: performerMeta[candidate.id].name }); })
        .sort(byRank);
    }

    const related = new Set();
    sources.forEach(function (source) { source.rows.forEach(function (row) { related.add(row.type + ":" + row.id); }); });
    const tallies = new Map();
    return {
      settings, onItem, cast, blocked, excludedBy, tagQualified, tagParents, tagOrdered, performerOrdered, performerEvidence,
      tags: tagOrdered.slice(0, settings.maxTagSuggestions),
      performers: performerOrdered.slice(0, settings.maxPerformerSuggestions),
      relatedItems: related.size,
      sampled: sources.some(function (source) { return source.sampled; }),
      tally: function (source, field) {
        if (!tallies.has(source)) tallies.set(source, {});
        const cache = tallies.get(source);
        if (!cache[field]) cache[field] = tally(source.rows, field);
        return cache[field];
      },
    };
  }

  function scoreSuggestions(data, rawSettings) {
    const details = scoreDetails(data, rawSettings);
    return { tags: details.tags, performers: details.performers, performerEvidence: details.performerEvidence, relatedItems: details.relatedItems, sampled: details.sampled };
  }

  // ---------------------------------------------------------------------------
  // Tuning: why a candidate was or was not suggested

  const VERDICTS = Object.freeze({
    suggested: "Suggested",
    present: "Already on item",
    blocked: "Parent of an item tag",
    excluded: "Excluded",
    "no-anchor": "No performer evidence",
    unrelated: "Not related",
    "below-thresholds": "Below thresholds",
    "parent-of-suggestion": "Child suggested instead",
    "over-limit": "Over the limit",
    unknown: "Unknown",
  });

  function percent(value) { return (Math.round(value * 1000) / 10) + "%"; }
  function fixed(value) { return (Math.round(value * 100) / 100).toFixed(2); }
  function joinNames(names) {
    return names.length <= 1 ? names.join("") : names.slice(0, -1).join(", ") + " and " + names[names.length - 1];
  }

  function failureText(evidence, thresholds) {
    const parts = [];
    if (evidence.failed.indexOf("support") !== -1) parts.push("support " + evidence.support + ", needs " + thresholds.support);
    if (evidence.failed.indexOf("confidence") !== -1) parts.push("confidence " + percent(evidence.confidence) + ", needs " + percent(thresholds.confidence));
    if (evidence.failed.indexOf("lift") !== -1) parts.push("lift " + fixed(evidence.lift) + ", needs " + thresholds.lift);
    return parts.join("; ");
  }

  // Mirrors scoreDetails step by step, so its verdict always matches what
  // the panel shows.
  function explainCandidate(details, data, kind, id) {
    const isTag = kind === "tag", item = data.item, settings = details.settings;
    const meta = (isTag ? data.tagMeta : data.performerMeta) || {};
    const entry = meta[id];
    if (!entry) return { kind, id, name: null, verdict: "unknown", reasons: ["Stash has no " + kind + " with ID " + id + "."], evidence: [] };
    const totals = data.totals || { taggedItems: 0, castItems: 0 };
    const population = isTag ? totals.taggedItems : totals.castItems;
    const base = rateOf(meta, id, population);
    const thresholds = thresholdsFor(settings, kind);
    const field = isTag ? "tagIds" : "performerIds";
    const kinds = isTag ? TAG_SOURCE_KINDS : PERFORMER_SOURCE_KINDS;
    const evidence = (data.sources || []).filter(function (source) { return kinds.indexOf(source.kind) !== -1; }).map(function (source) {
      const counts = details.tally(source, field);
      const support = counts.counts.get(id) || 0;
      const confidence = smoothedConfidence(support, counts.total, base), lift = confidence / base;
      const failed = [];
      if (support < thresholds.support) failed.push("support");
      if (confidence < thresholds.confidence) failed.push("confidence");
      if (lift < thresholds.lift) failed.push("lift");
      return { kind: source.kind, id: source.id, label: source.label, support, total: counts.total, confidence, lift, sampled: !!source.sampled, failed };
    }).sort(function (a, b) { return b.confidence - a.confidence || b.support - a.support; });
    const out = { kind, id, name: entry.name, count: entry.count, population, base, thresholds, evidence, rank: null, verdict: null, reasons: [] };
    const finish = function (verdict, reason) { out.verdict = verdict; out.reasons.push(reason); return out; };
    const noun = item.type;

    if (isTag ? details.onItem.has(id) : details.cast.has(id)) return finish("present", "Already on this " + noun + ".");
    if (isTag && details.blocked.has(id)) {
      const children = item.tags.filter(function (tag) { return ancestorsOf(tag.id, data.tagMeta).has(id); }).map(function (tag) { return tag.name; });
      return finish("blocked", "A parent of " + joinNames(children) + ", already on this " + noun + ".");
    }
    if (isTag) {
      const exclusion = details.excludedBy(id);
      if (exclusion) {
        return finish("excluded", exclusion.via === entry.name
          ? "\"" + exclusion.entry + "\" is in Excluded tags."
          : "Its parent " + exclusion.via + " matches \"" + exclusion.entry + "\" in Excluded tags.");
      }
    }
    if (!isTag && !details.performerEvidence) return finish("no-anchor", "Performer suggestions need a performer, group or gallery on this " + noun + ". A studio alone is not enough.");
    const seen = evidence.filter(function (e) { return e.support > 0; });
    if (!seen.length) return finish("unrelated", "No related item has this " + kind + ".");
    if (!evidence.some(function (e) { return !e.failed.length; })) {
      return finish("below-thresholds", "No source clears every threshold. Closest: " + describeEvidence(seen[0], kind) + " (" + failureText(seen[0], thresholds) + ").");
    }
    if (isTag && details.tagParents.has(id)) {
      const children = details.tagQualified.filter(function (candidate) { return ancestorsOf(candidate.id, data.tagMeta).has(id); })
        .map(function (candidate) { return data.tagMeta[candidate.id].name; });
      return finish("parent-of-suggestion", "Its child tag " + joinNames(children) + " also qualifies, and only the child is suggested.");
    }
    const ordered = isTag ? details.tagOrdered : details.performerOrdered;
    const index = ordered.findIndex(function (candidate) { return candidate.id === id; });
    if (index === -1) return finish("below-thresholds", "No source clears every threshold.");
    out.rank = index + 1;
    if (index >= thresholds.max) return finish("over-limit", "Qualifies, but ranks #" + out.rank + " of " + ordered.length + ". Only the top " + thresholds.max + " are shown.");
    return finish("suggested", "Suggested, ranked #" + out.rank + ".");
  }

  const NEAR_MISS_VERDICTS = Object.freeze(["below-thresholds", "parent-of-suggestion", "over-limit"]);

  // Candidates seen among related items that were not shown, closest first.
  function nearMisses(details, data, kind, limit) {
    const isTag = kind === "tag";
    const meta = (isTag ? data.tagMeta : data.performerMeta) || {};
    const field = isTag ? "tagIds" : "performerIds";
    const kinds = isTag ? TAG_SOURCE_KINDS : PERFORMER_SOURCE_KINDS;
    const seen = new Set();
    (data.sources || []).forEach(function (source) {
      if (kinds.indexOf(source.kind) === -1) return;
      details.tally(source, field).counts.forEach(function (count, id) { seen.add(id); });
    });
    const misses = [];
    seen.forEach(function (id) {
      if (!meta[id]) return;
      const explanation = explainCandidate(details, data, kind, id);
      if (NEAR_MISS_VERDICTS.indexOf(explanation.verdict) !== -1) misses.push(explanation);
    });
    misses.sort(function (a, b) {
      return b.evidence[0].confidence - a.evidence[0].confidence || b.evidence[0].support - a.evidence[0].support || String(a.name).localeCompare(String(b.name));
    });
    return misses.slice(0, limit);
  }

  const SEARCH_QUERIES = Object.freeze({
    tag: "query TagPerformerSuggestionsSearchTags($q: String!) { results: findTags(filter: { q: $q, per_page: 8, sort: \"name\", direction: ASC }) { items: tags { id name } } }",
    performer: "query TagPerformerSuggestionsSearchPerformers($q: String!) { results: findPerformers(filter: { q: $q, per_page: 8, sort: \"name\", direction: ASC }) { items: performers { id name } } }",
  });

  function searchCandidates(read, kind, text) {
    const q = typeof text === "string" ? text.trim() : "";
    if (!q || !SEARCH_QUERIES[kind]) return Promise.resolve([]);
    return read(SEARCH_QUERIES[kind], { q }).then(function (data) {
      return ((data && data.results && data.results.items) || []).map(function (entry) { return { id: String(entry.id), name: entry.name }; });
    });
  }

  // Metadata for a searched candidate that scoring never needed.
  function loadCandidateMeta(read, kind, id) {
    if (!isId(id)) return Promise.reject(new Error("Invalid ID."));
    return kind === "tag" ? loadTagMeta(read, [id]) : loadPerformerMeta(read, [id]);
  }

  function computeSuggestions(read, target) {
    let settings, item, totals, sources;
    return Promise.all([loadSettings(read), loadItem(read, target), loadTotals(read)]).then(function (loaded) {
      settings = loaded[0];
      item = loaded[1];
      totals = loaded[2];
      return mapLimit(evidenceSources(item), CONCURRENCY, function (source) { return loadSource(read, item, source); });
    }).then(function (loadedSources) {
      sources = loadedSources;
      // Tuning can lower thresholds on the spot, so it needs every candidate.
      const tagSupport = settings.showTuningTools ? 1 : settings.tagMinSupport;
      const performerSupport = settings.showTuningTools ? 1 : settings.performerMinSupport;
      const onItem = new Set(ids(item.tags));
      const tagIds = supportedIds(sources, TAG_SOURCE_KINDS, "tagIds", tagSupport, onItem);
      const performerIds = hasPerformerAnchor(item)
        ? supportedIds(sources, PERFORMER_SOURCE_KINDS, "performerIds", performerSupport, new Set(ids(item.performers)))
        : [];
      return Promise.all([loadTagMeta(read, tagIds.concat(Array.from(onItem))), loadPerformerMeta(read, performerIds)]);
    }).then(function (meta) {
      const data = { item, sources, tagMeta: meta[0], performerMeta: meta[1], totals };
      return Object.assign(scoreSuggestions(data, settings), { item, data, settings });
    });
  }

  // ---------------------------------------------------------------------------
  // Explanations

  function sourcePhrase(evidence) {
    switch (evidence.kind) {
      case "performer": return "featuring " + evidence.label;
      case "tag": return "tagged " + evidence.label;
      case "studio": return "from " + evidence.label;
      case "group": return "in group " + evidence.label;
      case "gallery": return "in gallery " + evidence.label;
      default: return "related to " + evidence.label;
    }
  }

  function describeEvidence(evidence, kind) {
    const counts = evidence.support + " of " + evidence.total;
    // Items with a tag are tagged items, so "tagged" would be said twice.
    const text = kind === "tag"
      ? "On " + counts + (evidence.kind === "tag" ? " items " : " tagged items ") + sourcePhrase(evidence)
      : "In " + counts + " items with performers " + sourcePhrase(evidence);
    return evidence.sampled ? text + " (sampled)" : text;
  }

  // ---------------------------------------------------------------------------
  // UI

  function createComponents(PluginApi) {
    const React = PluginApi.React, h = React.createElement;
    const libraries = PluginApi.libraries || {};
    const Router = libraries.ReactRouterDOM || {};
    const read = createReader(fetchTransport);

    // Our writes bypass Apollo, so Stash's own page queries are refreshed.
    function refreshStash(type) {
      const service = PluginApi.utils && PluginApi.utils.StashService;
      const client = service && service.getClient ? service.getClient() : null;
      if (!client || !client.refetchQueries) return;
      Promise.resolve(client.refetchQueries({ include: [type === "image" ? "FindImage" : "FindScene"] })).catch(function () {});
    }

    const SETTLED = new Set(["added", "dismissed", "excluded", "error"]);

    // The first enabled button after the row, else before it, else Recalculate.
    function nextFocusTarget(row, panel) {
      if (!panel || !panel.isConnected) return null;
      const rows = Array.prototype.slice.call(panel.querySelectorAll(".tps-row"));
      const button = function (candidate) { return candidate.querySelector(".tps-actions button:not([disabled])") || candidate.querySelector("button:not([disabled])"); };
      const index = rows.indexOf(row);
      const after = index === -1 ? rows : rows.slice(index + 1);
      const before = index === -1 ? [] : rows.slice(0, index).reverse();
      const found = after.concat(before).map(button).filter(Boolean)[0];
      return found || panel.querySelector(".tps-refresh");
    }

    function EntityLink(props) {
      const href = (props.kind === "tag" ? "/tags/" : "/performers/") + props.id;
      return Router.Link
        ? h(Router.Link, { to: href, className: "tps-name" }, props.name)
        : h("a", { href, className: "tps-name" }, props.name);
    }

    function metric(name, value, failed) {
      const fail = failed.indexOf(name) !== -1;
      return h("span", { className: "tps-metric " + (fail ? "tps-fail" : "tps-pass") }, name + " " + value + (fail ? " ✗" : " ✓"));
    }

    function SuggestionRow(props) {
      const suggestion = props.suggestion, kind = props.kind, state = props.state || {};
      const busy = state.status === "adding" || state.status === "excluding";
      const noun = kind === "tag" ? "tag" : "performer";
      const more = suggestion.evidence.slice(1);
      const expandedPair = React.useState(false), expanded = expandedPair[0], setExpanded = expandedPair[1];
      const listId = ID + "-sources-" + kind + "-" + suggestion.id;
      const actions = state.status === "added"
        ? h("span", { className: "tps-added", role: "status" }, "Added")
        : h("div", { className: "tps-actions" },
          h("button", {
            type: "button", className: "btn btn-primary btn-sm tps-add", disabled: busy,
            "aria-label": "Add " + noun + " " + suggestion.name,
            onClick: function (event) { props.onAdd(kind, suggestion, event); },
          }, state.status === "adding" ? "Adding…" : "Add"),
          h("button", {
            type: "button", className: "btn btn-secondary btn-sm tps-dismiss", disabled: busy,
            "aria-label": "Dismiss " + noun + " " + suggestion.name,
            onClick: function (event) { props.onDismiss(kind, suggestion, event); },
          }, "Dismiss"),
          kind === "tag" && suggestion.name.indexOf(",") === -1 ? h("button", {
            type: "button", className: "btn btn-link btn-sm tps-exclude", disabled: busy,
            "aria-label": "Exclude tag " + suggestion.name + " from suggestions",
            title: "Never suggest this tag (or its child tags) again",
            onClick: function (event) { props.onExclude(suggestion, event); },
          }, state.status === "excluding" ? "Excluding…" : "Exclude") : null);
      return h("li", { className: "tps-row", "data-kind": kind, "data-id": suggestion.id },
        h("div", { className: "tps-main" },
          h(EntityLink, { kind, id: suggestion.id, name: suggestion.name }),
          h("span", { className: "tps-reason" }, describeEvidence(suggestion.evidence[0], kind)),
          props.tuning ? h("span", { className: "tps-stats" },
            "confidence " + percent(suggestion.confidence) + " · lift " + fixed(suggestion.lift) + " · base " + percent(suggestion.base) + " · score " + fixed(suggestion.score)) : null,
          // A button, not a tooltip, so touch screens can show the sources too.
          more.length ? h("button", {
            type: "button", className: "btn btn-link tps-more",
            "aria-expanded": expanded ? "true" : "false", "aria-controls": listId,
            onClick: function () { setExpanded(!expanded); },
          }, (expanded ? "Hide " : "+") + more.length + " more " + (more.length === 1 ? "source" : "sources")) : null,
          more.length && expanded ? h("ul", { id: listId, className: "tps-sources" }, more.map(function (evidence) {
            return h("li", { key: evidence.kind + ":" + evidence.id }, describeEvidence(evidence, kind));
          })) : null),
        actions,
        state.status === "error" ? h("p", { className: "tps-error", role: "alert" }, state.error) : null);
    }

    function SuggestionList(props) {
      const visible = props.suggestions.filter(function (suggestion) {
        const state = props.states[props.kind + ":" + suggestion.id];
        return !state || (state.status !== "dismissed" && state.status !== "excluded");
      });
      return h("section", { className: "tps-section", "data-kind": props.kind },
        h("h6", { className: "tps-heading" }, props.title),
        visible.length
          ? h("ul", { className: "tps-list" }, visible.map(function (suggestion) {
            return h(SuggestionRow, {
              key: suggestion.id, kind: props.kind, suggestion, tuning: props.tuning,
              state: props.states[props.kind + ":" + suggestion.id],
              onAdd: props.onAdd, onDismiss: props.onDismiss, onExclude: props.onExclude,
            });
          }))
          : h("p", { className: "tps-empty" }, props.suggestions.length ? "No more " + props.kind + " suggestions." : props.empty));
    }

    // ---- Tuning tools: read-only; nothing here writes to Stash. ----

    function VerdictBadge(props) {
      return h("span", { className: "tps-verdict", "data-verdict": props.verdict }, VERDICTS[props.verdict] || props.verdict);
    }

    function ExplanationCard(props) {
      const explanation = props.explanation, kind = props.kind;
      const population = kind === "tag" ? "tagged items" : "items with performers";
      return h("div", { className: "tps-explanation", "data-verdict": explanation.verdict, "data-kind": kind, "data-id": explanation.id },
        h("div", { className: "tps-explanation-head" },
          h(EntityLink, { kind, id: explanation.id, name: explanation.name || kind + " " + explanation.id }),
          h(VerdictBadge, { verdict: explanation.verdict })),
        explanation.reasons.map(function (reason, index) { return h("p", { key: index, className: "tps-explanation-reason" }, reason); }),
        typeof explanation.population === "number"
          ? h("p", { className: "tps-muted" }, "Library: " + (kind === "tag" ? "on " : "in ") + explanation.count + " of " + explanation.population + " " + population + " (" + percent(explanation.base) + ").")
          : null,
        explanation.evidence.length
          ? h("ul", { className: "tps-evidence", "aria-label": "Sources" }, explanation.evidence.map(function (evidence) {
            return h("li", { key: evidence.kind + ":" + evidence.id, "data-failed": evidence.failed.join(" ") || "none" },
              h("span", { className: "tps-evidence-source" }, describeEvidence(evidence, kind)),
              h("span", { className: "tps-evidence-metrics" },
                metric("support", String(evidence.support), evidence.failed), " · ",
                metric("confidence", percent(evidence.confidence), evidence.failed), " · ",
                metric("lift", fixed(evidence.lift), evidence.failed)));
          }))
          : null);
    }

    function WhyNot(props) {
      const kindPair = React.useState("tag"), kind = kindPair[0], setKind = kindPair[1];
      const textPair = React.useState(""), text = textPair[0], setText = textPair[1];
      const resultsPair = React.useState({ status: "idle", items: [] }), results = resultsPair[0], setResults = resultsPair[1];
      React.useEffect(function () {
        const q = text.trim();
        if (!q) { setResults({ status: "idle", items: [] }); return undefined; }
        let live = true;
        const timer = setTimeout(function () {
          setResults(function (previous) { return { status: "loading", items: previous.items }; });
          searchCandidates(read, kind, q).then(function (items) {
            if (live) setResults({ status: "ready", items });
          }, function (error) {
            if (live) setResults({ status: "error", items: [], error: error.message });
          });
        }, 200);
        return function () { live = false; clearTimeout(timer); };
      }, [kind, text]);
      const noun = kind === "tag" ? "tags" : "performers";
      return h("section", { className: "tps-tool", "data-tool": "why-not" },
        h("h6", { className: "tps-heading" }, "Why not?"),
        h("p", { className: "tps-muted" }, "Look up any tag or performer to see how it scored for this " + props.noun + "."),
        h("div", { className: "tps-search-row" },
          h("div", { className: "btn-group btn-group-sm tps-kind", role: "group", "aria-label": "Look up" },
            ["tag", "performer"].map(function (value) {
              return h("button", {
                key: value, type: "button", "aria-pressed": kind === value ? "true" : "false",
                className: "btn " + (kind === value ? "btn-primary" : "btn-secondary"),
                onClick: function () { setKind(value); },
              }, value === "tag" ? "Tag" : "Performer");
            })),
          h("input", {
            type: "search", className: "form-control form-control-sm tps-search",
            placeholder: "Search " + noun, "aria-label": "Search " + noun, value: text,
            onChange: function (event) { setText(event.target.value); },
          })),
        results.status === "error" ? h("p", { className: "tps-error", role: "alert" }, "Search failed: " + results.error) : null,
        results.status === "ready" && !results.items.length ? h("p", { className: "tps-muted" }, "No " + noun + " match.") : null,
        results.items.length ? h("ul", { className: "tps-results", "aria-label": "Matching " + noun }, results.items.map(function (entry) {
          return h("li", { key: entry.id }, h("button", {
            type: "button", className: "btn btn-link tps-result",
            onClick: function () { props.onPick(kind, entry); setText(""); },
          }, entry.name));
        })) : null);
    }

    function NearMisses(props) {
      return h("section", { className: "tps-tool", "data-tool": "near-misses" },
        h("h6", { className: "tps-heading" }, "Near misses"),
        [["tag", "Tags"], ["performer", "Performers"]].map(function (pair) {
          const misses = props.misses[pair[0]];
          return h("div", { key: pair[0], className: "tps-misses", "data-kind": pair[0] },
            h("span", { className: "tps-subheading" }, pair[1]),
            misses.length
              ? h("ul", { className: "tps-results" }, misses.map(function (miss) {
                return h("li", { key: miss.id, className: "tps-miss" },
                  h("button", {
                    type: "button", className: "btn btn-link tps-result", "aria-label": "Explain " + pair[0] + " " + miss.name,
                    onClick: function () { props.onPick(pair[0], { id: miss.id, name: miss.name }); },
                  }, miss.name),
                  h(VerdictBadge, { verdict: miss.verdict }),
                  h("span", { className: "tps-muted tps-miss-reason" }, miss.reasons[0]));
              }))
              : h("p", { className: "tps-muted" }, "None."));
        }));
    }

    const THRESHOLD_FIELDS = Object.freeze([
      { kind: "tag", key: "tagMinSupport", label: "Min support", step: 1 },
      { kind: "tag", key: "tagMinConfidence", label: "Min confidence %", step: 1 },
      { kind: "tag", key: "tagMinLift", label: "Min lift", step: 0.1 },
      { kind: "tag", key: "maxTagSuggestions", label: "Max shown", step: 1 },
      { kind: "performer", key: "performerMinSupport", label: "Min support", step: 1 },
      { kind: "performer", key: "performerMinConfidence", label: "Min confidence %", step: 1 },
      { kind: "performer", key: "performerMinLift", label: "Min lift", step: 0.1 },
      { kind: "performer", key: "maxPerformerSuggestions", label: "Max shown", step: 1 },
    ]);

    function draftFrom(settings) {
      const draft = {};
      THRESHOLD_FIELDS.forEach(function (field) { draft[field.key] = String(settings[field.key]); });
      return draft;
    }

    // Trial thresholds re-score the loaded data in this view only.
    function TrialThresholds(props) {
      const draftPair = React.useState(function () { return draftFrom(props.effective); }), draft = draftPair[0], setDraft = draftPair[1];
      const errorPair = React.useState(""), error = errorPair[0], setError = errorPair[1];
      function apply(event) {
        event.preventDefault();
        const next = {}, problems = [];
        THRESHOLD_FIELDS.forEach(function (field) {
          const range = RANGES[field.key], value = Number(draft[field.key]);
          if (String(draft[field.key]).trim() === "" || !isFinite(value) || value < range[0] || value > range[1]) {
            problems.push((field.kind === "tag" ? "Tag " : "Performer ") + field.label.toLowerCase() + " must be " + range[0] + "–" + range[1] + ".");
          } else {
            next[field.key] = range[2] ? Math.floor(value) : value;
          }
        });
        setError(problems.join(" "));
        if (!problems.length) props.onApply(next);
      }
      function reset() {
        setError("");
        setDraft(draftFrom(props.saved));
        props.onApply(null);
      }
      return h("form", { className: "tps-tool", "data-tool": "thresholds", onSubmit: apply, noValidate: true },
        h("h6", { className: "tps-heading" }, "Trial thresholds"),
        h("p", { className: "tps-muted" }, props.active ? "Trial thresholds are applied to this view. Nothing is saved." : "Try other thresholds on this " + props.noun + ". Nothing is saved."),
        h("div", { className: "tps-threshold-grid" }, ["tag", "performer"].map(function (kind) {
          return h("fieldset", { key: kind, className: "tps-thresholds" },
            h("legend", { className: "tps-subheading" }, kind === "tag" ? "Tags" : "Performers"),
            THRESHOLD_FIELDS.filter(function (field) { return field.kind === kind; }).map(function (field) {
              const inputId = ID + "-" + field.key;
              return h("div", { key: field.key, className: "tps-field" },
                h("label", { htmlFor: inputId }, field.label),
                h("input", {
                  id: inputId, type: "number", className: "form-control form-control-sm", inputMode: "decimal",
                  min: RANGES[field.key][0], max: RANGES[field.key][1], step: field.step, value: draft[field.key],
                  onChange: function (event) { const value = event.target.value; setDraft(function (previous) { const next = Object.assign({}, previous); next[field.key] = value; return next; }); },
                }));
            }));
        })),
        error ? h("p", { className: "tps-error", role: "alert" }, error) : null,
        h("div", { className: "tps-actions" },
          h("button", { type: "submit", className: "btn btn-primary btn-sm" }, "Apply to this view"),
          h("button", { type: "button", className: "btn btn-secondary btn-sm", disabled: !props.active, onClick: reset }, "Reset to saved")));
    }

    const SOURCE_LABELS = Object.freeze({ performer: "Performer", tag: "Tag", studio: "Studio", group: "Group", gallery: "Gallery" });

    function DataSummary(props) {
      const data = props.data, totals = data.totals || { taggedItems: 0, castItems: 0 };
      return h("section", { className: "tps-tool", "data-tool": "data" },
        h("h6", { className: "tps-heading" }, "Data"),
        h("p", { className: "tps-muted" }, "Library: " + totals.taggedItems + " tagged items, " + totals.castItems + " items with performers."),
        data.sources.length
          ? h("ul", { className: "tps-data-sources", "aria-label": "Related item sources" }, data.sources.map(function (source) {
            return h("li", { key: source.kind + ":" + source.id },
              (SOURCE_LABELS[source.kind] || source.kind) + " " + source.label + ": " + source.rows.length + " related " + (source.rows.length === 1 ? "item" : "items") + (source.sampled ? " (sampled)" : ""));
          }))
          : h("p", { className: "tps-muted" }, "No sources: this " + props.noun + " has no performers, tags, studio, groups or galleries."));
    }

    function TuningPanel(props) {
      const selected = props.selected;
      let explanation = null;
      if (selected && selected.status === "ready") explanation = explainCandidate(props.details, props.data, selected.kind, selected.id);
      return h("div", { className: "tps-tuning", role: "region", "aria-label": "Tuning tools" },
        h("h6", { className: "tps-tuning-title" }, "Tuning"),
        h(WhyNot, { noun: props.noun, onPick: props.onPick }),
        selected && selected.status === "loading" ? h("p", { className: "tps-status", role: "status" }, "Loading " + selected.name + "…") : null,
        selected && selected.status === "error" ? h("p", { className: "tps-error", role: "alert" }, "Couldn't load " + selected.name + ": " + selected.error) : null,
        explanation ? h(ExplanationCard, { kind: selected.kind, explanation }) : null,
        h(NearMisses, { misses: props.misses, onPick: props.onPick }),
        h(TrialThresholds, { key: props.thresholdsKey, saved: props.saved, effective: props.effective, active: props.trial, noun: props.noun, onApply: props.onApply }),
        h(DataSummary, { data: props.data, noun: props.noun }));
    }

    function Suggestions(props) {
      const target = props.target;
      const resultPair = React.useState({ status: "loading" }), result = resultPair[0], setResult = resultPair[1];
      const statesPair = React.useState({}), states = statesPair[0], setStates = statesPair[1];
      const runPair = React.useState(0), run = runPair[0], setRun = runPair[1];
      const trialPair = React.useState(null), trial = trialPair[0], setTrial = trialPair[1];
      const extraPair = React.useState({ tag: {}, performer: {} }), extra = extraPair[0], setExtra = extraPair[1];
      const selectedPair = React.useState(null), selected = selectedPair[0], setSelected = selectedPair[1];
      const pending = React.useRef(new Set());
      const mounted = React.useRef(true);
      const focusAfter = React.useRef(null);
      // Counts finished loads, so tests and styles can tell a fresh result.
      const loads = React.useRef(0);

      React.useEffect(function () {
        mounted.current = true;
        return function () { mounted.current = false; };
      }, []);

      React.useEffect(function () {
        let live = true;
        setResult({ status: "loading" });
        computeSuggestions(read, target).then(function (value) {
          if (live) { loads.current += 1; setResult({ status: "ready", value }); }
        }, function (error) {
          if (live) { loads.current += 1; setResult({ status: "error", error: error && error.message ? error.message : String(error) }); }
        });
        return function () { live = false; };
      }, [target.type, target.id, run]);

      const value = result.status === "ready" ? result.value : null;
      const tuning = !!(value && value.settings.showTuningTools);
      // Metadata loaded for looked-up candidates joins the scored data.
      const data = React.useMemo(function () {
        if (!value) return null;
        return Object.assign({}, value.data, {
          tagMeta: Object.assign({}, value.data.tagMeta, extra.tag),
          performerMeta: Object.assign({}, value.data.performerMeta, extra.performer),
        });
      }, [value, extra]);
      const effective = React.useMemo(function () {
        return value ? normalizeSettings(Object.assign({}, value.settings, tuning ? trial : null)) : null;
      }, [value, trial, tuning]);
      const details = React.useMemo(function () { return data ? scoreDetails(data, effective) : null; }, [data, effective]);
      const misses = React.useMemo(function () {
        return tuning && details ? { tag: nearMisses(details, data, "tag", 5), performer: nearMisses(details, data, "performer", 5) } : null;
      }, [tuning, details, data]);

      // A finished action removes the pressed button. For keyboard users,
      // focus then moves to the next row instead of falling to the page.
      React.useEffect(function () {
        const pendingFocus = focusAfter.current;
        const state = pendingFocus && states[pendingFocus.key];
        if (!state || !SETTLED.has(state.status)) return;
        focusAfter.current = null;
        const origin = pendingFocus.origin;
        const element = origin.isConnected && !origin.disabled ? origin : nextFocusTarget(pendingFocus.row, pendingFocus.panel);
        if (element && element.focus) element.focus();
      }, [states]);
      function rememberFocus(key, event) {
        const origin = event && event.currentTarget;
        // Keyboard activation reports no click count.
        if (!origin || !origin.closest || event.detail !== 0) return;
        const row = origin.closest(".tps-row");
        focusAfter.current = { key, origin, row, panel: row && row.closest(".tps-panel") };
      }

      function setState(key, value) {
        if (!mounted.current) return;
        setStates(function (previous) { const next = Object.assign({}, previous); next[key] = value; return next; });
      }
      function add(kind, suggestion, event) {
        const key = kind + ":" + suggestion.id;
        if (pending.current.has(key)) return;
        pending.current.add(key);
        rememberFocus(key, event);
        setState(key, { status: "adding" });
        addToItem(fetchTransport, target, kind, suggestion.id).then(function () {
          setState(key, { status: "added" });
          refreshStash(target.type);
        }, function (error) {
          setState(key, { status: "error", error: error.message });
        }).then(function () { pending.current.delete(key); });
      }
      function dismiss(kind, suggestion, event) {
        const key = kind + ":" + suggestion.id;
        if (pending.current.has(key)) return;
        rememberFocus(key, event);
        setState(key, { status: "dismissed" });
      }
      function exclude(suggestion, event) {
        const key = "tag:" + suggestion.id;
        if (pending.current.has(key)) return;
        pending.current.add(key);
        rememberFocus(key, event);
        setState(key, { status: "excluding" });
        excludeTag(read, fetchTransport, suggestion.name).then(function () {
          setState(key, { status: "excluded" });
        }, function (error) {
          setState(key, { status: "error", error: error.message });
        }).then(function () { pending.current.delete(key); });
      }
      // Explains a candidate, first reading its counts and parents if
      // scoring never needed them.
      function pick(kind, entry) {
        const known = data && data[kind === "tag" ? "tagMeta" : "performerMeta"][entry.id];
        setSelected({ kind, id: entry.id, name: entry.name, status: known ? "ready" : "loading" });
        if (known) return;
        loadCandidateMeta(read, kind, entry.id).then(function (meta) {
          if (!mounted.current) return;
          setExtra(function (previous) { const next = Object.assign({}, previous); next[kind] = Object.assign({}, previous[kind], meta); return next; });
          setSelected(function (current) { return current && current.id === entry.id && current.kind === kind ? Object.assign({}, current, { status: "ready" }) : current; });
        }, function (error) {
          if (!mounted.current) return;
          setSelected(function (current) { return current && current.id === entry.id && current.kind === kind ? Object.assign({}, current, { status: "error", error: error.message }) : current; });
        });
      }

      let body;
      if (result.status === "loading") {
        body = h("p", { className: "tps-status", role: "status" }, "Finding suggestions…");
      } else if (result.status === "error") {
        body = h("p", { className: "tps-error", role: "alert" }, "Couldn't load suggestions: " + result.error);
      } else {
        body = h(React.Fragment, null,
          h(SuggestionList, {
            kind: "tag", title: "Tags", suggestions: details.tags, states, tuning,
            empty: "No tag suggestions. Nothing related is consistent enough.",
            onAdd: add, onDismiss: dismiss, onExclude: exclude,
          }),
          h(SuggestionList, {
            kind: "performer", title: "Performers", suggestions: details.performers, states, tuning,
            empty: details.performerEvidence
              ? "No performer suggestions. Nothing related is consistent enough."
              : "Add a performer, group or gallery to get performer suggestions.",
            onAdd: add, onDismiss: dismiss, onExclude: exclude,
          }),
          tuning ? h(TuningPanel, {
            noun: target.type, data, details, misses, selected, onPick: pick,
            saved: normalizeSettings(value.settings), effective, trial: !!trial, onApply: setTrial,
            thresholdsKey: loads.current,
          }) : null);
      }
      const summary = details
        ? "Based on " + details.relatedItems + " related " + (details.relatedItems === 1 ? "item" : "items") + (details.sampled ? " (sampled)" : "")
        : "";
      return h("div", { className: "tps-panel", "data-target": target.type + ":" + target.id, "data-status": result.status, "data-loads": loads.current, "data-trial": tuning && trial ? "true" : "false" },
        h("div", { className: "tps-toolbar" },
          props.heading ? h("h5", { className: "tps-title" }, "Suggestions") : null,
          h("span", { className: "tps-summary" }, summary),
          tuning && trial ? h("span", { className: "tps-verdict tps-trial-badge" }, "Trial thresholds") : null,
          h("button", {
            type: "button", className: "btn btn-secondary btn-sm tps-refresh",
            disabled: result.status === "loading",
            onClick: function () { setRun(function (count) { return count + 1; }); },
          }, "Recalculate")),
        body);
    }

    return { Suggestions, SuggestionRow, ExplanationCard };
  }

  function lastArgument(args) { return args[args.length - 1]; }

  function install(PluginApi) {
    if (!PluginApi || !PluginApi.patch || !PluginApi.patch.after || !PluginApi.React) return;
    const React = PluginApi.React, h = React.createElement;
    const Bootstrap = PluginApi.libraries && PluginApi.libraries.Bootstrap;
    const components = createComponents(PluginApi);

    if (Bootstrap && Bootstrap.Nav && Bootstrap.Tab) {
      PluginApi.patch.after("ScenePage.Tabs", function () {
        const args = Array.prototype.slice.call(arguments), props = args[0] || {}, result = lastArgument(args);
        if (!props.scene) return result;
        return h(React.Fragment, null, result,
          h(Bootstrap.Nav.Item, { key: ID }, h(Bootstrap.Nav.Link, { eventKey: PANEL_KEY }, "Suggestions")));
      });
      PluginApi.patch.after("ScenePage.TabContent", function () {
        const args = Array.prototype.slice.call(arguments), props = args[0] || {}, result = lastArgument(args);
        if (!props.scene) return result;
        // mountOnEnter: nothing is queried until the tab is first opened.
        return h(React.Fragment, null, result,
          h(Bootstrap.Tab.Pane, { key: ID, eventKey: PANEL_KEY, mountOnEnter: true },
            h(components.Suggestions, { key: String(props.scene.id), target: { type: "scene", id: String(props.scene.id) } })));
      });
    }
    PluginApi.patch.after("ImageDetailPanel", function () {
      const args = Array.prototype.slice.call(arguments), props = args[0] || {}, result = lastArgument(args);
      if (!props.image) return result;
      return h(React.Fragment, null, result,
        h("div", { className: "tps-image-section" },
          h(components.Suggestions, { key: String(props.image.id), heading: true, target: { type: "image", id: String(props.image.id) } })));
    });
  }

  return {
    ID, DEFAULTS, RANGES, SMOOTHING, SAMPLE_SIZE, WRITES, CONFIGURE, CONFIG_QUERY,
    parseExcludedTags, normalizeSettings,
    isId, isReadOnlyDocument, createReader, addToItem, excludeTag,
    loadItem, loadTotals, evidenceSources, loadSource, loadTagMeta, loadPerformerMeta, loadSettings,
    tally, smoothedConfidence, supportedIds, rankCandidates, ancestorsOf, scoreDetails, scoreSuggestions, computeSuggestions,
    VERDICTS, SEARCH_QUERIES, explainCandidate, nearMisses, searchCandidates, loadCandidateMeta, thresholdsFor,
    describeEvidence, createComponents, install,
  };
});
