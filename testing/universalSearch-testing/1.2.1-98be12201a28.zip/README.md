# Universal Search Plugin

Regular-expression search across a scene or image's **title**, **details**, and **file path**, in two places:

- **Stash's own search box** on scene and image lists gains a `.*` regex toggle. It is off by default, so the box keeps working exactly as before until you turn it on.
- **A Universal Search page** searches scenes and images together, with plain or regex searches and per-field options.

## Regex in the scene and image list search box

Every scene list (Scenes, and the Scenes tab of performers, studios, tags, and groups) and every image list has a `.*` button at the right of its search box.

- **Off (default):** nothing changes. The plugin passes Stash's own filter through untouched, so the box is Stash's normal search: words matched against title, details, path, and Stash's other search fields.
- **On:** the button is highlighted, the placeholder reads "Regex: title, details, or path…", and the box takes an [RE2 regular expression](https://github.com/google/re2/wiki/Syntax). A scene or image is listed when the pattern matches its title, details, or path. Everything else on the page — filters, sorting, paging, saved-filter buttons, selection, and Play Random — works as usual and is combined with the regex.

While regex is on and the search box has focus, a small **regex options** menu opens under it. It is not a dialog: you keep typing, and clicking anywhere else closes it.

| Option | Default | Effect |
|--------|---------|--------|
| **Match case** | off | Match upper and lower case exactly. RE2 flags such as `(?-i)` also work inside a pattern |
| **Whole word** | off | Wrap the pattern in word boundaries, so `sun` doesn't match "Sunset" |
| **Exclude matches** | off | List what does *not* match: no selected field matches the pattern. An empty title or details counts as not matching |
| **Highlight matches** | on | Highlight the text that matched in each card's title and details (and in the Path column of list view), so you can see at a glance why it was listed. Unavailable for exclude searches |
| **Search in** | Title, Details, Path | Limit the fields the pattern is tested against. At least one stays selected |
| **Recent** | — | The last 8 patterns, saved when you press Enter or leave the box. Click one to search it again; **Clear** forgets them |
| **Syntax help** | collapsed | Example patterns you can click to insert, RE2's main limits, and a link to the RE2 syntax reference |

Options that differ from the defaults are shown next to the toggle, so they are visible with the menu closed: `Aa` (match case), `\b` (whole word), `¬` (exclude), and the initials of the searched fields when not all three (for example `P` for path only). The placeholder also names the searched fields.

Highlights are painted with the browser's [CSS Custom Highlight API](https://developer.mozilla.org/en-US/docs/Web/API/CSS_Custom_Highlight_API) (Chrome and Edge 105+, Safari 17.2+, Firefox 140+), so Stash's cards are never modified; in older browsers the option is greyed out. Only visible text can be highlighted: scene cards don't show the file path (except as the title of an untitled scene), and long details are cut to three lines, so a match there filters the card in without a visible highlight. As on the Universal Search page, highlighting is a JavaScript translation of the RE2 pattern; the few RE2 features with no JavaScript equivalent still filter correctly but are not highlighted.

The regex mode, options, and recent patterns are remembered in this browser, separately for scene lists and image lists. Stash rewrites list URLs from its own filter, so the regex mode cannot be stored in the link: a copied link, a saved filter, or another browser opens the same text with the regex mode as that browser has it. An invalid pattern shows Stash's "Error loading items" message with the RE2 parse error (which includes the `(?i)` the plugin adds for case-insensitive matching).

Known limitation: when you open a scene from a regex result list, the scene page's play queue (next/previous scene) is rebuilt by Stash from the list's search text without the plugin, so it uses Stash's normal search of that text. Turn regex off, or use a filter, when you need the queue.

Set **Hide regex toggle in list search** to remove the toggle and keep list searches entirely Stash's own.

## Opening the search

- Click the magnifying glass in the top navigation bar. On phones it is in the menu (☰), next to Stash's settings and help buttons.
- Press `g f` on any page (configurable).
- Visit `/universal-search` directly. Search options are kept in the URL, so a search can be bookmarked, reloaded, or shared, and Back returns to it after you open a result.

## Searching

Results update as you type. Scenes and images are listed in separate sections, each with its total count. Each result shows its thumbnail, title (or filename when untitled), path, a details excerpt, and the fields that matched, with the matching text highlighted.

| Search | Matches |
|--------|---------|
| `beach 2019` | Every word appears somewhere: in the title, details, or path, in any order and in any combination of fields |
| `"golden hour"` | The quoted words appear together, in order, in one field. Spaces inside the quotes match any run of whitespace |
| `clip-2019.webm` | Plain text is literal: `.`, `(`, `*`, and other regex characters have no special meaning |

Plain searches ignore case. Use the controls under the search box to change how matching works:

- **Regex** treats the whole search as one [RE2 regular expression](https://github.com/google/re2/wiki/Syntax), the syntax Stash uses for its own "matches regex" filters. A scene or image matches when the pattern matches any selected field, for example `^Beach\s\d+`, `\d{4}-\d{2}-\d{2}`, `fireworks|receipt`, or `\.png$` with only Path selected. Invalid patterns show Stash's parse error instead of results.
- **Match case** makes plain and regex searches case-sensitive.
- **Search in** limits matching to any combination of Title, Details, and Path. At least one field stays selected.
- **All / Scenes / Images** filters the sections shown; the counts are still shown for both.
- **Sort** orders results by recently added (default), title, or path.

Each section loads a page of results at a time (24 by default). Use **Show more** to load the next page.

## Settings

All settings are optional. Configure them in Stash under **Settings → Plugins → Universal Search**.

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `openShortcut` | STRING | `g f` | [Mousetrap](https://craig.is/killing/mice) key combination that opens the search. Enter `none` to turn it off. Stash already uses `g u` for Studios |
| `hideNavbarButton` | BOOLEAN | off | Hide the navbar button; the shortcut and URL still work |
| `resultsPerPage` | NUMBER | `24` | Scenes or images loaded at a time per section, 1–100 |
| `hideListRegexToggle` | BOOLEAN | off | Don't add the `.*` regex toggle to scene and image list search boxes |

## How it works

The plugin is UI-only. For the list search box it patches `FilteredSceneList` and `FilteredImageList`: with regex on, it wraps the list's `filterHook` so the query Stash sends has an empty search term and the regex filter ANDed with the list's own criteria; with regex off, the hook is passed through unchanged. Stash's search box has no patch point, so the toggle is placed into it from the list's DOM. The page registers the `/universal-search` route, adds a button to `MainNavBar.UtilityItems`, and sends `findScenes` and `findImages` GraphQL queries with `title`, `details`, and `path` filter criteria using Stash's `MATCHES_REGEX` modifier. Plain searches are escaped and combined so that every word must match some field. Stash evaluates every pattern on the server, so the results are exactly what Stash's own regex filters would return. Highlighting is a best-effort JavaScript translation of the pattern; RE2 features with no JavaScript equivalent still filter correctly but are not highlighted.

Regex searches scan each selected field of every scene and image, so they can take a few seconds in large libraries.

## Testing

```text
npm run stash -- test --plugin universalSearch --suite unit
npm run stash -- test --plugin universalSearch --suite integration
npm run stash -- test --plugin universalSearch --suite ui
```

- **Unit** tests cover query building, highlighting, URL state, settings, list filter combination, the list patches (untouched when off, options only with regex on), the list options, flags, placeholder, recent patterns, and highlight offsets, and route and navbar registration.
- **Integration** scans generated videos and images into a managed Stash, then runs the plugin's own filters for plain, phrase, case, field, and regex searches, including NULL titles and details, paging, invalid patterns, and list regex searches with each menu option, combined with other list criteria.
- **UI** drives the page, and the Scenes and Images list search boxes (normal search, regex on and off, the regex options menu in the toolbar and the narrow filter sidebar: match case, whole word, exclude, highlight matches in titles and details, search in, recent patterns, and syntax help examples, invalid pattern, remembered mode), in Chromium at desktop (1440×900) and phone (390×844) sizes. It checks every state it visits for layout defects: horizontal scrolling, content escaping the page, overlapping rows or controls, clipped text, thumbnails that fail to load, and a navbar button that collides with its neighbors. It saves a screenshot of each state to `test-results/universalSearch/` for visual review, plus `failure.png` when a step fails.

The integration and UI tests need Docker and `ffmpeg`.
