(function (root) {
  "use strict";

  var PLUGIN_ID = "universalSearch-testing";
  // Not under /plugin: the server owns that prefix, so a reload or bookmark
  // of the page would bypass the web app.
  var ROUTE = "/universal-search";
  var INPUT_ID = "universal-search-input";
  var FIELDS = ["title", "details", "path"];
  var FIELD_LABELS = { title: "Title", details: "Details", path: "Path" };
  var TYPES = ["all", "scenes", "images"];
  var SORTS = {
    recent: { sort: "created_at", direction: "DESC", label: "Recently added" },
    title: { sort: "title", direction: "ASC", label: "Title" },
    path: { sort: "path", direction: "ASC", label: "Path" },
  };
  var DEFAULT_SORT = "recent";
  var DEFAULTS = { openShortcut: "g f", hideNavbarButton: false, resultsPerPage: 24, hideListRegexToggle: false };
  var MAX_PER_PAGE = 100;
  var SEARCH_DELAY_MS = 300;
  var SNIPPET_RADIUS = 90;

  var SCENES_QUERY = "query UniversalSearchScenes($filter: FindFilterType, $scene_filter: SceneFilterType){ findScenes(filter:$filter, scene_filter:$scene_filter){ count scenes{ id title details date files{ path duration } paths{ screenshot } } } }";
  var IMAGES_QUERY = "query UniversalSearchImages($filter: FindFilterType, $image_filter: ImageFilterType){ findImages(filter:$filter, image_filter:$image_filter){ count images{ id title details date visual_files{ ... on ImageFile{ path } ... on VideoFile{ path } } paths{ thumbnail } } } }";

  function hasOwn(obj, key) { return Object.prototype.hasOwnProperty.call(obj, key); }

  // ─── Query building ──────────────────────────────────────────────────
  // Stash evaluates MATCHES_REGEX criteria with Go's RE2 syntax.

  function escapeRegex(v) { return String(v).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&"); }

  // Whitespace-separated terms. Double quotes keep a phrase together; an
  // unclosed quote runs to the end of the query.
  function parseTerms(query) {
    var terms = [];
    var re = /"([^"]*)"?|(\S+)/g;
    var m;
    while ((m = re.exec(String(query || "")))) {
      var term = (m[1] !== undefined ? m[1] : m[2]).trim();
      if (term) terms.push(term);
    }
    return terms;
  }

  // Whitespace inside a phrase matches any run of whitespace.
  function termPattern(term) {
    return String(term).trim().split(/\s+/).map(escapeRegex).join("\\s+");
  }

  function normalizeFields(fields) {
    var list = Array.isArray(fields) ? fields : [];
    var picked = FIELDS.filter(function (f) { return list.indexOf(f) !== -1; });
    return picked.length ? picked : FIELDS.slice();
  }

  function criteria(fields, value, modifier) {
    var out = {};
    fields.forEach(function (f) { out[f] = { value: value, modifier: modifier }; });
    return out;
  }

  // A filter level ANDs its own criteria and then applies its one AND/OR/NOT
  // sub-filter, so { a, OR: { b, OR: c } } reads as a OR (b OR c).
  function orChain(filters) {
    return filters.reduceRight(function (rest, f) {
      return rest ? Object.assign({}, f, { OR: rest }) : f;
    }, null);
  }

  function anyField(fields, pattern) {
    return orChain(fields.map(function (f) { return criteria([f], pattern, "MATCHES_REGEX"); }));
  }

  /**
   * Build the scene/image filter for a search. Scenes and images share the
   * title, details, and path criteria, so one filter serves both.
   * wholeWord wraps each pattern in word boundaries. exclude (regex only)
   * matches scenes and images where no selected field matches the pattern.
   * @param {{query: string, regex?: boolean, caseSensitive?: boolean, fields?: string[],
   *   wholeWord?: boolean, exclude?: boolean}} options
   * @returns {Object|null} null when there is nothing to search for
   */
  function buildSearchFilter(options) {
    var query = String(options.query || "");
    if (!query.trim()) return null;
    var fields = normalizeFields(options.fields);
    var flags = options.caseSensitive ? "" : "(?i)";
    function word(p) { return options.wholeWord ? "\\b(?:" + p + ")\\b" : p; }
    if (options.regex) {
      var pattern = flags + word(query);
      // A missing (NULL) field never matches, so it counts as "doesn't match".
      return options.exclude ? criteria(fields, pattern, "NOT_MATCHES_REGEX") : anyField(fields, pattern);
    }

    var patterns = parseTerms(query).map(function (t) { return flags + word(termPattern(t)); });
    if (!patterns.length) return null;
    if (patterns.length === 1) return anyField(fields, patterns[0]);
    // Every term must appear in at least one field. A level cannot AND several
    // OR groups, so match: NOT (some term is missing from every field).
    return {
      NOT: orChain(patterns.map(function (p) { return criteria(fields, p, "NOT_MATCHES_REGEX"); })),
    };
  }

  function buildFindFilter(sortKey, page, perPage) {
    var s = SORTS[hasOwn(SORTS, sortKey) ? sortKey : DEFAULT_SORT];
    return { page: page, per_page: perPage, sort: s.sort, direction: s.direction };
  }

  // ─── Highlighting ────────────────────────────────────────────────────

  /**
   * A JavaScript approximation of the search, used only to highlight matches.
   * @returns {RegExp|null} global RegExp, or null when the RE2 pattern has no
   *   JavaScript equivalent
   */
  function buildHighlighter(options) {
    var query = String(options.query || "");
    if (!query.trim()) return null;
    var flags = "g" + (options.caseSensitive ? "" : "i");
    var source;
    if (options.regex) {
      source = query;
      var lead = /^\(\?([imsU]+)\)/.exec(source);
      if (lead) {
        source = source.slice(lead[0].length);
        "ims".split("").forEach(function (f) {
          if (lead[1].indexOf(f) !== -1 && flags.indexOf(f) === -1) flags += f;
        });
      }
      source = source.replace(/\(\?P</g, "(?<");
    } else {
      var terms = parseTerms(query);
      if (!terms.length) return null;
      source = terms.map(termPattern).join("|");
    }
    if (options.wholeWord) source = "\\b(?:" + source + ")\\b";
    try {
      return new RegExp(source, flags);
    } catch (_err) {
      return null;
    }
  }

  function matchesText(text, re) {
    if (!re || text == null || text === "") return false;
    re.lastIndex = 0;
    var ok = re.test(String(text));
    re.lastIndex = 0;
    return ok;
  }

  /** Split text into plain and matched segments. */
  function highlightSegments(text, re) {
    var value = text == null ? "" : String(text);
    if (!re || !value) return [{ text: value, hit: false }];
    var out = [];
    var last = 0;
    var m;
    re.lastIndex = 0;
    while ((m = re.exec(value))) {
      if (!m[0].length) {
        re.lastIndex++;
        continue;
      }
      if (m.index > last) out.push({ text: value.slice(last, m.index), hit: false });
      out.push({ text: m[0], hit: true });
      last = m.index + m[0].length;
    }
    re.lastIndex = 0;
    if (last < value.length || !out.length) out.push({ text: value.slice(last), hit: false });
    return out;
  }

  /** [start, end) offsets of each non-empty match in text. */
  function matchRanges(text, re) {
    var offsets = [];
    var at = 0;
    highlightSegments(text, re).forEach(function (seg) {
      if (seg.hit) offsets.push([at, at + seg.text.length]);
      at += seg.text.length;
    });
    return offsets;
  }

  /** A window of long text around its first match, with ellipses. */
  function snippet(text, re, radius) {
    var value = String(text || "").replace(/\s+/g, " ").trim();
    var size = radius * 2;
    if (value.length <= size) return value;
    var start = 0;
    if (re) {
      re.lastIndex = 0;
      var m = re.exec(value);
      re.lastIndex = 0;
      if (m) start = Math.max(0, m.index - radius);
    }
    var end = Math.min(value.length, start + size);
    start = Math.max(0, end - size);
    return (start > 0 ? "…" : "") + value.slice(start, end) + (end < value.length ? "…" : "");
  }

  // ─── Page state and settings ─────────────────────────────────────────

  function readSearchState(search) {
    var p = new URLSearchParams(search || "");
    var fields = p.get("fields");
    var type = p.get("type");
    var sort = p.get("sort");
    return {
      query: p.get("q") || "",
      regex: p.get("regex") === "1",
      caseSensitive: p.get("case") === "1",
      fields: normalizeFields(fields ? fields.split(",") : FIELDS),
      type: TYPES.indexOf(type) !== -1 ? type : "all",
      sort: sort && hasOwn(SORTS, sort) ? sort : DEFAULT_SORT,
    };
  }

  /** Query string for a page state; defaults are left out. */
  function writeSearchState(state) {
    var p = new URLSearchParams();
    if (state.query) p.set("q", state.query);
    if (state.regex) p.set("regex", "1");
    if (state.caseSensitive) p.set("case", "1");
    var fields = normalizeFields(state.fields);
    if (fields.length !== FIELDS.length) p.set("fields", fields.join(","));
    if (state.type && state.type !== "all") p.set("type", state.type);
    if (state.sort && state.sort !== DEFAULT_SORT) p.set("sort", state.sort);
    var s = p.toString();
    return s ? "?" + s : "";
  }

  function normalizeSettings(raw) {
    var s = raw || {};
    var shortcut = typeof s.openShortcut === "string"
      ? s.openShortcut.trim().replace(/\s*\+\s*/g, "+").replace(/\s+/g, " ").toLowerCase()
      : "";
    if (!shortcut) shortcut = DEFAULTS.openShortcut;
    if (/^(none|off)$/.test(shortcut)) shortcut = "";
    var perPage = Math.floor(Number(s.resultsPerPage));
    perPage = isFinite(perPage) && perPage >= 1 ? Math.min(perPage, MAX_PER_PAGE) : DEFAULTS.resultsPerPage;
    return {
      openShortcut: shortcut,
      hideNavbarButton: s.hideNavbarButton === true,
      resultsPerPage: perPage,
      hideListRegexToggle: s.hideListRegexToggle === true,
    };
  }

  function describeError(err) {
    var msg = String((err && err.message) || err || "Search failed");
    var m = /error parsing regexp: (.*)$/.exec(msg);
    if (m) return "Invalid regular expression: " + m[1].replace("`(?i)", "`");
    return msg;
  }

  // ─── Scene and image lists ───────────────────────────────────────────

  var FILTER_OPS = ["AND", "OR", "NOT"];

  /**
   * Combine two scene/image filters with AND. Stash's list UI builds flat
   * criteria, so the extra filter becomes the base's AND sub-filter.
   * @returns {Object|null} null when both filters already use OR or NOT
   */
  function andFilters(base, extra) {
    base = base || {};
    if (!extra) return base;
    var ops = FILTER_OPS.filter(function (k) { return base[k]; });
    if (!ops.length) return Object.assign({}, base, { AND: extra });
    if (ops.length === 1 && ops[0] === "AND") {
      var nested = andFilters(base.AND, extra);
      return nested && Object.assign({}, base, { AND: nested });
    }
    if (!FILTER_OPS.some(function (k) { return extra[k]; })) return Object.assign({}, extra, { AND: base });
    return null;
  }

  var MAX_RECENT = 8;

  /** The list regex options, with defaults for anything missing or invalid. */
  function normalizeListOptions(v) {
    v = v && typeof v === "object" ? v : {};
    return {
      caseSensitive: v.caseSensitive === true,
      wholeWord: v.wholeWord === true,
      exclude: v.exclude === true,
      highlight: v.highlight !== false,
      fields: normalizeFields(v.fields),
    };
  }

  /** Recent patterns, newest first, without duplicates. */
  function addRecent(list, pattern, max) {
    var p = String(pattern || "").trim();
    var prev = Array.isArray(list) ? list.filter(function (x) { return typeof x === "string" && x && x !== p; }) : [];
    return (p ? [p].concat(prev) : prev).slice(0, max || MAX_RECENT);
  }

  /** Short markers for the options that differ from the defaults. */
  function listFlags(options) {
    var o = normalizeListOptions(options);
    var flags = [];
    if (o.caseSensitive) flags.push({ text: "Aa", title: "Match case" });
    if (o.wholeWord) flags.push({ text: "\\b", title: "Whole word" });
    if (o.exclude) flags.push({ text: "¬", title: "Exclude matches" });
    if (o.fields.length < FIELDS.length) {
      flags.push({
        text: o.fields.map(function (f) { return FIELD_LABELS[f].charAt(0); }).join(""),
        title: "Only " + o.fields.map(function (f) { return FIELD_LABELS[f].toLowerCase(); }).join(" and "),
      });
    }
    return flags;
  }

  /** The search box placeholder for a list in regex mode. */
  function listPlaceholder(options) {
    var o = normalizeListOptions(options);
    var names = o.fields.map(function (f) { return FIELD_LABELS[f].toLowerCase(); });
    var where = names.length > 1 ? names.slice(0, -1).join(", ") + (names.length > 2 ? "," : "") + " or " + names[names.length - 1] : names[0];
    return (o.exclude ? "Regex, excluding matches: " : "Regex: ") + where + "…";
  }

  /**
   * Turn a list filter model's search term into a regex search of title,
   * details, and path. Stash's own search term is cleared so it does not
   * also apply; every other criterion is kept and ANDed with the regex.
   * @param {Object} filter Stash ListFilterModel
   * @param {Object} [options] list regex options (see normalizeListOptions)
   * @returns {Object} a new model, or the given one when there is nothing to change
   */
  function applyListRegex(filter, options) {
    var term = filter && filter.searchTerm;
    var extra = buildSearchFilter(Object.assign(normalizeListOptions(options), { query: term || "", regex: true }));
    if (!extra) return filter;
    var out = typeof filter.clone === "function" ? filter.clone() : Object.assign({}, filter);
    var makeFilter = out.makeFilter;
    var criteria = makeFilter.call(out);
    var combined = andFilters(criteria, extra);
    if (!combined) return filter;
    out.searchTerm = "";
    out.makeFilter = function () { return andFilters(makeFilter.call(this), extra) || makeFilter.call(this); };
    return out;
  }

  // ─── Result shaping ──────────────────────────────────────────────────

  function basename(path) {
    var s = String(path || "");
    var i = Math.max(s.lastIndexOf("/"), s.lastIndexOf("\\"));
    return i === -1 ? s : s.slice(i + 1);
  }

  function pad2(n) { return (n < 10 ? "0" : "") + n; }

  function formatDuration(seconds) {
    var total = Math.round(Number(seconds));
    if (!(total > 0)) return "";
    var hours = Math.floor(total / 3600);
    var minutes = Math.floor((total % 3600) / 60);
    var secs = total % 60;
    return hours ? hours + ":" + pad2(minutes) + ":" + pad2(secs) : minutes + ":" + pad2(secs);
  }

  function toResult(kind, item) {
    var scene = kind === "scenes";
    var files = (scene ? item.files : item.visual_files) || [];
    return {
      kind: kind,
      id: String(item.id),
      title: item.title || "",
      details: item.details || "",
      date: item.date || "",
      paths: files.map(function (f) { return f && f.path; }).filter(Boolean),
      duration: scene && files[0] ? formatDuration(files[0].duration) : "",
      thumbnail: item.paths ? (scene ? item.paths.screenshot : item.paths.thumbnail) : "",
      href: (scene ? "/scenes/" : "/images/") + item.id,
    };
  }

  /** The fields of a result that the highlighter matches, in field order. */
  function matchedFields(result, re, fields) {
    if (!re) return [];
    return normalizeFields(fields).filter(function (f) {
      if (f === "path") return result.paths.some(function (p) { return matchesText(p, re); });
      return matchesText(result[f], re);
    });
  }

  var core = {
    PLUGIN_ID: PLUGIN_ID,
    ROUTE: ROUTE,
    FIELDS: FIELDS,
    SORTS: SORTS,
    DEFAULTS: DEFAULTS,
    SCENES_QUERY: SCENES_QUERY,
    IMAGES_QUERY: IMAGES_QUERY,
    escapeRegex: escapeRegex,
    parseTerms: parseTerms,
    termPattern: termPattern,
    normalizeFields: normalizeFields,
    buildSearchFilter: buildSearchFilter,
    buildFindFilter: buildFindFilter,
    buildHighlighter: buildHighlighter,
    matchesText: matchesText,
    highlightSegments: highlightSegments,
    matchRanges: matchRanges,
    snippet: snippet,
    readSearchState: readSearchState,
    writeSearchState: writeSearchState,
    normalizeSettings: normalizeSettings,
    describeError: describeError,
    basename: basename,
    formatDuration: formatDuration,
    toResult: toResult,
    matchedFields: matchedFields,
    andFilters: andFilters,
    applyListRegex: applyListRegex,
    normalizeListOptions: normalizeListOptions,
    addRecent: addRecent,
    listFlags: listFlags,
    listPlaceholder: listPlaceholder,
  };

  if (typeof module === "object" && module.exports) module.exports = core;

  // ─── Stash UI ────────────────────────────────────────────────────────

  var api = root && root.PluginApi;
  if (!api) return;

  var React = api.React;
  var ReactDOM = api.ReactDOM;
  var h = React.createElement;
  var useCallback = React.useCallback;
  var useEffect = React.useEffect;
  var useMemo = React.useMemo;
  var useRef = React.useRef;
  var useState = React.useState;
  var libs = api.libraries || {};
  var Router = libs.ReactRouterDOM;
  var Mousetrap = libs.Mousetrap;
  var FontAwesomeIcon = libs.ReactFontAwesome && libs.ReactFontAwesome.FontAwesomeIcon;
  var solidIcons = libs.FontAwesomeSolid || {};
  var SEARCH_ICON = solidIcons.faMagnifyingGlass || solidIcons.faSearch;

  function gql(query, variables, signal) {
    return fetch("/graphql", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: query, variables: variables || {} }),
      signal: signal,
    })
      .then(function (r) { return r.json(); })
      .then(function (json) {
        if (json.errors && json.errors.length) throw new Error(json.errors[0].message || "GraphQL error");
        return json.data;
      });
  }

  function searchIcon(className) {
    if (!FontAwesomeIcon || !SEARCH_ICON) return null;
    return h(FontAwesomeIcon, { icon: SEARCH_ICON, className: "fa-icon " + (className || "") });
  }

  function usePluginSettings() {
    var result = api.utils.StashService.useConfiguration();
    var plugins = result && result.data && result.data.configuration ? result.data.configuration.plugins : null;
    var raw = plugins ? plugins[PLUGIN_ID] : null;
    return useMemo(function () { return normalizeSettings(raw); }, [raw]);
  }

  // The navbar renders its utility items twice (collapsed menu and bar), so
  // the open shortcut is bound once per combination and shared.
  var shortcutUsers = {};
  var shortcutHistory = { current: null };

  function focusSearchInput() {
    var input = document.getElementById(INPUT_ID);
    if (input) {
      input.focus();
      input.select();
    }
  }

  function openSearch() {
    var history = shortcutHistory.current;
    if (!history) return true;
    if (history.location && history.location.pathname === ROUTE) focusSearchInput();
    else history.push(ROUTE);
    return false;
  }

  function useOpenShortcut(combo, history) {
    useEffect(function () { shortcutHistory.current = history; }, [history]);
    useEffect(function () {
      if (!combo || !Mousetrap) return undefined;
      shortcutUsers[combo] = (shortcutUsers[combo] || 0) + 1;
      if (shortcutUsers[combo] === 1) Mousetrap.bind(combo, openSearch);
      return function () {
        shortcutUsers[combo] -= 1;
        if (!shortcutUsers[combo]) {
          delete shortcutUsers[combo];
          Mousetrap.unbind(combo);
        }
      };
    }, [combo]);
  }

  // Stash's own navbar buttons close the collapsed (phone) menu; do the same.
  function closeNavMenu() {
    var toggle = document.querySelector(".top-nav .nav-menu-toggle");
    if (toggle && document.querySelector(".top-nav .navbar-collapse.show")) toggle.click();
  }

  function NavSearchButton() {
    var settings = usePluginSettings();
    var history = Router.useHistory();
    useOpenShortcut(settings.openShortcut, history);
    if (settings.hideNavbarButton) return null;
    var title = "Universal Search" + (settings.openShortcut ? " (" + settings.openShortcut + ")" : "");
    return h(Router.NavLink, { className: "nav-utility universal-search-nav", exact: true, to: ROUTE, onClick: closeNavMenu },
      h("button", { type: "button", className: "btn minimal d-flex align-items-center h-100", title: title, "aria-label": "Universal Search" },
        searchIcon() || "Search"));
  }

  var EMPTY_RESULTS = { items: [], count: 0, page: 0, loading: false, error: null };

  function useResults(kind, filter, sort, perPage) {
    var resultsState = useState(EMPTY_RESULTS);
    var results = resultsState[0];
    var setResults = resultsState[1];
    var request = useRef({ id: 0, controller: null });
    var key = JSON.stringify([filter, sort, perPage]);

    function cancel() {
      request.current.id++;
      if (request.current.controller) request.current.controller.abort();
      request.current.controller = null;
    }

    var load = useCallback(function (page) {
      cancel();
      var id = request.current.id;
      var controller = typeof AbortController === "function" ? new AbortController() : null;
      request.current.controller = controller;
      setResults(function (prev) { return Object.assign({}, prev, { loading: true, error: null }); });

      var variables = { filter: buildFindFilter(sort, page, perPage) };
      variables[kind === "scenes" ? "scene_filter" : "image_filter"] = filter;
      gql(kind === "scenes" ? SCENES_QUERY : IMAGES_QUERY, variables, controller ? controller.signal : undefined)
        .then(function (data) {
          if (id !== request.current.id) return;
          var found = kind === "scenes" ? data.findScenes : data.findImages;
          var items = (kind === "scenes" ? found.scenes : found.images).map(function (item) { return toResult(kind, item); });
          setResults(function (prev) {
            return { items: page === 1 ? items : prev.items.concat(items), count: found.count, page: page, loading: false, error: null };
          });
        })
        .catch(function (err) {
          if (id !== request.current.id) return;
          setResults(function (prev) { return Object.assign({}, prev, { loading: false, error: describeError(err) }); });
        });
    }, [key]);

    useEffect(function () {
      if (!filter) {
        cancel();
        setResults(EMPTY_RESULTS);
        return undefined;
      }
      load(1);
      return cancel;
    }, [load]);

    return {
      items: results.items,
      count: results.count,
      loading: results.loading,
      error: results.error,
      hasMore: results.items.length < results.count,
      loadMore: function () { load(results.page + 1); },
    };
  }

  function Highlighted(props) {
    return h(React.Fragment, null, highlightSegments(props.text, props.re).map(function (seg, i) {
      return seg.hit ? h("mark", { key: i, className: "us-hit" }, seg.text) : seg.text;
    }));
  }

  function ResultRow(props) {
    var item = props.item;
    var fields = props.fields;
    var re = props.highlighter;
    function reFor(field) { return fields.indexOf(field) !== -1 ? re : null; }
    var path = item.paths.filter(function (p) { return matchesText(p, reFor("path")); })[0] || item.paths[0] || "";
    var matched = matchedFields(item, re, fields);
    var typeLabel = item.kind === "scenes" ? "Scene" : "Image";

    return h("li", { className: "us-result" },
      h(Router.Link, { to: item.href, className: "us-result-link" },
        h("div", { className: "us-thumb us-thumb-" + item.kind },
          item.thumbnail ? h("img", { src: item.thumbnail, alt: "", loading: "lazy" }) : null,
          item.duration ? h("span", { className: "us-duration" }, item.duration) : null),
        h("div", { className: "us-body" },
          item.title
            ? h("div", { className: "us-title" }, h(Highlighted, { text: item.title, re: reFor("title") }))
            : h("div", { className: "us-title us-untitled" }, basename(path) || "Untitled " + typeLabel.toLowerCase()),
          path ? h("div", { className: "us-path", title: path }, h(Highlighted, { text: path, re: reFor("path") })) : null,
          item.details
            ? h("p", { className: "us-details" }, h(Highlighted, { text: snippet(item.details, reFor("details"), SNIPPET_RADIUS), re: reFor("details") }))
            : null,
          h("div", { className: "us-meta" },
            h("span", { className: "us-kind" }, typeLabel),
            item.date ? h("span", null, item.date) : null,
            matched.length
              ? h("span", { className: "us-matched" }, "Matched in ", matched.map(function (f) {
                return h("span", { key: f, className: "us-chip" }, FIELD_LABELS[f]);
              }))
              : null))));
  }

  function ResultSection(props) {
    var results = props.results;
    var label = props.kind === "scenes" ? "Scenes" : "Images";
    var headingId = "us-heading-" + props.kind;
    var body;
    if (!results.items.length) {
      body = h("p", { className: "us-empty" }, results.loading ? "Searching…" : "No " + label.toLowerCase() + " match.");
    } else {
      body = h("ul", { className: "us-results" + (results.loading ? " us-stale" : "") }, results.items.map(function (item) {
        return h(ResultRow, { key: item.id, item: item, fields: props.fields, highlighter: props.highlighter });
      }));
    }
    return h("section", { className: "us-section us-section-" + props.kind, "aria-labelledby": headingId, "aria-busy": results.loading ? "true" : "false" },
      h("h3", { id: headingId, className: "us-section-title" }, label, " ", h("span", { className: "us-count" }, results.count)),
      body,
      results.hasMore
        ? h("button", { type: "button", className: "btn btn-secondary us-more", disabled: results.loading, onClick: results.loadMore },
          results.loading ? "Loading…" : "Show more " + label.toLowerCase() + " (" + (results.count - results.items.length) + " more)")
        : null);
  }

  function Intro(props) {
    return h("div", { className: "us-intro" },
      h("p", null, "Search scene and image titles, details, and file paths in one place."),
      h("ul", null,
        h("li", null, "Words can appear in any order and in different fields: ", h("code", null, "beach 2019")),
        h("li", null, "Quote a phrase to keep its words together: ", h("code", null, "\"golden hour\"")),
        h("li", null, "Turn on Regex for RE2 patterns: ", h("code", null, "\\d{4}-\\d{2}-\\d{2}")),
        props.shortcut ? h("li", null, "Press ", h("kbd", null, props.shortcut), " on any page to open this search.") : null));
  }

  function ToggleSwitch(props) {
    var id = "us-option-" + props.name;
    return h("div", { className: "custom-control custom-switch us-switch" },
      h("input", { type: "checkbox", className: "custom-control-input", id: id, checked: props.checked, onChange: function (e) { props.onChange(e.target.checked); } }),
      h("label", { className: "custom-control-label", htmlFor: id, title: props.title }, props.label));
  }

  function SearchPage() {
    var settings = usePluginSettings();
    var location = Router.useLocation();
    var history = Router.useHistory();
    var state = useMemo(function () { return readSearchState(location.search); }, [location.search]);
    var stateRef = useRef(state);
    stateRef.current = state;

    var draftState = useState(state.query);
    var draft = draftState[0];
    var setDraft = draftState[1];
    var draftRef = useRef(draft);
    draftRef.current = draft;
    var written = useRef(state.query);
    var timer = useRef(null);

    // Follow the URL when it changes from outside the input (back/forward).
    useEffect(function () {
      if (state.query !== written.current) {
        written.current = state.query;
        setDraft(state.query);
      }
    }, [state.query]);

    useEffect(function () { return function () { clearTimeout(timer.current); }; }, []);

    function update(patch) {
      clearTimeout(timer.current);
      var next = Object.assign({}, stateRef.current, { query: draftRef.current }, patch);
      written.current = next.query;
      history.replace({ pathname: ROUTE, search: writeSearchState(next) });
    }

    function onQueryChange(e) {
      var value = e.target.value;
      setDraft(value);
      draftRef.current = value;
      clearTimeout(timer.current);
      timer.current = setTimeout(function () { update({ query: value }); }, SEARCH_DELAY_MS);
    }

    function toggleField(field, on) {
      var fields = state.fields.filter(function (f) { return f !== field; });
      if (on) fields.push(field);
      if (fields.length) update({ fields: normalizeFields(fields) });
    }

    var options = { query: state.query, regex: state.regex, caseSensitive: state.caseSensitive, fields: state.fields };
    var filter = useMemo(function () { return buildSearchFilter(options); }, [location.search]);
    var highlighter = useMemo(function () { return buildHighlighter(options); }, [location.search]);

    var scenes = useResults("scenes", filter, state.sort, settings.resultsPerPage);
    var images = useResults("images", filter, state.sort, settings.resultsPerPage);
    var error = scenes.error || images.error;
    var counted = !scenes.loading && !images.loading;

    function tab(type, label, count) {
      var active = state.type === type;
      return h("button", {
        type: "button",
        className: "btn btn-secondary" + (active ? " active" : ""),
        "aria-pressed": active ? "true" : "false",
        onClick: function () { update({ type: type }); },
      }, label, count != null ? h("span", { className: "us-tab-count" }, count) : null);
    }

    var content;
    if (!filter) {
      content = h(Intro, { shortcut: settings.openShortcut });
    } else if (error) {
      content = h("div", { className: "alert alert-danger us-error", role: "alert" }, error);
    } else {
      content = h(React.Fragment, null,
        h("div", { className: "btn-group us-tabs", role: "group", "aria-label": "Result type" },
          tab("all", "All", counted ? scenes.count + images.count : null),
          tab("scenes", "Scenes", scenes.loading ? null : scenes.count),
          tab("images", "Images", images.loading ? null : images.count)),
        state.type !== "images" ? h(ResultSection, { kind: "scenes", results: scenes, fields: state.fields, highlighter: highlighter }) : null,
        state.type !== "scenes" ? h(ResultSection, { kind: "images", results: images, fields: state.fields, highlighter: highlighter }) : null);
    }

    return h("div", { className: "universal-search" },
      h("h2", { className: "us-heading" }, "Universal Search"),
      h("form", { className: "us-form", role: "search", onSubmit: function (e) { e.preventDefault(); update({}); } },
        h("div", { className: "us-query" },
          searchIcon("us-query-icon"),
          h("input", {
            id: INPUT_ID,
            className: "form-control text-input us-input" + (state.regex ? " us-input-regex" : ""),
            type: "search",
            value: draft,
            onChange: onQueryChange,
            onKeyDown: function (e) { if (e.key === "Escape") e.currentTarget.blur(); },
            placeholder: state.regex ? "Regular expression, e.g. ^Beach.*20(19|20)" : "Search titles, details, and paths",
            "aria-label": "Search scenes and images",
            autoFocus: true,
            autoComplete: "off",
            spellCheck: false,
          })),
        h("div", { className: "us-options" },
          h(ToggleSwitch, { name: "regex", label: "Regex", title: "Treat the search as an RE2 regular expression", checked: state.regex, onChange: function (on) { update({ regex: on }); } }),
          h(ToggleSwitch, { name: "case", label: "Match case", checked: state.caseSensitive, onChange: function (on) { update({ caseSensitive: on }); } }),
          h("div", { className: "us-fields", role: "group", "aria-label": "Search in" },
            h("span", { className: "us-fields-label" }, "Search in"),
            FIELDS.map(function (f) {
              var checked = state.fields.indexOf(f) !== -1;
              var id = "us-field-" + f;
              return h("div", { key: f, className: "custom-control custom-checkbox custom-control-inline" },
                h("input", {
                  type: "checkbox",
                  className: "custom-control-input",
                  id: id,
                  checked: checked,
                  disabled: checked && state.fields.length === 1,
                  onChange: function (e) { toggleField(f, e.target.checked); },
                }),
                h("label", { className: "custom-control-label", htmlFor: id }, FIELD_LABELS[f]));
            })),
          h("select", {
            className: "form-control form-control-sm btn-secondary us-sort",
            "aria-label": "Sort by",
            value: state.sort,
            onChange: function (e) { update({ sort: e.target.value }); },
          }, Object.keys(SORTS).map(function (key) { return h("option", { key: key, value: key }, SORTS[key].label); })))),
      content);
  }

  // ─── Regex mode for Stash's scene and image list search ──────────────
  // Off by default, so the list search stays Stash's own. Stash rebuilds the
  // list URL from its filter model, so the mode is remembered per list type
  // in this browser instead.

  var LISTS = { scenes: "FilteredSceneList", images: "FilteredImageList" };

  // A per-list-type value remembered in this browser.
  function kindStore(key, normalize) {
    var values = { scenes: normalize(undefined), images: normalize(undefined) };
    var listeners = [];
    try {
      var saved = JSON.parse(root.localStorage.getItem(key) || "{}");
      Object.keys(values).forEach(function (kind) { values[kind] = normalize(saved && saved[kind]); });
    } catch (_err) {
      // Storage is unavailable or holds something else; start from the defaults.
    }
    return {
      get: function (kind) { return values[kind]; },
      set: function (kind, value) {
        values = Object.assign({}, values);
        values[kind] = normalize(value);
        try { root.localStorage.setItem(key, JSON.stringify(values)); } catch (_err) { /* not remembered */ }
        listeners.slice().forEach(function (fn) { fn(values); });
      },
      use: function (kind) {
        var state = useState(values[kind]);
        var setValue = state[1];
        useEffect(function () {
          function onChange(all) { setValue(all[kind]); }
          listeners.push(onChange);
          onChange(values);
          return function () { listeners.splice(listeners.indexOf(onChange), 1); };
        }, [kind]);
        return state[0];
      },
    };
  }

  var listRegex = kindStore("universalSearch.listRegex", function (v) { return v === true; });
  var listOptions = kindStore("universalSearch.listRegexOptions", normalizeListOptions);
  var listRecent = kindStore("universalSearch.listRegexRecent", function (v) { return addRecent(v, ""); });

  function patchListOptions(kind, change) {
    listOptions.set(kind, Object.assign({}, listOptions.get(kind), change));
  }

  // Runs inside the list component's render (patch.before), so its hooks
  // belong to that component and run on every render.
  function withListRegex(kind) {
    return function (props) {
      var settings = usePluginSettings();
      var on = listRegex.use(kind) && !settings.hideListRegexToggle;
      var options = listOptions.use(kind);
      var original = props && props.filterHook;
      var filterHook = useMemo(function () {
        if (!on) return original;
        return function (filter) { return applyListRegex(original ? original(filter) : filter, options); };
      }, [on, options, original]);
      return [Object.assign({}, props, { filterHook: filterHook })];
    };
  }

  function searchInput(el) {
    var group = el && el.closest(".search-term-input");
    return group && group.querySelector("input:not(.us-regex-check)");
  }

  // Set the text of Stash's search box the way typing would, so Stash's own
  // change handler runs.
  function typeInto(input, value) {
    var setter = Object.getOwnPropertyDescriptor(root.HTMLInputElement.prototype, "value").set;
    setter.call(input, value);
    input.dispatchEvent(new root.Event("input", { bubbles: true }));
    input.focus();
  }

  function RegexToggle(props) {
    var flags = props.on ? listFlags(props.options) : [];
    return h("button", {
      type: "button",
      className: "us-regex-toggle" + (props.on ? " active" : ""),
      "aria-pressed": props.on ? "true" : "false",
      "aria-label": "Regex search",
      title: props.on
        ? "Regex search is on: " + listPlaceholder(props.options).replace(/…$/, "")
          + (flags.length ? " (" + flags.map(function (f) { return f.title.toLowerCase(); }).join(", ") + ")" : "")
          + ". Click for Stash's normal search."
        : "Search with a regular expression across title, details, and path",
      onClick: function (e) {
        props.onToggle(!props.on);
        // Move to the search text so the pattern can be typed and the options show.
        var input = !props.on && searchInput(e.currentTarget);
        if (input) input.focus();
      },
    }, ".*", flags.map(function (f) {
      return h("span", { key: f.title, className: "us-regex-flag", "aria-hidden": "true" }, f.text);
    }));
  }

  var REGEX_EXAMPLES = [
    { pattern: "^Beach", label: "starts with Beach" },
    { pattern: "\\.mp4$", label: "ends with .mp4" },
    { pattern: "\\d{4}-\\d{2}-\\d{2}", label: "a date like 2019-07-04" },
    { pattern: "sunset|sunrise", label: "either word" },
    { pattern: "beach.*dog", label: "beach, later dog" },
  ];
  var RE2_SYNTAX_URL = "https://github.com/google/re2/wiki/Syntax";

  function Check(props) {
    return h("label", { className: "us-regex-option", title: props.title || undefined },
      h("input", {
        type: "checkbox",
        className: "us-regex-check us-regex-" + props.name,
        checked: !!props.checked,
        disabled: !!props.disabled,
        onChange: function (e) { props.onChange(e.target.checked); },
      }),
      h("span", null, props.label));
  }

  // Shown under the search box while regex is on and the box has focus. It is
  // not a modal: typing continues and nothing behind it is blocked.
  function RegexOptions(props) {
    var o = props.options;
    var helpState = useState(false);
    var help = helpState[0];
    function set(change) { props.onChange(change); }
    function insert(e, pattern) { var input = searchInput(e.currentTarget); if (input) typeInto(input, pattern); }
    return h("div", {
      className: "us-regex-menu",
      role: "group",
      "aria-label": "Regex options",
      // Keep focus in the search box so clicking an option doesn't close the menu.
      onMouseDown: function (e) { if (e.target.tagName !== "INPUT" && !e.target.closest("a")) e.preventDefault(); },
    },
      h("div", { className: "us-regex-row" },
        h(Check, { name: "case", label: "Match case", checked: o.caseSensitive, onChange: function (v) { set({ caseSensitive: v }); } }),
        h(Check, { name: "word", label: "Whole word", checked: o.wholeWord, onChange: function (v) { set({ wholeWord: v }); } }),
        h(Check, { name: "exclude", label: "Exclude matches", checked: o.exclude, onChange: function (v) { set({ exclude: v }); } }),
        h(Check, {
          name: "highlight",
          label: "Highlight matches",
          checked: o.highlight && !o.exclude && canHighlight,
          // Nothing matches in an exclude search, and old browsers can't paint highlights.
          disabled: o.exclude || !canHighlight,
          title: !canHighlight ? "This browser can't highlight text (needs the CSS Custom Highlight API)" : o.exclude ? "Nothing matches in an exclude search" : "",
          onChange: function (v) { set({ highlight: v }); },
        })),
      h("div", { className: "us-regex-row us-regex-fields" },
        h("span", { className: "us-regex-label" }, "Search in"),
        FIELDS.map(function (f) {
          var checked = o.fields.indexOf(f) !== -1;
          return h(Check, {
            key: f, name: "field-" + f, label: FIELD_LABELS[f], checked: checked,
            // At least one field stays selected.
            disabled: checked && o.fields.length === 1,
            onChange: function (v) {
              set({ fields: FIELDS.filter(function (x) { return x === f ? v : o.fields.indexOf(x) !== -1; }) });
            },
          });
        })),
      props.recent.length ? h("div", { className: "us-regex-recent" },
        h("div", { className: "us-regex-label" }, "Recent",
          h("button", { type: "button", className: "us-regex-link us-regex-clear-recent", onClick: props.onClearRecent }, "Clear")),
        props.recent.map(function (p) {
          return h("button", { key: p, type: "button", className: "us-regex-pattern", title: p, onClick: function (e) { insert(e, p); } }, p);
        })) : null,
      h("div", { className: "us-regex-help-row" },
        h("button", {
          type: "button",
          className: "us-regex-link us-regex-help-toggle",
          "aria-expanded": help ? "true" : "false",
          onClick: function () { helpState[1](!help); },
        }, (help ? "▾ " : "▸ ") + "Syntax help"),
        h("a", { className: "us-regex-link", href: RE2_SYNTAX_URL, target: "_blank", rel: "noopener noreferrer" }, "RE2 reference ↗")),
      help ? h("div", { className: "us-regex-help" },
        REGEX_EXAMPLES.map(function (ex) {
          return h("div", { key: ex.pattern, className: "us-regex-example" },
            h("button", { type: "button", className: "us-regex-pattern", onClick: function (e) { insert(e, ex.pattern); } }, ex.pattern),
            h("span", null, ex.label));
        }),
        h("div", { className: "us-regex-note" }, "No lookahead, lookbehind, or backreferences; (?i) and (?-i) switch case.")) : null);
  }

  // ─── Highlighting matches in the list ────────────────────────────────
  // Drawn with the CSS Custom Highlight API, which paints ranges of existing
  // text without changing the DOM that React owns.

  var HIGHLIGHT_NAME = "universal-search-match";
  var HIGHLIGHT_SELECTORS = {
    title: ".card-section-title, td.title-data, .wall-item-text > div:first-child",
    details: ".scene-card__description, .image-card__description, td.details-data",
    path: ".file-path, td.path-data",
  };
  var canHighlight = !!(root.CSS && root.CSS.highlights && typeof root.Highlight === "function");
  var highlightOwners = new Map();

  function publishHighlights() {
    if (!canHighlight) return;
    var hl = new root.Highlight();
    highlightOwners.forEach(function (ranges) { ranges.forEach(function (r) { hl.add(r); }); });
    if (hl.size) root.CSS.highlights.set(HIGHLIGHT_NAME, hl);
    else root.CSS.highlights.delete(HIGHLIGHT_NAME);
  }

  // DOM ranges for the matches in an element's text, which may span nodes.
  function rangesIn(el, re) {
    var walker = document.createTreeWalker(el, root.NodeFilter.SHOW_TEXT);
    var nodes = [];
    var text = "";
    var node;
    while ((node = walker.nextNode())) {
      nodes.push({ node: node, start: text.length });
      text += node.nodeValue;
    }
    function at(offset, end) {
      for (var i = nodes.length - 1; i >= 0; i--) {
        if (end ? nodes[i].start < offset : nodes[i].start <= offset) return { node: nodes[i].node, offset: offset - nodes[i].start };
      }
      return null;
    }
    return matchRanges(text, re).map(function (m) {
      var from = at(m[0], false);
      var to = at(m[1], true);
      var range = document.createRange();
      range.setStart(from.node, from.offset);
      range.setEnd(to.node, to.offset);
      return range;
    });
  }

  function useListHighlights(anchor, hosts, on, options) {
    useEffect(function () {
      var scope = anchor.current && anchor.current.parentElement;
      var input = hosts[0] && hosts[0].parentElement.querySelector("input:not(.us-regex-check)");
      if (!canHighlight || !scope || !input || !on || !options.highlight || options.exclude) return undefined;
      var owner = {};
      var frame = 0;
      function update() {
        frame = 0;
        var re = buildHighlighter({ query: input.value, regex: true, caseSensitive: options.caseSensitive, wholeWord: options.wholeWord });
        var ranges = [];
        if (re) {
          var selector = options.fields.map(function (f) { return HIGHLIGHT_SELECTORS[f]; }).join(", ");
          scope.querySelectorAll(selector).forEach(function (el) {
            if (!el.closest(".us-regex-menu")) ranges.push.apply(ranges, rangesIn(el, re));
          });
        }
        highlightOwners.set(owner, ranges);
        publishHighlights();
      }
      function schedule() { if (!frame) frame = root.requestAnimationFrame(update); }
      update();
      var observer = new MutationObserver(schedule);
      observer.observe(scope, { childList: true, subtree: true, characterData: true });
      input.addEventListener("input", schedule);
      return function () {
        observer.disconnect();
        input.removeEventListener("input", schedule);
        if (frame) root.cancelAnimationFrame(frame);
        highlightOwners.delete(owner);
        publishHighlights();
      };
    }, [hosts, on, options]);
  }

  // Stash's search box has no patch point, so the toggle is portaled into
  // each search box of the list it follows (the toolbar and the sidebar).
  function ListRegexToggles(props) {
    var settings = usePluginSettings();
    var on = listRegex.use(props.kind);
    var options = listOptions.use(props.kind);
    var recent = listRecent.use(props.kind);
    var anchor = useRef(null);
    var onRef = useRef(on);
    onRef.current = on;
    var hostsState = useState([]);
    var hosts = hostsState[0];
    var setHosts = hostsState[1];

    useEffect(function () {
      var scope = anchor.current && anchor.current.parentElement;
      if (!scope || settings.hideListRegexToggle) {
        setHosts([]);
        return undefined;
      }
      // Remember a pattern when the search box is left or Enter is pressed.
      function remember(group) {
        var input = group.querySelector("input:not(.us-regex-check)");
        if (onRef.current && input && input.value.trim()) {
          listRecent.set(props.kind, addRecent(listRecent.get(props.kind), input.value));
        }
      }
      function onKeyDown(e) {
        if (e.key === "Enter" && !e.target.classList.contains("us-regex-check")) remember(e.currentTarget);
      }
      function onFocusOut(e) {
        if (!e.relatedTarget || !e.currentTarget.contains(e.relatedTarget)) remember(e.currentTarget);
      }
      // The list renders nothing until its sidebar state loads, so find it
      // again whenever the DOM changes.
      function container() {
        var el = anchor.current && anchor.current.previousElementSibling;
        return el && el.classList.contains("item-list-container") ? el : null;
      }
      function attach() {
        var found = [];
        var list = container();
        if (list) list.querySelectorAll(".search-term-input").forEach(function (group) {
          var host = group.querySelector(":scope > .us-regex-host");
          if (!host) {
            host = document.createElement("span");
            host.className = "us-regex-host";
            group.appendChild(host);
            // The menu is placed against the whole search box, not the toggle,
            // so it can take the box's width in the narrow filter sidebar.
            var menuHost = document.createElement("span");
            menuHost.className = "us-regex-menu-host";
            group.appendChild(menuHost);
            group.classList.add("us-regex-ready");
            group.addEventListener("keydown", onKeyDown);
            group.addEventListener("focusout", onFocusOut);
          }
          found.push(host);
        });
        setHosts(function (prev) {
          return prev.length === found.length && prev.every(function (el, i) { return el === found[i]; }) ? prev : found;
        });
      }
      attach();
      var observer = new MutationObserver(attach);
      observer.observe(scope, { childList: true, subtree: true });
      return function () {
        observer.disconnect();
        scope.querySelectorAll(".us-regex-host").forEach(function (host) {
          var group = host.parentElement;
          group.classList.remove("us-regex-ready", "us-regex-on");
          group.removeEventListener("keydown", onKeyDown);
          group.removeEventListener("focusout", onFocusOut);
          var input = group.querySelector("input:not(.us-regex-check)");
          if (input) {
            input.style.paddingRight = "";
            if (input.dataset.usPlaceholder) input.placeholder = input.dataset.usPlaceholder;
          }
          var menuHost = group.querySelector(":scope > .us-regex-menu-host");
          if (menuHost) menuHost.remove();
          host.remove();
        });
      };
    }, [settings.hideListRegexToggle]);

    // Mark the search boxes so the pattern reads as code, the placeholder says
    // what is searched, and the text stops short of the toggle and its flags.
    useEffect(function () {
      hosts.forEach(function (host) {
        var group = host.parentElement;
        var input = group && group.querySelector("input:not(.us-regex-check)");
        if (!group || !input) return;
        group.classList.toggle("us-regex-on", on);
        if (!input.dataset.usPlaceholder) input.dataset.usPlaceholder = input.placeholder;
        input.placeholder = on ? listPlaceholder(options) : input.dataset.usPlaceholder;
        var room = group.getBoundingClientRect().right - host.getBoundingClientRect().left;
        input.style.paddingRight = room > 0 ? Math.ceil(room + 6) + "px" : "";
      });
    }, [hosts, on, options]);

    useListHighlights(anchor, hosts, on, options);

    return h(React.Fragment, null,
      h("span", { ref: anchor, className: "us-regex-anchor", hidden: true }),
      hosts.map(function (host, i) {
        var menuHost = host.parentElement && host.parentElement.querySelector(":scope > .us-regex-menu-host");
        return h(React.Fragment, { key: "us-regex-" + i },
          ReactDOM.createPortal(h(RegexToggle, { on: on, options: options, onToggle: function (next) { listRegex.set(props.kind, next); } }), host),
          on && menuHost ? ReactDOM.createPortal(h(RegexOptions, {
            options: options,
            recent: recent,
            onChange: function (change) { patchListOptions(props.kind, change); },
            onClearRecent: function () { listRecent.set(props.kind, []); },
          }), menuHost) : null);
      }));
  }

  Object.keys(LISTS).forEach(function (kind) {
    // withListRegex returns the props alone, without the second argument
    // React passes components, so the after patch receives (props, result).
    api.patch.before(LISTS[kind], withListRegex(kind));
    api.patch.after(LISTS[kind], function (_props, result) {
      return h(React.Fragment, null, result, h(ListRegexToggles, { kind: kind }));
    });
  });

  api.register.route(ROUTE, SearchPage);

  api.patch.before("MainNavBar.UtilityItems", function (props) {
    return [Object.assign({}, props, {
      children: [h(NavSearchButton, { key: "universal-search" }), h(React.Fragment, { key: "stash" }, props.children)],
    })];
  });
})(typeof window !== "undefined" ? window : undefined);
