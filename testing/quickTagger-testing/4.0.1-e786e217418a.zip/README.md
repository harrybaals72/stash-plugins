# quickTagger

Quick Tagger adds **Quick Tagger** and **Quick Marker** buttons (shortcuts `alt+q` and `alt+m`) to scene and performer pages. It records *where* a scene tag came from, so Stash's own filters can tell tags you added apart from tags added by Auto Tag, scrapers, or anything else.

Requires Stash with custom fields on tags (v0.31.1 is tested). The `Compatibility check` task reports what is missing on older versions.

## Tag model

For a tag "A", Quick Tagger keeps plain **A** as an ordinary tag and adds up to two sub-tags of it:

| Tag | Meaning | Applied by |
|---|---|---|
| **A** | The general tag | Auto Tag, scrapers, anyone |
| **A (user)** | You added A to this scene (or performer) with Quick Tagger | Quick Tagger only |
| **A (marker)** | This scene contains a marker whose primary tag is A or one of A's sub-tags | Kept in sync by Quick Tagger |

- Each sub-tag has two parents: A, and its role's category tag, **Quick Tagger: user** or **Quick Tagger: marker**. Quick Tagger creates the category tags when it first needs them. Categories only help filtering: if one cannot be created (a tag Quick Tagger does not manage already has its name), tagging still works and the sub-tag has A as its only parent.
- Sub-tags are found by custom fields (`quickTagger_role`, `quickTagger_concept` = A's ID), never by name, so renaming A or a sub-tag does not break anything. Category tags have `quickTagger_role` = `category` and `quickTagger_category` = the role. Tags without these fields are never treated as Quick Tagger's.
- Sub-tags and category tags have **Ignore Auto Tag** on, so Auto Tag never applies them.
- Quick tagging a performer adds **A (user)** to the performer only, never to their scenes.
- A Quick Marker's primary tag is **A (marker)**. Markers made in Stash's own editor with primary tag A (or A (user)) count too.
- **A (marker)** is derived from markers: creating, editing, or deleting a marker (including in Stash's marker editor) updates it through the plugin's hooks, which Stash runs before the marker change returns. Deleting the last A marker removes **A (marker)** and nothing else. Adding or removing it by hand is undone by the next sync; the `Resync marker tags` task rebuilds it everywhere.
- Typing the name or alias of a sub-tag resolves to A. A migrated `A_USR` is an alias of **A (user)**, so typing it still works. Typing a category tag's name is refused with an error.
- If A does not exist, confirming creation creates plain A (an ordinary tag) and the needed sub-tag. If a tag that Quick Tagger does not manage already has a sub-tag's name or alias (for example an unrelated "A (user)"), the task fails with an error and changes nothing. The name is checked before Quick Tagger asks Stash to create a tag, so a clash never shows up as a failed request in Stash's log, even from the marker hook.

### Finding scenes (Scenes page → Filter → Tags)

1. **Every scene with A, from any source:** Tags = A, with *Include sub-tags*.
2. **Scenes containing an A marker:** Tags = A (marker).
3. **Scenes you tagged with A yourself:** Tags = A (user).
4. **Either 2 or 3:** Tags = A (user) and A (marker), modifier *includes any*.
5. **Scenes of a performer you tagged with A:** Performer Tags = A (user). (Performer Tags = A, with *Include sub-tags*, also finds performers tagged A by scrapers.)
6. **Every scene you tagged with anything:** Tags = Quick Tagger: user, with *Include sub-tags*. Quick Tagger: marker does the same for scenes with markers.

Stash's Scenes filter UI cannot combine Tags and Performer Tags with "or", so filter 1 does not include scenes that only have a tagged performer.

The **Markers** page filtered by A (marker) lists the quick markers themselves. A marker's tag filter checks its primary and secondary tags, so filtering by A with *Include sub-tags* lists quick markers and markers made in Stash's editor with primary tag A.

## Dialogs

- While typing, existing plain tags containing the text are suggested (up to 10, prefix matches first). Quick Tagger's sub-tags are not offered.
- Tab highlights the next suggestion (Shift+Tab the previous); Tab past the last one returns to the text box, and the cycle starts again. The arrow keys also move the highlight. The text box keeps focus throughout, so you can keep typing; typing clears the highlight.
- Enter on a highlighted suggestion fills the input with it and closes the list. Enter submits only when no suggestion is highlighted. Clicking a suggestion also fills the input.
- Escape closes the list, then the dialog. With the list closed, Tab moves on to the Submit and Cancel buttons as usual.
- Closing a dialog without submitting (Escape, or Cancel in the dialog or the create prompt) discards the typed text, so it reopens empty. **Don't create** on the create prompt is not a close: it returns to the input with the text kept.
- On submit, the dialog checks whether the text names an existing tag (by name or alias). If not, it asks `Tag "<name>" does not exist. Create it?` (or `Create it for this marker?`). **Create tag** continues; **Don't create** returns to the input with the text kept and creates nothing.
- With `skipCreateConfirmation` on, missing tags are created without asking. With `createMissingTags` off, the dialog reports the missing tag and runs nothing.
- The dialogs run the plugin with `runPluginOperation`, so task errors are shown as errors. (A `runPluginTask` job finishes as FINISHED even when the task fails.)
- Marker playback time is read from the scene player when the dialog is submitted, before any prompt, whether the video is paused or playing. The marker is placed at that time minus `markerPrerollSeconds`, rounded down and at least 1 second (paused at 0:13 with the default preroll gives 0:08).
- On a scene page the buttons sit at the top of the sidebar's tab content. The dialogs float near the top of the window, so opening one (by button or shortcut) does not scroll the page, and they still open while the scene sidebar is collapsed.
- After a task succeeds, the page refetches Stash's `FindScene`, `FindSceneMarkerTags`, and `FindPerformer` queries, so new tags and markers appear without a reload or scan.

## Tasks and hooks

- `Apply quick tag` (`mode: applyTag`)
- `Create quick marker` (`mode: createMarker`)
- Remove quick tag (`mode: removeTag`, through `runPluginOperation` only; not listed as a task): the inverse of `applyTag`, used by the Stash Bridge controllers to remove a tag and to undo one. It removes only **A (user)** from the scene or performer; plain **A**, **A (marker)**, and the performer's scenes are never touched. `keepTarget: true` removes nothing (an undo of an apply that added nothing). `applyTag` also returns `added`: whether the scene or performer itself gained **A (user)**.
- `Resync marker tags` (`mode: syncMarkerTags`): rebuild every `(marker)` sub-tag from the current markers. A tag whose `(marker)` name is already used by a tag Quick Tagger does not manage is skipped and logged as an error; every other scene still syncs.
- `Compatibility check` (`mode: compatibilityCheck`)
- Hook `Sync marker tags` on `SceneMarker.Create.Post`, `SceneMarker.Update.Post`, `SceneMarker.Destroy.Post` (`mode: markerHook`). Create and update recheck the marker's scene; Stash does not report the scene of a deleted marker, so deletion rechecks every scene carrying a `(marker)` sub-tag.

## Settings

- `createMissingTags` (BOOLEAN, default `true`): allow a missing plain tag to be created. Sub-tags of an existing tag are always created as needed.
- `skipCreateConfirmation` (BOOLEAN, default `false`): create missing tags from the dialogs without asking
- `scanAfterUpdate` (BOOLEAN, default `false`)
- `waitForScan` (BOOLEAN, default `true`)
- `markerPrerollSeconds` (NUMBER, default `5`)
- `quickTagShortcut` (STRING, default `alt+q`)
- `quickMarkerShortcut` (STRING, default `alt+m`)
- `showToasts` (BOOLEAN, default `true`)

## Upgrading from 1.x, 2.x, or 3.0

Earlier versions left tags that 4.0 does not use: `A_USR` (1.x and 2.x), and `A (performer)` scene tags and sub-tags without a category parent (3.0). Until they are migrated, 4.0 treats `A_USR` as an ordinary tag. Install the separate **Quick Tagger Migration** plugin and run its tasks: see [its README](../quickTaggerMigration/README.md). Remove that plugin once the library is migrated.

## Behavior notes

- Empty tag/marker text is rejected.
- Marker seconds are adjusted by `markerPrerollSeconds` with lower bound `1`.
- Tag updates are idempotent (no duplicate tag IDs, no duplicate sub-tags).
- Name lookups confirm exact case-insensitive matches, because Stash treats `_` and `%` as wildcards in name filters.
- Optional scan uses deterministic options (generated media disabled).
- **Scan wait caveat**: when `scanAfterUpdate` is enabled, the task queues a Stash `metadataScan` job. Inside Stash's plugin runtime it does **not** wait for the scan, even with `waitForScan` on, because a nested scan cannot finish while the plugin call is running. `waitForScan` only applies when the task runs outside Stash (for example in unit tests).

## Test commands

- Unit: `npm run stash -- test --plugin quickTagger --suite unit`
- Integration (real Stash, covers the filter scenarios, marker removal, Auto Tag, and error cases): `npm run stash -- test --plugin quickTagger --suite integration`
- UI (managed harness): `npm run stash -- test --plugin quickTagger --suite ui`
- All, plus the shared harness and deployment checks: `npm run stash -- test --plugin quickTagger --suite all`
