(function () {
  var PluginApi = window.PluginApi;
  var Core = window.SceneDateProposalCore;
  if (!PluginApi || !PluginApi.React || !PluginApi.ReactDOM || !PluginApi.libraries || !PluginApi.libraries.Bootstrap || !Core) return;

  var React = PluginApi.React;
  var ReactDOM = PluginApi.ReactDOM;
  var Bootstrap = PluginApi.libraries.Bootstrap;
  var h = React.createElement;

  var ITEM_BUTTON = "Propose date";
  var MODAL_TITLE = "Date Proposal";
  var RESULTS_PAGE = 50;
  var SNIPPET_CONTEXT = 40;

  var bulkDefaults = {
    scope: "all",
    folders: [],
    scenes: true,
    images: true,
    includeDated: false,
    skipOrganized: false,
    sources: { path: true, title: true, details: true, code: true, url: true },
  };

  function graphql(query, variables) {
    return fetch("/graphql", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: query, variables: variables || {} }),
    }).then(function (response) {
      return response.text().then(function (body) {
        var json;
        try {
          json = JSON.parse(body);
        } catch (err) {
          throw new Error("Stash returned non-JSON HTTP " + response.status + ": " + body.slice(0, 500));
        }
        if (!response.ok || json.errors) {
          throw new Error((json.errors || []).map(function (e) { return e.message; }).join("; ") || "HTTP " + response.status);
        }
        return json.data;
      });
    });
  }

  function errorMessage(err) {
    return err && err.message ? err.message : String(err);
  }

  function titleCase(value) {
    return value.charAt(0).toUpperCase() + value.slice(1);
  }

  function itemKey(item) {
    return item.type + ":" + item.id;
  }

  function checkbox(id, label, checked, onChange, disabled) {
    return h(Bootstrap.Form.Check, {
      type: "checkbox",
      id: id,
      label: label,
      checked: !!checked,
      disabled: !!disabled,
      onChange: function (event) { onChange(event.currentTarget.checked); },
    });
  }

  function radio(id, name, label, checked, onChange) {
    return h(Bootstrap.Form.Check, {
      type: "radio",
      id: id,
      name: name,
      label: label,
      checked: !!checked,
      onChange: function (event) { if (event.currentTarget.checked) onChange(); },
    });
  }

  // The matched text in its source, with some context around it. Paths and
  // URLs are shown whole; a decoded URL shows what was read from it.
  function Snippet(props) {
    var c = props.candidate;
    if (c.decoded) {
      return h("span", { className: "date-proposal-snippet" },
        h("mark", null, c.match),
        h("span", { className: "date-proposal-muted" }, " decoded from ", c.value)
      );
    }
    var before = c.value.slice(0, c.start);
    var after = c.value.slice(c.end);
    if (c.source !== "path" && c.source !== "url") {
      if (before.length > SNIPPET_CONTEXT) before = "…" + before.slice(-SNIPPET_CONTEXT);
      if (after.length > SNIPPET_CONTEXT) after = after.slice(0, SNIPPET_CONTEXT) + "…";
    }
    return h("span", { className: "date-proposal-snippet" }, before, h("mark", null, c.value.slice(c.start, c.end)), after);
  }

  function ItemInfo(props) {
    var item = props.item;
    var href = (item.type === "scene" ? "/scenes/" : "/images/") + item.id;
    var paths = props.compact ? item.paths.slice(0, 1) : item.paths;
    return h("div", { className: "date-proposal-item" },
      item.thumbnail ? h("img", { className: "date-proposal-thumb", src: item.thumbnail, alt: "", loading: "lazy" }) : null,
      h("div", { className: "date-proposal-item-text" },
        h("div", { className: "date-proposal-item-title" },
          h("a", { href: href, target: props.compact ? "_blank" : undefined, rel: "noopener noreferrer" }, Core.displayName(item)),
          h("span", { className: "date-proposal-muted" }, " ", titleCase(item.type), " #", item.id)
        ),
        h("dl", { className: "date-proposal-fields" },
          h("dt", null, "Current date"), h("dd", null, item.date || "none"),
          item.studio ? h("dt", null, "Studio") : null, item.studio ? h("dd", null, item.studio) : null,
          item.code ? h("dt", null, "Studio code") : null, item.code ? h("dd", null, item.code) : null,
          paths.length ? h("dt", null, paths.length > 1 ? "Files" : "File") : null,
          paths.length ? h("dd", null, paths.map(function (path) { return h("div", { key: path, className: "date-proposal-path" }, path); }),
            props.compact && item.paths.length > 1 ? h("div", { className: "date-proposal-muted" }, "and ", item.paths.length - 1, " more") : null) : null,
          !props.compact && item.urls.length ? h("dt", null, "URLs") : null,
          !props.compact && item.urls.length ? h("dd", null, item.urls.map(function (url) { return h("div", { key: url, className: "date-proposal-path" }, url); })) : null,
          !props.compact && item.details ? h("dt", null, "Details") : null,
          !props.compact && item.details ? h("dd", { className: "date-proposal-details" }, item.details) : null
        )
      )
    );
  }

  function Sources(props) {
    return h("ul", { className: "date-proposal-sources" }, props.candidates.map(function (c, index) {
      return h("li", { key: index },
        h("span", { className: "date-proposal-source" }, Core.SOURCE_LABELS[c.source]),
        " ",
        h(Snippet, { candidate: c }),
        h("span", { className: "date-proposal-muted" }, " (", c.format, ")")
      );
    }));
  }

  function Ignored(props) {
    var ambiguous = props.ambiguous || [];
    if (!ambiguous.length) return null;
    return h("div", { className: "date-proposal-ignored" },
      h("div", { className: "date-proposal-muted" }, "Ignored as ambiguous:"),
      h("ul", null, ambiguous.map(function (a, index) {
        return h("li", { key: index }, "\"", a.match, "\" in ", Core.SOURCE_LABELS[a.source].toLowerCase(), h("span", { className: "date-proposal-muted" }, " (", a.reason, ")"));
      }))
    );
  }

  // One scene or image with its proposed date (or conflicting dates), where
  // each came from, and accept/reject buttons. state: { status, date, error }
  // with status pending, saving, accepted or rejected.
  function ProposalView(props) {
    var proposal = props.proposal;
    var state = props.state || { status: "pending" };
    var item = proposal.item;
    var busy = state.status === "saving";
    var done = state.status === "accepted" || state.status === "rejected";
    var conflict = proposal.status === "conflict";

    var outcome = null;
    if (state.status === "accepted") outcome = h(Bootstrap.Alert, { variant: "success", className: "date-proposal-outcome" }, "Date set to ", h("strong", null, state.date), ".");
    if (state.status === "rejected") outcome = h(Bootstrap.Alert, { variant: "secondary", className: "date-proposal-outcome" }, "Rejected. The date was not changed.");

    return h("div", { className: "date-proposal-card" + (done ? " date-proposal-done" : ""), "data-date-proposal-item": itemKey(item) },
      h(ItemInfo, { item: item, compact: props.compact }),
      outcome,
      done ? null : h("div", null,
        conflict ? h(Bootstrap.Alert, { variant: "warning", className: "date-proposal-conflict" }, "The sources disagree. Accept a date only if you know it is right.") : null,
        proposal.dates.map(function (group) {
          return h("div", { key: group.date, className: "date-proposal-date-row" },
            h("div", { className: "date-proposal-date-head" },
              h("span", { className: "date-proposal-date" }, group.date),
              item.date ? h("span", { className: "date-proposal-muted" }, " replaces ", item.date) : null,
              conflict ? h(Bootstrap.Button, { variant: "outline-primary", size: "sm", disabled: busy, onClick: function () { props.onAccept(group.date); } }, "Accept " + group.date) : null
            ),
            h(Sources, { candidates: group.candidates })
          );
        }),
        h(Ignored, { ambiguous: proposal.ambiguous }),
        state.error ? h(Bootstrap.Alert, { variant: "danger" }, state.error) : null,
        h("div", { className: "date-proposal-actions" },
          conflict ? null : h(Bootstrap.Button, { variant: "primary", size: "sm", disabled: busy, onClick: function () { props.onAccept(proposal.proposedDate); } }, busy ? "Saving..." : "Accept"),
          h(Bootstrap.Button, { variant: "secondary", size: "sm", disabled: busy, onClick: props.onReject }, "Reject")
        )
      )
    );
  }

  function modalProps(onHide) {
    return { show: true, onHide: onHide, size: "lg", className: "date-proposal-modal", scrollable: true };
  }

  function ItemModal(props) {
    var loadPair = React.useState({ loading: true });
    var load = loadPair[0];
    var setLoad = loadPair[1];
    var statePair = React.useState({ status: "pending" });
    var state = statePair[0];
    var setState = statePair[1];

    React.useEffect(function () {
      var live = true;
      Promise.all([Core.loadItem(graphql, props.type, props.id), Core.loadLibraryRoots(graphql)]).then(function (results) {
        if (live) setLoad({ proposal: Core.proposeDate(results[0], { libraryRoots: results[1] }) });
      }).catch(function (err) {
        if (live) setLoad({ error: errorMessage(err) });
      });
      return function () { live = false; };
    }, [props.type, props.id]);

    function accept(date) {
      setState({ status: "saving" });
      Core.applyDates(graphql, [{ type: props.type, id: props.id, date: date }]).then(function () {
        setState({ status: "accepted", date: date });
      }).catch(function (err) {
        setState({ status: "pending", error: errorMessage(err) });
      });
    }

    var proposal = load.proposal;
    var body;
    if (load.loading) body = h("div", { className: "date-proposal-muted" }, "Loading...");
    else if (load.error) body = h(Bootstrap.Alert, { variant: "danger" }, load.error);
    else if (proposal.status === "proposed" || proposal.status === "conflict") {
      body = h(ProposalView, { proposal: proposal, state: state, onAccept: accept, onReject: function () { setState({ status: "rejected" }); } });
    } else {
      body = h("div", { className: "date-proposal-card" },
        h(ItemInfo, { item: proposal.item }),
        proposal.status === "unchanged"
          ? h("div", null, h(Bootstrap.Alert, { variant: "info" }, "The current date already matches what the sources say."), h(Sources, { candidates: proposal.dates[0].candidates }))
          : h(Bootstrap.Alert, { variant: "info" }, "No unambiguous date found in the file path, title, details, studio code, or URLs."),
        h(Ignored, { ambiguous: proposal.ambiguous })
      );
    }

    return h(Bootstrap.Modal, modalProps(props.onHide),
      h(Bootstrap.Modal.Header, { closeButton: true }, h(Bootstrap.Modal.Title, null, MODAL_TITLE)),
      h(Bootstrap.Modal.Body, null, body),
      h(Bootstrap.Modal.Footer, null,
        state.status === "accepted" ? h(Bootstrap.Button, { variant: "link", onClick: function () { window.location.reload(); } }, "Reload page to see changes") : null,
        h(Bootstrap.Button, { variant: "secondary", onClick: props.onHide }, "Close")
      )
    );
  }

  // Browse the server's folders, starting from the library folders.
  function FolderPicker(props) {
    var currentPair = React.useState("");
    var current = currentPair[0];
    var setCurrent = currentPair[1];
    var listingPair = React.useState({ directories: [], parent: null });
    var listing = listingPair[0];
    var setListing = listingPair[1];
    var rootsPair = React.useState([]);
    var roots = rootsPair[0];
    var setRoots = rootsPair[1];

    React.useEffect(function () {
      Core.loadLibraryRoots(graphql).then(setRoots).catch(function () {});
    }, []);

    React.useEffect(function () {
      if (!current) {
        setListing({ directories: [], parent: null });
        return undefined;
      }
      var live = true;
      var timer = window.setTimeout(function () {
        graphql(Core.QUERIES.DIRECTORY, { path: current }).then(function (data) {
          if (live) setListing({ directories: data.directory.directories || [], parent: data.directory.parent || null });
        }).catch(function (err) {
          if (live) setListing({ directories: [], parent: null, error: errorMessage(err) });
        });
      }, 250);
      return function () { live = false; window.clearTimeout(timer); };
    }, [current]);

    var choices = current ? listing.directories : roots;
    var selected = props.folders;

    function add() {
      var folder = current.replace(/[\/\\]+$/, "");
      if (folder && selected.indexOf(folder) === -1) props.onChange(selected.concat([folder]));
    }

    return h("div", { className: "date-proposal-folders" },
      selected.length ? h("ul", { className: "date-proposal-selected-folders" }, selected.map(function (folder) {
        return h("li", { key: folder },
          h("span", { className: "date-proposal-path" }, folder),
          h(Bootstrap.Button, { variant: "danger", size: "sm", onClick: function () { props.onChange(selected.filter(function (f) { return f !== folder; })); } }, "Remove")
        );
      })) : h("div", { className: "date-proposal-muted" }, "No folders selected."),
      h("div", { className: "date-proposal-folder-input" },
        h(Bootstrap.Form.Control, {
          placeholder: "Folder path",
          "aria-label": "Folder path",
          value: current,
          spellCheck: false,
          onChange: function (event) { setCurrent(event.currentTarget.value); },
        }),
        h(Bootstrap.Button, { variant: "secondary", disabled: !current.trim(), onClick: add }, "Add folder")
      ),
      listing.error ? h("div", { className: "text-danger" }, listing.error) : null,
      h("ul", { className: "date-proposal-folder-list" },
        current ? h("li", null, h(Bootstrap.Button, { variant: "link", size: "sm", onClick: function () { setCurrent(listing.parent && roots.indexOf(current) === -1 ? listing.parent : ""); } }, "Up a folder")) : null,
        choices.map(function (dir) {
          return h("li", { key: dir }, h(Bootstrap.Button, { variant: "link", size: "sm", onClick: function () { setCurrent(dir); } }, dir));
        })
      )
    );
  }

  function selectionLabel(selection) {
    var noun = selection.type === "scene" ? "scene" : "image";
    return (selection.ids.length === 1 ? "1 " + noun : selection.ids.length + " " + noun + "s") + (selection.selected ? " selected" : " on this page");
  }

  function BulkOptions(props) {
    var options = props.options;
    var set = props.set;
    function setSource(source, value) {
      var sources = {};
      Core.SOURCES.forEach(function (s) { sources[s] = options.sources[s]; });
      sources[source] = value;
      set("sources", sources);
    }
    var selection = props.selection;
    return h("div", { className: "date-proposal-options" },
      selection ? h("div", null, h(Bootstrap.Form.Label, null, "Look in"), h("div", null, selectionLabel(selection))) : h(Bootstrap.Form.Group, null,
        h(Bootstrap.Form.Label, null, "Look in"),
        radio("date-proposal-scope-all", "date-proposal-scope", "All scenes and images", options.scope === "all", function () { set("scope", "all"); }),
        radio("date-proposal-scope-folders", "date-proposal-scope", "Only selected folders", options.scope === "folders", function () { set("scope", "folders"); }),
        options.scope === "folders" ? h(FolderPicker, { folders: options.folders, onChange: function (folders) { set("folders", folders); } }) : null
      ),
      h("div", { className: "date-proposal-grid" },
        h("div", null,
          h(Bootstrap.Form.Label, null, selection ? "Options" : "Media"),
          selection ? null : checkbox("date-proposal-scenes", "Scenes", options.scenes, function (v) { set("scenes", v); }),
          selection ? null : checkbox("date-proposal-images", "Images", options.images, function (v) { set("images", v); }),
          checkbox("date-proposal-include-dated", "Include items that already have a date", options.includeDated, function (v) { set("includeDated", v); }),
          selection ? null : checkbox("date-proposal-skip-organized", "Skip organized items", options.skipOrganized, function (v) { set("skipOrganized", v); })
        ),
        h("div", null,
          h(Bootstrap.Form.Label, null, "Read dates from"),
          Core.SOURCES.map(function (source) {
            return h(React.Fragment, { key: source }, checkbox("date-proposal-source-" + source, Core.SOURCE_LABELS[source], options.sources[source], function (v) { setSource(source, v); }));
          })
        )
      )
    );
  }

  function BulkModal(props) {
    var optionsPair = React.useState(function () {
      var initial = {};
      for (var key in bulkDefaults) initial[key] = bulkDefaults[key];
      initial.scope = props.scope || "all";
      if (props.selection) initial.includeDated = true;
      return initial;
    });
    var options = optionsPair[0];
    var setOptions = optionsPair[1];
    var phasePair = React.useState("options");
    var phase = phasePair[0];
    var setPhase = phasePair[1];
    var progressPair = React.useState({ checked: 0, total: 0 });
    var progress = progressPair[0];
    var setProgress = progressPair[1];
    var resultPair = React.useState(null);
    var result = resultPair[0];
    var setResult = resultPair[1];
    var statesPair = React.useState({});
    var states = statesPair[0];
    var setStates = statesPair[1];
    var errorPair = React.useState("");
    var error = errorPair[0];
    var setError = errorPair[1];
    var shownPair = React.useState(RESULTS_PAGE);
    var shown = shownPair[0];
    var setShown = shownPair[1];
    var confirmPair = React.useState(false);
    var confirming = confirmPair[0];
    var setConfirming = confirmPair[1];
    var bulkPair = React.useState(false);
    var bulkSaving = bulkPair[0];
    var setBulkSaving = bulkPair[1];
    var mounted = React.useRef(true);
    React.useEffect(function () { return function () { mounted.current = false; }; }, []);

    React.useEffect(function () {
      if (props.selection) find();
      // eslint-disable-next-line
    }, []);

    function set(key, value) {
      setOptions(function (current) {
        var next = {};
        for (var k in current) next[k] = current[k];
        next[key] = value;
        return next;
      });
    }

    function setItemState(keys, state) {
      setStates(function (current) {
        var next = {};
        for (var k in current) next[k] = current[k];
        keys.forEach(function (key) { next[key] = state; });
        return next;
      });
    }

    function find() {
      var searchOptions = options;
      if (props.selection) {
        searchOptions = {};
        for (var name in options) searchOptions[name] = options[name];
        searchOptions.ids = {};
        searchOptions.ids[props.selection.type] = props.selection.ids;
      }
      setError("");
      setPhase("scanning");
      setProgress({ checked: 0, total: 0 });
      setStates({});
      setShown(RESULTS_PAGE);
      setConfirming(false);
      Core.findProposals(graphql, searchOptions, function (p) {
        if (mounted.current) setProgress(p);
      }).then(function (found) {
        if (!mounted.current) return;
        setResult(found);
        setPhase("results");
      }).catch(function (err) {
        if (!mounted.current) return;
        setError(errorMessage(err));
        setPhase("options");
      });
    }

    function accept(proposal, date) {
      var key = itemKey(proposal.item);
      setItemState([key], { status: "saving" });
      Core.applyDates(graphql, [{ type: proposal.item.type, id: proposal.item.id, date: date }]).then(function () {
        if (mounted.current) setItemState([key], { status: "accepted", date: date });
      }).catch(function (err) {
        if (mounted.current) setItemState([key], { status: "pending", error: errorMessage(err) });
      });
    }

    var proposals = result ? result.proposals : [];
    var pendingProposed = proposals.filter(function (p) {
      var state = states[itemKey(p.item)];
      return p.status === "proposed" && (!state || state.status === "pending");
    });
    var accepted = 0;
    var rejected = 0;
    for (var key in states) {
      if (states[key].status === "accepted") accepted += 1;
      if (states[key].status === "rejected") rejected += 1;
    }

    function acceptAll() {
      var batch = pendingProposed.slice();
      var keys = batch.map(function (p) { return itemKey(p.item); });
      setConfirming(false);
      setBulkSaving(true);
      setItemState(keys, { status: "saving" });
      Core.applyDates(graphql, batch.map(function (p) { return { type: p.item.type, id: p.item.id, date: p.proposedDate }; })).then(function () {
        if (!mounted.current) return;
        setStates(function (current) {
          var next = {};
          for (var k in current) next[k] = current[k];
          batch.forEach(function (p) { next[itemKey(p.item)] = { status: "accepted", date: p.proposedDate }; });
          return next;
        });
      }).catch(function (err) {
        if (!mounted.current) return;
        setError(errorMessage(err) + " Some dates may have been saved; search again to see what is left.");
        setItemState(keys, { status: "pending" });
      }).finally(function () {
        if (mounted.current) setBulkSaving(false);
      });
    }

    var noMedia = !props.selection && !options.scenes && !options.images;
    var noSources = !Core.SOURCES.some(function (s) { return options.sources[s]; });
    var noFolders = !props.selection && options.scope === "folders" && !options.folders.length;

    var body;
    if (phase === "options") {
      body = h("div", null,
        h("p", { className: "date-proposal-muted" }, "Finds dates that can only be read one way, such as 2020-12-25, 25.12.2020 or 25 December 2020, and lists each proposal for you to accept or reject. Nothing changes until you accept."),
        h(BulkOptions, { options: options, set: set, selection: props.selection })
      );
    } else if (phase === "scanning") {
      body = h("div", { className: "date-proposal-progress" },
        "Checked ", progress.checked, progress.total ? " of " + progress.total : "", " items...",
        Bootstrap.ProgressBar ? h(Bootstrap.ProgressBar, { now: progress.total ? Math.round(100 * progress.checked / progress.total) : 0, animated: true }) : null
      );
    } else {
      var counts = result.counts;
      body = h("div", null,
        h("div", { className: "date-proposal-summary" },
          h("div", null,
            "Checked ", h("strong", null, String(result.checked)), " items: ",
            h("strong", null, String(counts.proposed)), " proposed dates, ",
            h("strong", null, String(counts.conflict)), " with conflicting dates, ",
            String(counts.none), " without an unambiguous date",
            counts.unchanged ? ", " + counts.unchanged + " already matching" : "",
            "."
          ),
          accepted || rejected ? h("div", null, "Accepted ", accepted, ", rejected ", rejected, ".") : null,
          pendingProposed.length ? (confirming
            ? h("div", { className: "date-proposal-confirm" },
                "Set the proposed date on ", pendingProposed.length, " items? Items with conflicting dates are left for you to review.",
                h(Bootstrap.Button, { variant: "primary", size: "sm", onClick: acceptAll }, "Confirm"),
                h(Bootstrap.Button, { variant: "secondary", size: "sm", onClick: function () { setConfirming(false); } }, "Cancel"))
            : h(Bootstrap.Button, { variant: "outline-primary", size: "sm", disabled: bulkSaving, onClick: function () { setConfirming(true); } }, bulkSaving ? "Saving..." : "Accept all " + pendingProposed.length + " proposals")) : null
        ),
        error ? h(Bootstrap.Alert, { variant: "danger" }, error) : null,
        proposals.length ? null : h(Bootstrap.Alert, { variant: "info" }, "No dates to propose."),
        proposals.slice(0, shown).map(function (proposal) {
          var k = itemKey(proposal.item);
          return h(ProposalView, {
            key: k,
            compact: true,
            proposal: proposal,
            state: states[k],
            onAccept: function (date) { accept(proposal, date); },
            onReject: function () { setItemState([k], { status: "rejected" }); },
          });
        }),
        proposals.length > shown ? h(Bootstrap.Button, { variant: "link", onClick: function () { setShown(shown + RESULTS_PAGE); } }, "Show more (" + (proposals.length - shown) + " left)") : null
      );
    }

    return h(Bootstrap.Modal, modalProps(props.onHide),
      h(Bootstrap.Modal.Header, { closeButton: true }, h(Bootstrap.Modal.Title, null, MODAL_TITLE)),
      h(Bootstrap.Modal.Body, null, phase === "options" && error ? h(Bootstrap.Alert, { variant: "danger" }, error) : null, body),
      h(Bootstrap.Modal.Footer, null,
        phase === "results" ? h(Bootstrap.Button, { variant: "secondary", onClick: function () { setError(""); setPhase("options"); } }, "Change options") : null,
        h(Bootstrap.Button, { variant: "secondary", onClick: props.onHide }, "Close"),
        phase === "options" ? h(Bootstrap.Button, { variant: "primary", disabled: noMedia || noSources || noFolders, onClick: find }, "Find dates") : null
      )
    );
  }

  function ItemButton(props) {
    var openPair = React.useState(false);
    var open = openPair[0];
    var setOpen = openPair[1];
    React.useEffect(function () { setOpen(false); }, [props.type, props.id]);
    return h("span", { className: "date-proposal-action" },
      h(Bootstrap.Button, { variant: "secondary", size: "sm", onClick: function () { setOpen(true); } }, ITEM_BUTTON),
      open ? h(ItemModal, { type: props.type, id: props.id, onHide: function () { setOpen(false); } }) : null
    );
  }

  // Laid out like the stock Library tasks on Settings > Tasks.
  function TasksSection() {
    var scopePair = React.useState("");
    var scope = scopePair[0];
    var setScope = scopePair[1];
    return h("div", { className: "setting-section", id: "date-proposal-tasks" },
      h("h1", null, "Date proposals"),
      h(Bootstrap.Card, null,
        h("div", { className: "setting" },
          h("div", null,
            h("h3", null, "Propose dates"),
            h("div", { className: "sub-heading" }, "Finds unambiguous dates in file paths, titles, details, studio codes and URLs of scenes and images without a date, then lets you accept or reject each one.")
          ),
          h("div", null,
            h(Bootstrap.Button, { variant: "secondary", className: "mr-2", onClick: function () { setScope("all"); } }, "Propose dates…"),
            h(Bootstrap.Button, { variant: "secondary", onClick: function () { setScope("folders"); } }, "Selective propose dates…")
          )
        )
      ),
      scope ? h(BulkModal, { scope: scope, onHide: function () { setScope(""); } }) : null
    );
  }

  // The scenes or images on the current list page and which are selected,
  // captured as Stash renders its lists.
  var listState = { scene: { ids: [], selected: [] }, image: { ids: [], selected: [] } };

  function captureList(type, rows, selectedIds) {
    listState[type] = {
      ids: (rows || []).map(function (row) { return String(row.id); }),
      selected: Array.from(selectedIds || []).map(String),
    };
  }

  function patchList(name, type, key) {
    if (!PluginApi.patch || !PluginApi.patch.before) return;
    PluginApi.patch.before(name, function (props) {
      captureList(type, props && props[key], props && props.selectedIds);
      return Array.prototype.slice.call(arguments);
    });
  }

  patchList("SceneList", "scene", "scenes");
  patchList("ImageList", "image", "images");

  // Selected items, or the whole page when nothing is selected.
  function listSelection(type) {
    var state = listState[type];
    var visible = {};
    state.ids.forEach(function (id) { visible[id] = true; });
    var selected = state.selected.filter(function (id) { return visible[id]; });
    return selected.length ? { type: type, ids: selected, selected: true } : { type: type, ids: state.ids, selected: false };
  }

  function ListLauncher() {
    var selectionPair = React.useState(null);
    var selection = selectionPair[0];
    var setSelection = selectionPair[1];
    React.useEffect(function () {
      openListModal = function (type) {
        var next = listSelection(type);
        if (next.ids.length) setSelection(next);
      };
      return function () { openListModal = null; };
    }, []);
    return selection ? h(BulkModal, { key: selection.type + selection.ids.join(","), selection: selection, onHide: function () { setSelection(null); } }) : null;
  }

  var openListModal = null;

  var MENU_ITEM_CLASS = "dropdown-item bg-secondary text-white date-proposal-menu-item";
  var LIST_MENUS = [
    { selector: ".scene-list-operations-dropdown", type: "scene" },
    { selector: ".image-list-operations-dropdown", type: "image" },
  ];

  function menuItemText(type) {
    var selection = listSelection(type);
    return selection.selected ? "Propose dates for selected (" + selection.ids.length + ")…" : "Propose dates for this page…";
  }

  // Adds the item to the list's "..." menu. Stash builds that menu itself, so
  // the item is added to its DOM and its label follows the selection.
  function mountListMenuItems() {
    LIST_MENUS.forEach(function (entry) {
      var menu = document.querySelector(entry.selector);
      if (!menu || menu.querySelector(".date-proposal-menu-item")) return;
      var item = document.createElement("a");
      item.className = MENU_ITEM_CLASS;
      item.setAttribute("role", "button");
      item.setAttribute("href", "#");
      item.textContent = menuItemText(entry.type);
      item.addEventListener("click", function (event) {
        event.preventDefault();
        // A click outside the menu is what closes it.
        document.body.click();
        if (openListModal) openListModal(entry.type);
      });
      menu.appendChild(item);
      var refresh = function () {
        var text = menuItemText(entry.type);
        if (item.textContent !== text) item.textContent = text;
      };
      new MutationObserver(refresh).observe(menu, { attributes: true, attributeFilter: ["class"] });
    });
  }

  function mountListLauncher() {
    if (document.querySelector("[data-date-proposal-list-root]")) return;
    var container = document.createElement("div");
    container.setAttribute("data-date-proposal-list-root", "true");
    document.body.appendChild(container);
    render(container, h(ListLauncher));
  }

  var roots = [];

  function render(container, element) {
    if (ReactDOM.createRoot) {
      if (!container.__dateProposalRoot) {
        container.__dateProposalRoot = ReactDOM.createRoot(container);
        roots.push(container);
      }
      container.__dateProposalRoot.render(element);
    } else {
      if (roots.indexOf(container) === -1) roots.push(container);
      ReactDOM.render(element, container);
    }
  }

  // Stash replaces the page's DOM on navigation; release roots it removed.
  function releaseDetachedRoots() {
    roots = roots.filter(function (container) {
      if (document.body.contains(container)) return true;
      if (container.__dateProposalRoot) container.__dateProposalRoot.unmount();
      else ReactDOM.unmountComponentAtNode(container);
      return false;
    });
  }

  function itemTarget() {
    var path = window.location.pathname;
    var scene = path.match(/^\/scenes\/(\d+)/);
    if (scene) return { type: "scene", id: scene[1], selectors: [".scene-tabs > div:first-child", ".scene-tabs"] };
    var image = path.match(/^\/images\/(\d+)/);
    if (image) return { type: "image", id: image[1], selectors: [".image-tabs > div:first-child", ".image-tabs"] };
    return null;
  }

  function mountItemButton() {
    var target = itemTarget();
    var existing = document.querySelector("[data-date-proposal-item-root]");
    if (!target) {
      if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
      return;
    }
    var host = null;
    for (var i = 0; i < target.selectors.length && !host; i += 1) host = document.querySelector(target.selectors[i]);
    if (!host) return;
    if (existing && !host.contains(existing) && existing.parentNode) existing.parentNode.removeChild(existing);
    var container = host.querySelector("[data-date-proposal-item-root]");
    if (!container) {
      container = document.createElement("div");
      container.setAttribute("data-date-proposal-item-root", "true");
      container.className = "date-proposal-root";
      host.appendChild(container);
    }
    render(container, h(ItemButton, { type: target.type, id: target.id }));
  }

  // After the Library tasks, before the first divider.
  function mountTasksSection() {
    var panel = document.querySelector("#tasks-panel .tasks-panel-tasks");
    if (!panel || panel.querySelector("[data-date-proposal-tasks-root]")) return;
    var container = document.createElement("div");
    container.setAttribute("data-date-proposal-tasks-root", "true");
    var divider = panel.querySelector(":scope > hr");
    panel.insertBefore(container, divider || null);
    render(container, h(TasksSection));
  }

  function mount() {
    releaseDetachedRoots();
    mountItemButton();
    mountTasksSection();
    mountListLauncher();
    mountListMenuItems();
  }

  var mountTimer = null;
  function scheduleMount() {
    if (mountTimer) window.clearTimeout(mountTimer);
    mountTimer = window.setTimeout(mount, 75);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", scheduleMount);
  else scheduleMount();

  if (PluginApi.Event && PluginApi.Event.addEventListener) {
    PluginApi.Event.addEventListener("stash:location", scheduleMount);
  }

  function startObserver() {
    if (!document.body || !window.MutationObserver) return;
    new MutationObserver(scheduleMount).observe(document.body, { childList: true, subtree: true });
  }

  if (document.body) startObserver();
  else document.addEventListener("DOMContentLoaded", startObserver);
})();
