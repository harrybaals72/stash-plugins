// Finds dates that can only be read one way in a scene's or image's file
// paths, title, details, studio code, and URLs, and loads and saves dates
// through GraphQL. The UI script uses it in the browser; tests load it in Node.
(function (root) {
  var PLUGIN_ID = "scene-date-proposal-testing";
  var MIN_YEAR = 1900;
  var PAGE_SIZE = 500;

  var SOURCES = ["path", "title", "details", "code", "url"];
  var SOURCE_LABELS = {
    path: "File path",
    title: "Title",
    details: "Details",
    code: "Studio code",
    url: "URL",
  };

  var MONTHS = {
    january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7,
    august: 8, september: 9, october: 10, november: 11, december: 12,
    jan: 1, feb: 2, mar: 3, apr: 4, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9,
    oct: 10, nov: 11, dec: 12,
  };
  // Longest names first so "sept" wins over "sep" and "june" over "jun".
  var MONTH_PATTERN = Object.keys(MONTHS).sort(function (a, b) { return b.length - a.length; }).join("|");

  // Numeric dates use the same separator twice. Spaces are not separators:
  // "Best of 2019 10 3 way" is not a date.
  var YEAR_FIRST = /(\d{4})([-._\/])(\d{1,2})\2(\d{1,2})/g;
  var YEAR_LAST = /(\d{1,2})([-._\/])(\d{1,2})\2(\d{4})/g;
  var COMPACT = /\d{8}/g;
  var GAP = "[\\s.,_\\/-]*";
  var SUFFIX = "(?:st|nd|rd|th)?";
  var DAY_MONTH_YEAR = new RegExp("(\\d{1,2})" + SUFFIX + "(?:" + GAP + "of)?" + GAP + "(" + MONTH_PATTERN + ")(?![a-z])\\.?" + GAP + "(\\d{4})", "gi");
  var MONTH_DAY_YEAR = new RegExp("(" + MONTH_PATTERN + ")(?![a-z])\\.?" + GAP + "(\\d{1,2})" + SUFFIX + "[\\s.,_\\/-]+(\\d{4})", "gi");
  var YEAR_MONTH_DAY = new RegExp("(\\d{4})" + GAP + "(" + MONTH_PATTERN + ")(?![a-z])\\.?" + GAP + "(\\d{1,2})" + SUFFIX + "(?![a-z])", "gi");

  var SCENE_FIELDS = "id title details code urls date organized files { path } paths { screenshot } studio { name }";
  var IMAGE_FIELDS = "id title details code urls date organized visual_files { ... on BaseFile { path } } paths { thumbnail } studio { name }";

  var QUERIES = {
    FIND_SCENE: "query SceneDateProposalScene($id: ID!) { findScene(id: $id) { " + SCENE_FIELDS + " } }",
    FIND_IMAGE: "query SceneDateProposalImage($id: ID!) { findImage(id: $id) { " + IMAGE_FIELDS + " } }",
    FIND_SCENES: "query SceneDateProposalScenes($filter: FindFilterType, $scene_filter: SceneFilterType, $ids: [ID!]) { findScenes(filter: $filter, scene_filter: $scene_filter, ids: $ids) { count scenes { " + SCENE_FIELDS + " } } }",
    FIND_IMAGES: "query SceneDateProposalImages($filter: FindFilterType, $image_filter: ImageFilterType, $ids: [ID!]) { findImages(filter: $filter, image_filter: $image_filter, ids: $ids) { count images { " + IMAGE_FIELDS + " } } }",
    LIBRARY_PATHS: "query SceneDateProposalLibraryPaths { configuration { general { stashes { path } } } }",
    DIRECTORY: "query SceneDateProposalDirectory($path: String) { directory(path: $path) { path parent directories } }",
    UPDATE_SCENES: "mutation SceneDateProposalUpdateScenes($input: BulkSceneUpdateInput!) { bulkSceneUpdate(input: $input) { id date } }",
    UPDATE_IMAGES: "mutation SceneDateProposalUpdateImages($input: BulkImageUpdateInput!) { bulkImageUpdate(input: $input) { id date } }",
  };

  function pad2(value) {
    return value < 10 ? "0" + value : String(value);
  }

  function isoDate(year, month, day) {
    return year + "-" + pad2(month) + "-" + pad2(day);
  }

  function todayIso(now) {
    now = now || new Date();
    return isoDate(now.getFullYear(), now.getMonth() + 1, now.getDate());
  }

  function daysInMonth(year, month) {
    if (month === 2) return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 29 : 28;
    return month === 4 || month === 6 || month === 9 || month === 11 ? 30 : 31;
  }

  // A real calendar date from 1900 up to today, or null.
  function checkedDate(year, month, day, today) {
    if (year < MIN_YEAR || month < 1 || month > 12 || day < 1 || day > daysInMonth(year, month)) return null;
    var date = isoDate(year, month, day);
    return date > today ? null : date;
  }

  function isDigit(ch) {
    return ch >= "0" && ch <= "9";
  }

  function isLetter(ch) {
    return !!ch && ch.toLowerCase() !== ch.toUpperCase();
  }

  // Numbers that run on into more digits are part of something else.
  function digitBounded(text, start, end) {
    return !isDigit(text.charAt(start - 1)) && !isDigit(text.charAt(end));
  }

  // Year first is read as year-month-day. Only a middle value above 12 is
  // read as year-day-month, since it cannot be a month.
  function readYearFirst(a, b) {
    if (a <= 12) return { month: a, day: b, format: "YYYY-MM-DD" };
    if (b <= 12) return { month: b, day: a, format: "YYYY-DD-MM (day above 12)" };
    return null;
  }

  // Year last is accepted only when the day is above 12, or when day and month
  // are equal, so day-month and month-day orders give the same date.
  function readYearLast(a, b) {
    if (a === b) return { month: a, day: b, format: "DD-MM-YYYY (day equals month)" };
    if (a > 12 && b <= 12) return { month: b, day: a, format: "DD-MM-YYYY (day above 12)" };
    if (b > 12 && a <= 12) return { month: a, day: b, format: "MM-DD-YYYY (day above 12)" };
    return null;
  }

  // A number after one of these words counts something: "Top 10 May 2020"
  // and "Part 2 June 2021" are not days.
  var COUNT_WORDS = /(?:^|[^a-z])(?:top|best|part|pt|vol|volume|no|nr|number|ep|episode|chapter|ch|scene|season|s|e)[\s.:#-]*$|#\s*$/i;

  function countsSomething(text, start) {
    return COUNT_WORDS.test(text.slice(Math.max(0, start - 12), start));
  }

  function scan(re, text, fn) {
    re.lastIndex = 0;
    var m;
    while ((m = re.exec(text)) !== null) {
      // Retry one character later after a rejected match, so a match that
      // starts inside it is still found.
      if (!fn(m)) re.lastIndex = m.index + 1;
    }
  }

  function rawMatches(text, today) {
    var found = [];
    var ambiguous = [];

    function add(m, start, date, format) {
      found.push({ date: date, match: m[0].slice(start - m.index), start: start, end: m.index + m[0].length, format: format });
      return true;
    }

    scan(YEAR_FIRST, text, function (m) {
      var end = m.index + m[0].length;
      if (!digitBounded(text, m.index, end)) return false;
      var read = readYearFirst(parseInt(m[3], 10), parseInt(m[4], 10));
      var date = read && checkedDate(parseInt(m[1], 10), read.month, read.day, today);
      return date ? add(m, m.index, date, read.format) : false;
    });

    scan(YEAR_LAST, text, function (m) {
      var end = m.index + m[0].length;
      if (!digitBounded(text, m.index, end)) return false;
      var a = parseInt(m[1], 10);
      var b = parseInt(m[3], 10);
      var year = parseInt(m[4], 10);
      var read = readYearLast(a, b);
      if (!read) {
        // Both orders are valid dates: report it, but never propose it.
        if (checkedDate(year, a, b, today) && checkedDate(year, b, a, today)) {
          ambiguous.push({ match: m[0], start: m.index, end: end, reason: "day and month could be swapped" });
          return true;
        }
        return false;
      }
      var date = checkedDate(year, read.month, read.day, today);
      return date ? add(m, m.index, date, read.format) : false;
    });

    scan(COMPACT, text, function (m) {
      var end = m.index + 8;
      if (!digitBounded(text, m.index, end)) return false;
      var date = checkedDate(parseInt(m[0].slice(0, 4), 10), parseInt(m[0].slice(4, 6), 10), parseInt(m[0].slice(6, 8), 10), today);
      return date ? add(m, m.index, date, "YYYYMMDD") : false;
    });

    function monthBounded(m, monthText) {
      var at = m.index + m[0].toLowerCase().indexOf(monthText.toLowerCase());
      return !isLetter(text.charAt(at - 1));
    }

    scan(DAY_MONTH_YEAR, text, function (m) {
      if (!digitBounded(text, m.index, m.index + m[0].length) || !monthBounded(m, m[2]) || countsSomething(text, m.index)) return false;
      var date = checkedDate(parseInt(m[3], 10), MONTHS[m[2].toLowerCase()], parseInt(m[1], 10), today);
      return date ? add(m, m.index, date, "Day Month Year") : false;
    });

    scan(MONTH_DAY_YEAR, text, function (m) {
      if (isLetter(text.charAt(m.index - 1)) || isDigit(text.charAt(m.index + m[0].length))) return false;
      var date = checkedDate(parseInt(m[3], 10), MONTHS[m[1].toLowerCase()], parseInt(m[2], 10), today);
      return date ? add(m, m.index, date, "Month Day Year") : false;
    });

    scan(YEAR_MONTH_DAY, text, function (m) {
      if (!digitBounded(text, m.index, m.index + m[0].length) || !monthBounded(m, m[2])) return false;
      var date = checkedDate(parseInt(m[1], 10), MONTHS[m[2].toLowerCase()], parseInt(m[3], 10), today);
      return date ? add(m, m.index, date, "Year Month Day") : false;
    });

    return { found: found, ambiguous: ambiguous };
  }

  function overlaps(a, b) {
    return a.start < b.end && b.start < a.end;
  }

  // Dates found in one piece of text. Overlapping matches that agree are
  // merged into the longest; overlapping matches that disagree, such as
  // "25.12.2020.05.06", are both dropped and reported as ambiguous.
  function extractDates(text, options) {
    text = text === undefined || text === null ? "" : String(text);
    var today = (options && options.today) || todayIso();
    var raw = rawMatches(text, today);
    var dates = [];
    var ambiguous = raw.ambiguous.slice();
    var found = raw.found;
    var i;
    var j;

    found.sort(function (a, b) { return a.start - b.start || (b.end - b.start) - (a.end - a.start); });
    var dropped = [];
    for (i = 0; i < found.length; i += 1) {
      for (j = i + 1; j < found.length; j += 1) {
        if (overlaps(found[i], found[j]) && found[i].date !== found[j].date) {
          dropped[i] = true;
          dropped[j] = true;
        }
      }
      for (j = 0; j < ambiguous.length; j += 1) {
        if (overlaps(found[i], ambiguous[j])) dropped[i] = true;
      }
    }
    for (i = 0; i < found.length; i += 1) {
      if (dropped[i]) {
        ambiguous.push({ match: found[i].match, start: found[i].start, end: found[i].end, reason: "overlaps a different date" });
        continue;
      }
      var covered = false;
      for (j = 0; j < dates.length; j += 1) {
        if (overlaps(found[i], dates[j])) covered = true;
      }
      if (!covered) dates.push(found[i]);
    }

    var seen = Object.create(null);
    ambiguous = ambiguous.filter(function (item) {
      var key = item.start + ":" + item.end;
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    }).sort(function (a, b) { return a.start - b.start; });
    return { dates: dates, ambiguous: ambiguous };
  }

  function trimSeparators(path) {
    return String(path || "").replace(/[\/\\]+$/, "");
  }

  function isWindowsPath(path) {
    return /^[A-Za-z]:[\\\/]/.test(path) || /^\\\\/.test(path);
  }

  // The part of a file path below its library folder, so a library at
  // /media/2021-01-01 never dates every file in it.
  function relativePath(path, libraryRoots) {
    path = String(path || "");
    var windows = isWindowsPath(path);
    var compare = windows ? path.toLowerCase().replace(/\\/g, "/") : path;
    var best = "";
    for (var i = 0; i < (libraryRoots || []).length; i += 1) {
      var rootPath = trimSeparators(libraryRoots[i]);
      if (!rootPath) continue;
      var rootCompare = windows ? rootPath.toLowerCase().replace(/\\/g, "/") : rootPath;
      if (compare.indexOf(rootCompare + "/") === 0 && rootPath.length > best.length) best = rootPath;
    }
    return best ? path.slice(best.length + 1) : path;
  }

  // Paths and URLs are read one folder (or URL segment) at a time, so a date
  // never spans "2019/10/3 girls.mp4". Folders that are exactly a year, month
  // and day in a row, such as 2020/12/25/, are read together.
  function extractSegmentDates(text, options, decode) {
    var segments = String(text || "").split(/([\/\\])/);
    var dates = [];
    var ambiguous = [];
    var offset = 0;
    var parts = [];
    for (var i = 0; i < segments.length; i += 1) {
      var segment = segments[i];
      if (i % 2 === 0) {
        var readable = segment;
        if (decode) {
          try { readable = decodeURIComponent(segment); } catch (err) { readable = segment; }
        }
        var result = extractDates(readable, options);
        result.dates.forEach(function (d) { dates.push(withSegment(d, offset, readable, segment)); });
        result.ambiguous.forEach(function (d) { ambiguous.push(withSegment(d, offset, readable, segment)); });
        parts.push({ text: segment, start: offset });
      }
      offset += segment.length;
    }

    var today = (options && options.today) || todayIso();
    for (var p = 0; p + 2 < parts.length; p += 1) {
      var y = parts[p].text;
      var a = parts[p + 1].text;
      var b = parts[p + 2].text;
      if (!/^\d{4}$/.test(y) || !/^\d{1,2}$/.test(a) || !/^\d{1,2}$/.test(b)) continue;
      var read = readYearFirst(parseInt(a, 10), parseInt(b, 10));
      var date = read && checkedDate(parseInt(y, 10), read.month, read.day, today);
      if (!date) continue;
      var start = parts[p].start;
      var end = parts[p + 2].start + b.length;
      dates.push({ date: date, match: String(text).slice(start, end), start: start, end: end, format: read.format.replace(/-/g, "/") + " folders" });
    }
    dates.sort(function (x, z) { return x.start - z.start; });
    return { dates: dates, ambiguous: ambiguous };
  }

  // Positions refer to the original text; a decoded URL segment is shown as
  // its whole segment, since decoding changes lengths.
  function withSegment(item, offset, readable, segment) {
    var ret = {};
    for (var key in item) ret[key] = item[key];
    if (readable === segment) {
      ret.start = item.start + offset;
      ret.end = item.end + offset;
    } else {
      ret.start = offset;
      ret.end = offset + segment.length;
      ret.decoded = readable;
    }
    return ret;
  }

  function list(value) {
    if (!value) return [];
    return Array.isArray(value) ? value : [value];
  }

  // One shape for scenes and images, from either GraphQL row.
  function normalizeItem(type, row) {
    row = row || {};
    var files = type === "scene" ? row.files : row.visual_files;
    var paths = list(files).map(function (file) { return file && file.path; }).filter(Boolean);
    var thumbnail = row.paths ? (type === "scene" ? row.paths.screenshot : row.paths.thumbnail) : "";
    return {
      type: type,
      id: String(row.id),
      title: row.title || "",
      details: row.details || "",
      code: row.code || "",
      urls: list(row.urls).filter(Boolean),
      date: row.date || "",
      organized: !!row.organized,
      paths: paths,
      thumbnail: thumbnail || "",
      studio: row.studio && row.studio.name ? row.studio.name : "",
    };
  }

  function displayName(item) {
    if (item.title) return item.title;
    if (item.paths.length) return item.paths[0].split(/[\/\\]/).pop();
    return (item.type === "scene" ? "Scene" : "Image") + " #" + item.id;
  }

  function sourceEnabled(options, source) {
    var sources = options && options.sources;
    return !sources || sources[source] !== false;
  }

  // Every date in the item's enabled sources, then one proposal: a single
  // date all sources agree on, a conflict between several, or none.
  function proposeDate(item, options) {
    options = options || {};
    var candidates = [];
    var ambiguous = [];

    function collect(source, value, result, shown) {
      result.dates.forEach(function (d) {
        candidates.push({ date: d.date, source: source, value: shown, match: d.decoded || d.match, start: d.start, end: d.end, format: d.format, decoded: !!d.decoded });
      });
      result.ambiguous.forEach(function (d) {
        ambiguous.push({ source: source, value: shown, match: d.decoded || d.match, start: d.start, end: d.end, reason: d.reason });
      });
    }

    if (sourceEnabled(options, "path")) {
      item.paths.forEach(function (path) {
        var relative = relativePath(path, options.libraryRoots);
        var result = extractSegmentDates(relative, options, false);
        var offset = path.length - relative.length;
        result.dates.forEach(function (d) { d.start += offset; d.end += offset; });
        result.ambiguous.forEach(function (d) { d.start += offset; d.end += offset; });
        collect("path", path, result, path);
      });
    }
    if (sourceEnabled(options, "title") && item.title) collect("title", item.title, extractDates(item.title, options), item.title);
    if (sourceEnabled(options, "details") && item.details) collect("details", item.details, extractDates(item.details, options), item.details);
    if (sourceEnabled(options, "code") && item.code) collect("code", item.code, extractDates(item.code, options), item.code);
    if (sourceEnabled(options, "url")) {
      item.urls.forEach(function (url) {
        // Skip the scheme and host: they hold no dates, only digits.
        var host = String(url).match(/^[a-z][a-z0-9+.-]*:\/\/[^\/?#]*/i);
        var offset = host ? host[0].length : 0;
        var result = extractSegmentDates(String(url).slice(offset), options, true);
        result.dates.forEach(function (d) { d.start += offset; d.end += offset; });
        result.ambiguous.forEach(function (d) { d.start += offset; d.end += offset; });
        collect("url", url, result, url);
      });
    }

    var groups = [];
    var byDate = Object.create(null);
    candidates.forEach(function (candidate) {
      if (!byDate[candidate.date]) {
        byDate[candidate.date] = { date: candidate.date, candidates: [] };
        groups.push(byDate[candidate.date]);
      }
      byDate[candidate.date].candidates.push(candidate);
    });
    groups.sort(function (a, b) { return b.candidates.length - a.candidates.length || (a.date < b.date ? -1 : 1); });

    var status = "none";
    if (groups.length > 1) status = "conflict";
    else if (groups.length === 1) status = groups[0].date === item.date ? "unchanged" : "proposed";

    return {
      item: item,
      status: status,
      proposedDate: status === "proposed" ? groups[0].date : null,
      dates: groups,
      ambiguous: ambiguous,
    };
  }

  function escapeRegex(value) {
    return String(value).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&");
  }

  // Files directly in or anywhere below folder. Stash matches path regexes
  // against "<folder><separator><basename>".
  function folderRegex(folder) {
    return "^" + escapeRegex(trimSeparators(folder)) + "[/\\\\]";
  }

  function mediaFilter(options, folder, lastID) {
    var filter = {};
    if (!options.includeDated) filter.date = { value: "", modifier: "IS_NULL" };
    if (options.skipOrganized) filter.organized = false;
    if (folder) filter.path = { value: folderRegex(folder), modifier: "MATCHES_REGEX" };
    if (lastID > 0) filter.id = { value: lastID, modifier: "GREATER_THAN" };
    return filter;
  }

  function call(graphql, query, variables) {
    return Promise.resolve().then(function () { return graphql(query, variables || {}); });
  }

  function loadLibraryRoots(graphql) {
    return call(graphql, QUERIES.LIBRARY_PATHS).then(function (data) {
      var stashes = data && data.configuration && data.configuration.general && data.configuration.general.stashes;
      return (stashes || []).map(function (stash) { return stash.path; }).filter(Boolean);
    });
  }

  function loadItem(graphql, type, id) {
    return call(graphql, type === "scene" ? QUERIES.FIND_SCENE : QUERIES.FIND_IMAGE, { id: String(id) }).then(function (data) {
      var row = data && (type === "scene" ? data.findScene : data.findImage);
      if (!row) throw new Error("Unable to load " + type + " #" + id);
      return normalizeItem(type, row);
    });
  }

  // Pages through every matching scene or image in ID order and calls
  // onRows(items, total) for each page.
  function forEachPage(graphql, type, options, folder, onRows) {
    var query = type === "scene" ? QUERIES.FIND_SCENES : QUERIES.FIND_IMAGES;
    var filterKey = type === "scene" ? "scene_filter" : "image_filter";
    var pageSize = options.pageSize || PAGE_SIZE;
    var total = null;

    function next(lastID) {
      var variables = { filter: { per_page: pageSize, sort: "id", direction: "ASC" } };
      variables[filterKey] = mediaFilter(options, folder, lastID);
      return call(graphql, query, variables).then(function (data) {
        var result = type === "scene" ? data.findScenes : data.findImages;
        var rows = (result && (type === "scene" ? result.scenes : result.images)) || [];
        if (total === null) total = result ? result.count : rows.length;
        onRows(rows.map(function (row) { return normalizeItem(type, row); }), total);
        var maxID = lastID;
        rows.forEach(function (row) {
          var id = parseInt(row.id, 10);
          if (id > maxID) maxID = id;
        });
        if (rows.length < pageSize) return;
        if (maxID <= lastID) throw new Error("paging " + type + "s stopped advancing after id " + lastID);
        return next(maxID);
      });
    }

    return next(0);
  }

  // Calls onRows(items, total) with the given scenes or images, one chunk of
  // IDs at a time.
  function forEachIdPage(graphql, type, ids, options, onRows) {
    var query = type === "scene" ? QUERIES.FIND_SCENES : QUERIES.FIND_IMAGES;
    var size = options.pageSize || PAGE_SIZE;
    var chain = Promise.resolve();
    for (var i = 0; i < ids.length; i += size) {
      chain = chain.then(function (chunk) {
        return function () {
          return call(graphql, query, { ids: chunk, filter: { per_page: chunk.length } }).then(function (data) {
            var result = type === "scene" ? data.findScenes : data.findImages;
            var rows = (result && (type === "scene" ? result.scenes : result.images)) || [];
            onRows(rows.map(function (row) { return normalizeItem(type, row); }), ids.length);
          });
        };
      }(ids.slice(i, i + size)));
    }
    return chain;
  }

  // Scans scenes and/or images and resolves with every proposal and conflict.
  // The scope is everything, the given folders, or only options.ids
  // ({ scene: [...], image: [...] }). onProgress receives { checked, total }
  // after each page.
  function findProposals(graphql, options, onProgress) {
    options = options || {};
    var types = [];
    var chosen = options.ids || null;
    if (chosen) {
      if (list(chosen.scene).length) types.push("scene");
      if (list(chosen.image).length) types.push("image");
      if (!types.length) return Promise.reject(new Error("Choose at least one scene or image"));
    } else {
      if (options.scenes !== false) types.push("scene");
      if (options.images !== false) types.push("image");
    }
    var folders = (options.folders || []).filter(function (folder) { return trimSeparators(folder); });
    if (options.scope === "folders" && !folders.length) return Promise.reject(new Error("Choose at least one folder"));
    var scopes = options.scope === "folders" ? folders : [null];
    var today = options.today || todayIso();
    var result = { checked: 0, proposals: [], counts: { proposed: 0, conflict: 0, unchanged: 0, none: 0 } };
    var seen = Object.create(null);
    var totals = Object.create(null);

    function progress() {
      if (!onProgress) return;
      var total = 0;
      for (var key in totals) total += totals[key];
      onProgress({ checked: result.checked, total: total });
    }

    return loadLibraryRoots(graphql).then(function (roots) {
      var proposeOptions = { today: today, libraryRoots: roots, sources: options.sources };
      var chain = Promise.resolve();
      types.forEach(function (type) {
        (chosen ? [null] : scopes).forEach(function (folder, index) {
          chain = chain.then(function () {
            var page = chosen
              ? function (onRows) { return forEachIdPage(graphql, type, list(chosen[type]).map(String), options, onRows); }
              : function (onRows) { return forEachPage(graphql, type, options, folder, onRows); };
            return page(function (items, total) {
              totals[type + ":" + index] = total;
              items.forEach(function (item) {
                var key = type + ":" + item.id;
                if (seen[key]) return;
                seen[key] = true;
                result.checked += 1;
                var proposal = proposeDate(item, proposeOptions);
                result.counts[proposal.status] += 1;
                if (proposal.status === "proposed" || proposal.status === "conflict") result.proposals.push(proposal);
              });
              progress();
            });
          });
        });
      });
      return chain;
    }).then(function () {
      return result;
    });
  }

  // Saves accepted dates: [{ type, id, date }]. Items sharing a type and date
  // are saved with one bulk update.
  function applyDates(graphql, accepted) {
    var groups = [];
    var byKey = Object.create(null);
    var invalid = (accepted || []).filter(function (entry) { return !/^\d{4}-\d{2}-\d{2}$/.test(entry.date); });
    if (invalid.length) return Promise.reject(new Error("invalid date: " + invalid[0].date));
    (accepted || []).forEach(function (entry) {
      var key = entry.type + ":" + entry.date;
      if (!byKey[key]) {
        byKey[key] = { type: entry.type, date: entry.date, ids: [] };
        groups.push(byKey[key]);
      }
      byKey[key].ids.push(String(entry.id));
    });
    var updated = [];
    var chain = Promise.resolve();
    groups.forEach(function (group) {
      chain = chain.then(function () {
        var query = group.type === "scene" ? QUERIES.UPDATE_SCENES : QUERIES.UPDATE_IMAGES;
        return call(graphql, query, { input: { ids: group.ids, date: group.date } }).then(function () {
          group.ids.forEach(function (id) { updated.push({ type: group.type, id: id, date: group.date }); });
        });
      });
    });
    return chain.then(function () { return updated; });
  }

  var api = {
    PLUGIN_ID: PLUGIN_ID,
    SOURCES: SOURCES,
    SOURCE_LABELS: SOURCE_LABELS,
    QUERIES: QUERIES,
    todayIso: todayIso,
    extractDates: extractDates,
    extractSegmentDates: extractSegmentDates,
    relativePath: relativePath,
    normalizeItem: normalizeItem,
    displayName: displayName,
    proposeDate: proposeDate,
    folderRegex: folderRegex,
    mediaFilter: mediaFilter,
    loadLibraryRoots: loadLibraryRoots,
    loadItem: loadItem,
    findProposals: findProposals,
    applyDates: applyDates,
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
  root.SceneDateProposalCore = api;
})(typeof window !== "undefined" ? window : this);
