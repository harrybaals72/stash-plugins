# Date Proposal

Date Proposal suggests a date for scenes and images from dates already written in their file paths, titles, details, studio codes, and URLs. You see each proposal, where it came from, and accept or reject it. Nothing is changed until you accept.

Version 0.1 does not remember rejections: a rejected item is proposed again the next time you search.

## Install

Install it from the package source, or copy the `scene-date-proposal` folder into your Stash plugin directory and click `Reload Plugins`. The YAML filename is `scene-date-proposal.yml`, so the plugin id is `scene-date-proposal`.

## Use

### One scene or image

Open a scene or image page and click `Propose date`. The dialog shows the item's title, current date, studio, code, files, URLs, and details, then the proposed date. Each source that gave that date is listed with the matched text highlighted and the format it was read as. `Accept` saves the date; `Reject` closes the proposal without changes. After accepting, reload the page to see the new date.

If the item already has a date, the proposal says which date it replaces. If the sources already agree with the current date, the dialog says so.

### Selected items on a scenes or images list

On the Scenes or Images list, open the `...` menu in the toolbar and choose:

- `Propose dates for selected (N)…` when you have selected items, or
- `Propose dates for this page…` when nothing is selected (every item on the current page).

The review list opens straight away, with the same Accept, Reject, and Accept all controls as below. Items that already have a date are included, since you picked them; `Change options` lets you turn that off or choose which sources to read.

### All items, or selected folders

Go to **Settings > Tasks**. Below the Library tasks is a **Date proposals** section, laid out like the stock Auto Tag and Generate tasks:

- `Propose dates…` checks every scene and image.
- `Selective propose dates…` checks only items with a file in the chosen folders and their subfolders. Type a folder path, or start from a library folder and browse, then click `Add folder`. Add as many folders as you need.

Options:

| Option | Default | Effect |
| --- | --- | --- |
| Scenes, Images | on | Which media to check. |
| Include items that already have a date | off | Also propose a date for dated items when their sources say something else. |
| Skip organized items | off | Leave organized items out. |
| Read dates from | all on | File path, title, details, studio code, and URLs. |

`Find dates` lists every proposal. Each one has `Accept` and `Reject` buttons; 50 are shown at a time. `Accept all N proposals` saves every remaining single-date proposal after you confirm. Items whose sources disagree are never included in accept all.

## Which dates are used

Only dates that can be read one way are proposed:

| Written as | Example | Read as |
| --- | --- | --- |
| Year first | `2020-12-25`, `2020.12.25`, `2020_12_25`, `2020/1/5` | year-month-day |
| Year first, middle value above 12 | `2020.25.12` | year-day-month (25 cannot be a month) |
| Year last, one value above 12 | `25.12.2020`, `12/25/2020` | the value above 12 is the day |
| Year last, day equals month | `07.07.2020` | either order gives the same date |
| Eight digits | `IMG_20201225_123456`, `SS-20201225` | YYYYMMDD |
| Month written out | `25 December 2020`, `25th of Dec, 2020`, `December 25th, 2020`, `Dec. 3, 2019`, `2020-Dec-25` | English month names and three-letter abbreviations (plus `Sept`) |
| Year, month and day folders | `/2020/12/25/` | year-month-day |

These are never used:

- `05.06.2020` and other year-last dates where both values are 12 or less; the dialog lists them as ignored, with the reason.
- Two-digit years (`25.12.20`, `201225`), and dates without a day (`December 2020`).
- Numbers separated by spaces (`2019 10 3`) or by two different separators (`2020-12/25`).
- Numbers that run on into more digits (`12020-12-25`).
- A number after `Top`, `Part`, `Vol`, `No`, `Episode`, `Chapter`, `Scene`, `Season`, `E`, `S` or `#`, as in `Top 10 May 2020`.
- Impossible dates (`2021-02-29`), dates before 1900, and dates after today.
- Two different dates in overlapping text, such as `25.12.2020.05.06`.

File paths are read from below their Stash library folder, so a library at `/media/2021-01-01` never dates every file in it. Each folder and file name is read on its own, so a date never spans `2019/10/3 girls.mp4`; only folders that are exactly a year, month, and day in a row are read together. URLs are read one path segment at a time after the host, and percent-encoded text such as `Dec%2025%2C%202020` is decoded first.

When the sources give different dates, the item is shown as a conflict with each date and its sources. You can accept one of them or reject the item.

## Test

```text
npm run stash -- test --plugin scene-date-proposal --suite unit
npm run stash -- test --plugin scene-date-proposal --suite integration
npm run stash -- test --plugin scene-date-proposal --suite ui
npm run stash -- validate --plugin scene-date-proposal
npm run stash -- build --plugin scene-date-proposal
```

Unit tests cover date reading and the proposal, paging and saving logic with a mocked GraphQL client; they do not need Stash. The integration test scans real media into a disposable Stash and runs the plugin's own queries, filters, folder scope, and bulk saves. The UI test (`tests/ui/scene-date-proposal-flows.e2e.test.js`) drives the scene, image, and Settings > Tasks dialogs in Chromium, including accept all, selective folders, and a phone-width layout. Integration and UI tests need Docker and `ffmpeg`. Set `DATE_PROPOSAL_UI_SCREENSHOTS` to a directory to keep a screenshot of each step.
