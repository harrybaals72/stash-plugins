# Scene Frame Performer Image Picker

A UI-only Stash plugin that captures a frame from the playing scene, lets you crop it, and saves the crop as the image of one of the scene's performers. It never generates or changes the scene cover.

## Use

Start the scene, then click the viewfinder button in the player's control bar (beside fullscreen) or press `Alt+I` (configurable). Playback pauses and the picker opens on the current frame. If the player is fullscreen, it exits fullscreen first.

The picker fits the screen whatever the video's shape: the frame fills the main area, the timeline sits beneath it, and the sidebar holds the result preview, crop shape, and performer.

- **Find the frame.** Use the step buttons, `,` / `.` or `←` / `→` to step one frame, and `Shift+←` / `Shift+→` or the **1s** buttons to jump a second. You can also drag the scrubber. The scrubber covers a few seconds on each side and moves with you when you step past either end. A tick marks where you opened the picker, and **Return to opening frame** jumps back there. Seeks are coalesced, so fast scrubbing shows the latest frame instead of building up a queue.
- **Frame the crop.** Drag inside the box to move it and drag a corner to resize it. Drag anywhere else on the frame to draw a new box, or click to centre the box there. Choose a shape: **9:16** (default), **2:3**, **3:4**, **1:1** or **Free**, which adds edge handles. The plugin remembers your last shape in this browser. **Fit** restores the largest centred crop of the shape. With the box focused, the arrow keys move it (hold `Shift` for larger steps) and `+` / `−` resize it.
- **Save.** A sole performer is selected automatically. Otherwise choose one. **Save** encodes only the crop. If the performer already has an image, the picker shows the current and new images side by side, and **Replace image** checks again that the stored image hasn't changed before overwriting it.

`Esc` or **Cancel** restores the opening time and play state. A successful save leaves playback paused on the chosen frame.

Frames are captured at the video's native resolution, up to 4096 px. Only the saved image is scaled down to the configured maximum, and it is never scaled up.

Navigation is time-based. It steps to the middle of each neighbouring frame and waits for the browser to present it, but it cannot promise an exact encoded-frame index for variable-frame-rate media. Live-transcoded streams reload on every seek, so for those the picker only captures the current frame and suggests switching to the Direct stream source. If the browser refuses to export the video (for example, a cross-origin source), the picker says so when it opens. It never falls back to a server-side capture.

## Settings

| Setting | Default | Range |
|---|---|---|
| Launch hotkey | `alt+i` | Mousetrap syntax |
| Scrubber range (seconds each side) | `5` | 0.25–30 |
| Maximum image size (long edge, px) | `1920` | 256–4096 |
| JPEG quality | `0.9` | 0.1–1.0 |

An unset or out-of-range number uses the default.

## Used by other plugins

Other UI plugins can use `window.SceneFramePerformerImage`; the Stash Bridge controllers (`touchPortalBridge`) do:

- `open()` opens the picker on the current frame, as the hotkey does.
- `quickSave({ performerId, replaceImage })` saves the current frame without the picker, centred and cropped to the last shape you used, at the configured size and quality. If the performer already has an image, nothing changes and it resolves `{ saved: false, needsConfirmation, image }`; calling again with `replaceImage` set to that `image` replaces it, unless the image changed in between, which asks again.

## Development

Managed tests use the sibling `stash-test-harness` checkout (see the repository README). Unit tests run without Docker. The integration and UI checks each start their own disposable Stash and need Docker and `ffmpeg`:

```sh
npm run test:scene-frame:unit
npm run test:scene-frame:integration
npm run test:scene-frame:ui
npm run build:packages
```

The UI check drives Chromium against landscape and portrait fixtures. It checks that every control fits the viewport at desktop and phone sizes, then covers frame navigation, crop editing, save, replace confirmation, and cancel restoring playback. Sanitized harness diagnostics are retained under `.stash-dev/harness/`. The validated baseline is Chromium with an origin-clean direct MP4. Firefox, WebKit, HLS, DASH, and unauthenticated-source combinations remain unvalidated.
