# AutoTag Extended

AutoTag Extended is a Stash plugin that adds title/details based auto tagging in two directions:

- **Performer/tag mode**: from a performer or tag page, add that one performer or tag to every scene and image whose title, details, or file path mentions it.
- **Scene/image mode**: from a scene or image page, or for the whole library from the Tasks page, add every performer and tag whose name or alias appears in the item's title, details, or file path.

It does not change stock auto tag behavior. Both modes search scene/image `title`, `details`, and file paths. Paths cover what stock auto tag skips: stock auto tag matches tag aliases in paths but not performer aliases.

## Install

Copy the `autotag-extended` folder into your Stash plugin directory, then click `Reload Plugins` in Stash.

The YAML filename is `autotag-extended.yml`, so the plugin id is `autotag-extended`.

## Use

### Performer/tag mode

Open a performer or tag page and click `Auto tag title/details`.

The modal supports:

- preview without writes
- applying to scenes
- applying to images
- matching title
- matching details
- matching file path
- matching aliases
- skipping organized media
- respecting `ignore_auto_tag`

Stash's database search finds candidate items in one query per media type, covering the name, every alias, and every enabled field at once. Each candidate is then confirmed with the same matcher scene/image mode uses, so both modes apply identical rules, including the file path rules below. Unlike scene/image mode, all aliases are used here, including single-word ones and ones shared with another performer or tag, because you chose this performer or tag. Other performers and tags whose names contain one of its names are loaded too, so the longest-name rule below gives the same answer as on the scene page.

### Scene/image mode

Open a scene or image page and click `Auto tag title/details`. `Preview` lists each performer and tag that would be added and which name or alias matched. `Apply` adds them immediately; reload the page to see them.

To process the whole library, run one of these from Settings > Tasks:

- `Preview title/details auto tag for all media` writes the items that would change to the Stash log and changes nothing. The number of logged items is capped by `Preview result limit`.
- `Apply title/details auto tag to all media` updates every matching unorganized scene and image and logs each addition.

Library tasks use the options saved on the plugin's settings page. Unset options use these defaults: performers and tags on, aliases on, single-word aliases off, title, details and file path on, organized items skipped, `ignore_auto_tag` respected.

The task also accepts explicit items, for scripts and other plugins:

```json
{ "mode": "preview", "targetType": "media", "sceneIds": ["12", "13"], "imageIds": ["40"] }
```

How it works: the task loads every performer and tag once, indexes each name and alias by its words, then reads each item's title and details and looks up runs of consecutive words in that index. The time per item depends on the length of its text, not on how many performers and tags exist. Measured on a test library of 3,000 performers, 1,500 tags (about 10,000 names and aliases) and 5,000 scenes: one scene takes about 0.65 s, almost all of it loading the names; the whole library takes about 6 s to preview and 20 s to apply.

Matching uses the same rule as performer/tag mode: a multi-word name may be separated by spaces, `.`, `-` or `_`, and must not be part of a longer word. Case and Unicode composition (e.g. `é` typed as one or two characters) are ignored, and full-width characters match their normal forms (`ＭＩＳＡＫＩ` matches `Misaki`; the ideographic space `　` counts as a space). A standalone symbol inside a name is matched literally: `Rock & Roll` matches `Rock & Roll` but not `Rock Roll`.

Chinese and Japanese names match only when something separates them from the surrounding text: a space, punctuation such as `【】「」・`, or the start or end of the text. `美咲` matches `【美咲】新作` and `美咲 新作`, but not `美咲の新作`, because these languages do not put spaces between words. Stock auto tag has the same limitation.

File paths use stock auto tag's rule instead, which also accepts names written without separators: `Jane Doe` matches `JaneDoe.mp4`, `jane.doe-01.mp4` and a `Jane Doe/` folder, but not `JanetDoe.mp4` or `Jane/Doe.mp4`. Every file of a scene or image is checked. The path is matched from below its Stash library folder, so library locations such as `/data/videos` never match a `Videos` tag, and the file extension is ignored.

Guards against wrong matches:

- **The longest name wins.** A name inside a longer matched name is not added: in `Eva Elfie solo`, performer "Eva Elfie" is added but performer "Eva" is not. This applies across performers and tags, and the longer name counts even if it is not applied (ignored, switched off, or ambiguous).
- **Single-word aliases are skipped** unless `Match single-word aliases` is enabled. Initials do not count as words, so `J.Lo` and `T-Bone` are single-word aliases. Primary names are always used.
- **Ambiguous names are skipped.** A name or alias shared by two performers, or by two tags, is not applied, and the result lists it. Names that differ only in separators, such as `Jane Doe` and `Jane-Doe`, count as shared. In paths, `Jane Doe` and `Janedoe` also count as shared.
- Performers and tags with `ignore_auto_tag` are skipped while `Respect ignore auto tag` is on.
- Existing performers and tags are kept; the plugin only adds. Each update adds links in one database transaction instead of rewriting the item's list, so edits made while a run is in progress are not undone.
- A run without a `mode` argument previews; it never writes unless `mode` is `apply`.

## Test

Run pure-function tests:

```text
npm run stash -- test --plugin autotag-extended --suite unit
```

These tests do not require Stash.

Run GraphQL integration and browser tests against isolated Stash instances. The browser suite includes `tests/ui/autotag-extended-flows.e2e.test.js`, which scans a real video and image and drives the performer, tag, scene, and image dialogs end to end, including a phone-width layout. Set `AUTOTAG_UI_SCREENSHOTS` to a directory to keep a screenshot of each step.

```text
npm run stash -- test --plugin autotag-extended --suite integration
npm run stash -- test --plugin autotag-extended --suite ui
```

Build and validate the deployable package:

```text
npm run stash -- validate --plugin autotag-extended
npm run stash -- build --plugin autotag-extended
```

The shared test runner builds and installs the plugin artifact, reloads Stash, creates isolated fixtures, waits for jobs, verifies GraphQL state, and cleans up. The UI suite includes a mocked `PluginApi` contract test and a live browser interaction against managed Stash. See the repository [testing guide](../../docs/testing/README.md) and [deployment guide](../../docs/deployment/README.md) for harness settings and target rollout.

## Validation checklist

Use a disposable Stash database for release checks:

- create one performer with a name and alias and one tag with a name and alias
- create unorganized scene and image records with matching title text
- create unorganized scene and image records with matching details text
- create records that already contain the performer/tag
- create organized records that match
- run preview first and confirm counts and samples
- run apply and confirm only the expected performer/tag relationships were added
- repeat with `Respect ignore auto tag` enabled and disabled
- repeat after upgrading Stash by running the unit tests and the `Compatibility check` plugin task
